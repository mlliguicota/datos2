# Claro Almacenamiento Identificacion Ip
El presente proyecto tiene como funcionalidad:
- Recibir trama UDP desde DHCP por medio del protocolo radius.
- Obtener los datos de la ip de la trama UDP.
- Guarda los datos en objetos JSON.
- Insertar los objetos JSON en ElasticSearch haciendo uso del BulkAPI.

# Instalación
Para el despligue de deben ejecutar los siguientes pasos:
 1. Instalación de dependencias.
    `npm install`
 2. Contruir el aplicativo.
   ` npm run build`
 3. Ejecutar el aplicativo.
 	`npm run start`