module.exports = {
    NODE_ENV: process.env.NODE_ENV,
    SECRET: process.env.SECRET,
    UDP_PORT: 1814,
    TCP_PORT: 3000,
    BULK_SIZE: 1,
	USER_ELASTIC: process.env.USER_ELASTIC,
	PASS_ELASTIC: process.env.PASSWORD_ELASTIC
}
