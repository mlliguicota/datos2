'use strict'

const fs = require('fs');
const {Client} = require('@elastic/elasticsearch');
const confFileDev  = ('./config/development.json');
const confFileProd = ('./config/production.json');
const conf = require('./config');
const { logger } =  require('./utils/logger.js');
let   confFile;


module.exports.elasticBulkInsert = function ( dataSource ) {

    try{

        if(!dataSource || dataSource.length === 0) {
            logger.warn('No es posible indexar origen de datos vacio');
            return;
        }

        if(!conf.NODE_ENV === "development" && !conf.NODE_ENV === "production"){
            logger.warn('La variable NODE_ENV contiene un valor invalido');
            return;
        }
    
        confFile = conf.NODE_ENV === "development" ? confFileDev : confFileProd;
    
        if (!fs.existsSync(confFile)){
            logger.warn('El archivo de configuracion no existe ' + confFile);
            return;
        }
        
        const data = fs.readFileSync(confFile);
        const config = JSON.parse(data);
    
        if (!"type" in config || !typeof config.type === "string" || !config.type in config || !typeof config[config.type]==="object") {
            logger.warn('La configuracion del archivo no tiene el formato correcto');
            return; 
        }
    
        if (!config.type == 'elastic'){
            logger.warn('El tipo de configuracion del archivo no corresponde a elastic');
            return; 
        }
    
        const conLimit = "conLimit" in config.elastic ? config.elastic.conLimit : undefined;
        const bulkSize = "bulkSize" in config.elastic ? config.elastic.bulkSize : undefined;
        const retries = "maxRetries" in config.elastic ? config.elastic.maxRetries : undefined;
        const strdate = new Date().toLocaleString(undefined, {hour12: false,});
        const usser   = conf.USER_ELASTIC;
        const pass    = conf.PASS_ELASTIC;
        const client  = new Client({
            nodes: config.elastic.nodes,
            auth: {
                username: usser,
                password: pass,
            },
            maxRetries: config.elastic.maxRetries,
        });

        try {
        client.helpers.bulk ({
            datasource: dataSource,
            onDocument(doc){
                let index = config.elastic.index;
                return{
                    index: {_index: index,
                            _id: doc.id}
                }
            },
            onDrop(doc){
                let error = {
                    type: doc.error.type,
                    reason: doc.error.reason,
                    operation: doc.operation,
                    date: strdate,
                    doc: doc.document,
                };
                logger.warn('No se pudo indexar en ElasticSearch ' + JSON.stringify(error));
                return;
            },
            flushBytes: bulkSize,
            concurrency: conLimit,
            retries: retries                      
        });
		}catch(err){
          logger.error('Error al indexar en ElasticSearch client ' + err.message);
        }
    }catch(err){
        logger.error('Error al indexar en ElasticSearch ' + err.message);
    }
}
