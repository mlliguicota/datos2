'use strict'

const { logger } = require('./utils/logger.js');
const app = require('./app');
const radius = require("radius");
const dgram = require("dgram");
const ip = require("ip");
const crypto = require("crypto");
const config = require('./config');
const elastic = require('./elastic');
const server = dgram.createSocket("udp4");
const regex = /DR:([A-F0-9]{12})/;
const regsid = [/\d+\.\d+\.([A-F0-9]+)/, /0+(ZTE[A-Z0-9]+)\s/];
const cgant_cidr = "100.64.0.0/10";
const net = require('net');
var pkt_validos = 0;
const conf = require('./config');

function procesaPaquete(packet) {
    let time = Date.now();
    let obj = { ip: {}, type: "HFC", type_accounting: '' };
    time = (time / 1000) | 0;

    //Filtrar por Acct-Status-Type
    if ("Acct-Status-Type" in packet.attributes) {
        try {
            if (packet.attributes["Acct-Status-Type"] === "Start") {
                obj.type_accounting = packet.attributes["Acct-Status-Type"];
            } else if (packet.attributes["Acct-Status-Type"] === "Stop") {
                obj.type_accounting = packet.attributes["Acct-Status-Type"];
            } else if (packet.attributes["Acct-Status-Type"] === "Interim-Update") {
                obj.type_accounting = packet.attributes["Acct-Status-Type"];
            } else {
                obj.type_accounting = packet.attributes["Acct-Status-Type"];
            }
        } catch (error) {
            logger.warn("Error en el control de excepciones Acct-Status-Type: ", error);
        }
    } else {
        obj.type_accounting = 'Default';
    }


    if ("User-Name" in packet.attributes) {
        try {
            if (packet.attributes["User-Name"].toLowerCase().length == 12 && /^[0-9A-F]+$/gi.test(packet.attributes["User-Name"].toLowerCase())) {
                logger.info('El atributo User-Name cumple los requisitos');
                obj.ip.id = packet.attributes["User-Name"].toLowerCase();
            } else {
                obj.ip.id = packet.attributes["User-Name"];
                if (packet.attributes["User-Name"] === 'f5monitor') {
                    logger.info('Paquete no procesado por origen f5monitor');
                    
                }
                else {
                    obj.ip.id = packet.attributes["User-Name"];
                }

            }
        } catch (error) {
            logger.error("Error en el control de excepciones User-Name: ", error);
        }
    } else {
        obj.ip.id = '0';
        obj.type = 'OTROS';

    }
    try {
    if ("Framed-IP-Address" in packet.attributes) {
       
            obj.ip.addr = packet.attributes["Framed-IP-Address"];
        
    } else if ("Framed-IPv6-Prefix" in packet.attributes) {
        obj.ip.addr = "0000:0000:0000:0000:0000:0000:0000:0000";
            obj.ip.version = "v6";
            obj.index = "dhcp_priv";
    }

    else {
        obj.ip.addr = "0.0.0.0";
    }
} catch (error) {
    logger.error("Error en el control de excepciones Framed-IP-Address: ", error);
    obj.ip.addr = "0.0.0.0";
}

    //Acct-Delay-Time
    try {
        if ("Acct-Delay-Time" in packet.attributes) {
          
                obj.delay_time = packet.attributes["Acct-Delay-Time"];
             
        } else {
            
        obj.delay_time = "0";
           
        }
    } catch (error) {

        logger.error("Error en el control de excepciones Acct-Delay-Time: ", error);

        obj.delay_time = "0";
    }


    function formatMacAddress(mac) {
        // Se separa la cadena en grupos de dos caracteres
        let groups = mac.match(/.{1,2}/g);

        // Se agrega el separador ":" entre cada grupo
        return groups.join(":");
    }

    //Acct-Session-Id
    if ("Acct-Session-Id" in packet.attributes) {
        try {
            const regex = /\bCHADDR:([\dA-Fa-f]{12})\b/;
            const match = packet.attributes["Acct-Session-Id"].match(regex);
            const chaddr = match[1].toLowerCase();
            // Aplicar la transformación necesaria para obtener el formato de dirección MAC
            const formattedMac = formatMacAddress(chaddr);
            obj.ip.mac = formattedMac;
        }
        catch (error) {
            // Capturar y registrar cualquier error en el control de excepciones
            logger.error("Error en el control de excepciones Acct-Session-Id: ", error);
            obj.ip.mac = "00:00:00:00:00:00";
        }
    } else {
        // Si no se encuentra el atributo Acct-Session-Id en el paquete
        obj.ip.mac = "00:00:00:00:00:00";
    }

 //Se obtiene la fecha del Acct-Session-Id y se convierte en timestamp 
 if (packet.attributes["Acct-Session-Id"]) {
    let acctSessionId = packet.attributes["Acct-Session-Id"];
    let dateParts;
    let formattedDate;

    let segundos;

    // Primera expresión regular para el formato "dd MMM yyyy hh:mm:ss"
    dateParts = acctSessionId.match(/(\d{2})\s+(\w{3})\s+(\d{4})\s+(\d{2}):(\d{2}):(\d{2})/);

    if (dateParts) {
        let months = {
            "Jan": "Jan",
            "Feb": "Feb",
            "Mar": "Mar",
            "Apr": "Apr",
            "May": "May",
            "Jun": "Jun",
            "Jul": "Jul",
            "Aug": "Aug",
            "Sep": "Sep",
            "Oct": "Oct",
            "Nov": "Nov",
            "Dec": "Dec"
        };
        let year = dateParts[3];
        let monthAbbr = dateParts[2];
        let month = months[monthAbbr];

        let day = dateParts[1];
        let hour = dateParts[4];
        let minute = dateParts[5];
        let second = dateParts[6];

        //conversión de la fecha en timestamp
        formattedDate = new Date(`${day} ${month} ${year} ${hour}:${minute}:${second}`);
        segundos = formattedDate.getTime() / 1000;

    }
    else {
        dateParts = acctSessionId.match(/(\w{3})\s+(\w{3})\s+(\d{1,2})\s+(\d{2}):(\d{2}):(\d{2})\s+(\d{4})/);
        if (dateParts) {
            let months = {

                "Jan": "Jan",
                "Feb": "Feb",
                "Mar": "Mar",
                "Apr": "Apr",
                "May": "May",
                "Jun": "Jun",
                "Jul": "Jul",
                "Aug": "Aug",
                "Sep": "Sep",
                "Oct": "Oct",
                "Nov": "Nov",
                "Dec": "Dec"
            };
            let dias = {
                "Mon": "Mon",
                "Tue": "Tue",
                "Wed": "Wed",
                "Thu": "Thu",
                "Fri": "Fri",
                "Sat": "Sat",
                "Sun": "Sun",

            }

            let year = dateParts[7];
            let monthAbbr = dateParts[2];
            let month = months[monthAbbr];
            let diaAbbr = dateParts[1];
            let dia = dias[diaAbbr];
            let day = dateParts[3];
            let hour = dateParts[4];
            let minute = dateParts[5];
            let second = dateParts[6];

            formattedDate = new Date(`${dia} ${day} ${month} ${hour}:${minute}:${second} ${year}`);
            segundos = formattedDate.getTime() / 1000;
        }
        else {
            formattedDate = "0";
        }
    }

    obj.time = segundos;
}



    if (obj.ip.addr === '0.0.0.0') {
        obj.ip.version = "v4";
        obj.index = "dhcp_priv";
    } else if (net.isIPv4(obj.ip.addr)) {
        obj.ip.version = "v4";
        if (ip.cidrSubnet(cgant_cidr).contains(obj.ip.addr)) {
            obj.index = "dhcp_cgnat";
        } else if (ip.isPrivate(obj.ip.addr)) {
            obj.index = "dhcp_priv";
        } else {
            obj.index = "dhcp_pub";
        }
    }
    //Circuit-ID
    try {
        if ("Vendor-Specific" in packet.attributes) {
            const vendorSpecificAttributes = {};
            const vendorSpecificValue = packet.attributes["Vendor-Specific"]["Incognito-Circuit-ID"];

            if (vendorSpecificValue.length > 20) {
                // Convertir el valor en ASCII
                let asciiValue = '';
                for (let i = 0; i < vendorSpecificValue.length; i += 2) {
                    asciiValue += String.fromCharCode(parseInt(vendorSpecificValue.substr(i, 2), 16));
                }
                const regex = /[0-9A-F]{16}/g;  // Expresión regular para buscar 16 caracteres hexadecimales
                const match = asciiValue.match(regex);

                if (asciiValue.indexOf(".485754") !== -1) {
                    const resultado = asciiValue.split(".485754")[1];
                    obj.ip.id = "485754" + resultado;
                    obj.type = "GPON";

                } else if (asciiValue.indexOf("ZTEG") !== -1) {
                    const resultado = asciiValue.split("ZTEG")[1].trim();

                    if (resultado.match(" ")) {
                        const subcadena = resultado.slice(0, -3);
                        obj.ip.id = "ZTEG" + subcadena;
                        obj.type = "GPON";
                    }
                }

            }
        }
    }
    catch (error) {
        logger.error("Error en el control de excepciones Circuit-ID: ", error);

    }

    if (obj.type !== 'OTROS') {

        let id = obj.index === "dhcp_pub" ? obj.ip.addr + obj.time : obj.ip.addr;
        obj.id = crypto.createHash("md5").update(id).digest("hex");
        ++pkt_validos;
        return obj;
    }
    else {
        let time = Date.now();
        time = (time / 1000) | 0;
        let id = obj.ip.addr + time;
        obj.id = crypto.createHash("md5").update(id).digest("hex");
        ++pkt_validos;
        return obj;
    }
  }


logger.info('Configuracion de ambiente: ' + config.NODE_ENV);
let dataset = [];

server.on("message", function (msg, rinfo) {
    try {
        logger.info('-');
        logger.info('-');
        logger.info('CESAR SANCHEZ - INICIO DE ACTUALIZACION------------------------------------------------------------------------------------');
        logger.info("Rinfo address: " + rinfo.address);
        logger.info("Rinfo puerto: " + rinfo.port);
        logger.info("secret: " + config.SECRET);
        logger.info("fecha cambio 17/06/2024");
        logger.info('CESAR-PRUEBAS 1-VER EL MENSAJE: ' + msg);//SUD CS. ACTULIZADO

        let packet;
        let elasticObj;

        logger.info('CESAR-PRUEBAS 2-VER LA VARIABLE LET PAQUETE: ' + packet);//SUD CS. ACTULIZADO
        logger.info('CESAR-PRUEBAS 3-VER LA VARIABLE LET ELASTICOBJ: ' + elasticObj);//SUD CS. ACTULIZADO

        logger.info('-');
        logger.info('-');
        
        logger.info('VALIDACION 1:');
        logger.info('--TRY - CATCH DECODIFICACIÓN DEL PAQUETE RADIUS:');
        logger.info('CESAR-ENTRANDO en la decodificación del paquete RADIUS');//SUD CS. ACTULIZADO
        //try - catch Decodificación del paquete RADIUS:
        try {
            radius.add_dictionary('./incognito-radius.dictionary');
            logger.info('------------------------------------------------------------------------------------');//SUD CS. ACTULIZADO
            
            packet = radius.decode({ packet: msg, secret: config.SECRET });
            
            logger.info('---PAQUETE YA DECODIFICADO: '+ packet);//SUD CS. ACTULIZADO
            logger.info('---ELASTICOBJ YA DECODIFICADO: '+ elasticObj);//SUD CS. ACTULIZADO
            logger.info('------------------------------------------------------------------------------------');//SUD CS. ACTULIZADO

        } catch (error) {
            logger.error('Error durante la decodificación del paquete RADIUS: ' + error.toString());
        }

        logger.info('CESAR-SALIENDO de la decodificación del paquete RADIUS');//SUD CS. ACTULIZADO
        logger.info('--TRY - CATCH DECODIFICACIÓN DEL PAQUETE RADIUS:');

        logger.info('-');
        logger.info('-');
        
        logger.info('VALIDACION 2:');
        let response;
        logger.info('CESAR-PRUEBAS 4-VER LA VARIABLE LET RESPONSE: ' + response);//SUD CS. ACTULIZADO
        logger.info('--TRY - CATCH GENERACIÓN DE RESPUESTA RADIUS');
        logger.info('CESAR-ENTRANDO en la generación de respuesta RADIUS');//SUD CS. ACTULIZADO
        logger.info('------------------------------------------------------------------------------------');//SUD CS. ACTULIZADO
        //try - catch Generación de respuesta RADIUS:
        try {
            response = radius.encode_response({
                packet: packet,
                code: "Accounting-Response",
                secret: config.SECRET,
            });
        } catch (error) {
            logger.error('Error en la generación de respuesta RADIUS:', error.toString());
        }
        logger.info('------------------------------------------------------------------------------------');//SUD CS. ACTULIZADO
        logger.info('CESAR-SALIENDO de la generacion del paquete RADIUS');//SUD CS. ACTULIZADO
        logger.info('--TRY - CATCH GENERACIÓN DE RESPUESTA RADIUS:');

        logger.info('-');
        logger.info('-');
        
        logger.info('VALIDACION 3:');
        //try - catch Envío de la respuesta:
        try {
            logger.info('--TRY - CATCH ENVÍO DE LA RESPUESTA');
            logger.info('CESAR-ENTRANDO en el envío de la respuesta server.send');//SUD CS. ACTULIZADO
            logger.info('------------------------------------------------------------------------------------');//SUD CS. ACTULIZADO
            server.send(response, 0, response.length, rinfo.port, rinfo.address, function (err, bytes) {
                logger.info('CONDICIONAL PARA DETERMINAR SI EL ENVIO DE LA RESPUESTA DEL PAQUETE FUE EXITOSA-----------------------------------------------------------');
                if (err) {
                    if ("Framed-IP-Address" in packet.attributes) {
                        logger.warn("Error al enviar respuesta ", err.toString() + packet.attributes["Framed-IP-Address"]);
                    } else {
                        logger.warn("Error al enviar respuesta ", err.toString());
                    }
                }

                if ("Framed-IP-Address" in packet.attributes) {
                    logger.info('---Respuesta enviada con éxito IPv4  ' + packet.attributes["Framed-IP-Address"]);
                } else {
                    logger.info('---Respuesta con éxito');
                }
                logger.info('CONDICIONAL PARA DETERMINAR SI EL ENVIO DE LA RESPUESTA DEL PAQUETE FUE EXITOSA-----------------------------------------------------------');
                logger.info('-');
                logger.info('-');
                logger.info('CESAR SANCHEZ - FIN DE ACTUALIZACION------------------------------------------------------------------------------------');

            });
        } catch (error) {
            logger.error('Error durante el envío de la respuesta: ' + error.toString());
        }
        logger.info('------------------------------------------------------------------------------------');//SUD CS. ACTULIZADO
        logger.info('CESAR-SALIENDO en el envío de la respuesta server.send');
        logger.info('--TRY - CATCH ENVÍO DE LA RESPUESTA');

        logger.info('-');

        if (packet) {
            logger.info('------------------------------------------------------------------------------------');//SUD CS. ACTULIZADO
            logger.info('PAQUETE DECODIFICADO: ' + JSON.stringify(packet));

            if (packet && "code" in packet && packet.code == "Accounting-Request") {
                elasticObj = procesaPaquete(packet);

                logger.info('VALIDACION 4:');
                //try - catch Procesamiento del paquete y manejo de objetos elásticos:
                try {
                    logger.info('--TRY - CATCH DEL PROCESAMIENTO DEL PAQUETE Y MANEJO DE OBJETOS ELASTICOS');
                    logger.info('CESAR-ENTRANDO Procesamiento del paquete y manejo de objetos elásticos');//SUD CS. ACTULIZADO
                    logger.info('------------------------------------------------------------------------------------');//SUD CS. ACTULIZADO
                    elasticObj = procesaPaquete(packet);
                    if (elasticObj) {
                        logger.info('------------------------------------------------------------------------------------');//SUD CS. ACTULIZADO
                        logger.info('OBJETO PROCESADO: ' + JSON.stringify(elasticObj));
                        dataset.push(elasticObj);
                        logger.info('------------------------------------------------------------------------------------');//SUD CS. ACTULIZADO
                        logger.warn('Cantidad de paquetes válidos: ' + pkt_validos);
                        logger.warn('Cantidad de objecto actual en el bulk: ' + dataset.length);
                        logger.info('------------------------------------------------------------------------------------');//SUD CS. ACTULIZADO
                        pkt_validos = 0;
                        logger.info('-');
                        if (dataset.length === config.BULK_SIZE) {
                            elastic.elasticBulkInsert(dataset);
                            dataset = [];
                        }
                    }
                } catch (error) {
                    logger.error('Error durante el procesamiento del paquete y el manejo de objetos elásticos: ' + error.toString());
                }
                logger.info('------------------------------------------------------------------------------------');//SUD CS. ACTULIZADO
                logger.info('CESAR-SALIENDO Procesamiento del paquete y manejo de objetos elásticos');
                logger.info('--TRY - CATCH DEL PROCESAMIENTO DEL PAQUETE Y MANEJO DE OBJETOS ELASTICOS');
            } else {
                logger.warn('El paquete no contiene un code o es diferente de Accounting-Request');
            }
        } else {
            logger.warn('El paquete no fue decodificado');
        }
    } catch (err) {
        logger.error('Error en el aplicativo: ' + err.toString());
    }
});

server.on("listening", () => {
    logger.info("Servidor UDP corriendo en el puerto: " + config.UDP_PORT);
});

server.bind(config.UDP_PORT);

app.listen(config.TCP_PORT, () => {
    logger.info('Servidor TCP corriendo en el puerto: ' + config.TCP_PORT);
});