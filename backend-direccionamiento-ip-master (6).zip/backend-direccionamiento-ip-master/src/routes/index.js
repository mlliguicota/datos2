const { Router } = require('express');
const client = require('prom-client');
const router = Router();
const register = new client.Registry();

register.setDefaultLabels({
    app: 'backend-direccionamiento-ip'
});

client.collectDefaultMetrics({ register });
  
router.get('/', (req, res) => {
    res.status(200).json({status: "Working"});
});

router.get('/liveness', (req, res) => {
    res.status(200).json({status: "Liveness!"});
});

router.get('/readiness', (req, res) => {
    res.status(200).json({status: "readiness!"});
});

router.get('/metrics',  (req, res) => {
    res.setHeader('Content-Type', register.contentType);
    res.send(register.metrics());
});

module.exports = router;
  

