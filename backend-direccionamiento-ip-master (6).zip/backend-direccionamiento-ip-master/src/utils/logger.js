const {createLogger, format, transports} = require('winston');
require('winston-daily-rotate-file');
const filePath      = '../log/'
const fileName      = 'radius-app';
const fileExtension = '.log';
const currentDate   = new Date();
const currentYear   = currentDate.getFullYear();
const currentMonth  = String(currentDate.getMonth() + 1).padStart(2, '0');
const currentDay    = String(currentDate.getDate()).padStart(2, '0');

module.exports.logger = createLogger({
    format:  format.combine(
        format.timestamp({
            format: 'YYYY-MM-DD HH:mm:ss'
        }),
        format.colorize(),
        format.printf(info => `${info.timestamp} [${info.level}]: ${info.message}`)
    ), 
    transports: [
        new transports.DailyRotateFile({
            dailyrotate: true,
			level:'warn',
            filename: filePath + fileName + '%DATE%' + fileExtension,
            datePattern: 'YYYY-MM-DD', 
            maxSize: '25m',
			maxFiles: '3'
                     
        }),
		new transports.Console({
        })
    ], exitOnError: false
});