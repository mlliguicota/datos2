import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminGuard } from './core/guards/admin.guard';
import { ConsultaGuard } from './core/guards/consulta.guard';
import { InsertorGuard } from './core/guards/insertor.guard';
import { LogoutGuard } from './core/guards/logout.guard';
import { RolesGuard } from './core/guards/roles.guard';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'auth',
  },
  {
    path: 'auth',
    loadChildren: () => import('./modules/auth/auth.module')
        .then((m) => m.AuthModule),
    canActivate: [LogoutGuard],
  },
  {
    path: 'principal',
    loadChildren: () => import('./principal/principal.module')
        .then((m) => m.PrincipalModule),
    canActivate: [InsertorGuard],
  },
  {
    path: 'admin',
    loadChildren: () => import('./modules/admin/admin.module').then((m) => m.AdminModule),
    canActivate: [AdminGuard],
  },
  {
    path: 'consulta',
    loadChildren: () => import('./modules/consulta/consulta.module').then((m) => m.ConsultaModule),
    canActivate: [ConsultaGuard],
  },
  {
    path: 'roles',
    loadChildren: () => import('./modules/roles/roles.module')//creacion de la ruta para la aplicacion Campaña 9/5/2024
        .then((m) => m.rolesModule),
    canActivate: [RolesGuard],
  },
  {
    path: '**',
    redirectTo: 'auth',
  },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
