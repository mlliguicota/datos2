export enum TipoOficina{
    Edificio
}