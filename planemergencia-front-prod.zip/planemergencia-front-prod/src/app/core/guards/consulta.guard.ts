import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root',
})
export class ConsultaGuard implements CanActivate {
  constructor(private authService: AuthService,
    private router: Router) {

  }
  canActivate() {
    if (this.authService.getIsAuth()&&(
    this.authService.getRolUsuario().nombre=='Consultor'||
    this.authService.getRolUsuario().nombre=='ConsultMas')||
    this.authService.getRolUsuario().nombre=='Administrador') {
      return true;
    } else if (!this.authService.getIsAuth()) {
      this.router.navigateByUrl('/auth/login');
      return false;
    } else {
      return false;
    }
  }
}
