import { TestBed } from '@angular/core/testing';

import { InsertorGuard } from './insertor.guard';

describe('AuthGuard', () => {
  let guard: InsertorGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(InsertorGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
