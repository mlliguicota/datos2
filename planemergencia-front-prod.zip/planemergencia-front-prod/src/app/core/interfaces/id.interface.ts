export interface ID {
    codigo:          number;
    cprLicencCodigo: number;
}