import { ID } from "./id.interface";
import { IPlanta } from "./planta.interface";
import {TipoOficina} from "../enums/tipoOficina.enum"

export interface ILocationWP {
    //Mandatory
    id:                     ID,
    tipoOfcina:             string,
    nombreOficina:                string,
    telefono:               string,
    fax:                    string,
    correo:                 string,
    actividadEmpresa:       string,
    procesos:               string,

    //not
    razonSocial?:            string,
    edificacion?:            string,
    ciudad?:                 string,
    provincia?:              string,
    direccion?:              string,

    plantas:                 IPlanta[],

    cantidadPoblacion:       number,
    evacuacionOficina:       number,
    //Files
    fachada:                 File[],
    geoubicacion:            File[],

}