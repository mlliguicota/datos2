import { ID } from "./id.interface";

export interface IPlanta{
    id:                 ID;
    nivel:              string,
    areaTotal:          number,
    areaUtil:           number,
    totalHombres:       number,
    totalMujeres:       number,
    totalEmpleados:     number,
    servicios:          number,
    visitantes:         number,
}