import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { GenService } from './gen.service';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private URL_AUTH = environment.BASE_URL_JWT + environment.AUTH_URL;
  private URL_REFT = environment.BASE_URL_JWT + environment.REFT_URL;
  private tokenStr = environment.tokenStr;
  private token: string = '';
  private isAuth: boolean = false;
  private usuarioData: any;
  private rolUsuario:any;
  constructor(public http: HttpClient,
    private router: Router,
    private gen: GenService) { }
  getToken(): string {
    //console.log('TOKEN:', this.token);
    return this.token;
  }
  getIsAuth(): boolean {
    return this.isAuth;
  }
  postLogin(user: any) {
    return this.http.post(this.URL_AUTH, user);
  }
  getUsuarioData() {
    return this.usuarioData;
  }
  getRolUsuario() {
    return this.rolUsuario;
  }

  login(user: string, pass: string) {
    const formData: FormData = new FormData();
    formData.append('user', user);
    formData.append('pass', pass);
    const json = {
      'user': user,
      'pass': pass,
    };

    return new Promise((resolve) => {
      this.postLogin(json)
        .subscribe({
          next: (res: any) => {
            console.log(res);

            if (res != null) {
              sessionStorage.setItem(this.tokenStr, res.token);
              this.token = res.token;
              console.log('TOKEN!!!: ');
              console.log(res.token);
              this.isAuth = true;
              const data = { resCode: 0 };
              resolve(data);
            }
          },
          error: (err: { status: number; error: { error_description: any; }; }) => {
            let e;
            if (err.status === 400) {
              e = err.error.error_description;
            } else if (err.status == 403) {
              e = 'Credenciales incorrectas, intente de nuevo';
            } else {
              e = 'Las credenciales son incorrectas o el servicio' +
                ' no esta disponible por el momento, ' +
                'intente de nuevo mas tarde';
            }
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        },
        );
    });
  }
  logout() {
    this.token = '';
    this.isAuth = false;
    sessionStorage.clear();
    this.router.navigateByUrl('/auth/login');
  }
  obtenerUsuarioData(name: string) {
    return new Promise((resolve) => {
      this.gen.getUsuarios(name)
        .subscribe({
          next: async (res: any) => {
            if (res != null) {
              console.log('Imprimiendo usuario');
              console.log(res.pageContent[0]);

              sessionStorage.setItem('userData',
                JSON.stringify(res.pageContent[0]));

              this.usuarioData = res.pageContent[0];
              await this.obtenerRol(this.usuarioData.codigoRol);

              const data = { resCode: 0 };
              resolve(data);
            }
          },
          error: (err: any) => {
            const e = 'Error al intentar cargar los datos del usuario';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        },
        );
    });
  }

  generateRefreshToken() {
    const headers = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization':
        'Bearer ' + this.token,
    });
    return this.http.get(this.URL_REFT, {
      headers,
    });
  }
  refreshToken(token: any) {
    this.token = token;
    sessionStorage.setItem(this.tokenStr, token);
  }
  manageRefreshPage() {
    const token = sessionStorage.getItem(this.tokenStr);
    //console.log(token);
    if (token != null) {
      this.token = token;
      this.isAuth = true;
      this.usuarioData = JSON.parse(sessionStorage.getItem('userData')+'');
      this.rolUsuario= JSON.parse(sessionStorage.getItem('userRol')+'');
    }
  }
  private obtenerRol(codigoRol:number) {
    return new Promise((resolve)=>{
      this.gen.getRol(codigoRol).subscribe({
        next: (res:any)=>{
          if (res != null) {
            console.log('Rol usuario: ', res.pageContent[0]);

            sessionStorage.setItem('userRol',
              JSON.stringify(res.pageContent[0]));
            this.rolUsuario = res.pageContent[0];
            const data = { resCode: 0 };
            resolve(data);
          }
        },
        error: (err: any) => {
          console.log(err);
          const e = 'Error al intentar cargar el rol del usuario';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    });
  }
}
