import { TestBed } from '@angular/core/testing';

import { EmeService } from './eme.service';

describe('EmeService', () => {
  let service: EmeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
