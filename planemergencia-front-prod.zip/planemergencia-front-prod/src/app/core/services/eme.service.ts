import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { INivel } from
  'src/app/modules/plan-de-emergencia/core/interfaces/nivel.interface';
import { IUsuario } from
  'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class EmeService {
  private URL_GENN=environment.BASE_URL_EME + environment.GENN_URL;
  private URL_GENNV=environment.BASE_URL_EME + environment.GENNV_URL;

  constructor(public http:HttpClient) { }
  getNiveles(codigoEmpresa:number, codigoOficina:number) {
    const params={
      codigoEmpresa: codigoEmpresa,
      codigoOficina: codigoOficina,
    };
    return this.http.get(this.URL_GENN, {params});
  }
  postNiveles(niveles:INivel[], user: IUsuario) {
    const body=[];
    for (const nivel of niveles) {
      const subBody={
        estado: 'A',
        nombreEquipo: user.usuario,
        usuarioIngreso: user.usuario,
        codigoOficina: nivel.codigoOficina,
        codigoEmpresa: nivel.codigoEmpresa,
        numeroPiso: nivel.numeroPiso,
        descripcion: nivel.nivel,
        areaTotal: nivel.areaTotal,
        areaUtil: nivel.areaUtil,
        totalHombres: nivel.totalHombres,
        totalMujeres: nivel.totalMujeres,
        totalEmpleadosPiso: nivel.totalEmpleados,
        serviciosComplementarios: nivel.servicios,
        visitantes: nivel.visitantes,
      };
      body.push(subBody);
    }

    return this.http.post(this.URL_GENNV, body);
  }
  putNiveles(niveles:INivel[], user: IUsuario) {
    const body=[];
    for (const nivel of niveles) {
      const subBody={
        codigo: nivel.id,
        estado: 'A',
        nombreEquipo: user.usuario,
        usuarioModificacion: user.usuario,
        codigoOficina: nivel.codigoOficina,
        codigoEmpresa: nivel.codigoEmpresa,
        numeroPiso: nivel.numeroPiso,
        descripcion: nivel.nivel,
        areaTotal: nivel.areaTotal,
        areaUtil: nivel.areaUtil,
        totalHombres: nivel.totalHombres,
        totalMujeres: nivel.totalMujeres,
        totalEmpleadosPiso: nivel.totalEmpleados,
        serviciosComplementarios: nivel.servicios,
        visitantes: nivel.visitantes,
      };
      body.push(subBody);
    }
    return this.http.put(this.URL_GENNV, body);
  }
  deleteNiveles(niveles:INivel[], user: IUsuario) {
    const body=[];
    for (const nivel of niveles) {
      const subBody={
        codigo: nivel.id,
        estado: 'N',
        nombreEquipo: user.usuario,
        usuarioBaja: user.usuario,
        usuarioModificacion: user.usuario,
        codigoOficina: nivel.codigoOficina,
        codigoEmpresa: nivel.codigoEmpresa,
        numeroPiso: nivel.numeroPiso,
        descripcion: nivel.nivel,
        areaTotal: nivel.areaTotal,
        areaUtil: nivel.areaUtil,
        totalHombres: nivel.totalHombres,
        totalMujeres: nivel.totalMujeres,
        totalEmpleadosPiso: nivel.totalEmpleados,
        serviciosComplementarios: nivel.servicios,
        visitantes: nivel.visitantes,
      };
      body.push(subBody);
    }
    return this.http.put(this.URL_GENNV, body);
  }
}
