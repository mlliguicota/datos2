import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';
import { IOficina } from 'src/app/modules/plan-de-emergencia/core/interfaces/oficina.interface';
import { ITipoOficina } from 'src/app/modules/plan-de-emergencia/core/interfaces/tipoOficina.interface';
import { IUsuario } from 'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class GenService {
  private URL_GENU = environment.BASE_URL_GEN + environment.GENU_URL;
  private URL_GENP = environment.BASE_URL_GEN + environment.GENP_URL;
  private URL_GENO = environment.BASE_URL_GEN + environment.GENO_URL;
  private URL_GENR= environment.BASE_URL_GEN+ environment.GENR_URL;
  private URL_GETO= environment.BASE_URL_GEN+ environment.GENTO_URL;
  private URL_GENOIO= environment.BASE_URL_GEN+ environment.GENOIO_URL;
  constructor(public http: HttpClient,
    public router: Router) { }

  getUsuarios(name: string) {
    const params = {
      usuario: name,
    };
    return this.http.get(this.URL_GENU, { params });
  }
  getOficinas(codigoTipoOficina: number) {
    const params = {
      codigoTipoOficina: codigoTipoOficina,
    };
    return this.http.get(this.URL_GENO, { params });
  }

  getOficinaNombre(nombre: string) :Observable<any>  {
    const params = {
      nombreOficina: nombre,
    };
    return this.http.get<any>(this.URL_GENO, { params });
  }
  getTiposOficinas() {
    return this.http.get(this.URL_GETO);
  }
  getTiposOficinasInformacion() {
    return this.http.get(this.URL_GENOIO);
  }
  putOficina(ofi: IOficina, user:IUsuario) {
    const body = {
    nombreEquipo: user.usuario,
      estado: 'A',
      usuarioModificacion: user.usuario,
      id: {
        codigo: ofi.id.codigo,
        codigoEmpresa: ofi.id.codigoEmpresa??1,
      },
      nombreOficina: ofi.nombreOficina,
      codigoTipoOficina: ofi.codigoTipoOficina,
      telefono: ofi.telefono,
      fax: ofi.fax,
      actividadEmpresa: ofi.actividadEmpresa,
      correo: ofi.correo,
      procesosOficina: ofi.procesosOficina,
      rutaFachada: ofi.rutaFachada,
      rutaGeoubicacion: ofi.rutaUbicacion,
      poblacionTrabajadora: ofi.poblacionTrabajadora,
      rutasEvacuacion: ofi.rutasEvacuacion,
    };
    console.log('Body: ', body);
    return this.http.put(this.URL_GENO, body);
  }
  crearOficina(ofi: IOficina, user:IUsuario, tipoOficina:number) :Observable<any> {
    const body = {
        nombreEquipo: user.usuario,
        estado: 'A',
        usuarioIngreso: user.usuario,
        id: {
          codigoEmpresa: 1,
        },
        nombreOficina: ofi.edificacionOficina,

        codigoTipoOficina: tipoOficina,
        telefono: ofi.telefono,
        fax: ofi.fax,
        actividadEmpresa: ofi.actividadEmpresa,
        correo: ofi.correo,
        procesosOficina: ofi.procesosOficina,
        rutaFachada: ofi.rutaFachada,
        rutaGeoubicacion: ofi.rutaUbicacion,
        poblacionTrabajadora: ofi.poblacionTrabajadora,
        rutasEvacuacion: ofi.rutasEvacuacion,
      };
      console.log('Body: ',JSON.stringify(body));
      console.log('Body: ',JSON.parse(JSON.stringify(body)));
    return this.http.post<any>(this.URL_GENO, body);
  }
  getRol(codigoRol:number) {
    const params = {
      CODIGO: codigoRol,
    };
    return this.http.get(this.URL_GENR, { params });
  }


  // It is not finished
  getPermisos(codigoRol: string) {
    // MAKE THE REST
    return this.http.get(this.URL_GENP, {});
  }
}
