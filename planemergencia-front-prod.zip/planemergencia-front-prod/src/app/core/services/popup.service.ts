import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PopupService {
  private sharingPopUpObservable: BehaviorSubject<Boolean>=new BehaviorSubject<Boolean>(false);

  get SharingPopUpObservable():Observable<Boolean>{
    return this.sharingPopUpObservable.asObservable();
  }
  set SharingPopUpObservableData(data: Boolean){
    this.sharingPopUpObservable.next(data);
  }
}
