import { Injectable } from '@angular/core';
import { MessageService } from 'primeng/api';
import * as uuid from 'uuid';
@Injectable({
  providedIn: 'root',
})
export class ToastService {
  private tiempo = 3500;
  private key = 'my1stKey';

  constructor(private messageService: MessageService) { }

  mostrarToastError(mensaje: string, key?: string): void {
    this.messageService.add({
      severity: 'error',
      summary: 'Error',
      detail: mensaje,
      life: this.tiempo,
      key: key ? key : this.key,
    });
  }

  mostrarToastInfo(mensaje: string, key?: any): void {
    this.messageService.add({
      severity: 'info',
      summary: 'Información',
      detail: mensaje,
      life: this.tiempo,
      key: key ? key : this.key });
  }

  mostrarToastSuccess(mensaje: string, key?: any): void {
    this.messageService.add({
      severity: 'success',
      summary: 'Éxito',
      detail: mensaje,
      life: this.tiempo,
      key: key ? key : this.key });
  }

  mostrarConfirmacion(pregunta: string, data?: any, key?: any): void {
    this.messageService.clear();
    this.messageService.add({
      key: key ? key : 'c',
      sticky: true,
      severity: 'warn',
      summary: pregunta,
      detail: 'Confirma para proceder',
      data });
  }
  genToastKey() {
    return uuid.v4();
  }

  clear(): void {
    this.messageService.clear();
  }
}
