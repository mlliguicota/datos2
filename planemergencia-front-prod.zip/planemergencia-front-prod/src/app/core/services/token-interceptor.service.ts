import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from
  '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, switchMap, filter, take, timeout } from 'rxjs/operators';
import { Observable, throwError, BehaviorSubject} from 'rxjs';
import { AuthService } from './auth.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class TokenInterceptorService implements HttpInterceptor {
  private tiempoSolicitud = 1000; // 15000
  private isRefreshing = false;
  private refreshTokenSubject: BehaviorSubject<any> =
    new BehaviorSubject<any>(null);

  constructor(private authService: AuthService,
    private router: Router) { }
  intercept(req: HttpRequest<any>, next: HttpHandler):
    Observable<HttpEvent<any>> {
    if ( req.url != environment.loginUrl) {
      if (this.authService.getToken()) {
        //console.log('DENTRO DEL INTENTO DE INTERCEPTOR');
        req = this.addTokenHeader(req, this.authService.getToken());
      }
      return next.handle(req)
          .pipe(
              catchError((error)=>{
                console.log(error);

                if (error.status === 401 ) {
                  return this.handle401Error(req, next);
                }
                return throwError(()=> error);
              }),
          );
    } return next.handle(req);
  }

  addTokenHeader(request: HttpRequest<any>, token:string) {
    return request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      },
    });
  }

  handle401Error(request: HttpRequest<any>, next: HttpHandler):
  Observable<HttpEvent<any>> {
    if (!this.isRefreshing) {
      this.isRefreshing = true;
      this.refreshTokenSubject.next(null);
      //console.log('-----Redireccionando login-----');
      this.authService.logout();
      this.router.navigate(['/auth/login'], {queryParams:
          { expired_token: 'true' }});
      return this.authService.generateRefreshToken().pipe(
          switchMap((token:any)=>{
            this.isRefreshing = false;
            this.authService.refreshToken(token.acces_token);
            this.refreshTokenSubject.next(token.access_token);
            return next.handle(this.addTokenHeader(request,
                this.authService.getToken()))
                .pipe(timeout(this.tiempoSolicitud));
          }),

      );
    } else {
      return this.refreshTokenSubject.pipe(
          filter((token) => token != null),
          take(1),
          switchMap((jwt:any) => {
            this.router.navigate(['/auth/login'], {queryParams: {
              expired_token: 'true' }});
            return next.handle(this.addTokenHeader(request, jwt))
                .pipe(timeout(this.tiempoSolicitud));
          }),
      );
    }
  }
}
