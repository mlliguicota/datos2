import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdministradorUsuarioComponent } from './pages/administrador-usuario/administrador-usuario.component';
import { MantenedorGeneralComponent } from './pages/mantenedor-general/mantenedor-general.component';
import { TitulosSubtitulosComponent } from './pages/titulos-subtitulos/titulos-subtitulos.component';
import { ContactosEmergenciaComponent } from './pages/contactos-emergencia/contactos-emergencia.component';
import { PrincipalComponent } from './pages/principal/principal.component';
import { MantenimientoPreventivoComponent } from './pages/mantenimiento-preventivo/mantenimiento-preventivo.component';
import { ContactosInstitucionesComponent } from './pages/contactos-instituciones/contactos-instituciones.component';
import { MantenedorFirmasComponent } from './pages/mantenedor-firmas/mantenedor-firmas.component';
import { MantenedorRecursosComponent } from './pages/mantenedor-recursos/mantenedor-recursos.component';
import { MantenedorOficinasComponent } from './pages/mantenedor-oficinas/mantenedor-oficinas.component';
import { MantenedorRiesgosComponent } from './pages/mantenedor-riesgos/mantenedor-riesgos.component';
import { RolesPageComponent } from '../roles/pages/roles-page/roles-page.component';
const routes: Routes = [
  {
    path: '',
    component : PrincipalComponent,
    data: {breadcrumb: 'Modulo Administrador'},
    children: [
      {
        path: 'general',
        component: MantenedorGeneralComponent
      },
      {
        path: 'administrarUsuarios',
        component: AdministradorUsuarioComponent
      },
      {
        path: 'titulosSubtitulos',
        component: TitulosSubtitulosComponent
      },
      {
        path: 'contactosEmergencia',
        component: ContactosEmergenciaComponent
      },
      {
        path: 'mantenimientoPreventivo',
        component: MantenimientoPreventivoComponent
      },
      {
        path: 'contactosInstitucion',
        component: ContactosInstitucionesComponent
      },
      {
        path: 'mantFirmas',
        component: MantenedorFirmasComponent
      },
      {
        path: 'mantRecursos',
        component: MantenedorRecursosComponent
      },
      {
        path: 'mantOficinas',
        component: MantenedorOficinasComponent
      },
      {
        path: 'mantRiesgos',
        component: MantenedorRiesgosComponent
      },
      {
        path: 'pageRoles',
        component: RolesPageComponent
      },//creacion de ruta andres Campaña 9/5/2024
      {
        path: '**',
        redirectTo: '/admin/general'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }