import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdministradorUsuarioComponent } from './pages/administrador-usuario/administrador-usuario.component';
import { AdminRoutingModule } from './admin-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { PrimeNgModule } from '../prime-ng/prime-ng.module';
import { SidebarModule } from 'primeng/sidebar';
import { MantenedorGeneralComponent } from './pages/mantenedor-general/mantenedor-general.component';
import { TitulosSubtitulosComponent } from './pages/titulos-subtitulos/titulos-subtitulos.component';
import { ContactosEmergenciaComponent } from './pages/contactos-emergencia/contactos-emergencia.component';
import { PrincipalModule } from 'src/app/principal/principal.module';
import { PrincipalComponent } from './pages/principal/principal.component';
import { MantenimientoPreventivoComponent } from './pages/mantenimiento-preventivo/mantenimiento-preventivo.component';
import { ContactosInstitucionesComponent } from './pages/contactos-instituciones/contactos-instituciones.component';
import { MantenedorOficinasComponent } from './pages/mantenedor-oficinas/mantenedor-oficinas.component';
import { MantenedorRecursosComponent } from './pages/mantenedor-recursos/mantenedor-recursos.component';
import { MantenedorFirmasComponent } from './pages/mantenedor-firmas/mantenedor-firmas.component';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToastModule } from 'primeng/toast';
import { EditorModule } from 'primeng/editor';
import { MantenedorRiesgosComponent } from './pages/mantenedor-riesgos/mantenedor-riesgos.component';
import { ConsultaModule } from '../consulta/consulta.module';
import { HazardsModule } from '../plan-de-emergencia/plan-de-emergencia.module';
import { rolesModule } from '../roles/roles.module';


@NgModule({
  declarations: [
    AdministradorUsuarioComponent,
    MantenedorGeneralComponent,
    TitulosSubtitulosComponent,
    ContactosEmergenciaComponent,
    PrincipalComponent,
    MantenimientoPreventivoComponent,
    ContactosInstitucionesComponent,
    MantenedorOficinasComponent,
    MantenedorRecursosComponent,
    MantenedorFirmasComponent,
    MantenedorRiesgosComponent
  ],
  exports : [
    AdministradorUsuarioComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    ReactiveFormsModule,
    PrimeNgModule,
    SidebarModule,
    ConfirmDialogModule,
    PrincipalModule,
    ToastModule,
    EditorModule,
    FormsModule,
    ConsultaModule,
    HazardsModule,
    rolesModule
  ]
})
export class AdminModule { }
