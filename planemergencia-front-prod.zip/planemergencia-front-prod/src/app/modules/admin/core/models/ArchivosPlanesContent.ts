import { ArchivosPlanesId } from './ArchivosPlanesId';

export class ArchivosPlanesContent {
    ip                          : string;
    nombreEquipo                : string;
    estado                      : string;
    fechaIngreso                : Date;
    fechaModificacion?          : Date;
    fechaBaja?                  : Date;
    usuarioIngreso              : string;
    usuarioModificacion?        : string;
    usuarioBaja?                : string;
    id                          : ArchivosPlanesId;
    nombre                      : string;
    ruta                        : string;
}