export class ArchivosPlanesId {
    codigo :number;
    codigoOficina:number;
    codigoEmpresa:number;
}