export class CeldaRutaEvacuacion {
    codigo : number;
    tabla  : string;
    valor  : string | number;
    fila   : number;
    columna: number;
    modificado : boolean = false;
}