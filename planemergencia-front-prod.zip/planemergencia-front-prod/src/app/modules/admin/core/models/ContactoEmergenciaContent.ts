export class ContactoEmergenciaContent {
    ip                  : string;
    nombreEquipo        : string;
    estado              : string;
    fechaIngreso        : Date;
    fechaModificacion?  : Date;
    fechaBaja?          : Date;
    usuarioIngreso      : string;
    usuarioModificacion?: string;
    usuarioBaja?        : string;
    codigo              : number;
    primerNombre        : string;
    primerApellido      : string;
    correo              : string;
    telefono            : string;
    extensionTelefono   : string;

    constructor(ip                  : string,
                nombreEquipo        : string,
                estado              : string,
                fechaIngreso        : Date,
                usuarioIngreso      : string,
                codigo              : number,
                codigoOficina       : number,
                codigoEmpresa       : number,
                primerNombre        : string,
                primerApellido      : string,
                correo              : string,
                telefono            : string,
                extensionTelefono   : string){

        this.ip                    = ip               ;
        this.nombreEquipo          = nombreEquipo     ;
        this.estado                = estado           ;
        this.fechaIngreso          = fechaIngreso     ;
        this.usuarioIngreso        = usuarioIngreso   ;
        this.codigo                = codigo           ;
        this.primerNombre          = primerNombre     ;
        this.primerApellido        = primerApellido   ;
        this.correo                = correo           ;
        this.telefono              = telefono         ;
        this.extensionTelefono     = extensionTelefono;
    }

}