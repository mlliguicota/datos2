import { ContactoOficinaId } from "./ContactoOficinaId";

export class ContactoOficinaContent {
    ip                  : string;
    nombreEquipo        : string;
    estado              : string;
    fechaIngreso        : Date;
    fechaModificacion?  : Date;
    fechaBaja?          : Date;
    usuarioIngreso      : string;
    usuarioModificacion?: string;
    usuarioBaja?        : string;
    id                  : ContactoOficinaId;

    constructor(ip                  : string,
                nombreEquipo        : string,
                estado              : string,
                fechaIngreso        : Date,
                usuarioIngreso      : string,
                id                  : ContactoOficinaId){

        this.ip                    = ip               ;
        this.nombreEquipo          = nombreEquipo     ;
        this.estado                = estado           ;
        this.fechaIngreso          = fechaIngreso     ;
        this.usuarioIngreso        = usuarioIngreso   ;
        this.id                    = id               ;
    }

}