export class ContactoOficinaId {
    codigoContacto           : number;
    codigoEmpresa            : number;
    codigoOficina            : number;
 
    constructor(codigoContacto           : number,
                codigoEmpresa            : number,
                codigoOficina            : number){
        this.codigoContacto           = codigoContacto;
        this.codigoEmpresa            = codigoEmpresa ;
        this.codigoOficina            = codigoOficina ;
    }

}