export class EmeRecursosContent {
    ip                      : string;
    nombreEquipo            : string;
    estado                  : string;
    fechaIngreso            : Date;
    fechaModificacion?      : Date;
    fechaBaja?              : Date;
    usuarioIngreso          : string;
    usuarioModificacion?    : string;
    usuarioBaja?            : string;
    codigo                  : number;
    descripcion             : string;
/*
    constructor(ip                      : string,
                nombreEquipo            : string,
                estado                  : string,
                fechaIngreso            : Date,
                usuarioIngreso          : string,
                codigo                  : number,
                descripcion             : string){

        this.ip             = ip            ;
        this.nombreEquipo   = nombreEquipo  ;
        this.estado         = estado        ;
        this.fechaIngreso   = fechaIngreso  ;
        this.usuarioIngreso = usuarioIngreso;
        this.codigo         = codigo        ;
        this.descripcion    = descripcion   ;
    }*/

}