export class EstimacionRiesgoContent {
    ip                  : string;
    nombreEquipo        : string;
    estado              : string;
    fechaIngreso        : Date;
    fechaModificacion?  : Date;
    fechaBaja?          : Date;
    usuarioIngreso      : string;
    usuarioModificacion?: string;
    usuarioBaja?        : string;
    codigo              : number;
    codigoProbabilidad  : number;
    codigoConsecuencia  : number;
    riesgo              : string;
    accion              : string;
    

}