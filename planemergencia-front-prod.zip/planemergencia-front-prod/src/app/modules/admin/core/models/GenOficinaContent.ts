import { GenOficinaId } from "./GenOficinaId"

export class GenOficinaContent {
    ip                      : string;
    nombreEquipo            : string;
    estado                  : string;
    fechaIngreso            : Date;
    fechaModificacion?      : Date;
    fechaBaja?              : Date;
    usuarioIngreso          : string;
    usuarioModificacion?    : string;
    usuarioBaja?            : string;
    id                      : GenOficinaId;
    nombreOficina           : string;
    codigoTipoOficina             : number;
    telefono                : string;
    fax                     : string;
    actividadEmpresa        : string;
    correo                  : string;
    procesosOficina         : string;
    rutaFachada             : string;
    rutaGeoubicacion        : string;
    poblacionTrabajadora    : number;
    rutasEvacuacion         : number;

    constructor(ip                      : string,
                nombreEquipo            : string,
                estado                  : string,
                fechaIngreso            : Date,
                usuarioIngreso          : string,
                id                      : GenOficinaId,
                nombreOficina           : string,
                codigoTipoOficina             : number,
                telefono                : string,
                fax                     : string,
                actividadEmpresa        : string,
                correo                  : string,
                procesosOficina         : string,
                rutaFachada             : string,
                rutaGeoubicacion        : string,
                poblacionTrabajadora    : number,
                rutasEvacuacion         : number){

        this.ip                      = ip                  ;
        this.nombreEquipo            = nombreEquipo        ;
        this.estado                  = estado              ;
        this.fechaIngreso            = fechaIngreso        ;
        this.usuarioIngreso          = usuarioIngreso      ;
        this.id                      = id                  ;
        this.nombreOficina           = nombreOficina       ;
        this.codigoTipoOficina             = codigoTipoOficina         ;
        this.telefono                = telefono            ;
        this.fax                     = fax                 ;
        this.actividadEmpresa        = actividadEmpresa    ;
        this.correo                  = correo              ;
        this.procesosOficina         = procesosOficina     ;
        this.rutaFachada             = rutaFachada         ;
        this.rutaGeoubicacion        = rutaGeoubicacion    ;
        this.poblacionTrabajadora    = poblacionTrabajadora;
        this.rutasEvacuacion         = rutasEvacuacion     ;
    }

}