export class GenOficinaId {
    codigo           : number;
    codigoEmpresa    : number;

    constructor(codigo          :number,
                codigoEmpresa   :number){
        this.codigo         = codigo;
        this.codigoEmpresa  = codigoEmpresa;
    }

}