export class GenUserContent {
    bloqueo                  :string;
    codigo                   :number;
    codigoRol                :number;
    contrasena               :string;
    estado                   :string;
    fechaBaja?               :Date;
    fechaBloqueo?            :Date;
    fechaIngreso             :Date;
    fechaModificacion?       :Date;
    ip                       :string;
    nombreEquipo             :string;
    tiempoBloqueo            :number;
    usuario                  :string;
    usuarioBaja?             :string;
    usuarioIngreso           :string;
    usuarioModificacion?     :string;
    vigenciaContrasena       :Date;
    nombres                  :string;
    apellidos                :string;

/*
    constructor(bloqueo                  :string,
                codigo                   :number,
                codigoRol                :number,
                contrasena               :string,
                estado                   :string,
                fechaIngreso             :Date,
                ip                       :string,
                nombreEquipo             :string,
                tiempoBloqueo            :number,
                usuario                  :string,
                usuarioIngreso           :string,
                vigenciaContrasena       :Date,
                nombres                  :string,
                apellidos                :string){

        this.bloqueo                  = bloqueo           ;
        this.codigo                   = codigo            ;
        this.codigoRol                = codigoRol         ;
        this.contrasena               = contrasena        ;
        this.estado                   = estado            ;
        this.fechaIngreso             = fechaIngreso      ;
        this.ip                       = ip                ;
        this.nombreEquipo             = nombreEquipo      ;
        this.tiempoBloqueo            = tiempoBloqueo     ;
        this.usuario                  = usuario           ;
        this.usuarioIngreso           = usuarioIngreso    ;
        this.vigenciaContrasena       = vigenciaContrasena;
        this.nombres                  =nombres;
        this.apellidos                = apellidos;
    }
*/
}