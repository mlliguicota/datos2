export class LideresPisoContent {
    identificacion      : string;
    primerNombre        : string;
    segundoNombre       : string;
    primerApellido      : string;
    segundoApellido     : string;
    correo              : string;
    extensionTelefonica : string;
    telefonoCelular     : string;
    usuarioSfsf         : string;
    tipoRelacion        : string;
    nombre              : string;
}

