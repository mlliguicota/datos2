import { LideresPisoContent } from "./LideresPisoContent";

export class LideresPisoExtendido extends LideresPisoContent  {
    existeEnBase : boolean;
    seleccionado : boolean;
}

