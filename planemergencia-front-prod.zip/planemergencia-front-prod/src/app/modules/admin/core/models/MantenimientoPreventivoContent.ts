export class MantenimientoPreventivoContent {
    ip                      : string;
    nombreEquipo            : string;
    estado                  : string;
    fechaIngreso            : Date;
    fechaModificacion?       : Date;
    fechaBaja?               : Date;
    usuarioIngreso          : string;
    usuarioModificacion?     : string;
    usuarioBaja?             : string;
    codigo                  : number;
    nombre                  : string;
    detalle                 : string
    
    constructor(ip                      : string,
                nombreEquipo            : string,
                estado                  : string,
                fechaIngreso            : Date,
                usuarioIngreso          : string,
                codigo                  : number,
                nombre                  : string,
                detalle                 : string){

        this.ip                      = ip            ;
        this.nombreEquipo            = nombreEquipo  ;
        this.estado                  = estado        ;
        this.fechaIngreso            = fechaIngreso  ;
        this.usuarioIngreso          = usuarioIngreso;
        this.codigo                  = codigo        ;
        this.nombre                  = nombre        ;
        this.detalle                 = detalle       ;
    }

}