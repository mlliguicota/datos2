import { MetodoInshtId } from './MetodoInshtId';

export class MetodoInshtContent {
    ip                          : string;
    nombreEquipo                : string;
    estado                      : string;
    fechaIngreso                : Date;
    fechaModificacion?          : Date;
    fechaBaja?                  : Date;
    usuarioIngreso              : string;
    usuarioModificacion?        : string;
    usuarioBaja?                : string;
    id                          : MetodoInshtId;
    codigoEstimacionRiesgo      : number;
    factoresRiesgo              : string;
}