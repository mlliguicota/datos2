export class MetodoInshtId {
    codigo          : number;
    codigoOficina   : number;
    codigoEmpresa   : number;
}