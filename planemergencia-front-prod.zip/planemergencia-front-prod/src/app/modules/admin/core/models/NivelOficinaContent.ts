export class NivelOficinaContent
{
    ip                            : string;
    nombreEquipo                  : string;
    estado                        : string;
    fechaIngreso                  : Date;
    fechaModificacion             : Date;
    fechaBaja                     : Date;
    usuarioIngreso                : string;
    usuarioModificacion           : string;
    usuarioBaja                   : string;
    codigo                        : number;
    codigoOficina                 : number;
    codigoEmpresa                 : number;
    numeroPiso                    : number;
    descripcion                   : string;
    areaTotal                     : number;
    areaUtil                      : number;
    totalHombres                  : number;
    totalMujeres                  : number;
    totalEmpleadosPiso            : number;
    serviciosComplementarios      : number;
    visitantes                    : number;
}