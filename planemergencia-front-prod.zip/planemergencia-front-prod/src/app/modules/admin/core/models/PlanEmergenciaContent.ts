import { PlanEmergenciaId } from './PlanEmergenciaId';

export class PlanEmergenciaContent {
    ip                          : string;
    nombreEquipo                : string;
    estado                      : string;
    fechaIngreso                : Date;
    fechaModificacion?          : Date;
    fechaBaja?                  : Date;
    usuarioIngreso              : string;
    usuarioModificacion?        : string;
    usuarioBaja?                : string;
    id                          : PlanEmergenciaId;
    valorMeseri                 : number;
    categoriaMeseri             : string;
    rutaMeseri                  : string;
    rutaInsht                   : string;
    rutaPuntoEncuentro          : string;
    rutaMapa                    : string;
    elaborador                  : string;
    aprobador                   : string;
    superficieAreaUtil          : string;
    puntoEncuentro              : string;
    tiempoSalida                : number;
    personasEvacuacion          : number;
    anchoSalida                 : number;
    distanciaEvacuacion         : number;
    cargoElaborador             : string;
    cargoAprobador              : string;
    otrosFactores               : string;
}