export class PlanEmergenciaId {
    codigoOficina      : number;
    codigoEmpresa      : number;

    constructor(codigoOficina          :number,
                codigoEmpresa   :number){
        this.codigoOficina         = codigoOficina;
        this.codigoEmpresa  = codigoEmpresa;
    }

}