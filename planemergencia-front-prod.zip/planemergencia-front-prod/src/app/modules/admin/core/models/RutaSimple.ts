export class RutaSimple {
    codigo      : number;
    descripcion : number;
}