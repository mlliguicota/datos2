import { RutasNivelContent } from './RutasNivelContent';
export class RutasEvacuacionContent {
    ip                  : string;
    nombreEquipo        : string;
    estado              : string;
    fechaIngreso        : Date;
    fechaModificacion?  : Date;
    fechaBaja?          : Date;
    usuarioIngreso      : string;
    usuarioModificacion?: string;
    usuarioBaja?        : string;
    codigo              : number;
    descripcion         : string;
    nivel               : RutasNivelContent[];
}