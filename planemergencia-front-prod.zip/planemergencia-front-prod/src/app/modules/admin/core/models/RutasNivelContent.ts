import { RutaSimple } from "./RutaSimple";
import { RutasNivelId } from "./RutasNivelId";

export class RutasNivelContent
{
    ip                      : string;
    nombreEquipo            : string;
    estado                  : string;
    fechaIngreso            : Date;
    fechaModificacion       : Date;
    fechaBaja               : Date;
    usuarioIngreso          : string;
    usuarioModificacion     : string;
    usuarioBaja             : string;
    id                      : RutasNivelId;
    cantidad                : 0;
    rutas                   : RutaSimple;
}