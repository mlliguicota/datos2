export class RutasNivelId {
    codigo      : number;
    codigoNivel : number;
    codigoRuta  : number;
}