export class SeccionId {
    codigo              : number;
    codigoTipoPlan      : number;

    constructor(codigo          :number,
                codigoTipoPlan   :number){
        this.codigo         = codigo;
        this.codigoTipoPlan  = codigoTipoPlan;
    }

}