import { SeccionId } from './SeccionId';

export class SeccionesContent {
    ip                          : string;
    nombreEquipo                : string;
    estado                      : string;
    fechaIngreso                : Date;
    fechaModificacion?          : Date;
    fechaBaja?                  : Date;
    usuarioIngreso              : string;
    usuarioModificacion?        : string;
    usuarioBaja?                : string;
    id                          : SeccionId;
    titulo                      : string;
    nivel                       : number;
    codigoSeccionPadre?         : number;
    codigoTipoPlanPadre?        : number;
    orden                       : number;
    texto                       : string;
    identificadorCampo          : string;

    constructor(ip                          : string,
                nombreEquipo                : string,
                estado                      : string,
                fechaIngreso                : Date,
                usuarioIngreso              : string,
                id                          : SeccionId,
                titulo                      : string,
                nivel                       : number,
                orden                       : number,
                texto                       : string,
                identificadorCampo          : string){

        this.ip                          = ip                ;
        this.nombreEquipo                = nombreEquipo      ;
        this.estado                      = estado            ;
        this.fechaIngreso                = fechaIngreso      ;
        this.usuarioIngreso              = usuarioIngreso    ;
        this.id                          = id                ;
        this.titulo                      = titulo            ;
        this.nivel                       = nivel             ;
        this.orden                       = orden             ;
        this.texto                       = texto             ;
        this.identificadorCampo          = identificadorCampo;
    }

}