export class UsuariosSfContent {
    
    identificacion: string;
    primerNombre: string;
    segundoNombre: string;
    primerApellido: string;
    segundoApellido: string;
    usuarioSfsf: string
      
}