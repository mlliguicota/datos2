import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, switchMap, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ContactoEmergenciaContent } from '../models/ContactoEmergenciaContent';
import { LideresPisoExtendido } from '../models/LideresPisoExtendido';

@Injectable({
    providedIn: 'root'
})

export class ContactoEmergenciaService {

    private EMEC_URL = environment.BASE_URL_EME + environment.EMEC_URL;
    private EMECO_URL = environment.BASE_URL_EME + environment.EMECO_URL;

    constructor(private http: HttpClient) {
    }

    getContactoEmergencia(codigo: number): Observable<any> {
        const params = {
            codigo: codigo
        };

        return this.http.get(this.EMEC_URL, { params });
    }

    getContactoEmergenciaAll(): Observable<any> {
        const params = {
            size: 300
        };

        return this.http.get(this.EMEC_URL, { params });
    }

    getContactosOficina(codigoOficina: number): Observable<any> {
        const params = {
            codigoOficina: codigoOficina
        };

        return this.http.get(this.EMECO_URL, { params });
    }

    putRequest(objetoIn: ContactoEmergenciaContent, usuarioSession: any) {
        const body = {
            ip: objetoIn.ip,
            nombreEquipo: objetoIn.nombreEquipo,
            estado: objetoIn.estado,
            fechaIngreso: objetoIn.fechaIngreso,
            fechaModificacion: new Date,
            fechaBaja: objetoIn.fechaBaja,
            usuarioIngreso: objetoIn.usuarioIngreso,
            usuarioModificacion: usuarioSession.usuario,
            usuarioBaja: objetoIn.usuarioBaja,
            codigo: objetoIn.codigo,
            primerNombre: objetoIn.primerNombre,
            primerApellido: objetoIn.primerApellido,
            correo: objetoIn.correo,
            telefono: objetoIn.telefono,
            extensionTelefono: objetoIn.extensionTelefono

        }

        console.log("Body:");
        console.log(body);

        return this.http.put<any>(this.EMEC_URL, body);
    }

    putEstadoContactoOficina(codigoContacto: number, codigoOficina: number, estado: string, usuarioModifica: string) {
        const ip = "0.0.0.0";
        const nombreEquipo = "Equipo 1";

        const body = {
            ip: ip,
            nombreEquipo: nombreEquipo,
            estado: estado,
            fechaModificacion: new Date,
            usuarioModificacion: usuarioModifica,
            id: {
                codigoContacto: codigoContacto,
                codigoEmpresa: 1,
                codigoOficina: codigoOficina
            }
        }
        return this.http.put<any>(this.EMECO_URL, body);
    }

    putEstadoContactoEmergencia(codigoContacto: number, estado: string, usuarioModifica: string) {
        const ip = "0.0.0.0";
        const nombreEquipo = "Equipo 1";

        const body = {
            ip: ip,
            nombreEquipo: nombreEquipo,
            estado: estado,
            fechaModificacion: new Date,
            usuarioModificacion: usuarioModifica,
            codigo: codigoContacto
        }
        return this.http.put<any>(this.EMEC_URL, body);
    }

    postContactoEmergencia(objetoIn: LideresPisoExtendido, usuario: string) {
        const ip = "0.0.0.0";
        const nombreEquipo = "Equipo 1";
        const body = {
            ip: ip,
            nombreEquipo: nombreEquipo,
            estado: "A",
            fechaIngreso: new Date,
            usuarioIngreso: usuario,
            primerNombre: objetoIn.primerNombre,
            primerApellido: objetoIn.primerApellido,
            correo: objetoIn.correo,
            telefono: objetoIn.telefonoCelular,
            extensionTelefono: objetoIn.extensionTelefonica
        }
        console.log("Body para crear contacto de emergencia:", body);

        return this.http.post<any>(this.EMEC_URL, body);
    }
    
        postContactoOficina(codigoContacto: number, codigoOficina: number, usuario: string) {
            const ip = "0.0.0.0";
            const nombreEquipo = "Equipo 1";
            const body = {
                ip: ip,
                nombreEquipo: nombreEquipo,
                estado: "A",
                fechaIngreso: new Date,
                usuarioIngreso: usuario,
                id: {
                    codigoContacto: codigoContacto,
                    codigoEmpresa: 1,
                    codigoOficina: codigoOficina
                }
            }
            console.log("Body para crear contacto de oficina:", body);
    
            return this.http.post<any>(this.EMECO_URL, body);
        }
}