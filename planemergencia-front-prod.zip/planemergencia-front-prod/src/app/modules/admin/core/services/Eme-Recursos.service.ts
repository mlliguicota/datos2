import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { EmeRecursosContent } from '../models/EmeRecursosContent';

@Injectable({
    providedIn: 'root'
})

export class EmeRecursosService {
    
    private EME_RECURSOS_URL = environment.BASE_URL_EME+ environment.EME_RECURSOS_URL;
    
    
    constructor(private http : HttpClient){
    }

    getRecursos() :Observable<any>{
        const params ={
            size: 100
          };
        return this.http.get(this.EME_RECURSOS_URL,{params});
    }


    editarRecurso(recursoIn : EmeRecursosContent, usuarioSession : any){
        const body = {
            ip                      : "0.0.0.0"                 ,
            nombreEquipo            : "Equipo 1"       ,
            estado                  : recursoIn.estado             ,
            fechaIngreso            : recursoIn.fechaIngreso       ,
            fechaModificacion       : new Date,
            fechaBaja               : recursoIn.fechaBaja          ,
            usuarioIngreso          : recursoIn.usuarioIngreso     ,
            usuarioModificacion     : usuarioSession.usuario,
            usuarioBaja             : recursoIn.usuarioBaja        ,
            codigo                  : recursoIn.codigo,
            descripcion             : recursoIn.descripcion
        }

        return this.http.put<any>(this.EME_RECURSOS_URL,body).subscribe({
            next: data => {
                console.log(data);
            },
            error: error => {
                console.error('There was an error!', error);
            }
        });
    }

    crearRecurso(ip               : string,
                nombreEquipo     : string,
                usuarioIngreso   : string,
                descripcion      : string,
                estado           : string) {

        const body = {
            ip                      : "0.0.0.0",
            nombreEquipo            : "Equipo 1",
            estado                  : estado,
            fechaIngreso            : new Date,
            fechaModificacion       : null,
            fechaBaja               : null,
            usuarioIngreso          : usuarioIngreso,
            usuarioModificacion     : null,
            usuarioBaja             : null ,
            codigo                  : null,
            descripcion             : descripcion
        }

        return this.http.post<any>(this.EME_RECURSOS_URL,body);
    }

}