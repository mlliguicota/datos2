import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { InstitucionEmergenciaContent } from '../models/InstitucionesEmergenciaContent';

@Injectable({
    providedIn: 'root'
})

export class InstitucionEmergenciaService{

    private EMEI_URL=environment.BASE_URL_EME+ environment.EMEI_URL;

    constructor(private http : HttpClient){
    }

    getInstitucionesEmergenciaCiudad(ciudad:string) :Observable<any>{
        const params ={
            ciudad: ciudad
        };

        return this.http.get(this.EMEI_URL, {params});
    }

    getInstitucionesEmergencia() :Observable<any>{
        const params ={
            size: 300
        };

        return this.http.get(this.EMEI_URL, {params});
    }

    editarContacto(contactoIn : InstitucionEmergenciaContent| null, usuarioSession : any){
        
        let body;

        if(contactoIn!=null){
            body = {
                ip                      : "0.0.0.0"                 ,
                nombreEquipo            : "Equipo 1"       ,
                estado                  : contactoIn.estado             ,
                fechaIngreso            : contactoIn.fechaIngreso       ,
                fechaModificacion       : new Date,
                fechaBaja               : contactoIn.fechaBaja          ,
                usuarioIngreso          : contactoIn.usuarioIngreso     ,
                usuarioModificacion     : usuarioSession.usuario,
                usuarioBaja             : contactoIn.usuarioBaja        ,
                codigo                  : contactoIn.codigo             ,
                ciudad                  : contactoIn.ciudad             ,
                institucion             : contactoIn.institucion        ,
                telefono                : contactoIn.telefono
            }
        }
        return this.http.put<any>(this.EMEI_URL,body);
    }

    crearContacto(ip               : string,
                  nombreEquipo     : string,
                  usuarioIngreso   : string,
                  ciudad           : string,
                  institucion      : string,
                  telefono         : string,
                  estado           : string) {

        const body = {
            ip                      : "0.0.0.0",
            nombreEquipo            : "Equipo 1",
            estado                  : estado,
            fechaIngreso            : new Date,
            fechaModificacion       : null,
            fechaBaja               : null,
            usuarioIngreso          : usuarioIngreso,
            usuarioModificacion     : null,
            usuarioBaja             : null ,
            codigo                  : null,
            ciudad                  : ciudad,
            institucion             : institucion,
            telefono                : telefono
        }

        return this.http.post<any>(this.EMEI_URL,body);
    }

}