import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { GenOficinaContent } from '../models/GenOficinaContent';

@Injectable({
    providedIn: 'root'
})

export class LideresPisoService {
    
    private GEN_LIDERES_PISO = environment.BASE_URL_GEN+ environment.GEN_LIDERES_PISO;
    
    
    constructor(private http : HttpClient){
    }

    getLideres(nombreOficina : string) :Observable<any>{
        const params ={
            nombre: nombreOficina
        };
        return this.http.get(this.GEN_LIDERES_PISO, {params});
    }

    getInfoByUserName(username : string) :Observable<any>{
        const params ={
            usuarioSfsf: username
        };
        return this.http.get(this.GEN_LIDERES_PISO, {params});
    }

    

    

}