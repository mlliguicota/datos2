import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MantenimientoPreventivoComponent } from '../../pages/mantenimiento-preventivo/mantenimiento-preventivo.component';
import { MantenimientoPreventivoContent } from '../models/MantenimientoPreventivoContent';

@Injectable({
    providedIn: 'root'
})

export class MantenimientoPreventivoService{
    
    private EMEM_URL=environment.BASE_URL_EME+ environment.EMEM_URL;
    
    constructor(private http : HttpClient){
    }

    getMantenimientos() :Observable<any>{
        const params ={
            size: 100
          };
        return this.http.get(this.EMEM_URL,{params});
    }

    editarMantenimiento(mantenimientoIn : MantenimientoPreventivoContent, usuarioSession : any){
        
        console.log('body del request enviado');
        console.log(mantenimientoIn);


        const body = {
            ip                      : "0.0.0.0"                 ,
            nombreEquipo            : "Equipo 1"       ,
            estado                  : mantenimientoIn.estado             ,
            fechaIngreso            : mantenimientoIn.fechaIngreso       ,
            fechaModificacion       : new Date,
            fechaBaja               : mantenimientoIn.fechaBaja          ,
            usuarioIngreso          : mantenimientoIn.usuarioIngreso     ,
            usuarioModificacion     : usuarioSession.usuario,
            usuarioBaja             : mantenimientoIn.usuarioBaja        ,
            codigo                  : mantenimientoIn.codigo             ,
            nombre                  : mantenimientoIn.nombre             ,
            detalle                 : mantenimientoIn.detalle        
        }
        console.log('body:');
        console.log(body);
        

        return this.http.put<any>(this.EMEM_URL,body).subscribe({
            next: data => {
                console.log(data);
            },
            error: error => {
                console.error('There was an error!', error);
            }
        });
    }

    crearMantenimiento(ip               : string,
                       nombreEquipo     : string,
                       usuarioIngreso   : string,
                       nombre           : string,
                       detalle          : string,
                       estado           : string) {

        const body = {
            ip                      : "0.0.0.0",
            nombreEquipo            : "Equipo 1",
            estado                  : estado,
            fechaIngreso            : new Date,
            fechaModificacion       : null,
            fechaBaja               : null,
            usuarioIngreso          : usuarioIngreso,
            usuarioModificacion     : null,
            usuarioBaja             : null ,
            codigo                  : null,
            nombre                  : nombre,
            detalle                 : detalle
        }

        return this.http.post<any>(this.EMEM_URL,body);
    }

}
