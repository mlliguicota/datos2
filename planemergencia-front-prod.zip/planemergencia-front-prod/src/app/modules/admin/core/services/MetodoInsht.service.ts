import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MetodoInshtContent } from '../models/MetodoInshtContent';

@Injectable({
    providedIn: 'root'
})

export class MetodoInshtService{
    
    private EME_METODO_INSHT_URL=environment.BASE_URL_EME+ environment.EME_METODO_INSHT_URL;

    constructor(private http : HttpClient){
    }

    getMetodoByOfiRiesgo(idOficina: number, riesgo: string) :Observable<any>{
        const params ={
            codigoOficina: idOficina,
            factoresRiesgo: riesgo
        };
        return this.http.get(this.EME_METODO_INSHT_URL, {params});
    }

    postMetodo(MetodoInshtIn : MetodoInshtContent, usuarioIngreso: string) :Observable<any>{
        let ip = "0.0.0.0";
        let nombreEquipo = 'Equipo 1';
        let body = {
            ip                      : ip,
            nombreEquipo            : nombreEquipo,
            estado                  : 'A',
            fechaIngreso            : new Date,
            usuarioIngreso          : usuarioIngreso,
            id: {
                codigoOficina  : MetodoInshtIn.id.codigoOficina,
                codigoEmpresa  : MetodoInshtIn.id.codigoEmpresa
            },
            codigoEstimacionRiesgo: MetodoInshtIn.codigoEstimacionRiesgo,
            factoresRiesgo: MetodoInshtIn.factoresRiesgo
        } 
    
               
        return this.http.post<any>(this.EME_METODO_INSHT_URL,body);
    }

    putMetodo(MetodoInshtIn : MetodoInshtContent, usuario: string) :Observable<any>{
        let ip = "0.0.0.0";
        let nombreEquipo = 'Equipo 1';
        let body = {
            ip                      : ip,
            nombreEquipo            : nombreEquipo,
            estado                  : MetodoInshtIn.estado,
            fechaIngreso            : MetodoInshtIn.fechaIngreso       ,
            fechaModificacion       : new Date,
            fechaBaja               : null,
            usuarioIngreso          : MetodoInshtIn.usuarioIngreso     ,
            usuarioModificacion     : usuario,
            usuarioBaja             : null        ,
            id: {
                codigo         : MetodoInshtIn.id.codigo,
                codigoOficina  : MetodoInshtIn.id.codigoOficina,
                codigoEmpresa  : MetodoInshtIn.id.codigoEmpresa
            },
            codigoEstimacionRiesgo: MetodoInshtIn.codigoEstimacionRiesgo,
            factoresRiesgo: MetodoInshtIn.factoresRiesgo
        } 

        return this.http.put<any>(this.EME_METODO_INSHT_URL,body);
    }
}