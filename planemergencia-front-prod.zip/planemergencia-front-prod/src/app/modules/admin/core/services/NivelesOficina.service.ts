import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { PlanEmergenciaContent } from '../models/PlanEmergenciaContent';

@Injectable({
    providedIn: 'root'
})

export class NivelesOficinaService{
    
    private EME_NIVELES_OFICINA_URL=environment.BASE_URL_EME+ environment.EME_NIVELES_OFICINA_URL;
    
    constructor(private http : HttpClient){
    }

    getRequest(codigoOficina:number) :Observable<any>{
        const params ={
            codigoEmpresa: 1,
            codigoOficina: codigoOficina
        };

        return this.http.get(this.EME_NIVELES_OFICINA_URL, {params});
    }
}
