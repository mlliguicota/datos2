import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { GenOficinaContent } from '../models/GenOficinaContent';

@Injectable({
    providedIn: 'root'
})

export class OficinaService {
    
    private GENO_URL = environment.BASE_URL_GEN+ environment.GENO_URL;
    
    
    constructor(private http : HttpClient){
    }

    getOficinas() :Observable<any>{
        const params ={
            size: 300
        };

        return this.http.get(this.GENO_URL, {params});
    }

    getOficinasByNombre(nombreOficina:string) :Observable<any>{
        let params ={
            nombreOficina: nombreOficina
        };
        return this.http.get(this.GENO_URL, {params});
    }

    getOficinaById(codigoOficina:number) :Observable<any>{
        let params ={
            codigo: codigoOficina
        };
        return this.http.get(this.GENO_URL, {params});
    }

    editarOficina(oficinaIn : GenOficinaContent, usuarioSession : any){
        const body = {
            ip                      : "0.0.0.0"                 ,
            nombreEquipo            : "Equipo 1"       ,
            estado                  : oficinaIn.estado             ,
            fechaIngreso            : oficinaIn.fechaIngreso       ,
            fechaModificacion       : new Date,
            fechaBaja               : oficinaIn.fechaBaja          ,
            usuarioIngreso          : oficinaIn.usuarioIngreso     ,
            usuarioModificacion     : usuarioSession.usuario,
            usuarioBaja             : oficinaIn.usuarioBaja        ,
            id: {
                codigo              : oficinaIn.id.codigo,
                codigoEmpresa      :  oficinaIn.id.codigoEmpresa
            },
            nombreOficina           : oficinaIn.nombreOficina       ,
            codigoTipoOficina       : oficinaIn.codigoTipoOficina   ,
            telefono                : oficinaIn.telefono            ,
            fax                     : oficinaIn.fax                 ,
            actividadEmpresa        : oficinaIn.actividadEmpresa    ,
            correo                  : oficinaIn.correo              ,
            procesosOficina         : oficinaIn.procesosOficina     ,
            rutaFachada             : oficinaIn.rutaFachada         ,
            rutaGeoubicacion        : oficinaIn.rutaGeoubicacion    ,
            poblacionTrabajadora    : oficinaIn.poblacionTrabajadora,
            rutasEvacuacion         : oficinaIn.rutasEvacuacion     
        }

        console.log('body:');
        console.log(body);
        
        return this.http.put<any>(this.GENO_URL,body).subscribe({
            next: data => {
                console.log(data);
            },
            error: error => {
                console.error('There was an error!', error);
            }
        });
    }

}