import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { PlanEmergenciaContent } from '../models/PlanEmergenciaContent';

@Injectable({
    providedIn: 'root'
})

export class PlanEmergenciaService{
    
    private EME_PLANEMERGENCIA_URL=environment.BASE_URL_EME+ environment.EME_PLANEMERGENCIA_URL;
    
    constructor(private http : HttpClient){
    }

    getRequest(codigoOficina:number) :Observable<any>{
        const params ={
            codigoEmpresa: 1,
            codigoOficina: codigoOficina
        };

        return this.http.get(this.EME_PLANEMERGENCIA_URL, {params});
    }

    putRequest(objetoIn : PlanEmergenciaContent, usuarioSession : any, accion:number){
        let body = {};
        if(accion == 1){
            body = {
                ip                      : "0.0.0.0"                 ,
                nombreEquipo            : "Equipo 1"       ,
                estado                  : objetoIn.estado             ,
                fechaIngreso            : objetoIn.fechaIngreso       ,
                fechaModificacion       : new Date,
                fechaBaja               : objetoIn.fechaBaja          ,
                usuarioIngreso          : objetoIn.usuarioIngreso     ,
                usuarioModificacion     : usuarioSession.usuario,
                usuarioBaja             : objetoIn.usuarioBaja        ,
                id: {
                    codigoOficina       : objetoIn.id.codigoOficina,
                    codigoEmpresa       : objetoIn.id.codigoEmpresa
                },
                elaborador              : objetoIn.elaborador,
                cargoElaborador         : objetoIn.cargoElaborador
            }
        }else{
            body = {
                ip                      : "0.0.0.0"                 ,
                nombreEquipo            : "Equipo 1"       ,
                estado                  : objetoIn.estado             ,
                fechaIngreso            : objetoIn.fechaIngreso       ,
                fechaModificacion       : new Date,
                fechaBaja               : objetoIn.fechaBaja          ,
                usuarioIngreso          : objetoIn.usuarioIngreso     ,
                usuarioModificacion     : usuarioSession.usuario,
                usuarioBaja             : objetoIn.usuarioBaja        ,
                id: {
                    codigoOficina       : objetoIn.id.codigoOficina,
                    codigoEmpresa       : objetoIn.id.codigoEmpresa
                },
                aprobador              : objetoIn.aprobador,
                cargoAprobador         : objetoIn.cargoAprobador
            }  
        }
        

        console.log("Body:");
        console.log(body);

        return this.http.put<any>(this.EME_PLANEMERGENCIA_URL,body);
    }

    
}
