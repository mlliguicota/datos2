import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { RiesgoContent } from '../models/RiesgoContent';

@Injectable({
    providedIn: 'root'
})

export class RiesgosService{
    
    private EME_RIESGOS_URL=environment.BASE_URL_EME+ environment.EME_RIESGOS_URL;
    private ESTIMA_RIES_URL=environment.BASE_URL_EME+ environment.ESTIMA_RIES_URL; 

    constructor(private http : HttpClient){
    }

    getRiesgos() :Observable<any>{
        return this.http.get(this.EME_RIESGOS_URL);
    }

    getEstimacionByCode(codigo: number) :Observable<any>{
        const params ={
            codigo: codigo
        };
        return this.http.get(this.ESTIMA_RIES_URL, {params});
    }

    getEstimacionRiego(probabilidad: number, consecuencia: number) :Observable<any>{
        const params ={
            codigoProbabilidad: probabilidad,
            codigoConsecuencia: consecuencia
        };
        return this.http.get(this.ESTIMA_RIES_URL, {params});
    }

    getRiesgoPorDescripcion(descripcion: string) :Observable<any>{
        const params ={
            descripcion: descripcion
        };
        return this.http.get(this.EME_RIESGOS_URL, {params});
    }

    putRiesgo(objetoIn : RiesgoContent, usuarioSession : any){
        const body = {
            ip                      : "0.0.0.0"                 ,
            nombreEquipo            : "Equipo 1"       ,
            estado                  : objetoIn.estado             ,
            fechaIngreso            : objetoIn.fechaIngreso       ,
            fechaModificacion       : new Date,
            fechaBaja               : objetoIn.fechaBaja          ,
            usuarioIngreso          : objetoIn.usuarioIngreso     ,
            usuarioModificacion     : usuarioSession.usuario,
            usuarioBaja             : objetoIn.usuarioBaja        ,
            codigo                  : objetoIn.codigo,
            tipoRiesgo              : objetoIn.tipoRiesgo,
            descripcion             : objetoIn.descripcion,
            descripcionRiesgo       : objetoIn.descripcionRiesgo
        }

        console.log("Body:");
        console.log(body);

        return this.http.put<any>(this.EME_RIESGOS_URL,body);
    }

    postRiesgo(ip                 : string,
               nombreEquipo       : string,
               usuarioIngreso     : string,
               descripcion        : string,
               descripcionRiesgo  : string,
               estado             : string) {

        let body = {};
        
        body = {
            ip                      : "0.0.0.0"                 ,
            nombreEquipo            : "Equipo 1"       ,
            estado                  : estado             ,
            fechaIngreso            : new Date       ,
            usuarioIngreso          : usuarioIngreso     ,
            tipoRiesgo              : descripcion,
            descripcion             : descripcion,
            descripcionRiesgo       : descripcionRiesgo
        }
        console.log(body);

        return this.http.post<any>(this.EME_RIESGOS_URL,body);
    }
}