import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})

export class RutasEvacuacionService{
    
    private EME_RUTAS_EVACUACION=environment.BASE_URL_EME+ environment.EME_RUTAS_EVACUACION;

    constructor(private http : HttpClient){
    }

    getMetodo(codigo: number) :Observable<any>{
        const params ={
            codigo: codigo,
        };
        return this.http.get(this.EME_RUTAS_EVACUACION, {params});
    }

    postMetodo(descripcion :string, usuarioIngreso: string) :Observable<any>{
        let ip = "0.0.0.0";
        let nombreEquipo = 'Equipo 1';
        let body = {
            ip                      : ip,
            nombreEquipo            : nombreEquipo,
            estado                  : 'A',
            fechaIngreso            : new Date,
            usuarioIngreso          : usuarioIngreso,
            descripcion             : descripcion

        } 
    
               
        return this.http.post<any>(this.EME_RUTAS_EVACUACION,body);
    }

    putDescripcionByCodigo(codigo:number, descripcion: string|number, usuario: string) :Observable<any>{
        let ip = "0.0.0.0";
        let nombreEquipo = 'Equipo 1';
        let body = {
            ip                      : ip,
            nombreEquipo            : nombreEquipo,
            fechaModificacion       : new Date,
            usuarioModificacion     : usuario,
            codigo                  : codigo,
            descripcion             : descripcion
        } 

        return this.http.put<any>(this.EME_RUTAS_EVACUACION,body);
    }

    putMetodo(codigo:number, descripcion: string, estado: string, usuario: string) :Observable<any>{
        let ip = "0.0.0.0";
        let nombreEquipo = 'Equipo 1';
        let body = {
            ip                      : ip,
            nombreEquipo            : nombreEquipo,
            estado                  : estado,
            fechaModificacion       : new Date,
            usuarioModificacion     : usuario,
            codigo                  : codigo,
            descripcion             : descripcion
        } 

        return this.http.put<any>(this.EME_RUTAS_EVACUACION,body);
    }
}