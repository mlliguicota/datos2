import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { RutasNivelContent } from '../models/RutasNivelContent';

@Injectable({
    providedIn: 'root'
})

export class RutasNivelService{
    
    private EME_RUTAS_NIVEL=environment.BASE_URL_EME+ environment.EME_RUTAS_NIVEL;
    
    constructor(private http : HttpClient){
    }

    getRequest(codigoNivel:number) :Observable<any>{
        const params ={
            codigoNivel: codigoNivel
        };

        return this.http.get(this.EME_RUTAS_NIVEL, {params});
    }

    getRequestByCodigo(codigo:number) :Observable<any>{
        const params ={
            codigo: codigo
        };

        return this.http.get(this.EME_RUTAS_NIVEL, {params});
    }

    postMetodo(rutaNivel : RutasNivelContent) :Observable<any>{
        
        let body = {id: {
                codigo       : rutaNivel.id.codigo,
                codigoNivel  : rutaNivel.id.codigoNivel,
                codigoRuta   : rutaNivel.id.codigoRuta
            },
            cantidad : rutaNivel.cantidad
        } 
    
               
        return this.http.post<any>(this.EME_RUTAS_NIVEL,body);
    }

    postRequest(codigoNivel : number, codigoRuta : number, usuario: string){
        let ip = "0.0.0.0";
        let equipo = 'Equipo 1';
        let body = {
            usuarioIngreso: usuario,
            fechaIngreso  : new Date,
            ip: ip,
            estado:'A',
            nombreEquipo: equipo,
              id: {
                codigoNivel: codigoNivel,
                codigoRuta: codigoRuta
              },
              cantidad: 0
            }
        return this.http.post<any>(this.EME_RUTAS_NIVEL,body);
    }

    putByCodigo(codigoRutaNivel: number, codigoNivel: number,codigoRuta : number,cantidad: number|string, usuario: string) :Observable<any>{
        let ip = "0.0.0.0";
        let nombreEquipo = 'Equipo 1';
        let body = {
            usuarioModificacion: usuario,
            fechaModificacion  : new Date,
            ip: ip,
            nombreEquipo: nombreEquipo,
            id: {
                codigo       : codigoRutaNivel,
                codigoNivel  : codigoNivel,
                codigoRuta   : codigoRuta
            },
            cantidad : cantidad
        } 

        return this.http.put<any>(this.EME_RUTAS_NIVEL,body);
    }

    putbyRutaNivel(rutaNivel : RutasNivelContent) :Observable<any>{
        let body = {id: {
            codigo       : rutaNivel.id.codigo,
            codigoNivel  : rutaNivel.id.codigoNivel,
            codigoRuta   : rutaNivel.id.codigoRuta
        },
        cantidad : rutaNivel.cantidad
    } 

        return this.http.put<any>(this.EME_RUTAS_NIVEL,body);
    }
}
