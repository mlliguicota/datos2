import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { SeccionesContent } from '../models/SeccionesContent';

@Injectable({
    providedIn: 'root'
})

export class SeccionesService{
    
    private EME_PLA_SECCIONES_URL=environment.BASE_URL_PLA+ environment.EME_PLA_SECCIONES_URL;
    
    constructor(private http : HttpClient){
    }

    getSeccionByProperties(nivel:number,codigoSeccionPadre:number|null) :Observable<any>{
        let params = {};

        if (codigoSeccionPadre != null ){
            params ={
                nivel: nivel,
                codigoSeccionPadre: codigoSeccionPadre
            };
        }else{
            params ={
                nivel: nivel
            };
        }

        return this.http.get(this.EME_PLA_SECCIONES_URL, {params});
    }

    putSeccion(seccionIn : SeccionesContent, usuarioSession : any){
        const body = {
            ip                      : "0.0.0.0"                 ,
            nombreEquipo            : "Equipo 1"       ,
            estado                  : seccionIn.estado             ,
            fechaIngreso            : seccionIn.fechaIngreso       ,
            fechaModificacion       : new Date,
            fechaBaja               : seccionIn.fechaBaja          ,
            usuarioIngreso          : seccionIn.usuarioIngreso     ,
            usuarioModificacion     : usuarioSession.usuario,
            usuarioBaja             : seccionIn.usuarioBaja        ,
            id: {
                codigo              : seccionIn.id.codigo,
                codigoTipoPlan      : seccionIn.id.codigoTipoPlan
            },
            titulo                  : seccionIn.titulo,
            nivel                   : seccionIn.nivel,
            codigoSeccionPadre      : seccionIn.codigoSeccionPadre,
            codigoTipoPlanPadre     : seccionIn.codigoTipoPlanPadre,
            orden                   : seccionIn.orden,
            texto                   : seccionIn.texto,
            identificadorCampo      : seccionIn.identificadorCampo
        }

        console.log("Body:");
        console.log(body);

        return this.http.put<any>(this.EME_PLA_SECCIONES_URL,body);
    }

    postSeccion(ip                 : string,
                nombreEquipo       : string,
                usuarioIngreso     : string,
                titulo             : string,
                nivel              : number,
                orden              : number,
                texto              : string,
                estado             : string,
                codigoSeccionPadre : number|null,
                identificadorCampo : string) {

        let body = {};
        
        if(codigoSeccionPadre!=null){
            body = {
                ip                      : "0.0.0.0"                 ,
                nombreEquipo            : "Equipo 1"       ,
                estado                  : estado             ,
                fechaIngreso            : new Date       ,
                fechaModificacion       : null,
                fechaBaja               : null,
                usuarioIngreso          : usuarioIngreso     ,
                usuarioModificacion     : null,
                usuarioBaja             : null        ,
                id: {
                    codigoTipoPlan      : 1
                },
                titulo                  : titulo,
                nivel                   : nivel,
                codigoSeccionPadre      : codigoSeccionPadre,
                codigoTipoPlanPadre     : 1,
                orden                   : orden,
                texto                   : texto,
                identificadorCampo      : identificadorCampo
            }
        }else{
            body = {
                ip                      : "0.0.0.0"                 ,
                nombreEquipo            : "Equipo 1"       ,
                estado                  : estado             ,
                fechaIngreso            : new Date       ,
                fechaModificacion       : null,
                fechaBaja               : null,
                usuarioIngreso          : usuarioIngreso     ,
                usuarioModificacion     : null,
                usuarioBaja             : null        ,
                id: {
                    codigoTipoPlan      : 1
                },
                titulo                  : titulo,
                nivel                   : nivel,
                orden                   : orden,
                texto                   : texto,
                identificadorCampo      : identificadorCampo
            } 
        }
                   
        return this.http.post<any>(this.EME_PLA_SECCIONES_URL,body);
    }

}
