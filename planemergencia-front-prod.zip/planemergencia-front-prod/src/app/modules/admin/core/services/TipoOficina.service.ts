import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { TipoOficinaContent } from '../models/TipoOficinaContent';

@Injectable({
    providedIn: 'root'
})

export class TipoOficinaService {
    
    private GENTO_URL = environment.BASE_URL_GEN+ environment.GENTO_URL;
    
    
    constructor(private http : HttpClient){
    }

    getTiposOficinas() :Observable<any>{
        return this.http.get(this.GENTO_URL);
    }


    editarOficina(tipoOficinaIn : TipoOficinaContent, usuarioSession : any){
        const body = {
            ip                      : "0.0.0.0"                 ,
            nombreEquipo            : "Equipo 1"       ,
            estado                  : tipoOficinaIn.estado             ,
            fechaIngreso            : tipoOficinaIn.fechaIngreso       ,
            fechaModificacion       : new Date,
            fechaBaja               : tipoOficinaIn.fechaBaja          ,
            usuarioIngreso          : tipoOficinaIn.usuarioIngreso     ,
            usuarioModificacion     : usuarioSession.usuario        ,
            usuarioBaja             : tipoOficinaIn.usuarioBaja        ,
            codigo                  : tipoOficinaIn.codigo,
            descripcion             : tipoOficinaIn.descripcion
        }

        return this.http.put<any>(this.GENTO_URL,body).subscribe({
            next: data => {
                console.log(data);
            },
            error: error => {
                console.error('There was an error!', error);
            }
        });
    }

    postRequest(ip                 : string,
                nombreEquipo       : string,
                usuarioIngreso     : string,
                descripcion        : string,
                estado             : string) {

        let body = {};
        
        body = {
            ip                      : "0.0.0.0"                 ,
            nombreEquipo            : "Equipo 1"       ,
            estado                  : estado             ,
            fechaIngreso            : new Date       ,
            usuarioIngreso          : usuarioIngreso     ,
            descripcion             : descripcion
        }
        console.log(body);

        return this.http.post<any>(this.GENTO_URL,body);
    }

}