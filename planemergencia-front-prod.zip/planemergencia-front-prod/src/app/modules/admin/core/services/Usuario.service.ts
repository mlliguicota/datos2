import { HttpClient, HttpHeaders, HttpParams, HttpParamsOptions } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { GenUserContent } from '../models/GenUserContent';

@Injectable({
    providedIn: 'root'
})

export class UsuarioService {
    
    private URL_GENU=environment.BASE_URL_GEN + environment.GENU_URL;
    
    
    constructor(private http : HttpClient){
    }

    getGenUsuarios(name:string) :Observable<any>{
        const params ={
          usuario: name
        };

        return this.http.get(this.URL_GENU, {params});
    }

    editarUsuario(usuario : GenUserContent, usurioModificacion: string){
        
        const body = {
            ip                      : "0.0.0.0",
            nombreEquipo            : "Equipo 1",
            estado                  : usuario.estado,
            fechaIngreso            : usuario.fechaIngreso,
            fechaModificacion       : usuario.fechaModificacion,
            fechaBaja               : usuario.fechaBaja,
            usuarioIngreso          : usuario.usuarioIngreso,
            usuarioModificacion     : usurioModificacion,
            usuarioBaja             : usuario.usuarioBaja,
            codigo                  : usuario.codigo,
            usuario                 : usuario.usuario,
            contrasena              : usuario.contrasena,
            vigenciaContrasena      : usuario.vigenciaContrasena,
            bloqueo                 : usuario.bloqueo,
            fechaBloqueo            : usuario.fechaBloqueo,
            tiempoBloqueo           : usuario.fechaBloqueo,
            codigoRol               : usuario.codigoRol
        }
        return this.http.put<any>(this.URL_GENU,body);
    }

    postRequest(usuario : GenUserContent, usuarioIngreso: string){
        
        const body = {
            ip                      : "0.0.0.0",
            nombreEquipo            : "Equipo 1",
            estado                  : usuario.estado,
            fechaIngreso            : usuario.fechaIngreso,
            usuarioIngreso          : usuarioIngreso,
            usuario                 : usuario.usuario,
            codigoRol               : usuario.codigoRol,
            nombres                 : usuario.nombres,
            apellidos               : usuario.apellidos,
            contrasena              : '12345',
            vigenciaContrasena      : new Date,
            bloqueo                 : 'N',
            tiempoBloqueo           : 100
        }

        return this.http.post<any>(this.URL_GENU,body);
    }
}