import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})

export class UsuariosSfService{
    
    private GEN_INFO_TRABAJADORES=environment.BASE_URL_GEN+ environment.GEN_INFO_TRABAJADORES;
    
    constructor(private http : HttpClient){
    }

    getRequest(primerNombre:string,segundoNombre:string, primerApellido:string, segundoApellido: string) :Observable<any>{
        
        const params ={
            primerApellido   : primerApellido,
            primerNombre     : primerNombre,
            segundoApellido  : segundoApellido,
            segundoNombre    : segundoNombre
        };
        console.log(params);

        return this.http.get(this.GEN_INFO_TRABAJADORES, {params});
    }

}
