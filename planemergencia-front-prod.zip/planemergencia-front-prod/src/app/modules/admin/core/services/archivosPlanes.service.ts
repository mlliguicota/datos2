import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})

export class ArchivosPlanesService{
    
    private EME_ARCHIVOS_URL=environment.BASE_URL_EME+ environment.EME_ARCHIVOS_URL;

    constructor(private http : HttpClient){
    }

    getByOficina(idOficina: number) :Observable<any>{
        const params ={
            codigoOficina: idOficina,
            codigoEmpresa: 1,
            tipoArchivo: "archivo"
        };
        return this.http.get(this.EME_ARCHIVOS_URL, {params});
    }
}