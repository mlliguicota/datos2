import { Component, OnInit } from '@angular/core';
import { UsuarioService } from '../../core/services/Usuario.service';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { GenUserContent } from '../../core/models/GenUserContent';
import { MessageService, PrimeNGConfig } from 'primeng/api';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RolService } from '../../core/services/Rol.service';
import { GenRolContent } from '../../core/models/GenRolContent';
import { IUsuario } from 'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';
import { UsuariosSfContent } from '../../core/models/UsuariosSfContent';
import { UsuariosSfService } from '../../core/services/UsuariosSF.service';


@Component({
  selector: 'app-administrador-usuario',
  templateUrl: './administrador-usuario.component.html',
  styleUrls: ['../estilos.scss']
})
export class AdministradorUsuarioComponent implements OnInit {

  usuariosesion             : any                                       ;

  listGenUsers        : GenUserContent[] = [];
  listUsuariosMostrar : GenUserContent[] = [];

  listGenRoles        : GenRolContent [] = [];
  visibleSidebar : boolean = false;

  usuarioForm           : FormGroup;
  usuario?              : GenUserContent;
  visibleSidebarCrear   : boolean = false;
  visibleSidebarUsuarios : boolean = false;

  listUsuariosSfsf : UsuariosSfContent[] = [];

  accionEditarCrear : string;

  //Variables de busqueda
  primerNombre     : string='';
  primerApellido   : string='';
  segundoNombre    : string='';
  segundoApellido  : string='';

  stateOptions = [{label: 'A', value: 'A'}, {label: 'I', value: 'I'}];

  usuarioSfForm : FormGroup;

  loading                     : boolean = true;
  busque                      : boolean = false;

  constructor(private primengConfig: PrimeNGConfig,
              private _usuarioService: UsuarioService,
              private _usuarioSfService : UsuariosSfService,
              private _rolService: RolService,
              private fb : FormBuilder,
              private messageService: MessageService) { 

    this.usuarioForm = this.fb.group({
      usuario   : ['', Validators.required],
      nombreCompleto : ['', Validators.required],
      rol       : ['', Validators.required],
      estado    : ['', Validators.required]
    });

    this.usuarioSfForm = this.fb.group({
      primerNombre     : [''],
      primerApellido   : [''],
      segundoNombre    : [''],
      segundoApellido  : ['']
    });

    
  }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.listarGenUsuarios();
    this.listarGenRoles();
    const user: string = sessionStorage.getItem('userData') + '';
    this.usuariosesion = this.buildUserData(JSON.parse(user));
  }

  private buildUserData(user: any): IUsuario {
    const usuario: IUsuario = {
      id            : user.codigo,
      usuario       : user.usuario,
      codigoRol     : user.codigoRol,
    };
    return usuario;
  }

  editarUsuario( usuarioIn : GenUserContent ){
    this.accionEditarCrear = "Editar Usuario";
    console.log(usuarioIn);
    this.usuarioForm.setValue({
      usuario   : usuarioIn.usuario,
      nombreCompleto : usuarioIn.nombres + " " + usuarioIn.apellidos,
      estado    : usuarioIn.estado,
      rol       : usuarioIn.codigoRol
    });



    this.usuario = usuarioIn;
    this.visibleSidebar = true;
  }

  crearUsuario( usuarioIn : UsuariosSfContent ){
    this.visibleSidebarCrear = false;
    this.visibleSidebarUsuarios = false;
    this.accionEditarCrear = "Crear Usuario";
    
    this.primerNombre = usuarioIn.primerNombre;
    this.segundoNombre = usuarioIn.segundoNombre;
    this.primerApellido = usuarioIn.primerApellido;
    this.segundoApellido = usuarioIn.segundoApellido;

    console.log(usuarioIn);
    this.usuarioForm.setValue({
      usuario   : usuarioIn.usuarioSfsf,
      nombreCompleto : this.primerNombre + " "+ this.primerApellido,
      estado    : '',
      rol       : ''
    });
    
    this.visibleSidebar = true;
  }

  agregarUsuario(){
    this.visibleSidebarCrear = true;
    this.visibleSidebarUsuarios = false;
  }


  async buscarUsuarioSfsf(){
    this.primerNombre = this.usuarioSfForm.get('primerNombre')?.value;
    this.segundoNombre = this.usuarioSfForm.get('segundoNombre')?.value;
    this.primerApellido = this.usuarioSfForm.get('primerApellido')?.value;
    this.segundoApellido = this.usuarioSfForm.get('segundoApellido')?.value;

    await this.getUsuariosSf().then((data: any) => {
      if (data.resCode == 0) {
        this.listUsuariosSfsf = data.resData;
        this.visibleSidebarCrear = false;
        this.visibleSidebarUsuarios = true;
      } else {
        this.messageService.add({severity:'error', summary:'Editar usuario', detail:'Hubo un error al guardar el usuario'});
        this.visibleSidebarCrear = false;
      }
    });
  }

  async guardarUsuario(){ 
    console.log("Guardando usuario");

    if(this.accionEditarCrear == "Crear Usuario"){
      console.log("Entre");
      let actual = new GenUserContent();
      actual.estado = 'A';
      actual.ip = '192.168.0.222';
      actual.apellidos = this.primerApellido +" "+this.segundoApellido;
      actual.nombres = this.primerNombre + " " + this.segundoNombre;
      actual.codigoRol = this.usuarioForm.get('rol')?.value;
      actual.fechaIngreso = new Date;
      actual.usuario = this.usuarioForm.get('usuario')?.value.toLowerCase(); //21/6/2024
      actual.nombreEquipo = "Equipo 221";

      await this.postPromesa(actual).then((data: any) => {
        if (data.resCode == 0) {
          this.messageService.add({severity:'success', summary:'Editar Usuario', detail:"Usuario correctamente guardado."});
          this.listarGenUsuarios();
          this.visibleSidebar = false;
        } else {
          this.messageService.add({severity:'error', summary:'Editar usuario', detail:'Hubo un error al guardar el usuario'});
          this.visibleSidebar = false;
        }
      });
    }else if(this.usuario != null){
      console.log("Entre2");
      this.usuario.usuario   = this.usuarioForm.get('usuario')?.value;
      this.usuario.codigoRol = this.usuarioForm.get('rol')?.value;
      this.usuario.estado    = this.usuarioForm.get('estado')?.value;

      await this.putPromesa().then((data: any) => {
        if (data.resCode == 0) {
          this.messageService.add({severity:'success', summary:'Editar Usuario', detail:"Usuario correctamente guardado."});
          this.visibleSidebar = false;
        } else {
          this.messageService.add({severity:'error', summary:'Editar usuario', detail:'Hubo un error al guardar el usuario'});
          this.visibleSidebar = false;
        }
      });
    }
    console.log("Saliendo");
  }

  putPromesa(){
    return new Promise((resolve)=>{
      if (this.usuario != null){
        this._usuarioService.editarUsuario(this.usuario,this.usuariosesion.usuario).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _usuarioService.editarUsuario';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
      }
    },
    );
  }

  postPromesa(usuarioIn : GenUserContent){
    return new Promise((resolve)=>{
      this._usuarioService.postRequest(usuarioIn,this.usuariosesion.usuario).subscribe({
        next: (res:any)=>{
          const data = { resCode: 0 };
          resolve(data);
        },
        error: (err)=>{
          const e='Error _usuarioService.editarUsuario';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    });
  }

  listarGenUsuarisos(){
    this._usuarioService.getGenUsuarios("").subscribe(
      data => {
        this.listGenUsers        = data.pageContent
        this.listUsuariosMostrar = this.listGenUsers;
        console.log(this.listGenUsers);
      }, error => {
        console.log(error);
      }
    );
  }

  async listarGenUsuarios(){
    this.loading = true;
    await this.getUsuariosPromise().then((data: any) => {
      if (data.resCode == 0) {
        this.listGenUsers        = data.resData
        this.listUsuariosMostrar = this.listGenUsers;
        this.loading = false;
        this.busque = true;
      } else {
        this.messageService.add({severity:'error', summary:'Información', detail:"No se pudo obtener los usuarios"});
        this.loading = false;
        this.busque = true;
      }
    });
  }


  getUsuariosPromise(){
    return new Promise((resolve)=>{
      this._usuarioService.getGenUsuarios("").subscribe({
        next: (res:any)=>{
          const data = { resCode: 0, resData : res.pageContent };
          resolve(data);
        },
        error: (err)=>{
          const e='Error ._usuarioService.getGenUsuarios';
          const data = { resCode: -1, error: e };
          resolve(data);
        }
      });
    });
  }



  buscar(){
    let busqueda = (document.getElementById("txt_busqueda") as HTMLInputElement).value;

    if (busqueda == null || busqueda == ""){
      this.listUsuariosMostrar = this.listGenUsers;
    }else{
      this.listUsuariosMostrar = [];
      this.listGenUsers.forEach(element => {
        if (element.apellidos.toLowerCase().includes(busqueda.toLowerCase()) || element.nombres.toLowerCase().includes(busqueda.toLowerCase())){
          this.listUsuariosMostrar.push(element);
        }
      });
    }
  }


  getUsuariosSf(){
    return new Promise((resolve)=>{
      this._usuarioSfService.getRequest(this.primerNombre,this.segundoNombre,this.primerApellido,this.segundoApellido).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData: res.pageContent};
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.obtenerPlanEmergencia';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    }
    );
  }


  obtenerNombreRol( codigoRol : number ) : string { //Esta funcion se llama a cada rato cuando modifico al editar
    let nombre = "";
    if(this.listGenRoles!= null){
      this.listGenRoles.forEach(element => {
        if (element.codigo == codigoRol){
          //nombre = element.descripcion;
         nombre = element.nombre;
        }
      });
    }
    return nombre;
  }

  async listarGenRoles(){
    await this.getRolesPromise().then((data: any) => {
      if (data.resCode == 0) {
        this.listGenRoles = data.resData;
      } else {
        this.messageService.add({severity:'error', summary:'Información', detail:"No se pudo obtener los contactos de institución"});
      }
    });
  }


  getRolesPromise(){
    return new Promise((resolve)=>{
      this._rolService.getGenRoles().subscribe({
        next: (res:any)=>{
          const data = { resCode: 0, resData : res.pageContent };
          resolve(data);
        },
        error: (err)=>{
          const e='Error _tipoOficinaService.postRequest';
          const data = { resCode: -1, error: e };
          resolve(data);
        }
      });
    });
  }

}
