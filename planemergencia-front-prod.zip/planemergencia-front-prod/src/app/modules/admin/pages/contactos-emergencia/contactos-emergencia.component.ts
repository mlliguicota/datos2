import { Component, OnInit } from '@angular/core';
import { ContactoEmergenciaService } from '../../core/services/Contacto-Emergencia.service';
import { OficinaService } from '../../core/services/Oficina.service';
import { GenOficinaContent } from '../../core/models/GenOficinaContent';
import { ContactoEmergenciaContent } from '../../core/models/ContactoEmergenciaContent';
import { ContactoOficinaContent } from '../../core/models/ContactoOficinaContent';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IUsuario } from 'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-contactos-emergencia',
  templateUrl: './contactos-emergencia.component.html',
  styleUrls: ['../estilos.scss']
})
export class ContactosEmergenciaComponent implements OnInit {
  

  listOficinas              : GenOficinaContent         [] = [];
  listContactosEmergencia   : ContactoEmergenciaContent [] = [];
  listContactosOficina      : ContactoOficinaContent [] = [];
  oficinaSeleccionada       : boolean                      = false;
  visibleSidebar            : boolean = false;
  accionCrearEditar?        : string;
  contactoForm              : FormGroup;
  stateOptions = [{label: 'A', value: 'A'}, {label: 'I', value: 'I'}];

  contactoEmergencia? : ContactoEmergenciaContent;
  usuariosesion             : any                                       ;
  ip?                       : string                                    ;
  nombreEquipo?             : string                                    ;

  loading                     : boolean = true;
  busque                      : boolean = false;
  noError                     : boolean = true;


  constructor(private _ContactoEmergenciaService : ContactoEmergenciaService,
              private _OficinaService            : OficinaService,
              private fb                        : FormBuilder,
              private messageService: MessageService ) {
                
    this.contactoForm= this.fb.group({
      extension        : ['', Validators.required],
      telefono   : ['', Validators.required],
      estado        : ['', Validators.required]
    });
  
  }

  ngOnInit(): void {
    this.obtenerOficinas();
    const user: string = sessionStorage.getItem('userData') + '';
    this.usuariosesion = this.buildUserData(JSON.parse(user));
  }

  private buildUserData(user: any): IUsuario {
    const usuario: IUsuario = {
      id            : user.codigo,
      usuario       : user.usuario,
      codigoRol     : user.codigoRol,
    };
    return usuario;
  }

  /*
  async obtenerContactosEmergencia(codigoOficina : number){
    
    const responseContactosOficina = await this._ContactoEmergenciaService.getContactosOficina(codigoOficina).toPromise();

    this.listContactosOficina = responseContactosOficina.pageContent;

    this.listContactosOficina.forEach(async element => {
      
      let responseContactosOficina = await this._ContactoEmergenciaService.getContactoEmergencia(element.id.codigoContacto).toPromise();
      
      this.listContactosEmergencia.push(responseContactosOficina.pageContent[0]);

    });
  */

/* Modificacion de ordenacion SUD-BCALVOPIÑA 22/01/2024 */
  async obtenerContactosEmergencia(codigoOficina : number){
    this.loading = true;
    await this.getContactosOficina(codigoOficina).then((data: any) => {
      if (data.resCode == 0){
        this.listContactosOficina = data.resData;
      } else {
        this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener contactos de oficina'});
        this.noError = false;
      }
    });

    if(this.noError){
      for (let indiceFila = 0; indiceFila < this.listContactosOficina.length; indiceFila++){
        await this.getContactosEmergencia(this.listContactosOficina[indiceFila].id.codigoContacto).then((data: any) => {
          if (data.resCode == 0){
            this.listContactosEmergencia.push(data.resData[0]);



          } else {
            this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al cargar contactos de emergencia'});
            this.noError = false;
          }
        });
        if(!this.noError){
          break;
        }
      }
    }

    this.listContactosEmergencia.sort((a, b) => {
      const nombreA = a.primerApellido.toUpperCase(); // Convertir a mayúsculas para una comparación insensible a mayúsculas/minúsculas
      const nombreB = b.primerApellido.toUpperCase(); // Convertir a mayúsculas para una comparación insensible a mayúsculas/minúsculas
      if (nombreA < nombreB) {
        return -1; // a viene antes que b
      }
      if (nombreA > nombreB) {
        return 1; // a viene después que b
      }
      return 0; // los nombres son iguales
    });
  
    
    this.loading = false;
  }

  getContactosOficina(codigoOficina : number){
    return new Promise((resolve)=>{
      this._ContactoEmergenciaService.getContactosOficina(codigoOficina).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData : res.pageContent};
            resolve(data);
          },
          error: (err)=>{
            const e='Error _ContactoEmergenciaService.getContactosOficina';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    });
  }

  getContactosEmergencia(codigoContacto : number){
    return new Promise((resolve)=>{
      this._ContactoEmergenciaService.getContactoEmergencia(codigoContacto).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData : res.pageContent};
            resolve(data);
          },
          error: (err)=>{
            const e='Error _ContactoEmergenciaService.getContactoEmergencia';
            const data = { resCode: -1, error: e };
            resolve(data);
          }
        });
    });
  }




  obtenerOficinas(){
    this._OficinaService.getOficinas().subscribe(
      data => {
        this.listOficinas = data.pageContent;
      }, error => {
        console.log(error);
      }
    );
    this.loading = false;
  }

  cargarContactosOficina(event:any) {
    this.oficinaSeleccionada = true;
    let codigoOficina = event.value;
    this.listContactosEmergencia = [];
    this.obtenerContactosEmergencia(codigoOficina);
  }

  editar(objetoIN : ContactoEmergenciaContent){
    this.accionCrearEditar = "Editar Contacto Emergencia";

    this.contactoForm.setValue({
      extension  : objetoIN.extensionTelefono,
      telefono   : objetoIN.telefono,
      estado     : objetoIN.estado,
    });

    this.contactoEmergencia = objetoIN;
    this.visibleSidebar = true;
  }

  async guardar(){
    this.ip           = "192.168.0.221"; //obtener ip 
    this.nombreEquipo = "maquina 221"  ; //obtener nombre equipo
    
    //Editar
    if(this.contactoEmergencia != null){
      
      this.contactoEmergencia.estado                         = this.contactoForm.get('estado')?.value;
      this.contactoEmergencia.extensionTelefono              = this.contactoForm.get('extension')?.value;
      this.contactoEmergencia.telefono                       = this.contactoForm.get('telefono')?.value;
      
      await this.putPromesa().then((data: any) => {
        if (data.resCode == 0) {
          this.messageService.add({severity:'success', summary:'Editar Contacto', detail:"Titulo correctamente guardado codigoPadre:"});
          this.visibleSidebar = false;
        } else {
          this.messageService.add({severity:'error', summary:'Editar Contacto', detail:'Hubo un error al guardar el contacto'});
          this.visibleSidebar = false;
        }
      });
    }
  }


  putPromesa(){
    return new Promise((resolve)=>{
      if (this.contactoEmergencia != null){
        this._ContactoEmergenciaService.putRequest(this.contactoEmergencia,this.usuariosesion).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _seccionesService.editarSeccion';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
      }
    },
    );
  }

}
