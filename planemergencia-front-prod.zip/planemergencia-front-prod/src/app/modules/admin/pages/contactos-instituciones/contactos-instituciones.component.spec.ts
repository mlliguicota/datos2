import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactosInstitucionesComponent } from './contactos-instituciones.component';

describe('ContactosInstitucionesComponent', () => {
  let component: ContactosInstitucionesComponent;
  let fixture: ComponentFixture<ContactosInstitucionesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContactosInstitucionesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactosInstitucionesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
