import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { IUsuario } from 'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';
import { InstitucionEmergenciaContent } from '../../core/models/InstitucionesEmergenciaContent';
import { InstitucionEmergenciaService } from '../../core/services/Institucion-Emergencia.service';

@Component({
  selector: 'app-contactos-instituciones',
  templateUrl: './contactos-instituciones.component.html',
  styleUrls: ['../estilos.scss']
})
export class ContactosInstitucionesComponent implements OnInit {

  listContactosInstituciones  : InstitucionEmergenciaContent [] = [];
  accionCrearEditar?          : string;
  contactoForm                : FormGroup;
  contactoInstitucion         : InstitucionEmergenciaContent | null;
  visibleSidebar              : boolean = false;
  ip                          : string ;
  nombreEquipo               : string;
  usuariosesion               : any                                       ;
  loading                     : boolean = true;
  busque                      : boolean = false;

  stateOptions = [{label: 'A', value: 'A'}, {label: 'I', value: 'I'}];

  listMostrar  : InstitucionEmergenciaContent [] = [];


  constructor(private _institucionEmergenciaService : InstitucionEmergenciaService,
              private fb                    : FormBuilder,
              private messageService                 : MessageService) { 

      this.contactoForm= this.fb.group({
        ciudad        : ['', Validators.required],
        institucion   : ['', Validators.required],
        telefono      : ['', Validators.required],
        estado        : ['', Validators.required]
      });
  }

  ngOnInit(): void {
    this.obtenerContactosEmergencia();
    const user: string = sessionStorage.getItem('userData') + '';
    this.usuariosesion = this.buildUserData(JSON.parse(user));
  }

  private buildUserData(user: any): IUsuario {
    const usuario: IUsuario = {
      id            : user.codigo,
      usuario       : user.usuario,
      codigoRol     : user.codigoRol,
    };
    return usuario;
  }

  buscar(){
    let busqueda = (document.getElementById("txt_busqueda") as HTMLInputElement).value;

    if (busqueda == null || busqueda == ""){
      this.listMostrar = this.listContactosInstituciones;
    }else{
      this.listMostrar = [];
      this.listContactosInstituciones.forEach(element => {
        if (element.ciudad.toLowerCase().includes(busqueda.toLowerCase())){
          this.listMostrar.push(element);
        }
      });
    }
  }

  async obtenerContactosEmergencia(){

    await this.getPromesa().then((data: any) => {
      if (data.resCode == 0) {
        this.listContactosInstituciones = data.resData;
        this.listMostrar = this.listContactosInstituciones;
        this.loading = false;
        this.busque = true;
      } else {
        this.messageService.add({severity:'error', summary:'Información', detail:"No se pudo obtener los contactos de institucion"});
        this.loading = false;
        this.busque = true;
      }
    });
  }

  getPromesa(){
    return new Promise((resolve)=>{
        this._institucionEmergenciaService.getInstitucionesEmergencia().subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData : res.pageContent };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _tipoOficinaService.postRequest';
            const data = { resCode: -1, error: e };
            resolve(data);
          }
        });
    });
  }



  editarContacto(contactoIn : InstitucionEmergenciaContent){
    this.accionCrearEditar = "Editar Contacto Institución";

    this.contactoForm.setValue({
      ciudad        : contactoIn.ciudad,
      institucion   : contactoIn.institucion,
      telefono      : contactoIn.telefono,
      estado        : contactoIn.estado
    });

    this.contactoInstitucion  = contactoIn;
    this.visibleSidebar = true;
  }

  crearContacto(){
    this.contactoInstitucion = null;

    this.accionCrearEditar = "Crear Contacto Institución";

    this.contactoForm= this.fb.group({
      ciudad        : ['', Validators.required],
      institucion   : ['', Validators.required],
      telefono      : ['', Validators.required],
      estado        : ['', Validators.required]
    });

    this.contactoForm.setValue({
      ciudad        : '',
      institucion   : '',
      telefono      : '',
      estado        : ''
    });

    this.visibleSidebar = true;
  }

  async guardarContacto(){
    this.loading = true;
    this.ip           = "192.168.0.221"; //obtener ip 
    this.nombreEquipo = "maquina 221"  ; //obtener nombre equipo

    if(this.contactoInstitucion != null){
      this.contactoInstitucion.ciudad       = this.contactoForm.get('ciudad')?.value;
      this.contactoInstitucion.institucion  = this.contactoForm.get('institucion')?.value;
      this.contactoInstitucion.telefono     = this.contactoForm.get('telefono')?.value;
      this.contactoInstitucion.estado       = this.contactoForm.get('estado')?.value;
      
      await this.putPromesa().then((data: any) => {
        if (data.resCode == 0) {
          this.obtenerContactosEmergencia();
        } else {
          this.messageService.add({severity:'error', summary:'Información', detail:"No se pudo guardar la información"});
          this.loading = false;
        }
      });

    }else{
      await this.postPromesa().then((data: any) => {
        if (data.resCode == 0) {
          this.obtenerContactosEmergencia();
        } else {
          this.messageService.add({severity:'error', summary:'Información', detail:"No se pudo guardar la información"});
          this.loading = false;
        }
      });
    }

    this.visibleSidebar = false;
  }

  putPromesa(){
    return new Promise((resolve)=>{
      this._institucionEmergenciaService.editarContacto(this.contactoInstitucion, this.usuariosesion).subscribe({
        next: (res:any)=>{
          const data = { resCode: 0, resData : res.pageContent };
          resolve(data);
        },
        error: (err)=>{
          const e='Error _tipoOficinaService.postRequest';
          const data = { resCode: -1, error: e };
          resolve(data);
        }
      });
    });
  }

  postPromesa(){
    return new Promise((resolve)=>{
      this._institucionEmergenciaService.crearContacto(this.ip, 
                                                       this.nombreEquipo,
                                                       this.usuariosesion.usuario,
                                                       this.contactoForm.get('ciudad')?.value,
                                                       this.contactoForm.get('institucion')?.value,
                                                       this.contactoForm.get('telefono')?.value,
                                                       this.contactoForm.get('estado')?.value).subscribe({
        next: (res:any)=>{
          const data = { resCode: 0, resData : res.pageContent };
          resolve(data);
        },
        error: (err)=>{
          const e='Error _tipoOficinaService.postRequest';
          const data = { resCode: -1, error: e };
          resolve(data);
        }
      });
    });
  }

}
