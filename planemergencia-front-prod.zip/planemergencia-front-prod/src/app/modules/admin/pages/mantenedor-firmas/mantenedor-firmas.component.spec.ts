import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MantenedorFirmasComponent } from './mantenedor-firmas.component';

describe('MantenedorFirmasComponent', () => {
  let component: MantenedorFirmasComponent;
  let fixture: ComponentFixture<MantenedorFirmasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MantenedorFirmasComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MantenedorFirmasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
