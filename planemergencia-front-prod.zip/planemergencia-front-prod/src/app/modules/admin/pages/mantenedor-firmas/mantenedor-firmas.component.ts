import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GenOficinaContent } from '../../core/models/GenOficinaContent';
import { OficinaService } from '../../core/services/Oficina.service';
import { PlanEmergenciaService } from '../../core/services/PlanEmergencia.service';
import { PlanEmergenciaContent } from '../../core/models/PlanEmergenciaContent';
import { IUsuario } from 'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';

@Component({
  selector: 'app-mantenedor-firmas',
  templateUrl: './mantenedor-firmas.component.html',
  styleUrls: ['../estilos.scss']
})
export class MantenedorFirmasComponent implements OnInit {

  firmaForm  : FormGroup;
  visibleSidebar : boolean = false;
  accion? : string;

  listOficinas              : GenOficinaContent         [] = [];

  nombreElaborador : string = "";
  cargoElaborador  : string = "";

  nombreAprobador : string = "";
  cargoAprobador  : string = "";

  isEditElaborador : boolean = false;

  oficinaSeleccionada       : boolean                      = false;

  firmaSeleccionada? : PlanEmergenciaContent;

  usuariosesion             : any                                       ;


  constructor(private fb                   : FormBuilder,
              private _OficinaService      : OficinaService,
              private _firmasService       : PlanEmergenciaService) {
    this.firmaForm = this.fb.group({
      nombre   : ['', Validators.required],
      cargo : ['', Validators.required]
    })

  }

  ngOnInit(): void {
    this.obtenerOficinas();
    const user: string = sessionStorage.getItem('userData') + '';
    this.usuariosesion = this.buildUserData(JSON.parse(user));
  }

  private buildUserData(user: any): IUsuario {
    const usuario: IUsuario = {
      id            : user.codigo,
      usuario       : user.usuario,
      codigoRol     : user.codigoRol,
    };
    return usuario;
  }

  obtenerOficinas(){
    this._OficinaService.getOficinas().subscribe(
      data => {
        this.listOficinas = data.pageContent;
      }, error => {
        console.log(error);
      }
    );
  }


  cargarFirmas(event:any) {
    let codigoOficina = event.value;
    this.obtenerFirmas(codigoOficina);
  }

  async obtenerFirmas(codigoOficina : number){
    await this.getPromesa(codigoOficina).then((data: any) => {
      if (data.resCode == 0) {
        this.oficinaSeleccionada = true;
      }
    });
  }

  getPromesa(codigoOficina : number){
    return new Promise((resolve)=>{
      this._firmasService.getRequest(codigoOficina).subscribe({
        next: (res:any)=>{
          this.firmaSeleccionada = res.pageContent[0];
          this.nombreElaborador = res.pageContent[0].elaborador;
          this.nombreAprobador  = res.pageContent[0].aprobador;
          this.cargoElaborador  = res.pageContent[0].cargoElaborador;
          this.cargoAprobador   = res.pageContent[0].cargoAprobador;
          const data = { resCode: 0 };
          resolve(data);
        },
        error: (err)=>{
          const e='Error _seccionesService.editarSeccion';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    });
  }

  putPromesa(accion :number){
    return new Promise((resolve)=>{
      if (this.firmaSeleccionada != null){
        this._firmasService.putRequest(this.firmaSeleccionada,this.usuariosesion,accion).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _seccionesService.editarSeccion';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
      }
    });
  }

  editarElaborador(){
    this.accion = "Editar Elaborador"
    
    this.firmaForm.setValue({
      nombre   : this.nombreElaborador,
      cargo    : this.cargoElaborador
    });

    this.isEditElaborador = true;
    this.visibleSidebar = true;

  }

  editarAprobador(){
    this.accion = "Editar Aprobador"

    this.firmaForm.setValue({
      nombre   : this.nombreAprobador,
      cargo : this.cargoAprobador
    });

    this.isEditElaborador = false;
    this.visibleSidebar = true;

  }

  async guardarFirma(){
    if (this.isEditElaborador){
      this.nombreElaborador = this.firmaForm.get('nombre')?.value;
      this.cargoElaborador = this.firmaForm.get('cargo')?.value;

      if (this.firmaSeleccionada != null){
        this.firmaSeleccionada.elaborador = this.nombreElaborador;
        this.firmaSeleccionada.cargoElaborador = this.cargoElaborador;
      }

      await this.putPromesa(1).then((data: any) => {
        if (data.resCode == 0) {
          this.visibleSidebar = false;
        } else {
          this.visibleSidebar = false;
        }
      });


    }else{
      this.nombreAprobador = this.firmaForm.get('nombre')?.value;
      this.cargoAprobador = this.firmaForm.get('cargo')?.value;
      if (this.firmaSeleccionada != null){
        this.firmaSeleccionada.aprobador = this.nombreAprobador;
        this.firmaSeleccionada.cargoAprobador = this.cargoAprobador;
      }

      await this.putPromesa(2).then((data: any) => {
        if (data.resCode == 0) {
          this.visibleSidebar = false;
        } else {
          this.visibleSidebar = false;
        }
      });

    }
  }

}
