import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MantenedorGeneralComponent } from './mantenedor-general.component';

describe('MantenedorGeneralComponent', () => {
  let component: MantenedorGeneralComponent;
  let fixture: ComponentFixture<MantenedorGeneralComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MantenedorGeneralComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MantenedorGeneralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
