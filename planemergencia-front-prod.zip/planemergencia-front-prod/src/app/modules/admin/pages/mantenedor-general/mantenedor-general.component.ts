import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mantenedor-general',
  templateUrl: './mantenedor-general.component.html',
  styleUrls: ['./mantenedor-general.component.scss']
})
export class MantenedorGeneralComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
