import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MantenedorOficinasComponent } from './mantenedor-oficinas.component';

describe('MantenedorOficinasComponent', () => {
  let component: MantenedorOficinasComponent;
  let fixture: ComponentFixture<MantenedorOficinasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MantenedorOficinasComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MantenedorOficinasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
