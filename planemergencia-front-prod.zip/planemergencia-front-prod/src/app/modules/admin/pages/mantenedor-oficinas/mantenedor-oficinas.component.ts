import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IUsuario } from 'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';
import { GenOficinaContent } from '../../core/models/GenOficinaContent';
import { OficinaService } from '../../core/services/Oficina.service';
import { TipoOficinaContent } from '../../core/models/TipoOficinaContent';
import { TipoOficinaService } from '../../core/services/TipoOficina.service';
import { TipoOficina } from '../../../../core/enums/tipoOficina.enum';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-mantenedor-oficinas',
  templateUrl: './mantenedor-oficinas.component.html',
  styleUrls: ['../estilos.scss']
})
export class MantenedorOficinasComponent implements OnInit {

  listOficinas              : TipoOficinaContent[] = [];
  listOficinasMostrar       : TipoOficinaContent[] = [];
  usuariosesion             : any                                       ;
  accionCrearEditar         : string                            = ""    ;

  visibleSidebar : boolean = false;

  oficinaForm  : FormGroup;
  oficina? : TipoOficinaContent;

  ip?                       : string                                    ;
  nombreEquipo?             : string                                    ;

  loading                     : boolean = true;
  busque                      : boolean = false;

  stateOptions = [{label: 'A', value: 'A'}, {label: 'I', value: 'I'}];
  
  constructor(private _tipoOficinaService            : TipoOficinaService,
              private fb                             : FormBuilder,
              private messageService                 : MessageService ) { 

    this.oficinaForm = this.fb.group({
      tipoOficina   : ['', Validators.required],
      estado   : ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.obtenerOficinas();
    const user: string = sessionStorage.getItem('userData') + '';
    this.usuariosesion = this.buildUserData(JSON.parse(user));
  }

  private buildUserData(user: any): IUsuario {
    const usuario: IUsuario = {
      id            : user.codigo,
      usuario       : user.usuario,
      codigoRol     : user.codigoRol,
    };
    return usuario;
  }

  async obtenerOficinas(){
    await this.getOficinas().then((data: any) => {
      if (data.resCode == 0) {
        this.listOficinas = data.resData;
        this.listOficinasMostrar = [];

      this.listOficinas.forEach(element => {
        if (element.estado!='I'){
          this.listOficinasMostrar.push(element);
        }
      });

        this.busque = true;
      } else {
        this.messageService.add({severity:'error', summary:'Agregar Tipo Oficina', detail:'Error al listar oficinas'});
        this.busque = true;
      }
    });
    this.loading=false;
  }

  getOficinas(){
    return new Promise((resolve)=>{
      this._tipoOficinaService.getTiposOficinas().subscribe({
        next: (res:any)=>{
          const data = { resCode: 0, resData : res.pageContent };
          resolve(data);
        },
        error: (err)=>{
          const e='Error _tipoOficinaService.getTiposOficinas';
          const data = { resCode: -1, error: e };
          resolve(data);
        }
      });
    });
  }

  editarOficina(oficinaIn : TipoOficinaContent){
    this.accionCrearEditar = "Editar Tipo Oficina";
    this.oficinaForm.setValue({
      tipoOficina     :    oficinaIn.descripcion,
      estado          :    oficinaIn.estado
    });
    this.oficina = oficinaIn;
    this.visibleSidebar = true;
  }

  async guardarOficina(){
    this.ip           = "192.168.0.221"; //obtener ip 
    this.nombreEquipo = "maquina 221"  ; //obtener nombre equipo

    if(this.oficina != null ){
      this.oficina.descripcion        = this.oficinaForm.get('tipoOficina')?.value;
      this.oficina.estado             = this.oficinaForm.get('estado')?.value;

      this._tipoOficinaService.editarOficina(this.oficina,this.usuariosesion);
      this.visibleSidebar = false;
    }else{
      await this.postPromesa(this.ip,
                             this.nombreEquipo,
                             this.usuariosesion.usuario,
                             this.oficinaForm.get('tipoOficina')?.value,
                             this.oficinaForm.get('estado')?.value).then(
        (data: any) => {
          if (data.resCode == 0) {
            this.messageService.add({severity:'success', summary:'Agregar Tipo Oficina', detail:"Tipo Oficina correctamente guardado"});
            this.obtenerOficinas();
            this.visibleSidebar = false;
          } else {
            this.messageService.add({severity:'error', summary:'Agregar Tipo Oficina', detail:'Hubo un error al guardar el Tipo Oficina'});
            this.visibleSidebar = false;
          }
        }
      );
    }
    
  }

  agregarOficina(){
    this.accionCrearEditar = "Agregar Tipo Oficina";

    this.oficinaForm = this.fb.group({
      tipoOficina   : ['', Validators.required],
      estado   : ['', Validators.required]
    });

    this.oficinaForm.setValue({
      tipoOficina   : '',
      estado   : ''
    });
    this.oficina = undefined;
    this.visibleSidebar = true;
  }

  buscar(){
    let busqueda = (document.getElementById("txt_busqueda") as HTMLInputElement).value;

    if (busqueda == null || busqueda == ""){
      this.listOficinasMostrar = [];

      this.listOficinas.forEach(element => {
        if (element.estado!='I'){
          this.listOficinasMostrar.push(element);
        }
      });
    }else{
      this.listOficinasMostrar = [];
      this.listOficinas.forEach(element => {
        if (element.descripcion.toLowerCase().includes(busqueda.toLowerCase())){
          this.listOficinasMostrar.push(element);
        }
      });
    }
  }

  postPromesa(ip:string,nombreEquipo:string,usuarioIngreso:string,tipo: string, estado:string){
    return new Promise((resolve)=>{
        this._tipoOficinaService.postRequest(ip,nombreEquipo,usuarioIngreso,tipo,estado).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _tipoOficinaService.postRequest';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    }
    );
  }

}
