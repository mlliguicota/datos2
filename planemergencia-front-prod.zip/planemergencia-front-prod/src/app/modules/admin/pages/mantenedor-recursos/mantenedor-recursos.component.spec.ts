import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MantenedorRecursosComponent } from './mantenedor-recursos.component';

describe('MantenedorRecursosComponent', () => {
  let component: MantenedorRecursosComponent;
  let fixture: ComponentFixture<MantenedorRecursosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MantenedorRecursosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MantenedorRecursosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
