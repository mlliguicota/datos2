import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { IUsuario } from 'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';
import { EmeRecursosContent } from '../../core/models/EmeRecursosContent';
import { EmeRecursosService } from '../../core/services/Eme-Recursos.service';

@Component({
  selector: 'app-mantenedor-recursos',
  templateUrl: './mantenedor-recursos.component.html',
  styleUrls: ['../estilos.scss']
})
export class MantenedorRecursosComponent implements OnInit {

  ip?                       : string                                    ;
  nombreEquipo?             : string                                    ;
  accionCrearEditar         : string                            = ""    ;
  listRecursos        : EmeRecursosContent[] = [];
  usuariosesion             : any                                       ;

  visibleSidebar : boolean = false;

  recursoForm   : FormGroup;
  recurso?      : EmeRecursosContent;

  loading                     : boolean = true;
  busque                      : boolean = false;

  stateOptions = [{label: 'A', value: 'A'}, {label: 'I', value: 'I'}];

  constructor(private _RecursoService            : EmeRecursosService,
              private fb : FormBuilder,
              private messageService                 : MessageService) { 
    
    this.recursoForm = this.fb.group({
      descripcion : ['', Validators.required],
      estado   : ['', Validators.required]
    })

  }

  ngOnInit(): void {
    this.obtenerRecursos();
    const user: string = sessionStorage.getItem('userData') + '';
    this.usuariosesion = this.buildUserData(JSON.parse(user));
  }

  private buildUserData(user: any): IUsuario {
    const usuario: IUsuario = {
      id            : user.codigo,
      usuario       : user.usuario,
      codigoRol     : user.codigoRol,
    };
    return usuario;
  }

  async obtenerRecursos(){
    await this.getRecursos().then((data: any) => {
      if (data.resCode == 0) {
        this.listRecursos = data.resData;
        this.busque = true;
      } else {
        this.messageService.add({severity:'error', summary:'Info Pagina', detail:'Error al cargar recursos'});
        this.busque = true;
      }
    });

    this.loading = false;
  }

  getRecursos(){
    return new Promise((resolve)=>{
      this._RecursoService.getRecursos().subscribe({
        next: (res:any)=>{
          const data = { resCode: 0 , resData : res.pageContent};
          resolve(data);
        },
        error: (err)=>{
          const e='Error _RecursoService.getRecursos';
          const data = { resCode: -1, error: e };
          resolve(data);
        }
      });
    });
  }

  editarRecurso(recursoIn : EmeRecursosContent){
    this.recursoForm.setValue({
      descripcion : recursoIn.descripcion,
      estado   : recursoIn.estado
    });
    this.recurso = recursoIn;
    this.visibleSidebar = true;
  }

  crearRecurso(){
    
      this.accionCrearEditar = "Crear Recurso";
  
      this.recursoForm= this.fb.group({
        descripcion : ['', Validators.required],
        estado   : ['', Validators.required]
      });
  
      this.recursoForm.setValue({
        descripcion   : '',
        estado        : ''
      });
  
      this.visibleSidebar = true;
    
  }

  async guardarRecurso(){
    this.ip           = "192.168.0.221"; //obtener ip 
    this.nombreEquipo = "maquina 221"  ; //obtener nombre equipo

    if(this.recurso != null){
      this.recurso.estado             = this.recursoForm.get('estado')?.value;
      this.recurso.descripcion        = this.recursoForm.get('descripcion')?.value;

      this._RecursoService.editarRecurso(this.recurso,this.usuariosesion);
    }else{
      await this.postPromesa(this.ip, 
                             this.nombreEquipo,
                             this.usuariosesion.usuario,
                             this.recursoForm.get('descripcion')?.value,
                             this.recursoForm.get('estado')?.value).then(
        (data: any) => {
          if (data.resCode == 0) {
            this.messageService.add({severity:'success', summary:'Agregar Recurso', detail:"Recurso correctamente guardado"});
            this.obtenerRecursos();
            this.visibleSidebar = false;
          } else {
            this.messageService.add({severity:'error', summary:'Agregar Recurso', detail:'Hubo un error al guardar el Recurso'});
            this.visibleSidebar = false;
          }
        }
      );
    }

    this.visibleSidebar = false;
  }

  postPromesa(ip:string,nombreEquipo:string,usuarioIngreso:string,descripcion: string, estado:string){
    return new Promise((resolve)=>{
      this._RecursoService.crearRecurso(ip,nombreEquipo,usuarioIngreso,descripcion,estado).subscribe({
        next: (res:any)=>{
          const data = { resCode: 0 };
          resolve(data);
        },
        error: (err)=>{
          const e='Error _tipoOficinaService.postRequest';
          const data = { resCode: -1, error: e };
          resolve(data);
        }
      });
    });
  }


  

}
