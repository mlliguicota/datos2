import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MantenedorRiesgosComponent } from './mantenedor-riesgos.component';

describe('MantenedorRiesgosComponent', () => {
  let component: MantenedorRiesgosComponent;
  let fixture: ComponentFixture<MantenedorRiesgosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MantenedorRiesgosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MantenedorRiesgosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
