import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { RiesgoContent } from '../../core/models/RiesgoContent';
import { RiesgosService } from '../../core/services/Riesgo.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { riesgo } from '../../../plan-de-emergencia/core/interfaces/seleccionRiesgo.interface';
import { IUsuario } from 'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-mantenedor-riesgos',
  templateUrl: './mantenedor-riesgos.component.html',
  styleUrls: ['../estilos_2.scss']
})
export class MantenedorRiesgosComponent implements OnInit {

  accionCrearEditar         : string                            = ""    ;
  listRiegos : RiesgoContent [] = [];
  htmlVistaPrevia : SafeHtml;
  tituloRiesgo : string;
  riesgoSeleccionado : RiesgoContent =new RiesgoContent('','','',new Date(),'',0,'','','');

  stateOptions = [{label: 'A', value: 'A'}, {label: 'I', value: 'I'}];

  visibleEditarCrear  : boolean = false;
  vistaPrevia         : boolean = false;
  vistaGeneral        : boolean = true;

  usuariosesion             : any                                       ;
  ip?                       : string                                    ;
  nombreEquipo?             : string                                    ;

  loading                     : boolean = true;
  busque                      : boolean = false;

  constructor(private _riesgosService   : RiesgosService,
              private sanitizer         : DomSanitizer,
              private messageService    : MessageService) {

     
  }

  ngOnInit(): void {
    this.listarRiegos();
    const user: string = sessionStorage.getItem('userData') + '';
    this.usuariosesion = this.buildUserData(JSON.parse(user));
  }

  private buildUserData(user: any): IUsuario {
    const usuario: IUsuario = {
      id            : user.codigo,
      usuario       : user.usuario,
      codigoRol     : user.codigoRol,
    };
    return usuario;
  }

  agregarRiesgo(){
    this.accionCrearEditar = "Crear Riesgo";
    this.riesgoSeleccionado = new RiesgoContent('','','',new Date(),'',0,'','','');
    this.vistaGeneral = false;
    this.visibleEditarCrear = true;
  }

  async listarRiegos(){
    await this.getRiesgos().then((data: any) => {
      if (data.resCode == 0) {
        this.listRiegos = data.resData;
        this.busque     = true;
      } else {
        this.messageService.add({severity:'error', summary:'Info Pagina', detail:'Error al cargar riesgos'});
        this.busque     = true;
      }
    });

    this.loading = false;
  }

  getRiesgos(){
    return new Promise((resolve)=>{
      this._riesgosService.getRiesgos().subscribe({
        next: (res:any)=>{
          const data = { resCode: 0, resData : res.pageContent };
          resolve(data);
        },
        error: (err)=>{
          const e='Error _riesgosService.getRiesgos';
          const data = { resCode: -1, error: e };
          resolve(data);
        }
      });
    });
  }

  vistaPreviaRiesgo(riesgoIn : RiesgoContent){
    this.riesgoSeleccionado = riesgoIn;
    this.tituloRiesgo = riesgoIn.descripcion;
    const htmlreplace = this.replaceAll(riesgoIn.descripcionRiesgo,'class="ql-align-center"','style="text-align: center;padding: 0px;margin: 0px;"');
    this.htmlVistaPrevia = this.sanitizer.bypassSecurityTrustHtml(htmlreplace);
    this.vistaPrevia = true;
    this.vistaGeneral = false;
  }

  replaceAll(str : string, find: string, replace: string) {
    return str.split(find).join(replace);
  }

  editarRiesgo(){
    this.accionCrearEditar = "Editar Riesgo";
    this.vistaPrevia = false;
    this.visibleEditarCrear = true;
  }

  async guardar(){
    this.ip           = "192.168.0.221"; //obtener ip 
    this.nombreEquipo = "maquina 221"  ; //obtener nombre equipo

    if (this.accionCrearEditar == "Editar Riesgo"){
      await this.putPromesa().then((data: any) => {
        if (data.resCode == 0) {
          this.messageService.add({severity:'success', summary:'Editar Riesgo', detail:"Riesgo correctamente guardado"});
          
          this.visibleEditarCrear = false;
          this.vistaGeneral = true;
         
        } else {
          this.messageService.add({severity:'error', summary:'Editar Riesgo', detail:'Hubo un error al guardar el riesgo'});
          this.visibleEditarCrear = false;
          this.vistaGeneral = true;
        }
      });
    }else{
      console.log('post');
      await this.postPromesa(this.ip,
                             this.nombreEquipo,
                             this.usuariosesion.usuario,
                             this.riesgoSeleccionado.descripcion,
                             this.riesgoSeleccionado.descripcionRiesgo,
                             this.riesgoSeleccionado.estado
                             ).then((data: any) => {
        if (data.resCode == 0) {
          this.messageService.add({severity:'success', summary:'Agregar Riesgo', detail:"Riesgo correctamente guardado"});
          this.listarRiegos();       
          this.visibleEditarCrear = false;
          this.vistaGeneral = true;
        } else {
          this.messageService.add({severity:'error', summary:'Agregar Riesgo', detail:'Hubo un error al guardar el riesgo'});
                  
          this.visibleEditarCrear = false;
          this.vistaGeneral = true;
        }
        });
    }
  }

  regresar(){
    this.riesgoSeleccionado = new RiesgoContent('','','',new Date(),'',0,'','','');

    this.vistaPrevia = false;
    this.visibleEditarCrear = false;
    this.vistaGeneral = true;
  }

  putPromesa(){
    return new Promise((resolve)=>{
      
        this._riesgosService.putRiesgo(this.riesgoSeleccionado,this.usuariosesion).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _riesgosService.putRiesgo';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
      
    },
    );
  }

  postPromesa(ip:string,nombreEquipo:string,usuarioIngreso:string,descripcion :string,descripcionRiesgo: string, estado:string){
    return new Promise((resolve)=>{
        this._riesgosService.postRiesgo(ip,nombreEquipo,usuarioIngreso,descripcion,descripcionRiesgo,estado).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _riesgosService.postRiesgo';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    }
    );
  }

}



