import { Component, OnInit }                  from '@angular/core';
import { MantenimientoPreventivoService }     from '../../core/services/Mantenimiento-Preventivo.service';
import { MantenimientoPreventivoContent }     from '../../core/models/MantenimientoPreventivoContent';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IUsuario }                           from 'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';
import { MessageService } from 'primeng/api';

@Component({
  selector    : 'app-mantenimiento-preventivo',
  templateUrl : './mantenimiento-preventivo.component.html',
  styleUrls   : ['../estilos.scss']
})
export class MantenimientoPreventivoComponent implements OnInit {

  accionCrearEditar         : string                            = ""    ;
  listMantenimientos        : MantenimientoPreventivoContent[]  = []    ;
  mantenimientoForm         : FormGroup                                 ;
  mantenimiento?            : MantenimientoPreventivoContent            ;
  visibleSidebar            : boolean                           = false ;
  usuariosesion             : any                                       ;
  ip?                       : string                                    ;
  nombreEquipo?             : string                                    ;

  stateOptions = [{label: 'A', value: 'A'}, {label: 'I', value: 'I'}];

  loading                     : boolean = true;
  busque                      : boolean = false;

  constructor(private _mantenimientoService : MantenimientoPreventivoService,
              private fb                    : FormBuilder,
              private messageService: MessageService) { 

    this.mantenimientoForm= this.fb.group({
      nombre   : ['', Validators.required],
      detalle  : ['', Validators.required],
      estado   : ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.listarMantenimientos();

    const user: string = sessionStorage.getItem('userData') + '';
    this.usuariosesion = this.buildUserData(JSON.parse(user));
  }

  private buildUserData(user: any): IUsuario {
    const usuario: IUsuario = {
      id            : user.codigo,
      usuario       : user.usuario,
      codigoRol     : user.codigoRol,
    };
    return usuario;
  }

  async listarMantenimientos(){
    await this.getMantenimientos().then((data: any) => {
      if (data.resCode == 0) {
        this.listMantenimientos = data.resData;
        this.busque = true; 
      } else {
        this.messageService.add({severity:'error', summary:'Info Pagina', detail:'Error al cargar mantenimientos'});
        this.busque = true;
      }
    });

    this.loading = false;
  }

  getMantenimientos(){
    return new Promise((resolve)=>{
      this._mantenimientoService.getMantenimientos().subscribe({
        next: (res:any)=>{
          const data = { resCode: 0 , resData : res.pageContent };
          resolve(data);
        },
        error: (err)=>{
          const e='Error _mantenimientoService.getMantenimientos';
          const data = { resCode: -1, error: e };
          resolve(data);
        }
      });
    });
  }

  crearMantenimiento(){
    this.accionCrearEditar = "Crear Mantenimiento";

    this.mantenimiento = undefined;

    this.mantenimientoForm= this.fb.group({
      nombre    : ['', Validators.required],
      detalle   : ['', Validators.required],
      estado    : ['', Validators.required]
    });

    this.mantenimientoForm.setValue({
      nombre    : '',
      detalle   : '',
      estado    : ''
    });

    this.visibleSidebar = true;
  }

  editarMantenimiento(mantIn : MantenimientoPreventivoContent){
    this.accionCrearEditar = "Editar Mantenimiento";

    this.mantenimientoForm.setValue({
      nombre        : mantIn.nombre,
      detalle       : mantIn.detalle,
      estado        : mantIn.estado
    });

    this.mantenimiento  = mantIn;
    this.visibleSidebar = true;
  }

  async guardarMantenimiento(){
    this.ip           = "192.168.0.221"; //obtener ip 
    this.nombreEquipo = "maquina 221"  ; //obtener nombre equipo

    if(this.mantenimiento != null){
      this.mantenimiento.nombre  = this.mantenimientoForm.get('nombre')?.value;
      this.mantenimiento.detalle = this.mantenimientoForm.get('detalle')?.value;
      this.mantenimiento.estado = this.mantenimientoForm.get('estado')?.value;
      this._mantenimientoService.editarMantenimiento(this.mantenimiento, this.usuariosesion);
      this.visibleSidebar = false;
    }else{
      await this.postPromesa(this.ip, 
                             this.nombreEquipo,
                             this.usuariosesion.usuario,
                             this.mantenimientoForm.get('nombre')?.value,
                             this.mantenimientoForm.get('detalle')?.value,
                             this.mantenimientoForm.get('estado')?.value).then((data: any) => {
        if (data.resCode == 0) {
          this.messageService.add({severity:'success', summary:'Agregar Mantenimiento', detail:"Mantenimiento correctamente guardado"});
          this.listarMantenimientos();
          this.visibleSidebar = false;
        } else {
          this.messageService.add({severity:'error', summary:'Agregar Mantenimiento', detail:'Hubo un error al guardar el Mantenimiento'});
          this.visibleSidebar = false;
        }
      });
    }
  }

  postPromesa(ip:string,nombreEquipo:string,usuarioIngreso:string,nombre:string,detalle:string, estado : string){
    return new Promise((resolve)=>{
        this._mantenimientoService.crearMantenimiento(ip,nombreEquipo,usuarioIngreso,nombre,detalle,estado).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _seccionesService.editarSeccion';
            const data = { resCode: -1, error: e };
            resolve(data);
          }
        });
    });
  }

}
