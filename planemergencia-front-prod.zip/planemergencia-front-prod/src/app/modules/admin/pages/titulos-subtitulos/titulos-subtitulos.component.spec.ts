import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TitulosSubtitulosComponent } from './titulos-subtitulos.component';

describe('TitulosSubtitulosComponent', () => {
  let component: TitulosSubtitulosComponent;
  let fixture: ComponentFixture<TitulosSubtitulosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TitulosSubtitulosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TitulosSubtitulosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
