import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SeccionesContent } from '../../core/models/SeccionesContent';
import { SeccionesService } from '../../core/services/Seccion.service';
import {ConfirmationService, MessageService} from 'primeng/api';
import { IUsuario } from 'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';

@Component({
  selector: 'app-titulos-subtitulos',
  templateUrl: './titulos-subtitulos.component.html',
  styleUrls: ['../estilos.scss'],
  providers: [ConfirmationService,MessageService]
})
export class TitulosSubtitulosComponent implements OnInit {

  accionCrearEditar         : string                            = ""    ;
  seccionForm               : FormGroup                                 ;
  listTitulos               : SeccionesContent[]                = []    ;
  visibleSidebar            : boolean                           = false ;
  usuariosesion             : any                                       ;
  ip?                       : string                                    ;
  nombreEquipo?             : string                                    ;

  titulo?                   : SeccionesContent                          ;
  listSubTitulos            : SeccionesContent[]                = []    ;


  opcionesTipo = [{label: 'TITULO', value: 'TITULO'}, {label: 'SUBTITULO', value: 'SUBTITULO'}];
  stateOptions = [{label: 'A', value: 'A'}, {label: 'I', value: 'I'}];


  //Variables de nivel, padre, orden
  codigoPadre? : number;
  nivelPadre?  : number;

  useBotonGuardar   : boolean = false;

  loading                     : boolean = true;
  busque                      : boolean = false;

  constructor(private _seccionesService : SeccionesService,
              private fb                : FormBuilder,
              private confirmationService: ConfirmationService,
              private messageService: MessageService
              ) { 
    
    this.seccionForm= this.fb.group({
      titulo   : ['', Validators.required],
      orden    : ['', Validators.required],
      texto    : [''],
      tipo     : ['',Validators.required],
      estado   : ['',Validators.required]
    }); 
  }

  ngOnInit(): void {
    this.listarTitulos();
    const user: string = sessionStorage.getItem('userData') + '';
    this.usuariosesion = this.buildUserData(JSON.parse(user));
  }

  private buildUserData(user: any): IUsuario {
    const usuario: IUsuario = {
      id            : user.codigo,
      usuario       : user.usuario,
      codigoRol     : user.codigoRol,
    };
    return usuario;
  }

  async listarTitulos(){
    await this.getListarTitulos().then((data: any) => {
      if (data.resCode == 0) {
        this.listTitulos        = data.resData;
        this.busque = true;
      } else {
        this.messageService.add({severity:'error', summary:'Info pagina', detail:'Error al listar titulos'});
        this.busque = true;
      }
    });
    this.loading = false;
  }

  getListarTitulos(){
    return new Promise((resolve)=>{
      this._seccionesService.getSeccionByProperties(1,null).subscribe({
        next: (res:any)=>{
          const data = { resCode: 0, resData: res.pageContent };
          resolve(data);
        },
        error: (err)=>{
          const e='Error _seccionesService.getSeccionByProperties';
          const data = { resCode: -1, error: e };
          resolve(data);
        }
      });
    });
  }

  async editarTitulo(tituloIn : SeccionesContent){
    this.titulo = tituloIn;
    this.codigoPadre = tituloIn.id.codigo;
    this.nivelPadre = tituloIn.nivel;


    await this.getSubPromesa(tituloIn.nivel+1,tituloIn.id.codigo).then((data: any) => {
      if (data.resCode != 0) {
        this.messageService.add({severity:'error', summary:'Editar Titulo', detail:'Hubo un error al guardar el titulo'});
      }
    });

    this.accionCrearEditar = "Editar Titulo ";

    this.seccionForm= this.fb.group({
      titulo   : ['', Validators.required],
      orden   : ['', Validators.required],
      texto    : [''],
      tipo     : ['',Validators.required],
      estado   : ['',Validators.required]
    });

    this.seccionForm.setValue({
      titulo    : tituloIn.titulo,
      orden     : tituloIn.orden,
      texto     : tituloIn.texto,
      tipo      : tituloIn.identificadorCampo,
      estado    : tituloIn.estado
    });

    this.visibleSidebar = true;
  }

  //Funcion que llama a los metodos de guardado en la base
  async saveTitulo(){
    this.ip           = "192.168.0.221"; //obtener ip 
    this.nombreEquipo = "maquina 221"  ; //obtener nombre equipo
    
    //Editar
    if(this.titulo != null){
      
      this.titulo.estado                         = this.seccionForm.get('estado')?.value;

      this.titulo.texto                          = this.seccionForm.get('texto')?.value;
      this.titulo.orden                          = this.seccionForm.get('orden')?.value;
      
      this.titulo.identificadorCampo             = this.seccionForm.get('tipo')?.value;
      this.titulo.titulo                         = this.seccionForm.get('titulo')?.value;
      
      await this.putPromesa().then((data: any) => {
        if (data.resCode == 0) {
          this.messageService.add({severity:'success', summary:'Editar Titulo', detail:"Titulo correctamente guardado."});
          this.titulo = undefined;

          if(this.useBotonGuardar){
            this.listarTitulos();
            this.codigoPadre = undefined;
            this.nivelPadre  = undefined;

            this.visibleSidebar = false;
            this.useBotonGuardar = false;
          }else{
            this.agregar();
          }

        } else {
          this.titulo = undefined;
          this.messageService.add({severity:'error', summary:'Editar Titulo', detail:'Hubo un error al guardar el titulo'});
        }
      });
    
    //Guardar
    }else{
      let codigoPapa: number|null;
      let nivel     : number|null;

      if(this.codigoPadre != null){
        codigoPapa = this.codigoPadre;
      }else{
        codigoPapa = null;
      }

      if(this.nivelPadre != null){
        nivel = this.nivelPadre+1;
      }else{
        nivel = 1;
      }

      console.log(this.seccionForm.get('orden')?.value);
      
      await this.postPromesa(this.ip,
                             this.nombreEquipo,
                             this.usuariosesion.usuario,
                             this.seccionForm.get('titulo')?.value,
                             nivel,
                             this.seccionForm.get('orden')?.value,
                             this.seccionForm.get('texto')?.value,
                             this.seccionForm.get('estado')?.value,
                             codigoPapa,
                             this.seccionForm.get('tipo')?.value
                             ).then((data: any) => {
        if (data.resCode == 0) {
          //this.messageService.add({severity:'success', summary:'Editar Titulo', detail:'Titulo correctamente guardado'});
          this.messageService.add({severity:'success', summary:'Editar Titulo', detail:"Titulo correctamente guardado codigoPadre:"+this.codigoPadre+" Nivel padre: "+this.nivelPadre});
          this.titulo      = undefined;
          this.codigoPadre = undefined;
          this.nivelPadre  = undefined;
          this.listarTitulos();
          this.visibleSidebar = false;
          this.useBotonGuardar = false;
        } else {
          this.messageService.add({severity:'error', summary:'Editar Titulo', detail:'Hubo un error al guardar el titulo'});
          this.titulo = undefined;
          this.codigoPadre = undefined;
          this.nivelPadre  = undefined;
          this.listarTitulos();
          this.visibleSidebar = false;
          this.useBotonGuardar = false;
        }
      });
    }
  }

  putPromesa(){
    return new Promise((resolve)=>{
      if (this.titulo != null){
        this._seccionesService.putSeccion(this.titulo,this.usuariosesion).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _seccionesService.editarSeccion';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
      }
    },
    );
  }

  getSubPromesa(nivel:number,codigoSeccionPadre:number|null){
    return new Promise((resolve)=>{
        this._seccionesService.getSeccionByProperties(nivel,codigoSeccionPadre).subscribe({
          next: (res:any)=>{
            this.listSubTitulos = res.pageContent;
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _seccionesService.editarSeccion';
            const data = { resCode: -1, error: e };
            resolve(data);
          }
        });
    });
  }

  postPromesa(ip:string,nombreEquipo:string,usuarioIngreso:string,titulo:string,nivel:number,orden:number,texto:string,estado:string,codigoSeccionPadre:number|null,tipo:string){
    return new Promise((resolve)=>{
        this._seccionesService.postSeccion(ip,nombreEquipo,usuarioIngreso,titulo,nivel,orden,texto,estado,codigoSeccionPadre,tipo).subscribe({
          next: (res:any)=>{
            this.titulo = res;
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _seccionesService.editarSeccion';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    },
    );
  }
  //funcion del boton guardar del sidebar para que se cierre 
  guardar(){
    this.useBotonGuardar = true;
    this.saveTitulo();
  }
  
  agregarSubTitulo(){
    
    if(this.seccionForm.touched){
      this.confirmationService.confirm({
        message: 'Al crear un subtitulo se guardará la información actual del titulo. Desea continuar?',
        header: 'Confirmar',
        icon: 'pi pi-exclamation-triangle',
        acceptLabel: 'Si',
        accept: () => {
          this.accionCrearEditar = "Crear Subtitulo";
          this.listSubTitulos = [];
          this.saveTitulo();
        },
        reject: () => {
            
        }
      });
    }else{
      this.accionCrearEditar = "Crear Subtitulo";
      this.titulo = undefined;
      this.listSubTitulos = [];
      this.agregar();
    }
    
  }

  agregarTitulo(){
    this.accionCrearEditar = "Crear Titulo Principal";
    this.titulo = undefined;
    this.codigoPadre = undefined;
    this.nivelPadre  = undefined;
    this.listSubTitulos = [];
    this.agregar();
  }

  agregar(){
    this.seccionForm= this.fb.group({
      titulo   : ['', Validators.required],
      orden   : ['', Validators.required],
      texto    : [''],
      tipo     : ['',Validators.required],
      estado   : ['',Validators.required]
    });

    this.seccionForm.setValue({
      titulo    : '',
      orden     : '',
      texto     : '',
      tipo      : 'TITULO',
      estado    : ''
    });

    this.visibleSidebar = true;
  }


}
