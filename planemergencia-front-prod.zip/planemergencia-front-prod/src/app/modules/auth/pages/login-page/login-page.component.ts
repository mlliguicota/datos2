import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from
  '@angular/forms';
import { Router } from '@angular/router';
import { FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { Message } from 'primeng/api';
import { AuthService } from 'src/app/core/services/auth.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { faUser, faLock, faEye, faEyeSlash } from
  '@fortawesome/free-solid-svg-icons';
import { fas } from '@fortawesome/free-solid-svg-icons';
import { far } from '@fortawesome/free-regular-svg-icons';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss'],
})
export class LoginPageComponent implements OnInit {
  formLogin!: FormGroup;
  loading: boolean = false;
  mensajeSistema: Message[] = [];
  toastKey: any;
  usuario: any;
  showPass: boolean = false;
  //  temp para probar que hale el getTransacciones


  constructor(library: FaIconLibrary,
    private authService: AuthService,
    private router: Router,
    private fb: FormBuilder,
    private toast: ToastService,
  ) {
    this.toastKey = this.toast.genToastKey();
    library.addIcons(faUser, faLock, faEye, faEyeSlash);
    library.addIconPacks(fas, far);
  }

  ngOnInit(): void {
    this.loading=false;
    this.authService.logout();
    this.buildForm();
  }

  buildForm() {
    this.formLogin = this.fb.group({
      usuario: ['', [Validators.required, Validators.minLength(3)]],
      clave: ['', [Validators.required,
        Validators.minLength(3)]],
    });
  }

  public getError(controlName: string): string {
    const control: AbstractControl = this.formLogin.controls[controlName];
    if (control.touched && control.errors != null) {
      if (control.errors['required'] != null) {
        let campo = controlName;
        if (campo === 'usuario') {
          campo = 'usuario';
        } else {
          campo = 'contraseña';
        }
        return `El campo ${campo} es requerido.`;
      }
      if (controlName == 'usuario' && control.errors['minlength']) {
        return 'El usuario no es válido.';
      }
      if (control.errors['minlength']) {
        return 'La contraseña no tiene un formato válido,'+
        ' debe contener al menos un número, una letra mayúscula,'+
        ' una minúscula y tener de 3 a 8 dígitos.';
      }
    }
    return '';
  }


  ingresar() {
    if (this.formLogin.valid) {
      this.loading=true;
      console.log(this.formLogin.value.usuario);
      console.log(this.formLogin.value.clave);
      this.authService.login(this.formLogin.value.usuario,
          this.formLogin.value.clave)
          .then((data: any) => {
            if (data.resCode === 0) {
              this.obtenerUsuario();
            } else {
              this.toast.mostrarToastError(data.error, this.toastKey);
              console.log(data.error);
              this.router.navigate(['/']);
              this.loading=false;
            }
          }).catch((err) => {
            console.log(err);
            this.loading=false;
          });
    } else {
      this.loading=false;
      this.toast.mostrarToastError('Porfavor rellene los campos adecuadamente');
      console.log('Porfavor rellene los campos adecuadamente', this.toastKey);
    }
  }

  obtenerUsuario() {
    this.authService.obtenerUsuarioData(this.formLogin.value.usuario)
        .then((data: any) => {
          if (data.resCode === 0) {
            this.usuario = this.authService.getUsuarioData();
            if(this.usuario.estado == "A"){
              switch (this.authService.getRolUsuario().nombre) {
                case 'Insertador':
                  this.router.navigateByUrl('/principal/plan-de-emergencia');
                  break;
                case 'Consultor':
                  this.router.navigateByUrl('/consulta/consultaPlanes');
                  break;
                case 'ConsultMas':
                  this.router.navigateByUrl('/consulta/consultaPlanes');
                  break;
                case 'Administrador':
                  this.router.navigateByUrl('/admin/pageRoles');//cambio de ruta a roles andres
                  break;
              }
            }else{
              this.toast.mostrarToastError("Credenciales no validas", this.toastKey);
            }
            this.loading=false;
          } else {
            this.toast.mostrarToastError(data.error, this.toastKey);
            console.log(data.error);
            this.loading=false;
          }
        }).catch((err) => {
          console.log(err);
          this.loading=false;
        });
  }
}

