import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultaPlanesComponent } from './consulta-planes.component';

describe('ConsultaPlanesComponent', () => {
  let component: ConsultaPlanesComponent;
  let fixture: ComponentFixture<ConsultaPlanesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsultaPlanesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultaPlanesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
