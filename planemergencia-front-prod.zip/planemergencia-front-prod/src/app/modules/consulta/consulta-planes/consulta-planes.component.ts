import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { GenOficinaContent } from '../../admin/core/models/GenOficinaContent';
import { OficinaService } from '../../admin/core/services/Oficina.service';
import { IUsuario } from '../../plan-de-emergencia/core/interfaces/usuario.interface';
import Constantes from '../../plan-de-emergencia/core/util/constantes';
import { ArchivosPlanesService } from '../../admin/core/services/archivosPlanes.service';
import { ArchivosPlanesContent } from '../../admin/core/models/ArchivosPlanesContent';
import { MessageService } from 'primeng/api';
import { ArchivosoficinasService } from '../../plan-de-emergencia/core/services/archivosoficinas.service';
import { LideresPisoService } from '../../admin/core/services/LideresPiso.service';

@Component({
  selector: 'app-consulta-planes',
  templateUrl: './consulta-planes.component.html',
  styleUrls: ['./consulta-planes.component.scss']
})
export class ConsultaPlanesComponent implements OnInit {

  usuario: IUsuario = Constantes.USUARIO_DEFAULT;
  rolUsuarioLogin : any;

  listOficinas              : GenOficinaContent         [] = [];
  listArchivos              : ArchivosPlanesContent     [] = [];

  mostrarOficinaSingular  : boolean = false;
  mostrarSelectorOficinas : boolean = false;
  mensaje_vacio : boolean = false;
  hayArchivos             :boolean = false;

  oficinaSeleccionada       : boolean                      = false;
  codigoOficinaSeleccionada : number;
  noError :boolean = true;

  constructor(private _OficinaService           : OficinaService,
              private _authService              : AuthService,
              private _archivosService          : ArchivosPlanesService,
              private messageService            : MessageService,
              private _archivosoficinasService  : ArchivosoficinasService,
              private _lideresPisoService       : LideresPisoService) { }

  ngOnInit(): void {
    this.usuario = this._authService.getUsuarioData();
    console.log(this.usuario);
    this.rolUsuarioLogin = this._authService.getRolUsuario().nombre;
    //this.rolUsuarioLogin= 'ConsultMas'; //por el momento haremos como que siempre es este
    this.cargarOficinas();
  }

  cargarOficinas(){
    if(this.rolUsuarioLogin != null){
      if(this.rolUsuarioLogin=='Consultor'){
        //Lo de aqui se hara cuando este el api que falta
        this.obtenerOficinasByUsuario();
      }else if (this.rolUsuarioLogin=='ConsultMas'){
        this.obtenerOficinas();
      
      }else if (this.rolUsuarioLogin=='Administrador'){  //24/06/2024 amdres campaña
        this.obtenerOficinas();
      }
    }
  }

  async obtenerOficinasByUsuario(){
    //1 Aqui se llama al nuevo api y debo buscar por usuarioSfsf y de la respuesta sacar el campo nombre
    let nombreOficina = ''; //Por el momento sera siempre Centrum
    //2 obtener oficinas por nombre

    await this.obtenerInfoLiderPiso(this.usuario.usuario).then((data: any) => {
      if (data.resCode != 0) {
        this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener oficina del usuario'});
        this.mensaje_vacio = true; //andres campaña mostrar mensaje de que no existen archivos 
      }else{
        if(data.resData.length>0){
          nombreOficina = data.resData[0].nombre;
        }else{
          this.messageService.add({severity:'warn', summary:'Información pagina', detail:'Error al obtener oficina del usuario'});
          this.noError = false;
          this.mensaje_vacio = true;
        }


      }
    });

    if(this.noError){
      await this.obtenerOficinasByName(nombreOficina).then((data: any) => {
        if (data.resCode != 0) {
          this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener oficina'});
          this.mensaje_vacio = true;
        }else{
          this.listOficinas = data.resData;
          if (this.listOficinas.length>0){
            this.codigoOficinaSeleccionada = this.listOficinas[0].id.codigo;
            this.mostrarOficinaSingular = true;
            this.listarArchivos(this.codigoOficinaSeleccionada);
          }

        }
      });
    }

  }

  obtenerInfoLiderPiso(userName:string){
    return new Promise((resolve)=>{
      this._lideresPisoService.getInfoByUserName(userName).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 , resData : res.pageContent};
            resolve(data);
          },
          error: (err)=>{
            const e='Error this._lideresPisoService.getInfoByUserName';
            const data = { resCode: -1, error: e };
            resolve(data);
          }
        });
    });
  }

  obtenerOficinasByName(name:string){
    return new Promise((resolve)=>{
      this._OficinaService.getOficinasByNombre(name).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 , resData : res.pageContent};
            resolve(data);
          },
          error: (err)=>{
            const e='Error this._OficinaService.getOficinasByNombre';
            const data = { resCode: -1, error: e };
            resolve(data);
          }
        });
    });
  }

  obtenerOficinas(){
    this._OficinaService.getOficinas().subscribe(
      data => {
        this.listOficinas = data.pageContent;
        this.mostrarSelectorOficinas = true;
        console.log('hola');
      }, error => {
        console.log(error);
      }
    );
  }

  async listarArchivos(codigoOficina:number){
    this.oficinaSeleccionada = false;
    this.hayArchivos = false;

    await this.getPromesa(codigoOficina).then((data: any) => {
      if (data.resCode == 0) {
        if(this.listArchivos.length>0){
          this.oficinaSeleccionada = true;
          this.hayArchivos = true;
        }else{
          this.oficinaSeleccionada = true;
          this.hayArchivos = false;
          //mostrar no se encontro archivos en la oficina
        }
      }else{
        this.oficinaSeleccionada = true;
        this.hayArchivos = false;
        //mostrar no se encontro archivos en la oficina
      }
    });
  }

  cargarDocumentos(event:any) {
    let codigoOficina = event.value;
    this.listarArchivos(codigoOficina);
  }

  getPromesa(codigoOficina:number){
    return new Promise((resolve)=>{
        this._archivosService.getByOficina(codigoOficina).subscribe({
          next: (res:any)=>{
            this.listArchivos = res.pageContent;


            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _seccionesService.editarSeccion';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });

    },
    );
  }

  /*descargarArchivo(ruta:string){
     this.messageService.add({severity:'success', summary:'Info descarga', detail:'Se descargara el archivo de la ruta: '+ruta});
  }*/


  async descargarArchivo(path : string,nombreArchivo:string){
    this.messageService.add({severity:'success', summary:'Info descarga', detail:'Se descargara el archivo: '+nombreArchivo});
    console.log(path);

    let ruta= path.substring(1).replace('/',  `%2F`);
    console.log(ruta);

    let documento : any = await this._archivosoficinasService.obtenerArchivo(nombreArchivo,ruta ).toPromise();

    this.downloadPdf(documento.archivoBase64 ,documento.nombreArchivo);
    console.log(documento.nombreArchivo);
    console.log(documento.archivoBase64);
  }

  downloadPdf(pdf :string, fileName :string) {
    const link = document.createElement("a");
    link.href = pdf;
    link.download = fileName
    link.click();
  }

}
