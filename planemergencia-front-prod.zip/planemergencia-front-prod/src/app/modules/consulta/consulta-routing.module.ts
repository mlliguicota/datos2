import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConsultaPlanesComponent } from './consulta-planes/consulta-planes.component';
const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'consultaPlanes',
        component: ConsultaPlanesComponent
      },
      {
        path: '**',
        redirectTo: '/consulta/consultaPlanes'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConsultaRoutingModule { }