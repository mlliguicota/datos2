import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsultaPlanesComponent } from './consulta-planes/consulta-planes.component';
import { ConsultaRoutingModule } from './consulta-routing.module';
import { PrimeNgModule } from '../prime-ng/prime-ng.module';
import { PrincipalModule } from "../../principal/principal.module";
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToastModule } from 'primeng/toast';

@NgModule({
    declarations: [
        ConsultaPlanesComponent
    ],
    imports: [
        CommonModule,
        ConsultaRoutingModule,
        PrimeNgModule,
        PrincipalModule,
        ConfirmDialogModule,
        ToastModule
    ]
})
export class ConsultaModule { }
