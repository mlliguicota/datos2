import { Component, Input, OnChanges, OnInit, SimpleChanges } from
  '@angular/core';
import { PopupService } from 'src/app/core/services/popup.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { Mood } from '../../core/enums/mood.enum';
import { INivel } from '../../core/interfaces/nivel.interface';
import { IOficina } from '../../core/interfaces/oficina.interface';
import { FloorService } from '../../core/services/floor.service';
import { SharingFloorsService } from
  '../../core/services/sharing-floors.service';
import Constantes from '../../core/util/constantes';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-floors-table',
  templateUrl: './floors-table.component.html',
  styleUrls: ['./floors-table.component.scss'],
})
export class FloorsTableComponent implements OnChanges, OnInit {
  @Input() currentOffice: IOficina = Constantes.OFICINA_DEFAULT;
  niveles: INivel[] = [Constantes.NIVEL_DEFAULT];
  // Variables for the popUp input
  outputPlanta: INivel = Constantes.NIVEL_DEFAULT;
  editablePopUp = false;
  loading: boolean = true;

  totalEmpleados: any;
  hombres: any;
  mujeres: any;
  toastKey: any;

  constructor(private popUpService: PopupService,
    private _floorService: FloorService,
    private toast: ToastService,
    private sharingFloors: SharingFloorsService,
    private confirmationService: ConfirmationService,
  ) {
    this.toastKey = this.toast.genToastKey();
  }
  ngOnInit(): void {
  //  this.loading= true;
  }
  ngOnChanges(_changes: SimpleChanges): void {
    console.log("INGRESE a ON chage")
    this.loading = true;
    const empresa = this.currentOffice.id.codigoEmpresa;
    const oficina = this.currentOffice.id.codigo;
    this.fillNumberPeopleInformation();
    this.obtenerNiveles(empresa, oficina);
  }
  // Show the popUp component
  showModalDialog() {
    this.outputPlanta = Constantes.NIVEL_DEFAULT;
    this.editablePopUp = false;
    this.popUpService.SharingPopUpObservableData = true;
  }

  // Update the floors added or deleted by the user
  refreshData() {
    this.niveles = this.sharingFloors.sharingFloorData;
  }

  // public methods
  deleteFloor(nivel: INivel) {
    this.confirmationService.confirm({
      message: 'Esta seguro que de desea eliminar este Nivel?',
      header: 'Confirmacion',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.toast.mostrarToastSuccess('El nivel ha sido eliminado exitosamente.', this.toastKey);
        this.sharingFloors.SharingRemoveFloorObservableData = nivel;
      },
      reject: (type: any) => {
        this.toast.mostrarToastError('El procedimiento ha sido rechazado.', this.toastKey);
      },
    });
  }
  editFloorData(planta: INivel) {
    this.outputPlanta = planta;
    this.editablePopUp = true;
    this.popUpService.SharingPopUpObservableData = true;
  }
  // private methods
  private obtenerNiveles(codigoEmpresa: number, codigoOficina: number) {
    console.log("ANtes de AL if")
    if (codigoEmpresa == null || codigoOficina == null || codigoEmpresa === undefined || codigoOficina === undefined) {
       this.niveles = new Array<INivel>();
    /* this.niveles.push(Constantes.NIVEL_DEFAULT);
     // this.sharingFloors.SharingFloorsObservableData = this.niveles;
      this.sharingFloors.SharingAddFloorObservableData=  Constantes.NIVEL_DEFAULT
      this.sharingFloors.SharingFloorsObservableData = this.niveles
      this.sharingFloors.originalFloorList = this.niveles;
     */
      this.loading = false;
      console.log("INGRESE AL if")
      
    }else {
      console.log("INGRESE con datos")
      this._floorService.obtenerFloorsData(codigoEmpresa, codigoOficina)
      .then(async (data: any) => {
        if (data.resCode == 0) {
          // Cargar los datos en las tablas
          this.niveles = await this.buildCompleteFloorList(
            this._floorService.getFloorsData());
          this.sharingFloors.SharingFloorsObservableData = this.niveles;
          this.sharingFloors.originalFloorList = this.niveles;
          if (this.niveles.length<1) this.niveles=[Constantes.NIVEL_DEFAULT];
          // this.fillNumberPeopleInformation(this.niveles);
          this.loading = false;
        } else {
          this.toast.mostrarToastError('Error al cargar los niveles!!,' +
            ' intentelo de nuevo por favor.', this.toastKey);
        }
      }).catch((err) => {
        console.log(err);
      });

    }
   
  }
  thereIsANivel() {
    const floor:INivel[]=this.sharingFloors.sharingFloorData;
    return floor.length>0;
  }
  // It fill only the information get by the GET request
  private fillNumberPeopleInformation() {
    /* let employees=0;
    let men=0;
    let women=0;
    for (const nivel of niveles) {
      employees+=nivel.totalEmpleados;
      men+=nivel.totalHombres;
      women+=nivel.totalMujeres;
    }*/
    this.totalEmpleados = this.currentOffice.totalEmpleados;
    this.hombres = this.currentOffice.cantidadHombres;
    this.mujeres = this.currentOffice.cantidadMujeres;
  }
  private buildCompleteFloorList(niveles: any[]) {
    const floors: INivel[] = [];
    for (const nivel of niveles) {
      const floor: INivel = this.buildNivel(nivel);
      floors.push(floor);
    }
    return floors;
  }
  private buildNivel(resNivel: any): INivel {
    const nivel: INivel = {
      id: resNivel.codigo,
      codigoOficina: resNivel.codigoOficina,
      codigoEmpresa: resNivel.codigoEmpresa,
      numeroPiso: resNivel.numeroPiso,
      nivel: resNivel.descripcion,
      areaTotal: resNivel.areaTotal,
      areaUtil: resNivel.areaUtil,
      totalHombres: resNivel.totalHombres,
      totalMujeres: resNivel.totalMujeres,
      totalEmpleados: resNivel.totalEmpleadosPiso,
      servicios: resNivel.serviciosComplementarios,
      visitantes: resNivel.visitantes,
      mood: Mood.ORIGINAL,
    };
    return nivel;
  }
}
