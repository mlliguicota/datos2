import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ToastService } from 'src/app/core/services/toast.service';
import { IOficina } from '../../core/interfaces/oficina.interface';
import { ITipoOficina } from '../../core/interfaces/tipoOficina.interface';
import { OfficeService } from '../../core/services/office.service';
import { SharingFloorsService } from
  '../../core/services/sharing-floors.service';
import { SharingOfficeService } from
  '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';
import { IUsuario } from '../../core/interfaces/usuario.interface';
import { AuthService } from 'src/app/core/services/auth.service';
import { MessageService } from 'primeng/api';
import { ɵHttpInterceptingHandler } from '@angular/common/http';
import { GenService } from 'src/app/core/services/gen.service';
import { error } from 'console';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss'],
})
export class FormComponent implements OnInit {
  currentOffice: IOficina = Constantes.OFICINA_DEFAULT;
  // EventEmitter
  notShowBody: boolean = true;
  @Output() defaultOfficeBoolEmitter = new EventEmitter<boolean>();
  @Output() activeLoading = new EventEmitter<boolean>(false);
  // Oficinas
  officesList: IOficina[] = [];
  officesListAux: IOficina[] = [];

  // Filter var
  officeTypes: any[];//ESTA VARIABLE TRAE SOLO LAS OFICINAS ACTIVAS
  officeNames: any[] = [];
  officeTypesAll: any []; //SUD CAMBIO CESAR SANCHEZ 30/08/2024
  /*SE AGREGO ESTA VARIABLE PARA TRAER TODAS LAS OFICINAS*/

  selectedOfficeType: any;
  selectedOfficeName: any;
  editable: boolean = false;
  toastKey: any;
  searched: boolean = false;
  loading: boolean = true;
  // input
  razonSocial: string = '';
  edificacion: string = '';
  ciudad: string = '';
  provincia: string = '';
  direccion: string = '';

  telefono: string = '';
  fax: string = '';
  correo: string = '';
  actividadEmpresa: string = '';
  procesos: string = '';

  DescripcionTipoOficina: string;
  codigoTipoOficina: number;
  actualizar: boolean =false;
  nuevoPlan: boolean =false;
  error: boolean =true;

  constructor(private _officeService: OfficeService,
    private toast: ToastService,
    private sharingOffice: SharingOfficeService,
    private sharingFloors: SharingFloorsService,
    private authService: AuthService,
    private officeService: OfficeService,
    private messageService: MessageService,
    private _genService : GenService ,) {
    // this.loadLazyData();

  }

  async ngOnInit() {
    this.obtenerTiposOficinas();
    console.log(this.sharingOffice.currentOfficeData);
    if (this.sharingOffice.currentOfficeData.id.codigo != -1) {
      this.activeLoading.emit(true);
      this.selectedOfficeType = this.sharingOffice.currentOfficeData.codigoTipoOficina;
      await this.onChangeOficinas({ value: this.sharingOffice.currentOfficeData.codigoTipoOficina });
      console.log(JSON.stringify(this.officeNames));
      setTimeout(() => {
        this.selectedOfficeName = this.sharingOffice.currentOfficeData.edificacionOficina;
        this.sharingOffice.currentOfficeData.fax
        //this.buscar();
        this.activeLoading.emit(false);
      }, 1000);
    }
  }
  private buildUserData(user: any): IUsuario {
    const usuario: IUsuario = {
      id: user.codigo,
      usuario: user.usuario,
      codigoRol: user.codigoRol,
    };
    return usuario;
  }
  /*public verificar_plan() { // 21/6/2024
    //this.sharingFloors.restartSharing();
    //this.sharingOffice.restartSharing();
    const oficinas = this._officeService.getOfficesData();
    for (const oficina of this.officesList) {

        if (this.selectedOfficeName == oficina.edificacionOficina && this.selectedOfficeType == oficina.codigoTipoOficina ) {
            this.buscar();
            this.actualizar = true;
            this.error = false;
            this.nuevoPlan = false;
            console.log(this.actualizar + ' actualizar');
            console.log(this.selectedOfficeType);
            console.log(oficina.codigoTipoOficina);
            console.log(this.sharingOffice.currentOfficeData.id.codigo);
            console.log(this.actualizar);
            console.log(this.nuevoPlan + ' nuevoPlan');
            console.log('if 1');
            console.log(this.sharingOffice.currentOfficeData.actividadEmpresa);
            console.log(oficina.id.codigo);
            console.log(oficina);
           
        }else if(this.selectedOfficeName == oficina.edificacionOficina && this.sharingOffice.currentOfficeData.id.codigo == -1
           ){
          this.buscar();
            this.nuevoPlan = true;
            this.error = false;
            this.actualizar = false;
            console.log(this.selectedOfficeType);
            console.log(oficina.codigoTipoOficina);
            console.log(this.sharingOffice.currentOfficeData.id.codigo);
            console.log(this.actualizar);
            console.log(this.nuevoPlan + ' nuevoPlan');
            console.log('if 2');
            console.log(this.sharingOffice.currentOfficeData.actividadEmpresa);
          console.log(oficina.id.codigo);
          console.log(oficina);

            
           
        }else if(this.selectedOfficeName == oficina.edificacionOficina &&
          this.selectedOfficeType != oficina.codigoTipoOficina  ){
          this.messageService.add({ severity: 'warn', summary: 'Información página', detail: 'Centro ya tiene un plan de emergencia creado para '+this.selectedOfficeType});
          console.log(this.selectedOfficeType);
          console.log(oficina.codigoTipoOficina);
          console.log(this.sharingOffice.currentOfficeData.id.codigo);
          console.log(this.actualizar);
          console.log(this.sharingOffice.currentOfficeData.actividadEmpresa);
          console.log(this.nuevoPlan + ' nuevoPlan');
          console.log('else');
          console.log(oficina.id.codigo);
          console.log(oficina);
            break;
        }

        /*if (this.selectedOfficeName == oficina.edificacionOficina && this.sharingOffice.currentOfficeData.id.codigo == -1) {
            this.buscar();
            this.nuevoPlan = true;
            this.actualizar = false;
            console.log(this.nuevoPlan + ' nuevoPlan');
            this.sharingFloors.restartSharing();
            this.sharingOffice.restartSharing();
            break;
        }*/
        
        /*if (this.selectedOfficeName == oficina.edificacionOficina && this.selectedOfficeType != oficina.codigoTipoOficina) {
            this.messageService.add({ severity: 'warn', summary: 'Información página', detail: 'Centro ya tiene un plan de emergencia creado' });
            console.log(this.selectedOfficeType);
            console.log(oficina.codigoTipoOficina);
            console.log(this.sharingOffice.currentOfficeData.id.codigo);
            break;
        }
    }
    this.sharingOffice.restartSharing();
    this.sharingFloors.restartSharing();
    this.actualizar = false;
    this.nuevoPlan = false;
    console.log('cambio1')
    
    console.log('cambio2')
    this.error = true;
}*/

  public async verificar_plan() {
    
    this.sharingFloors.restartSharing();
    this.sharingOffice.restartSharing();

    const oficinas = this.officesList;

    console.log("-----oficinasConfiguradas Inicial-----");
    const oficinasConfiguradas = oficinas.filter(oficina => {
      return oficina.edificacionOficina === this.selectedOfficeName;
    });

    console.log(" [VERIFICARPLAM oficinasConfiguradas] -> " + oficinasConfiguradas.length);

    console.log("-----Validacion 01-----");
      if (oficinasConfiguradas[0].codigoTipoOficina && this.selectedOfficeType === oficinasConfiguradas[0].codigoTipoOficina) { //cuando ya existe un plan de emergencia 
        this.buscar();
        console.log('ACTUALIZAR');
      } else {
        this.messageService.add({
          severity: 'info',
          summary: 'Informacion',
          detail: 'Obteniendo datos de la oficina ,por favor espere un momento...',
          life: 11000
        });
        //se traen las oficinas que tienen un tipo definido por la oficina seleccionada
        console.log("-----oficinasConfiguradasBD-----");
        let bandNuevo: boolean = true;
        for(const e of this.officeTypesAll){//SE REEMPLASO LA VARIABLE officeTypes POR LA NUEVA VARIABLE QUE TRAE TODAS LAS OFICINAS Y REALIZA LAS VALIDACIONES
          if(Number(this.selectedOfficeType) !== Number(e.codigo)){
            console.log("Validando para Tipo de Oficina: " + e.codigo);
            await this.obtenerOficinas(e.codigo, "A");
            this.codigoTipoOficina=e.codigo;
            console.log("====DATOS OBTENIDOS====")

            console.log("====Filtrando por el Nombre de la Oficina Seleccionada====")
            const oficinasConfiguradasBD = this.officesListAux.filter(oficina=> oficina.codigoTipoOficina && oficina.edificacionOficina===this.selectedOfficeName);
            console.log("oficinasConfiguradasBD -> " + oficinasConfiguradasBD.length)

            if(oficinasConfiguradasBD.length > 0){
              console.log("=====No es nueva oficina=====");
              bandNuevo = false;
              break;
            }
          }
        }
        //obtener la descripcion de tipo de oficina segun el codigo de tipo de oficina
        const tiposOficina = this.officeService.getOfficeTypesData()
        console.log(this.officesListAux);
        for (const tipo of tiposOficina){
          if(tipo.codigo == this.codigoTipoOficina){
            this.DescripcionTipoOficina=tipo.descripcion;
          }
        }

        //la oficina es otro tipo de oficina
        console.log("-----Validacion 02-----");
        if(!bandNuevo){
          this.messageService.add({
            severity: 'warn',
            summary: 'Información página',
            detail: 'Centro ya tiene un plan de emergencia creado con tipo de oficina '+this.DescripcionTipoOficina,
            life:5000 
          });
        }else{//nueva conf de oficina
          this.buscar();
          console.log("NUEVO");
        }

      }
    /* } else {
      this.buscar();
      console.log(this.selectedOfficeType);
      console.log(oficinasFiltradas[0].codigoTipoOficina);
      console.log(this.sharingOffice.currentOfficeData.id.codigo);
      console.log('Nuevo plan');
      console.log(oficinasFiltradas[0].id.codigo);
      console.log(oficinasFiltradas[0]);
    } */

  } 


  async buscar() {
    
    // Reiniciando los sharing
    this.sharingFloors.restartSharing();
    this.sharingOffice.restartSharing();
    
    for (const oficina of this.officesList) {
      if ( // this.selectedOfficeType == oficina.tipoOficina &&
        this.selectedOfficeName == oficina.edificacionOficina) {
          //console.log(this.selectedOfficeType);
          //console.log(oficina.codigoTipoOficina);  
        this.searched = true;
        this.currentOffice = oficina;
        this.sharingOffice.SharingOfficeObservableData = this.currentOffice;
        this.notifyOfficeChange();
        // Put the editable value of the form
        this.telefono = this.currentOffice.telefono;
        this.fax = this.currentOffice.fax;
        this.correo = this.currentOffice.correo;
        this.actividadEmpresa = this.currentOffice.actividadEmpresa;
        this.procesos = this.currentOffice.procesosOficina;
        this.razonSocial = this.currentOffice.razonSocial;
        this.edificacion = this.currentOffice.edificacionOficina;
        this.ciudad = this.currentOffice.ciudadOficina;
        this.provincia = this.currentOffice.provinciaOficina;
        this.direccion = this.currentOffice.direccionOficina;
        return;
      }
    }
    this.searched = false;
    
  }
  changeInputOficina() {
    this.currentOffice.telefono = this.telefono;
    this.currentOffice.fax = this.fax;
    this.currentOffice.correo = this.correo;
    this.currentOffice.actividadEmpresa = this.actividadEmpresa;
    this.currentOffice.procesosOficina = this.procesos;
    this.sharingOffice.SharingOfficeObservableData = this.currentOffice;
  }

  async onChangeOficinas(e: any) {
    console.log("Ingreso seleccione tipo oficina")
    console.log(e);
    console.log(e.value);
    console.log(this.selectedOfficeType);
    this.loadLazyData();
    await this.obtenerOficinas(e.value, "N");
    this.currentOffice = Constantes.OFICINA_DEFAULT;
    this.sharingOffice.SharingOfficeTypeCodigoData=e.value;
    this.notifyOfficeChange();
  }
  private loadLazyData() {
    this.officeNames = [];
    this.loading = true;
    const objt = {
      descripcion: 'empty',
      codigo: 'empty',
    };
    this.officeNames.push(objt);
    this.officeNames.push(objt);
  }
  private notifyOfficeChange() {
    this.notShowBody = this.currentOffice == Constantes.OFICINA_DEFAULT;
    this.defaultOfficeBoolEmitter.emit(this.notShowBody);
  }
  private cargarNombreOficina() {
    this.officeNames = [];
    for (const oficina of this.officesList) {
      this.officeNames.push({
        value: oficina.edificacionOficina,
        name: oficina.edificacionOficina,
      });
    }
  }

  private async obtenerOficinas(codigoTipoOficina: number, tipo: string) {
    await this._officeService.obtenerOfficeInformationData()
      .then(async (data: any) => {
        if (data.resCode == 0) {
          const oficinasInformacion = this._officeService.getOfficesInformationData();

          
            await this._officeService.obtenerOfficesData(codigoTipoOficina)
            .then((data: any) => {
              if (data.resCode == 0) {
                const oficinas = this._officeService.getOfficesData();

                if(tipo==="N") this.officesList=this.officeMerge(oficinasInformacion, oficinas);
                else if(tipo==="A") this.officesListAux=this.officeMerge(oficinasInformacion, oficinas);

                this.cargarNombreOficina();
                this.loading = false;
              } else {
                this.toast.mostrarToastError('Hubo un problema al cargar los datos' +
                  ', por favor intentelo mas tarde', this.toastKey);
              }
            });
          

        } else {
          this.toast.mostrarToastError('Hubo un problema al cargar los datos' +
            ', por favor intentelo mas tarde', this.toastKey);
        }
      });
  }
  // Obtener tipos oficina
  /*
  private async obtenerTiposOficinas() {
    await this._officeService.obtenerOfficeTypesData()
      .then((data: any) => {
        if (data.resCode == 0) {
          const oficinas = this._officeService.getOfficeTypesData();

          console.log("rueba oficina " , oficinas);

          this.officeTypes = this.buildCompleteOfficeType(oficinas);
          this.loading = false;
        } else {
          this.toast.mostrarToastError('Hubo un problema al cargar los datos' +
            ', por favor intentelo mas tarde', this.toastKey);
        }
      });
  }
*/

/* Garantizar que solo se muestre los tipos de oficina con estado A - Modificado SUD-BCALVOPIÑA 8/01/2024 */
private async obtenerTiposOficinas() {
  await this._officeService.obtenerOfficeTypesData()
    .then((data: any) => {
      if (data.resCode == 0) {
        let oficinas = this._officeService.getOfficeTypesData();

        // Filtrar para incluir solo oficinas con estado 'A'
        this.officeTypesAll = this.buildCompleteOfficeType(oficinas);
        oficinas = oficinas.filter(oficina => oficina.estado === 'A');

        console.log("Prueba oficina ", oficinas);
        

        this.officeTypes = this.buildCompleteOfficeType(oficinas);
        console.log(this.officeTypes);
        this.loading = false;
      } else {
        this.toast.mostrarToastError('Hubo un problema al cargar los datos' +
          ', por favor intente lo más tarde', this.toastKey);
      }
    });
}


  private buildCompleteOfficeType(officeTypeList: any[]): ITipoOficina[] {
    const officesData: ITipoOficina[] = [];
    for (const tipo of officeTypeList) {
      officesData.push(this.buildOfficeType(tipo));
    }
    return officesData;
  }

  private officeMerge(officeInformationList: any, officeDataList: any): IOficina[] {
    const officeList: IOficina[] = [];
    for (const officeInformation of officeInformationList) {
      const match = officeDataList.find((element: any) => element.nombreOficina == officeInformation.edificacionOficina);
      const oficina = this.buildOffice(officeInformation, match);
      officeList.push(oficina);
    }
    return officeList;
  }
  private buildOffice(officeInformation: any, officeData: any): IOficina {
    const oficina: IOficina = {
      // Informacion oficina
      razonSocial: officeInformation.razonSocial,
      edificacionOficina: officeInformation.edificacionOficina,
      ciudadOficina: officeInformation.ciudadOficina,
      provinciaOficina: officeInformation.provinciaOficina,
      direccionOficina: officeInformation.direccionOficina,
      totalEmpleados: officeInformation.totalEmpleados,
      cantidadHombres: officeInformation.cantidadHombres,
      cantidadMujeres: officeInformation.cantidadMujeres,
      liderPiso: officeInformation.liderPiso,
      // Office editable data
      id: {
        codigo: officeData?.id.codigo,
        codigoEmpresa: officeData?.id.codigoEmpresa,
      },
      nombreOficina: officeData?.nombreOficina,
      codigoTipoOficina: officeData?.codigoTipoOficina,
      telefono: officeData?.telefono,
      fax: officeData?.fax,
      actividadEmpresa: officeData?.actividadEmpresa,
      correo: officeData?.correo,
      procesosOficina: officeData?.procesosOficina,
      rutaFachada: officeData?.rutaFachada,
      rutaUbicacion: officeData?.rutaUbicacion,
      poblacionTrabajadora: officeData?.poblacionTrabajadora,
      rutasEvacuacion: officeData?.rutasEvacuacion,
    };
    return oficina;
  }
  private buildOfficeType(resOffice: any): ITipoOficina {
    const oficina: ITipoOficina = {
      codigo: resOffice.codigo,
      descripcion: resOffice.descripcion,
    };
    return oficina;
  }
  
}
