import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HazardFooterComponent } from './hazard-footer.component';

describe('HazardFooterComponent', () => {
  let component: HazardFooterComponent;
  let fixture: ComponentFixture<HazardFooterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HazardFooterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HazardFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
