import { Component, Input, OnChanges, OnInit, SimpleChanges } from
  '@angular/core';
import { IOficina } from '../../core/interfaces/oficina.interface';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';

@Component({
  selector: 'app-hazard-footer',
  templateUrl: './hazard-footer.component.html',
  styleUrls: ['./hazard-footer.component.scss'],
})
export class HazardFooterComponent implements OnInit, OnChanges {
  @Input() currentOffice:IOficina=Constantes.OFICINA_DEFAULT;
  poblacion:any;
  evacuacion:any;
  filesLocalidad:any[]=[];
  filesGeoubicacion:any[]=[];
  constructor( private sharingOffice:SharingOfficeService) {}
  ngOnChanges(changes: SimpleChanges): void {
    this.evacuacion=this.currentOffice.rutasEvacuacion;
    this.poblacion=this.currentOffice.poblacionTrabajadora;
  }
  ngOnInit(): void {}

  changesInputPoblacion(e:any) {
    console.log(e.value)
    this.sharingOffice.setPoblacion(e.value);
  }
  changesInputEvacuacion(e:any) {
    console.log(e.value)
    this.sharingOffice.setEvacuacion(e.value);
  }

}
