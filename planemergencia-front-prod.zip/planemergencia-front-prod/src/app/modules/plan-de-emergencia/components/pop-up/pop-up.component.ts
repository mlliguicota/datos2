import { Component, EventEmitter, Input, OnChanges, OnInit, Output,
  SimpleChanges } from '@angular/core';
import { Observable } from 'rxjs';
import { PopupService } from 'src/app/core/services/popup.service';
import { AbstractControl, FormBuilder, FormGroup, Validators } from
  '@angular/forms';
import { ToastService } from 'src/app/core/services/toast.service';
import Constantes from '../../core/util/constantes';
import { INivel } from '../../core/interfaces/nivel.interface';
import { Mood } from '../../core/enums/mood.enum';
import { SharingOfficeService } from
  '../../core/services/sharing-office.service';
import { SharingFloorsService } from
  '../../core/services/sharing-floors.service';
@Component({
  selector: 'app-pop-up',
  templateUrl: './pop-up.component.html',
  styleUrls: ['./pop-up.component.scss'],
})
export class PopUpComponent implements OnInit, OnChanges {
  toastKey: any;
  @Input() inputFloor=Constantes.NIVEL_DEFAULT;
  @Input() editable=false;
  // EventEmitter
  @Output() peopleUpdate = new EventEmitter();

  display$: Observable<Boolean>;
  // Form vars
  formPopUp!: FormGroup;
  private static ID_NIVEL=-1;
  maxFractionDigits:number=4;
  minFractionDigits:number=1;

  constructor(private PopUpService: PopupService,
    private fb: FormBuilder, private toast: ToastService,
    private sharingOffice:SharingOfficeService,
    private sharingFloors: SharingFloorsService) {
    this.display$ = this.PopUpService.SharingPopUpObservable;
    this.toastKey = this.toast.genToastKey();
  }
  ngOnChanges(changes: SimpleChanges): void {
    // Take care about the REbuilding of the form on the ngOnInit()
    if (this.editable) this.putInputValues();
  }

  ngOnInit(): void {
    this.buildForm();
    if (this.editable) this.putInputValues();
  }

  buildForm() {
    const initialValue=0; //21/06/2024
    this.formPopUp = this.fb.group({
      nivel: ['', [Validators.required, Validators.maxLength(30)]],
      piso: ['', [Validators.required, Validators.pattern('^[0-9]*$'),
      Validators.min(-1)]],
      areaTotal: ['', [Validators.required, Validators.pattern('^[0-9]+([.][0-9]{1,4})?$'),
        Validators.min(initialValue)]],
      areaUtil: ['', [Validators.required, Validators.pattern('^[0-9]+([.][0-9]{1,4})?$'),
        Validators.min(initialValue)]],
      totalHombres: ['', [Validators.required, Validators.pattern('^[0-9]*$'),
        Validators.min(initialValue)]],
      totalMujeres: ['', [Validators.required, Validators.pattern('^[0-9]*$'),
        Validators.min(initialValue)]],
      servicios: ['', [Validators.required, Validators.pattern('^[0-9]*$'),
        Validators.min(initialValue)]],
      visitantes: ['', [Validators.required, Validators.pattern('^[0-9]*$'),
        Validators.min(initialValue)]],
    });
  }
  public getError(controlName: string): string {
    const control: AbstractControl = this.formPopUp.controls[controlName];
    const nombreServicio= this.getNombre(controlName);
    if (control.touched && control.errors != null) {
      if (control.errors['required'] != null) {
        return nombreServicio + ` es requerido.`; //21/06/2024
      }
    }
    return '';
  }
  public getNombre (nombre: string):String { //21/6/2024
    switch (nombre) {
      case "nivel":
          nombre = 'Nivel'
          break;
      case 'piso':
          nombre = 'Piso'
          break;
      case "areaUtil":
          nombre = 'Area Util'
          break;
      case "areaTotal":
          nombre = 'Area Total'
          break;
      case "totalMujeres":
          nombre = 'Total Mujeres'
          break;
      case "totalHombres":
          nombre = 'Total Hombres'
          break;
      case "servicios":
          nombre = 'Servicios'
          break;
      case "visitantes":
          nombre = 'Visitantes'
          break;    
  }
  return nombre;
  }
  unshowModalDialog() {
    this.PopUpService.SharingPopUpObservableData = false;
    this.clearInputs();
  }
  saveData() {
    if (this.formPopUp.valid && this.canWeProceed()) {
      // Asegurarse de que si el popUp se esta usando para editar
      // o para agregar
      let mood=Mood.AGREGAR;
      PopUpComponent.ID_NIVEL+=-1;
      let id=PopUpComponent.ID_NIVEL;
      if (this.editable) {
        mood=Mood.MODIFICAR;
        id=this.inputFloor.id;
      }
      const men=Number(this.formPopUp.value.totalHombres);
      const women=Number(this.formPopUp.value.totalMujeres);
      const numeroPiso = Number(this.formPopUp.value.piso)
      const nivel:INivel={
        id: id,
        codigoOficina: this.sharingOffice.currentOfficeData.id.codigo,
        codigoEmpresa: this.sharingOffice.currentOfficeData.id.codigoEmpresa,
        numeroPiso: numeroPiso,
        nivel: this.formPopUp.value.nivel,
        areaTotal: Number(this.formPopUp.value.areaTotal),
        areaUtil: Number(this.formPopUp.value.areaUtil),
        totalHombres: men,
        totalMujeres: women,
        totalEmpleados: (men+women),
        servicios: Number(this.formPopUp.value.servicios),
        visitantes: Number(this.formPopUp.value.visitantes),
        mood: mood,
      };
      console.log('NIvel en pop up', nivel);
      this.addToProceduresList(nivel);
      this.notifyUpdate();
      this.unshowModalDialog();
    } else if (this.formPopUp.valid) {
      this.toast.mostrarToastError('Ocurrio un problema {la oficina '+
      ' a la que se le intenta insertar un nivel no es valido}', this.toastKey);
    } else {
      this.toast.mostrarToastError('Aun quedan campos sin llenar,'+
      ' llene todos los campos.', this.toastKey);
    }
  }
  private addToProceduresList(nivel:INivel) {
    const mood=nivel.mood;
    if (mood==Mood.AGREGAR) {
      this.sharingFloors.SharingAddFloorObservableData=nivel;
    } else {
      // Update
      this.sharingFloors.SharingUpdateFloorObservableData=nivel;
    }
  }
  private canWeProceed():boolean {
    return this.sharingOffice.letsProceed();
  }
  private clearInputs() {
    this.formPopUp.reset();
  }
  private putInputValues() {
    this.formPopUp.patchValue({
      nivel: this.inputFloor.nivel,
      piso: this.inputFloor.numeroPiso,
      areaTotal: this.inputFloor.areaTotal,
      areaUtil: this.inputFloor.areaUtil,
      totalHombres: this.inputFloor.totalHombres,
      totalMujeres: this.inputFloor.totalMujeres,
      totalEmpleados: this.inputFloor.totalEmpleados,
      servicios: this.inputFloor.servicios,
      visitantes: this.inputFloor.visitantes,
    });
  }

  private notifyUpdate() {
    this.peopleUpdate.emit();
  }
}
