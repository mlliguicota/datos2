import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-step-menu',
  templateUrl: './step-menu.component.html',
  styleUrls: ['./step-menu.component.scss'],
})
export class StepMenuComponent implements OnInit {
  @Input() menuItems:any[]=[];
  @Input() ind_clicked:number=0;
  @Output() newItemEvent = new EventEmitter<number>();

  clicked:boolean=false;


  constructor(private _router: Router,
    private _activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
    this.onClick(this.menuItems[0]);
  }
  onClick(item:any) {
    const path=item.path;
    this._router.navigate([path], {relativeTo: this._activatedRoute});
    const index=this.menuItems.findIndex((x) => x.name === item.name);
    this.ind_clicked=index;
    // Emmiting the item which the step menu is changing
    this.newItemEvent.emit(this.ind_clicked);
  }
}
