import { Component, Input, OnInit } from '@angular/core';
import { ToastService } from 'src/app/core/services/toast.service';
@Component({
  selector: 'app-upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.scss']
})
export class UploadFileComponent implements OnInit {
  fileTypes: string[] = []
  @Input() files: any[] = [];
  static Classvar: number = 0;
  private uniqueID: string;
  toastKey: any;
  constructor(private toast: ToastService,) {
    this.toastKey = this.toast.genToastKey();
    this.fileTypes = [
      "image/apng",
      "image/bmp",
      "image/gif",
      "image/jpeg",
      "image/pjpeg",
      "image/png",
      "image/svg+xml",
      "image/tiff",
      "image/webp",
      "image/x-icon"
    ];
    this.files = [];
  }

/*Metodo para cargar la imagen modificado 21/12/2023 -- SUD- BCALVOPIÑA */
/*modificacion de alerta para cargar la imagen modificado 9/01/2024 -- SUD- BCALVOPIÑA */
/*updateImageDisplay(e: any): void {
  let files = e.target.files;

  // Verificar si se seleccionaron archivos
  if (files && files.length > 0) {
    // Filtrar solo los archivos con extensión .png
    const pngFiles = Array.from(files).filter(file => this.isPngFile(file));

    // Verificar si se seleccionaron archivos válidos
    if (pngFiles.length > 0) {
      // Procesar cada archivo válido
      for (let file of pngFiles) {
        this.getImage(file);
      }
  }else{
    this.toast.mostrarToastError('Imagen de formato no válido, solo es permitido .png', this.toastKey);
  }
}
}*/

/*Metodo para la imagen AGREGADO 12/03/2023 -- SUD- BCALVOPIÑA */
generateUniqueID(): string {
  return `<span class="math-inline">\{Date\.now\(\)\}\-</span>{Math.random().toString(36).substring(7)}`;
}

/*Metodo para la imagen AGREGADO 21/12/2023 -- SUD- BCALVOPIÑA */
updateImageDisplay(e: any): void {
  let files = e.target.files;

  // Verificar si se seleccionaron archivos
  if (files && files.length > 0) {
    // Filtrar solo archivos .png
    const pngFiles = Array.from(files).filter(file => this.isPngFile(file));

    // Verificar si se seleccionaron archivos válidos
    if (pngFiles.length > 0) {
      // Procesar cada archivo válido
      for (let file of pngFiles) {
        this.uniqueID = this.generateUniqueID();
        this.getImage(file, this.uniqueID);
      }
    } else {
      this.toast.mostrarToastError('Imagen de formato no válido, solo es permitido .png', this.toastKey);
    }
  }
}

/*modificacion QUE NO PERMITA cargar varias imagenes modificado 7/02/2024 -- SUD- BCALVOPIÑA*/
/*updateImageDisplay(e: any): void {
  let files = e.target.files;

  // Verificar si se seleccionaron archivos
  if (files && files.length > 0) {
    // Limpiar el arreglo antes de agregar la nueva imagen
    this.files = [];

    // Filtrar solo los archivos con extensión .png
    const pngFiles = Array.from(files).filter(file => this.isPngFile(file));

    // Verificar si se seleccionaron archivos válidos
    if (pngFiles.length > 0) {
      // Procesar cada archivo válido
      for (let file of pngFiles) {
        this.getImage(file);
      }
    } else {
      this.toast.mostrarToastError('Imagen de formato no válido, solo es permitido .png', this.toastKey);
    }
  }
}
*/


/*Metodo para la imagen AGREGADO 21/12/2023 -- SUD- BCALVOPIÑA */
isPngFile(file: any): boolean {
  // Verifica si el archivo tiene la extensión .png
  return file.name.toLowerCase().endsWith('.png');
}

/*Metodo para la imagen AGREGADO 21/12/2023 -- SUD- BCALVOPIÑA */
showAlert(message: string): void {
  alert(message);
}

/*Metodo para la imagen AGREGADO 21/12/2023 -- SUD- BCALVOPIÑA */
clearFileInput(input: any): void {
  // Limpia el campo de entrada de archivo
  input.value = '';
}


/*
  getImage(file: any) {
    var reader = new FileReader();
    reader.onload = (event: any) => {
      console.log("onload event fired successfully");

      let extension = '';
      if (file.name.indexOf('.') != -1) {
        extension = file.name.slice(file.name.indexOf('.'), file.name.length);
      }
      let url = event.target.result;
      this.files.push(
        {
          url: url,
          name: file.name,
          shortName: file.name.slice(0, 6) + extension
        }
      );
    };
    reader.onerror = (event: any) => {
      console.log("File could not be read: " + event.target.error.code);
      this.toast.mostrarToastError('No se pudo leer el archivo, ' +
        'por favor intentelo de nuevo.', this.toastKey);
    };

    reader.readAsDataURL(file);
  }
*/

/*Metodo modificado 12/03/2024 -- SUD- BCALVOPIÑA */
getImage(file: any, uniqueID: string) {
  var reader = new FileReader();
  reader.onload = (event: any) => {
    console.log("onload event fired successfully");

    let extension = '';
    if (file.name.indexOf('.') != -1) {
      extension = file.name.slice(file.name.indexOf('.'), file.name.length);
    }
    let url = event.target.result;

    // Check if the file already exists in the array
    const existingFileIndex = this.files.findIndex(f => f.id === uniqueID);

    // If the file does not exist, add it to the array
    if (existingFileIndex === -1) {
      this.files.push(
        {
          url: url,
          name: file.name,
          shortName: file.name.slice(0, 6) + extension,
          id: uniqueID
        }
      );
    } else {
      // Update the existing file with the new data
      this.files[existingFileIndex] = {
        url: url,
        name: file.name,
        shortName: file.name.slice(0, 6) + extension,
        id: uniqueID
      };
    }

  };

  reader.onerror = (event: any) => {
    console.log("File could not be read: " + event.target.error.code);
    this.toast.mostrarToastError('No se pudo leer el archivo, ' +
      'por favor intentelo de nuevo.', this.toastKey);
  };
    reader.readAsDataURL(file);

}

  deleteFile(file: any) {
    this.files.forEach((value, index) => {
      if (file.url == value.url) this.files.splice(index, 1);
    });
  }

  //OK
  validFileType(file: any) {
    return this.fileTypes.includes(file.type);
  }
  //OK
  returnFileSize(number: any): any {
    if (number < 1024) {
      return `${number} bytes`;
    } else if (number >= 1024 && number < 1048576) {
      return `${(number / 1024).toFixed(1)} KB`;
    } else if (number >= 1048576) {
      return `${(number / 1048576).toFixed(1)} MB`;
    }
  }


  ngOnInit(): void {
    UploadFileComponent.Classvar += 1;
  }

}
