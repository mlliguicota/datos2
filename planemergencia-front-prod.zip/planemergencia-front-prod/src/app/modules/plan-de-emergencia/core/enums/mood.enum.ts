export enum Mood{
    //estado original desde la obtencion del servicio
    ORIGINAL,
    //fue modificado
    MODIFICAR,
    //se desea eliminar
    ELIMINAR,
    //es requerido actualizarlo
    ACTUALIZAR,
    //agregar un nuevo nivel al servidor
    AGREGAR
}