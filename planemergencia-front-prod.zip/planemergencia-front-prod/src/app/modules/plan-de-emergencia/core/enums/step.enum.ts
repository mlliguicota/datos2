export enum Step{
    LWP, // Location working population 
    KEC, // Keep emergency contact
}