export class ContactoEmergenciaContent {
    ip                  : string;
    nombreEquipo        : string;
    estado              : string;
    fechaIngreso        : Date;
    fechaModificacion?  : Date;
    fechaBaja?          : Date;
    usuarioIngreso      : string;
    usuarioModificacion?: string;
    usuarioBaja?        : string;
    codigo              : number;
    codigoOficina       : number;
    codigoEmpresa       : number;
    primerNombre        : string;
    primerApellido      : string;
    correo              : string;
    telefono            : string;
    extensionTelefono   : string;

    constructor(ip                  : string,
                nombreEquipo        : string,
                estado              : string,
                fechaIngreso        : Date,
                usuarioIngreso      : string,
                codigo              : number,
                codigoOficina       : number,
                codigoEmpresa       : number,
                primerNombre        : string,
                primerApellido      : string,
                correo              : string,
                telefono            : string,
                extensionTelefono   : string){

        this.ip                    = ip               ;
        this.nombreEquipo          = nombreEquipo     ;
        this.estado                = estado           ;
        this.fechaIngreso          = fechaIngreso     ;
        this.usuarioIngreso        = usuarioIngreso   ;
        this.codigo                = codigo           ;
        this.codigoOficina         = codigoOficina    ;
        this.codigoEmpresa         = codigoEmpresa    ;
        this.primerNombre          = primerNombre     ;
        this.primerApellido        = primerApellido   ;
        this.correo                = correo           ;
        this.telefono              = telefono         ;
        this.extensionTelefono     = extensionTelefono;
    }

}



export class ContactoOficinaContent {
    ip                  : string;
    nombreEquipo        : string;
    estado              : string;
    fechaIngreso        : Date;
    fechaModificacion?  : Date;
    fechaBaja?          : Date;
    usuarioIngreso      : string;
    usuarioModificacion?: string;
    usuarioBaja?        : string;
    id                  : ContactoOficinaId;

    constructor(ip                  : string,
                nombreEquipo        : string,
                estado              : string,
                fechaIngreso        : Date,
                usuarioIngreso      : string,
                id                  : ContactoOficinaId){

        this.ip                    = ip               ;
        this.nombreEquipo          = nombreEquipo     ;
        this.estado                = estado           ;
        this.fechaIngreso          = fechaIngreso     ;
        this.usuarioIngreso        = usuarioIngreso   ;
        this.id                    = id               ;
    }

}

export class ContactoOficinaId {
    codigoContacto           : number;
    codigoEmpresa            : number;
    codigoOficina            : number;
 
    constructor(codigoContacto           : number,
                codigoEmpresa            : number,
                codigoOficina            : number){
        this.codigoContacto           = codigoContacto;
        this.codigoEmpresa            = codigoEmpresa ;
        this.codigoOficina            = codigoOficina ;
    }

}



export class InstitucionEmergenciaContent {
    ip                      : string;
    nombreEquipo            : string;
    estado                  : string;
    fechaIngreso            : Date;
    fechaModificacion?      : Date;
    fechaBaja?              : Date;
    usuarioIngreso          : string;
    usuarioModificacion?    : string;
    usuarioBaja?            : string;
    codigo                  : number;
    ciudad                  : string;
    institucion             : string;
    telefono                : string;

    constructor(ip                      : string,
                nombreEquipo            : string,
                estado                  : string,
                fechaIngreso            : Date,
                usuarioIngreso          : string,
                codigo                  : number,
                ciudad                  : string,
                institucion             : string,
                telefono                : string
    ){
        this.ip                      = ip            ;
        this.nombreEquipo            = nombreEquipo  ;
        this.estado                  = estado        ;
        this.fechaIngreso            = fechaIngreso  ;
        this.usuarioIngreso          = usuarioIngreso;
        this.codigo                  = codigo        ;
        this.ciudad                  = ciudad        ;
        this.institucion             = institucion   ;
        this.telefono                = telefono      ;
    }
}
