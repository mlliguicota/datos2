import { Iget, IgetGeneral2 } from "./interfaces"

export interface IConsecuencia extends IgetGeneral2 {

  
        codigo: number,
        grado: string,
        gradoCorto: string,
        criterio: string
  

}

export interface IConsecuenciaGet extends Iget {

    pageContent: IConsecuencia[]

}


