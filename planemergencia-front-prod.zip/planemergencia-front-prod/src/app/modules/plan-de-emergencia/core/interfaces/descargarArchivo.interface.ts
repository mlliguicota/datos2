import { Iget, IgetGeneral2, IPost, IPut } from "./interfaces"

export interface Archivo {
    tipo: string
    nombreArchivo: string
    rutaArchivo: string
}

export interface IArchivo extends IgetGeneral2 {
    codigo: number
    codigoOficina: number
    codigoEmpresa: number
    nombre: string
    ruta: string
    tipoArchivo: string
}


export interface IArchivoGet extends Iget {
    pageContent: IArchivo[]
}



export interface IArchivoPut extends IPut {

    codigo: number
    codigoOficina: number
    codigoEmpresa: number
    estado: string
    nombre: string
    ruta: string
    tipoArchivo: string


}

export interface IArchivoPost extends IPost {



    codigoOficina: number
    codigoEmpresa: number

    nombre: string
    ruta: string
    tipoArchivo: string
}


export interface IDocumento {

    nombreArchivo: string
    rutaArchivo: string
    archivoBase64: any

}






