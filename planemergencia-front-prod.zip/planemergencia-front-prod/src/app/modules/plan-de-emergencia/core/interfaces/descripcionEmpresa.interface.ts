import { Iget , IgetGeneral2 , IPut , IPost } from "./interfaces" 


export interface ISecciones extends IgetGeneral2 {
    id: {
        codigo: number
        codigoTipoPlan: number
      }
      titulo: string
      nivel: number
      codigoSeccionPadre: number
      codigoTipoPlanPadre: number
      orden: number
      texto: string
      identificadorCampo: string
}

export interface IseccionesGet extends Iget {

    pageContent : ISecciones[]
}



export interface Idescripcion extends IgetGeneral2 {

    id: {
        codigo: number
        codigoOficina: number
        codigoEmpresa: number 
        codigoSeccion: number
        codigoTipoPlan: number
      }
      valor: string

}


export interface IdescripcionGet extends Iget {

    pageContent : Idescripcion[]
}



export interface IdescripcionPost extends IPost {
 
    id: {
        codigoOficina: number
        codigoEmpresa: number 
        codigoSeccion: number
        codigoTipoPlan: number
      }
      valor: string
  
}

export interface IdescripcionPut extends IPut {
   
    id: {
        codigo: number
        codigoOficina: number
        codigoEmpresa: number 
        codigoSeccion: number
        codigoTipoPlan: number
      }
      valor: string
  
}



