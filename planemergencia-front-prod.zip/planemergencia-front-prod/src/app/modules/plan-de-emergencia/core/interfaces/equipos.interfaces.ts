import { Iget, IgetGeneral2 } from "./interfaces"


export  interface IEquipo extends IgetGeneral2 {
   
    codigo: number
    nombre: string
    descripcion: string 

   }
 
 export interface IEquipoGet extends Iget{
 
     pageContent: IEquipo[]
     
 }