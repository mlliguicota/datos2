import { Iget, IgetGeneral2, IPost, IPut } from "./interfaces"


export  interface IEquipoOficina extends IgetGeneral2 {
   
    id: {
        codigo:  number,
        codigoEquipo : number,
        codigoOficina : number,
        codigoEmpresa : number
      }
      detalle : string 

   }
 
 export interface IEquipoOficinaGet extends Iget{
     pageContent: IEquipoOficina[]    
 }

export interface IEquipoOficinaPost extends IPost
{
    id : {
      codigoEquipo : number 
      codigoOficina : number
      codigoEmpresa : number
    }
    detalle : string
}

export interface IEquipoOficinaPut extends IPut
{
    id : {
        codigo : number
      codigoEquipo : number 
      codigoOficina : number
      codigoEmpresa : number
    }
    detalle : string
}
