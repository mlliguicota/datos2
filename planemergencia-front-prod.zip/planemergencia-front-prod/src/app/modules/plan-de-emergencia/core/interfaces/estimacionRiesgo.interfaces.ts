import { Iget, IgetGeneral2 } from "./interfaces"


export interface IestimacionRiesgo extends IgetGeneral2 {
    codigo: number,
    codigoProbabilidad: number,
    codigoConsecuencia: number,
    riesgo: string,
    accion: string
}

export interface IProbabilidadGet extends Iget {
pageContent: IestimacionRiesgo[]
}
