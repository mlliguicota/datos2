

import { IPost, IPut , IgetGeneral2 , Iget } from "./interfaces"

export interface IEvaluacionPrevencionPost extends IPost {

  
    id: {
        codigoEmpresa: number
        codigoOficina: number 
      }
      otrosFactoresMeseri: string
 
}


export interface IEvaluacionPrevencionPut extends IPut {

  
    id: {
        codigoEmpresa: number
        codigoOficina: number 
      }
      otrosFactores: string
     
 
}



export interface IEvaluacionCuantitativa extends IgetGeneral2 {

  codigo: number
  categoria: string
  rangoInicio: number
  rangoFin: number

}

export interface IEvaluacionCuantitativaGet extends Iget{
  pageContent: IEvaluacionCuantitativa[]

}


export interface IEvaluacionTaxativa extends IgetGeneral2 {

  codigo: number
  aceptabilidad: string
  rangoInicio: number
  rangoFin: number

}

export interface IEvaluacionTaxativaGet extends Iget{
  pageContent: IEvaluacionTaxativa[]

}



