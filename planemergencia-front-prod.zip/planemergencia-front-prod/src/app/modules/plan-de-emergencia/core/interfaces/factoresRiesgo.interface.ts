import { Iget, IgetGeneral, IPost, IPut } from "./interfaces"



export  interface IAreaOficina extends IgetGeneral {
   
    configuracion: string
    accesos: string
    ayudaExterior: string
    materialesAlmacenados: string 
    desechosGenerados: string
    materialesPeligrosos: string

}

export interface IAreaOficinaGet extends Iget{

    pageContent: IAreaOficina[]
    
}

export interface  IAreaOficinaPut  extends IPut{
 
    id: {
        codigoEmpresa: number
        codigoOficina: number 
      }
      configuracion: string
      accesos: string
      ayudaExterior: string
      materialesAlmacenados: string
      desechosGenerados: string
      materialesPeligrosos: string

}




export interface  IAreaOficinaPost  extends IPost{
   
    id: {
        codigoEmpresa: number
        codigoOficina: number 
      }
      configuracion: string
      accesos: string
      ayudaExterior: string
      materialesAlmacenados: string
      desechosGenerados: string
      materialesPeligrosos: string

}


/////////////////////////// CARACTERISTICAS OFICINA 
export  interface ICaracteristicaOficina extends IgetGeneral {
   
      plantasSobre: number
      plantasBajo: number
      altura: number
      pilares: string
      vigas: string
      cerramientosExt: string
      cerramientosInt: string
      superficieTotal: string

}

export interface ICaracteristicaOficinaGet extends Iget{

    pageContent: ICaracteristicaOficina[]
    
}

export interface  ICaracteristicaOficinaPut  extends IPut{
 
    id: {
        codigoEmpresa: number
        codigoOficina: number 
      }
      plantasSobre: number
      plantasBajo: number
      altura: number
      pilares: string
      vigas: string
      cerramientosExt: string
      cerramientosInt: string
      superficieTotal: string

}




export interface  ICaracteristicaOficinaPost  extends IPost{
   
    id: {
        codigoEmpresa: number
        codigoOficina: number 
      }
      plantasSobre: number
      plantasBajo: number
      altura: number
      pilares: string
      vigas: string
      cerramientosExt: string
      cerramientosInt: string
      superficieTotal: string

}