
export interface  IPut { 
    usuarioModificacion: string
    nombreEquipo: string

}

export interface  IPost { 
    usuarioIngreso: string
    nombreEquipo: string
    estado:string

}

export interface Iget {
 
    numberOfPages : number 
    totalItems : number
  }


  export interface IgetGeneral {

        ip: string
        nombreEquipo: string
        estado: string
        fechaIngreso: any
        fechaModificacion: any
        fechaBaja: any
        usuarioIngreso: string
        usuarioModificacion: string
        usuarioBaja: string
        id: {
          codigoOficina: number
          codigoEmpresa: number
        }

  }

  export interface IgetGeneral2 {

    ip: string
    nombreEquipo: string
    estado: string
    fechaIngreso: any
    fechaModificacion: any
    fechaBaja: any
    usuarioIngreso: string
    usuarioModificacion: string
    usuarioBaja: string
    

 

}
