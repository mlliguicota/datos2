export interface  Imantenimiento {
    codigo : number 
    nombre : string 
    detalle : string 
    estado : string

}

export interface  mantenimiento {
    key : string  ;
    name : string  ;
    visible_detalle : boolean  ;
    detalle : string;

}

export interface RequestMantenimiento {
    pageContent : Imantenimiento []
    numberOfPages : number 
    totalItems : number
  }