import { IPut, Iget, IgetGeneral2, IPost } from "./interfaces"; 



export class Meseri {

  codigoOficina: number ;
  codigoEmpresa: number ;
  altura: number ;
  superficieIncendios: number;
  resistenciaFuego: number;
  falsoTecho: number;
  distanciaBomberos: number;
  accesibilidadEdificio: number;
  peligroActivacion: number;
  cargaTermica: number;
  combustibilidad: number;
  ordenLimpieza: number;
  almacenamientoAltura: number;
  factorConcentracion: number;
  propagabilidadVertical: number;
  propagabilidadHorizontal: number;
  destructibilidadCalor: number;
  destructibilidadHumo: number;
  destructibilidadCorrosion: number;
  destructibilidadAgua: number;
  extintores: number;
  bocasIncendio: number;
  columnasHidratantes: number;
  detectoresIncendio: number;
  rociadoresAutomaticos: number;
  extincionGaseosos: number 
}



export  interface IMeseri  extends IgetGeneral2 , Meseri {
   
  codigo : number ;
  

}

export interface IMeseriGet extends Iget{

  pageContent: IMeseri[]

}


export interface  IMeseriPut  extends IPut , Meseri{ 
   codigo : number ;
  
}


export interface  IMeseriPost  extends IPost , Meseri{ 

  
}

export interface MesseriDropdown {
  name: string 
  code: string 
}


export interface IplanEmergenciaMesseriPost extends IPost {
 
  id: {
    codigoOficina: number,
    codigoEmpresa: number
  },
  valorMeseri: number,
  categoriaMeseri: string,

}


export interface IplanEmergenciaMesseriPut extends IPut {
 
  id: {
    codigoOficina: number,
    codigoEmpresa: number
  },
  valorMeseri: number,
  categoriaMeseri: string,

}






 