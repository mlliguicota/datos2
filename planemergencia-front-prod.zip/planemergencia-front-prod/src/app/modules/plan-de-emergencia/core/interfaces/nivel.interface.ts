/* eslint-disable no-multi-spaces */
import { Mood } from '../enums/mood.enum';
export interface INivel{
    id:                 number,
    codigoOficina:      number,
    codigoEmpresa:      number,
    numeroPiso:         number,
    // nombre del piso
    nivel:              string,
    areaTotal:          number,
    areaUtil:           number,
    totalHombres:       number,
    totalMujeres:       number,
    totalEmpleados:     number,
    servicios:          number,
    visitantes:         number,
    // Estado interno
    mood:               Mood
}
