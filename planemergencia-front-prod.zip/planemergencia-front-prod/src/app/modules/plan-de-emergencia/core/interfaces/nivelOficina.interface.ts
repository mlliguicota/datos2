import {  Iget  , IgetGeneral2 } from "./interfaces"


  export interface  InivelOficina extends IgetGeneral2 {
   
    codigo: number,
    codigoOficina: number,
    codigoEmpresa: number,
    numeroPiso: number,
    descripcion:string,
    areaTotal: number,
    areaUtil: number,
    totalHombres: number,
    totalMujeres: number,
    totalEmpleadosPiso: number,
    serviciosComplementarios: number,
    visitantes: number

}



export interface InivelOficinaGet extends Iget {
  pageContent : InivelOficina []
 
}