/* eslint-disable no-multi-spaces */
export interface IOficina{
    id:                 {
        codigo:         number,
        codigoEmpresa:  number
    },
    nombreOficina:        string,
    codigoTipoOficina:          number,
    telefono:             string,
    fax:                  string,
    actividadEmpresa:     string,
    correo:               string,
    procesosOficina:      string,
    rutaFachada:          string,
    rutaUbicacion:        string,
    poblacionTrabajadora:  number,
    rutasEvacuacion:      number,
    // Informacion oficina
    razonSocial:                 string,
    edificacionOficina:          string,
    ciudadOficina:               string,
    provinciaOficina:            string,
    direccionOficina:            string,
    totalEmpleados:               number,
    cantidadHombres:              number,
    cantidadMujeres:              number,
    liderPiso:                    string,
}
