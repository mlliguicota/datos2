import { Iget, IgetGeneral2, IPost, IPut } from "./interfaces"


export interface IpeligroPuntoEncuentro extends IgetGeneral2 { 
        codigo: number,
        codigoOficina: number,
        codigoEmpresa: number,
        peligroIdentificado: string,
        codigoEstimacionRiesgo: number
}

export interface IpeligroPuntoEncuentroGet extends Iget {

    pageContent: IpeligroPuntoEncuentro[]

}

export interface IpeligroPuntoEncuentroPut extends IPut{
 
    codigo: number,
    codigoOficina: number,
    codigoEmpresa: number,
    peligroIdentificado: string,
    codigoEstimacionRiesgo: number

}


export interface IpeligroPuntoEncuentroPost extends IPost{
 
    codigoOficina: number,
    codigoEmpresa: number,
    peligroIdentificado: string,
    codigoEstimacionRiesgo: number

}
