import { Iget, IgetGeneral, IPost, IPut } from "./interfaces"

export interface IplanEmergencia extends IgetGeneral {

    valorMeseri: number
    categoriaMeseri: string
    rutaMeseri: string
    rutaInsht: string
    rutaPuntoEncuentro: string
    rutaMapa: string
    elaborador: string
    aprobador: string
    superficieAreaUtil: string
    configuracion: string
    accesos: string
    otrosRecursos: string
    puntoEncuentro: string
    tiempoSalida: number
    observacionesEvacuacion: string
    personasEvacuacion: number
    anchoSalida: number
    distanciaEvacuacion: number
    otrosFactores : string
    cargoElaborador : string
    cargoAprobador :string

}


export interface RequestPLanEmergencia extends Iget{
  pageContent: IplanEmergencia[]
  

}

export interface IplanEmergenciaPuntoReunionPut extends IPut {
 
  id: {
    codigoOficina: number,
    codigoEmpresa: number
  },
  puntoEncuentro: string,

}


export interface IplanEmergenciaPost extends IPost {
 
  id: {
    codigoOficina: number,
    codigoEmpresa: number
  } ,
  elaborador: string ,
  aprobador: string,
  cargoElaborador : string,
  cargoAprobador :string ,
  otrosFactores : string
}


