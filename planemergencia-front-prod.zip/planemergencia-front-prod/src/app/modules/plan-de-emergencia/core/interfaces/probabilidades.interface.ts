import { Iget, IgetGeneral2 } from "./interfaces"

export interface IProbabilidad extends IgetGeneral2 {

  
        codigo: number,
        grado: string,
        gradoCorto: string,
        criterio: string
  

}

export interface IProbabilidadGet extends Iget {

    pageContent: IProbabilidad[]

}

