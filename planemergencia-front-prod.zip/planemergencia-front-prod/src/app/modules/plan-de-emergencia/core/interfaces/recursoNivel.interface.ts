import { Iget, IPost, IPut } from "./interfaces";



export interface recursoNivel {


    ip                          : string;
    nombreEquipo                : string;
    estado                      : string;
    fechaIngreso                : Date;
    fechaModificacion?          : Date;
    fechaBaja?                  : Date;
    usuarioIngreso              : string;
    usuarioModificacion?        : string;
    usuarioBaja?                : string;
    id: {
        codigo: number
        codigoNivel: number
        codigoRecurso: number
      }
      cantidad                      : number;
      observacion                       : string;
     
}


export interface IRecursoNivelGet extends Iget {
    pageContent : recursoNivel []
   
  }


  
export interface IRecursoNivelPut extends IPut {
  
  id: {
      codigo:  number
      codigoNivel: number
      codigoRecurso: number
    } ,
    cantidad:  number
    observacion : string
    


}

export interface IRecursoNivelPost extends IPost {

  id: {
     
    codigoNivel: number
    codigoRecurso: number

    } ,
    cantidad:  number
    observacion : string
}



