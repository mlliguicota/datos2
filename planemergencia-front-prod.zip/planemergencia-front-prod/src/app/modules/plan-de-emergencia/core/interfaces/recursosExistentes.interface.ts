

import { Iget , IgetGeneral2, IPost, IPut} from "./interfaces"


export interface IRecursos extends IgetGeneral2 {

    codigo: number 
    descripcion: string 

}

export interface IRecursoGet extends Iget{

    pageContent: IRecursos[]
    
}



export interface IrecursosExistentesPost extends IPost {

  
    id: {
        codigoEmpresa: number
        codigoOficina: number 
      }
      otrosRecursos: string
 
}


export interface IrecursosExistentesPut extends IPut {

  
    id: {
        codigoEmpresa: number
        codigoOficina: number 
      }
      otrosRecursos: string
 
}


export interface InivelesOficina extends IgetGeneral2 {

    codigo: number 
    codigoOficina: number 
    codigoEmpresa: number
    numeroPiso: number
    descripcion: number 
    areaTotal: number 
    areaUtil: number
    totalHombres: number
    totalMujeres: number
    totalEmpleadosPiso: number
    serviciosComplementarios: number
    visitantes: number
}



export interface INivelesOficinaGet extends Iget{

    pageContent: InivelesOficina[]
    
}





export interface IRecursosNivel extends IgetGeneral2 {

    id: {
        codigo: number,
        codigoNivel: number,
        codigoRecurso: number
      },
      cantidad: 120

}

export interface IRecursoNivelGet extends Iget{

    pageContent: IRecursosNivel[]
    
}


export interface IRecursoNivelPut extends IPut {
       
        id: {
          codigo: number
          codigoNivel: number
          codigoRecurso: number
        },
        cantidad: number
  
}

export interface IRecursoNivelPost extends IPost {
       
    id: {
     // codigo: number no se debe enviar
      codigoNivel: number
      codigoRecurso: number
    },
    cantidad: number

}







