import { Iget, IgetGeneral2 } from "./interfaces"


export interface IrutasEvacuacion extends IgetGeneral2  {

    codigo: number,
    descripcion: string,
    nivel :nivel[]
}

export interface nivel {
    id: {
        codigo: 1,
        codigoNivel: 1,
        codigoRuta: 1
      },
      cantidad: 15
}

export interface RequestRutasEvacuacion extends Iget {
    pageContent : IrutasEvacuacion []
   
  }