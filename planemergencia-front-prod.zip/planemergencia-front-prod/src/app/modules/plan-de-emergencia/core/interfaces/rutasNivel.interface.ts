import { Iget, IgetGeneral2 } from "./interfaces"


export interface IrutasNivel extends IgetGeneral2  {

    id: {
        codigo: number,
        codigoNivel: number,
        codigoRuta: number
      },
      cantidad: number,
      rutas: {
        codigo: number,
        descripcion: string
      }
  

}

export interface RequestRutasNivel extends Iget {
    pageContent : IrutasNivel []
   
  }
  
