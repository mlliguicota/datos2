import { Iget } from './interfaces';

export interface SeccionDocumentos {
    ip : string 
    nombreEquipo : string 
    estado : string
    fechaIngreso : Date
    fechaModificacion : Date
    fechaBaja : Date
    usuarioIngreso : string
    usuarioModificacion : string
    usuarioBaja : string
    id: {
        codigo: number
        codigoTipoPlan: number
      }
    titulo : string
    nivel : number
    codigoSeccionPadre : number
    codigoTipoPlanPadre : number
    orden : number
    texto : string
    identificadorCampo : string

}


export interface ISeccionesGet extends Iget {
    pageContent : SeccionDocumentos [] }