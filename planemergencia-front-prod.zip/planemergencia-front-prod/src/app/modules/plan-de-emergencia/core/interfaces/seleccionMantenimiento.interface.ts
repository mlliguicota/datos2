import { IPost , Iget  , IgetGeneral2, IPut } from "./interfaces"


  export interface  Imantenimiento extends IgetGeneral2 {
    codigo : number 
    nombre : string 
    detalle : string 
    estado : string

}

export interface  mantenimiento {
  key : string  ;
  name : string  ;
  visible_detalle : boolean  ;
  detalle : string;

}

export interface RequestMantenimiento extends Iget {
  pageContent : Imantenimiento []
 
}

export interface ImantenimientoGet extends Iget{

    pageContent: Imantenimiento[]
    
}


export interface ImantenientosOficinasPut extends IPut {
  
    id: {
        codigo:  number
        codigoOficina: number
        codigoEmpresa: number
        codigoMantenimiento: number
      } ,
    estado : string 


}

export interface ImantenientosOficinasPost extends IPost {

    id: {
       
        codigoOficina: number
        codigoEmpresa: number
        codigoMantenimiento: number
      }
}


export  interface ImantenimientosOficinas extends IgetGeneral2 {
   
  id :{  codigo:  number
    codigoOficina: number
    codigoEmpresa: number
    codigoMantenimiento: number
  }
  }


  export interface ImantenimientosOficinasGet extends Iget{

    pageContent: ImantenimientosOficinas[]
    
}




