

import { IPost , Iget  , IgetGeneral2, IPut } from "./interfaces"
export  interface Iriesgo extends IgetGeneral2 {
   
   codigo: number
   tipoRiesgo: string
   descripcion: string 
   rutaArchivo: string
   descripcionRiesgo :string
  }


export interface IriesgoGet extends Iget{

    pageContent: Iriesgo[]
    
}


export interface  riesgo {
  key : string  ;
  name : string  ;

}



  export  interface IriesgoOficina extends IgetGeneral2 {
   
    id: {
        codigo: number,
        codigoOficina: number,
        codigoEmpresa: number,
        codigoRiesgo: number
      },
      accionesPreventivas: string,
      otros: string , 
      estado : string
   }
 
 
 export interface IriesgoOficinagoGet extends Iget{
 
     pageContent: IriesgoOficina[]
     
 }
 

export interface IriesgoOficinaPut extends IPut {
  
    id: {
        codigo: number,
        codigoOficina: number,
        codigoEmpresa: number,
        codigoRiesgo: number
      } ,
      estado : string 

}

export interface IriesgoOficinaPost extends IPost {

    id: {
     
        codigoOficina: number,
        codigoEmpresa: number,
        codigoRiesgo: number
      } 

      
}