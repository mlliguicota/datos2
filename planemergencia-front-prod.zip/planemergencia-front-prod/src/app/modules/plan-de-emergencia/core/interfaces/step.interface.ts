import { Step } from "../enums/step.enum";

/* eslint-disable no-multi-spaces */
export interface IStep{
    id:           Step,
    save:         boolean,
    done:         boolean,
    error:        boolean,
}