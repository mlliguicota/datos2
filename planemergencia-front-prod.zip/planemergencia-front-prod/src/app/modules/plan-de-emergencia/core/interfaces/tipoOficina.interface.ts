export interface ITipoOficina{
    codigo: number;
    descripcion: string;
}
