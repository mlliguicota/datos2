/* eslint-disable no-multi-spaces */
export interface IUsuario{
    id:                 number,
    usuario:            string,
    codigoRol:          number,
}
