import { TestBed } from '@angular/core/testing';

import { AdminVariosService } from './admin-varios.service';

describe('AdminVariosService', () => {
  let service: AdminVariosService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdminVariosService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
