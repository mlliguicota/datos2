import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminVariosService {

  constructor(private http : HttpClient) { }
  private EMEC_URL=environment.BASE_URL_EME+ environment.EMEC_URL;
  private EMECO_URL=environment.BASE_URL_EME+ environment.EMECO_URL;
  private EMEI_URL=environment.BASE_URL_EME+ environment.EMEI_URL;
  private URL_GENN=environment.BASE_URL_EME + environment.GENN_URL;

  getContactoEmergencia() :Observable<any>{

    return this.http.get(this.EMEC_URL);
}

getContactosOficina(codigoOficina:number) :Observable<any>{
  const params ={
      codigoOficina: codigoOficina
  };

  return this.http.get(this.EMECO_URL, {params});
}

/*GET PARA TRAER LOS CONTACTOS POR CODIGO - BCALVOPIÑA - 17/01/2024 */
getContactoEmergencia2(codigo:number) :Observable<any>{
  const params ={
    codigo: codigo
  };

  return this.http.get(this.EMEC_URL, {params});
}


getInstitucionesEmergencia() :Observable<any>{
  return this.http.get(this.EMEI_URL);
}





}
