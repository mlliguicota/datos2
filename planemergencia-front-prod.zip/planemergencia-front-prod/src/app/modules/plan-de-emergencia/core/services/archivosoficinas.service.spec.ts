import { TestBed } from '@angular/core/testing';

import { ArchivosoficinasService } from './archivosoficinas.service';

describe('ArchivosoficinasService', () => {
  let service: ArchivosoficinasService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ArchivosoficinasService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
