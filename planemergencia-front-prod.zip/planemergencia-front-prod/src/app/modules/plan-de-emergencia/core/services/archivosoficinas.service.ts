import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { firstValueFrom, Observable, Subscriber } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IArchivoGet, IArchivoPost, IArchivoPut, IDocumento } from '../interfaces/descargarArchivo.interface';

@Injectable({
  providedIn: 'root'
})
export class ArchivosoficinasService {

  constructor(private _http: HttpClient) { }

  obtenerArchivosOficinas(codigoOficina : number , codigoEmpresa : number ) : Observable<IArchivoGet> {

    return this._http.get<IArchivoGet>(`${environment.BASE_URL_EME}${environment.EME_ARCHIVOS_URL}?codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`)
   
  }


  registrarArchivosOficinas( archivosOficinas : IArchivoPost[] )  :Observable<IArchivoPost[]> {
          
    return this._http.post<IArchivoPost[]>(`${environment.BASE_URL_EME}${environment.EME_ARCHIVOS_URL}/varios`  ,archivosOficinas)
  
  }

  registrarArchivo( archivosOficinas : IArchivoPost )  :Observable<IArchivoPost> {
          
    return this._http.post<IArchivoPost>(`${environment.BASE_URL_EME}${environment.EME_ARCHIVOS_URL}`  ,archivosOficinas)
  
  }

  actualizarArchivosOficinas( archivosOficinas : IArchivoPut[] )  :Observable<IArchivoPut[]> {
          
    return this._http.put<IArchivoPut[]>(`${environment.BASE_URL_EME}${environment.EME_ARCHIVOS_URL}/varios`  ,archivosOficinas)
  
  }

  obtenerArchivo(nombreArchivo : string  , rutaArchivo : string) :Observable<IDocumento>{
    console.log("==SERVICIO OBTENER ARCHIVO==: " + `${environment.BASE_URL_GEN}${environment.GEN_DESCARGA_ARCHIVO}/${nombreArchivo}/${rutaArchivo}`)
    return this._http.get<IDocumento>(`${environment.BASE_URL_GEN}${environment.GEN_DESCARGA_ARCHIVO}/${nombreArchivo}/${rutaArchivo}`)
    
  }

  obtenerImagenesArchivo(nombreArchivo : string  , rutaArchivo : string) : Promise<IDocumento>{
    return firstValueFrom(this._http.get<IDocumento>(`${environment.BASE_URL_GEN}${environment.GEN_DESCARGA_ARCHIVO}/${nombreArchivo}/${rutaArchivo}`));
  }

  RegistrarArchivo(documento :IDocumento) :Observable<IDocumento>{  
    return this._http.post<IDocumento>(`${environment.BASE_URL_GEN}${environment.GEN_SUBIR_ARCHIVO}`  , documento )

    
  }

  convertToBas64(file :File ) {
    return new Promise((resolve) =>{
  
      const observable  = new Observable((suscriber : Subscriber<any>)=> {
          this.readFile(file , suscriber)
      })
    
       observable.subscribe( archivo => {
        console.log(file)
        console.log(archivo)
      
        const dataRes = { resCode: 0  ,
          archivoBase64 : archivo } ;
resolve(dataRes);
       })

    })
       
  }

  readFile(file: File, suscriber: Subscriber<any>) {
    const fileReader = new FileReader()
    fileReader.readAsDataURL(file)
    fileReader.onload = () => {
      suscriber.next(fileReader.result)
      suscriber.complete()
    }
    fileReader.onerror = () => {
       suscriber.error()
       suscriber.complete()
    }
}

  

}


