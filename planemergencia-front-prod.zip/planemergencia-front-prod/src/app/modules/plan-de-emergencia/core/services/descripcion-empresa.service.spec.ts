import { TestBed } from '@angular/core/testing';

import { DescripcionEmpresaService } from './descripcion-empresa.service';

describe('DescripcionEmpresaService', () => {
  let service: DescripcionEmpresaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DescripcionEmpresaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
