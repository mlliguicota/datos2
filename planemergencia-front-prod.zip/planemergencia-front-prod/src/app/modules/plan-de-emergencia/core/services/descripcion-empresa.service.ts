import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Idescripcion, IdescripcionGet, IdescripcionPost, IdescripcionPut, IseccionesGet } from '../interfaces/descripcionEmpresa.interface';

@Injectable({
  providedIn: 'root'
})
export class DescripcionEmpresaService {

  constructor(private _http: HttpClient) { }

  obtenerDescripcion(codigoOficina : number , codigoEmpresa : number  ,codigoTipoPlan : number , codigoSeccion : number) : Observable<IdescripcionGet> {

    return this._http.get<IdescripcionGet>(`${environment.BASE_URL_EME}${environment.EME_PARAMETROS_OFICINA_URL}?codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&codigoSeccion=${codigoSeccion}&codigoTipoPlan=${codigoTipoPlan}&page=1&size=20`)
   
  }

  
  registrar( descripcionEmpresa : IdescripcionPost ) : Observable<Idescripcion> {

    return this._http.post<Idescripcion>(`${environment.BASE_URL_EME}${environment.EME_PARAMETROS_OFICINA_URL}` ,descripcionEmpresa);
  }

  actualizar( descripcionEmpresa : IdescripcionPut ) : Observable<Idescripcion> {

    return this._http.put<Idescripcion>(`${environment.BASE_URL_EME}${environment.EME_PARAMETROS_OFICINA_URL}` ,descripcionEmpresa);
}




obtenerSeccion(identificadorCampo : string ) : Observable<IseccionesGet> {

  return this._http.get<IseccionesGet>(`${environment.BASE_URL_PLA}${environment.EME_PLA_SECCIONES_URL}?titulo=${identificadorCampo}&identificadorCampo=PLANTILLA&page=1&size=20`)
 
}




}
