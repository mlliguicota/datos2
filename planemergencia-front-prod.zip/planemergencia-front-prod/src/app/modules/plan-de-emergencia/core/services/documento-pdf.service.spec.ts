import { TestBed } from '@angular/core/testing';

import { DocumentoPdfService } from './documento-pdf.service';

describe('DocumentoPdfService', () => {
  let service: DocumentoPdfService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DocumentoPdfService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
