import { Injectable } from '@angular/core';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

@Injectable({
  providedIn: 'root'
})
export class DocumentoPdfService {

  constructor() { }


  
  downloadPDF(nombreArchivo :string , data :any) {
    // Extraemos el

    const DATA :any =  data // document.getElementById('htmlData');
    const doc = new jsPDF('p', 'pt', 'a4');
    const options = {
      background: 'white',
      scale: 3
    };
    html2canvas(DATA, options).then((canvas) => {

      const img = canvas.toDataURL('image/PNG');

      // Add image Canvas to PDF
      const bufferX = 15;
      const bufferY = 15;
      const imgProps = (doc as any).getImageProperties(img);
      const pdfWidth = doc.internal.pageSize.getWidth() - 2 * bufferX;
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      doc.addImage(img, 'PNG', bufferX, bufferY, pdfWidth, pdfHeight, undefined, 'FAST');
    
 
      return doc;
    }).then((docResult) => {
      docResult.save(nombreArchivo);
    });
  }
  async downloadPDFMesseri(nombreArchivo: string, data: any) {
    const DATA: any = data;
    const doc = new jsPDF('p', 'pt', 'a4');
    const options = {
        background: 'white',
        scale: 3
    };
    const pageHeight = doc.internal.pageSize.height;
    const bufferX = 15;
    const bufferY = 15;

    let currentPosition = 0;
    const totalHeight = DATA.scrollHeight;

    while (currentPosition < totalHeight) {
        const canvas = await html2canvas(DATA, {
            ...options,
            windowHeight: pageHeight,
            windowWidth: doc.internal.pageSize.width,
            x: 0,
            y: currentPosition,
            scrollY: -currentPosition
        });

        const img = canvas.toDataURL('image/PNG');
        const imgProps = (doc as any).getImageProperties(img);
        const pdfWidth = doc.internal.pageSize.getWidth() - 2 * bufferX;
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
        doc.addImage(img, 'PNG', bufferX, bufferY, pdfWidth, pdfHeight, undefined, 'FAST');

        currentPosition += pdfHeight -45;  // SUD CS - Ajuste basado en la altura real de la imagen añadida

        if (currentPosition < totalHeight) {
            doc.addPage();
        }
    }

    doc.save(nombreArchivo);
}

  /*
  async downloadPDFMesseri(nombreArchivo: string, data: any) {
    const DATA: any = data;
    const doc = new jsPDF('p', 'pt', 'a4');
    const options = {
      background: 'white',
      scale: 3
    };
    const pageHeight = doc.internal.pageSize.height;
    const pageWidth = doc.internal.pageSize.width;//cambio
    const bufferX = 15;
    const bufferY = 15;
  
    let currentPosition = 0;
    const totalHeight = DATA.scrollHeight;
  
    while (currentPosition < totalHeight) {
      // Correccion Andres Camapaña--error en el pdf descargado 6/5/2024
      // Ajusta las opciones de captura para capturar una porción diferente de la página en cada iteración
      const canvas = await html2canvas(DATA, {
        ...options,
        //: currentPosition + pageHeight,
        windowHeight: pageHeight,
        //windowWidth: DATA.clientWidth, // Ancho de la página web
        windowWidth: pageWidth,
        x: 0, // Posición X de inicio de la captura
        y: currentPosition, // Posición Y de inicio de la captura
        scrollY: -currentPosition
      });
  
      const img = canvas.toDataURL('image/PNG');
      const imgProps = (doc as any).getImageProperties(img);
      const pdfWidth = doc.internal.pageSize.getWidth() - 2 * bufferX;
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      doc.addImage(img, 'PNG', bufferX, bufferY, pdfWidth, pdfHeight, undefined, 'FAST');
      //
      console.log('se tomo la imagen')
      console.log(currentPosition)
      console.log(currentPosition += pageHeight)
      console.log(doc.internal.pageSize.getWidth() - 2 * bufferX)
      console.log((imgProps.height * pdfWidth) / imgProps.width)
      //
      currentPosition += pageHeight;  //andres modificacion 27/6/2024
      if (currentPosition <= totalHeight) {
        doc.addPage();
        console.log('se añadio una hoja')
      }
    }
  
    doc.save(nombreArchivo);
  }
    */
}

  



