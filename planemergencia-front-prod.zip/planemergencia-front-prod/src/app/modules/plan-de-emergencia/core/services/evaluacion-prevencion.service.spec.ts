import { TestBed } from '@angular/core/testing';

import { EvaluacionPrevencionService } from './evaluacion-prevencion.service';

describe('EvaluacionPrevencionService', () => {
  let service: EvaluacionPrevencionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EvaluacionPrevencionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
