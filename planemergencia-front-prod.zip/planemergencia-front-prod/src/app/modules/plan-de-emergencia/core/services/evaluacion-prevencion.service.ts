import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IEvaluacionCuantitativaGet, IEvaluacionPrevencionPost, IEvaluacionPrevencionPut, IEvaluacionTaxativaGet } from '../interfaces/evaluacionPrevencion.interface';
import { IplanEmergencia } from '../interfaces/planEmergencia.interface';

@Injectable({
  providedIn: 'root'
})
export class EvaluacionPrevencionService {

  constructor(private  _http : HttpClient) { }

 
   registrarEvaluacion( Evaluacion: IEvaluacionPrevencionPost ) {

    this._http.post(`${environment.BASE_URL_EME}${environment.EME_PLANEMERGENCIA_URL}` ,Evaluacion);
     

   }

   ActualizarEvaluacion( Evaluacion: IEvaluacionPrevencionPut ) {

    this._http.post(`${environment.BASE_URL_EME}${environment.EME_PLANEMERGENCIA_URL}` ,Evaluacion);
     

   }

   obtenerEvaluacionCuantitativa() :Observable<IEvaluacionCuantitativaGet>  {

       return this._http.get<IEvaluacionCuantitativaGet>(`${environment.BASE_URL_EME}${environment.EME_EVALUACION_CUANTITATIVA_URL}`) 
   }
   
   obtenerEvaluacionTaxativa() :Observable<IEvaluacionTaxativaGet>  {

    return this._http.get<IEvaluacionTaxativaGet>(`${environment.BASE_URL_EME}${environment.EME_EVALUACION_TAXATIVA_URL}`) 
}
   

actualizarPlanEmergencia(evaluacionPlanEmergencia : IEvaluacionPrevencionPut) :Observable<IplanEmergencia> {

  return this._http.put<IplanEmergencia>(`${environment.BASE_URL_EME}${environment.EME_PLANEMERGENCIA_URL}` ,evaluacionPlanEmergencia)
}




}
