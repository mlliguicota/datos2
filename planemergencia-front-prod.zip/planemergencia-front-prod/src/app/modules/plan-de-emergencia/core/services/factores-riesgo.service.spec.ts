import { TestBed } from '@angular/core/testing';

import { FactoresRiesgoService } from './factores-riesgo.service';

describe('FactoresRiesgoService', () => {
  let service: FactoresRiesgoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FactoresRiesgoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
