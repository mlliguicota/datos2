import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IEquipoGet } from '../interfaces/equipos.interfaces';
import { IEquipoOficinaGet, IEquipoOficinaPost, IEquipoOficinaPut } from '../interfaces/equiposOficinas.interface';
import { IAreaOficina, IAreaOficinaGet, IAreaOficinaPost, IAreaOficinaPut, ICaracteristicaOficina, ICaracteristicaOficinaGet, ICaracteristicaOficinaPost, ICaracteristicaOficinaPut } from '../interfaces/factoresRiesgo.interface';
import { IplanEmergencia, IplanEmergenciaPost } from '../interfaces/planEmergencia.interface';

@Injectable({
  providedIn: 'root'
})
export class FactoresRiesgoService {

   

  constructor(private _http : HttpClient) { }

  
  ObtenerAreasOficinas(codigoOficina : number , codigoEmpresa : number) :Observable<IAreaOficinaGet> {

    return this._http.get<IAreaOficinaGet>(`${environment.BASE_URL_EME}${environment.EME_AREAS_OFICINA_URL}?codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`)

 }
  registrarAreasOficinas( areasOficinas : IAreaOficinaPost) :Observable<IAreaOficina> {
      
     return this._http.post<IAreaOficina>(`${environment.BASE_URL_EME}${environment.EME_AREAS_OFICINA_URL}` , areasOficinas)

  }
  actualizarAreasOficinas(areasOficinas : IAreaOficinaPut) :Observable<IAreaOficina> {

    return this._http.put<IAreaOficina>(`${environment.BASE_URL_EME}${environment.EME_AREAS_OFICINA_URL}` , areasOficinas)
  }

  

  obtenerCaracteristicasEdificio(codigoOficina : number , codigoEmpresa : number) :Observable<ICaracteristicaOficinaGet> {
    return this._http.get<ICaracteristicaOficinaGet>(`${environment.BASE_URL_EME}${environment.EME_CARACTERISTICAS_EDIFICIO_URL}?codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`)

  }

  registrarCaracteristicasEdificio(caracteristicasEdificio : ICaracteristicaOficinaPost ) :Observable<ICaracteristicaOficina>{
    return this._http.post<ICaracteristicaOficina>(`${environment.BASE_URL_EME}${environment.EME_CARACTERISTICAS_EDIFICIO_URL}` , caracteristicasEdificio)

  }


  actualizarCaracteristicasEdificio(caracteristicasEdificio : ICaracteristicaOficinaPut) :Observable<ICaracteristicaOficina>{

   return this._http.put<ICaracteristicaOficina>(`${environment.BASE_URL_EME}${environment.EME_CARACTERISTICAS_EDIFICIO_URL}` , caracteristicasEdificio)
  }

  obtenerEquipos():Observable<IEquipoGet>{

    return this._http.get<IEquipoGet>(`${environment.BASE_URL_EME}${environment.EME_EQUIPO}?page=1&size=20`)

  }

  obtenerEquiposOficinas(codigoOficina : number , codigoEmpresa : number):Observable<IEquipoOficinaGet>{

    return this._http.get<IEquipoOficinaGet>(`${environment.BASE_URL_EME}${environment.EME_EQUIPO_OFICINA}?codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`)

  }


  actualizarEquiposOficinas( equipoOficina : IEquipoOficinaPut [] ) :Observable<any> {

    return this._http.put<IEquipoOficinaPut>(`${environment.BASE_URL_EME}${environment.EME_EQUIPO_OFICINA}/varios` , equipoOficina)
  }


 
  registrarEquiposOficinas( equipoOficina : IEquipoOficinaPost [] ) :Observable<any> {

    return this._http.post<IEquipoOficinaPost>(`${environment.BASE_URL_EME}${environment.EME_EQUIPO_OFICINA}/varios` , equipoOficina)
  }


  registrarPlanEmergencia(planEmergencia : IplanEmergenciaPost) :Observable<IplanEmergencia> {

    return this._http.post<IplanEmergencia>(`${environment.BASE_URL_EME}${environment.EME_PLANEMERGENCIA_URL}` ,planEmergencia)
  }
  

}
