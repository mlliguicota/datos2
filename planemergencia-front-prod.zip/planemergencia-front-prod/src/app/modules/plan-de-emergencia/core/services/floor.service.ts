import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { EmeService } from 'src/app/core/services/eme.service';
import { INivel } from '../interfaces/nivel.interface';
import { IUsuario } from '../interfaces/usuario.interface';
import { SharingFloorsService } from './sharing-floors.service';
@Injectable({
  providedIn: 'root',
})
export class FloorService {
  private floorsData:any[]=[];

  constructor(private _eme: EmeService) { }

  getFloorsData() {
    return this.floorsData;
  }

  obtenerFloorsData(codigoEmpresa:number, codigoOficina:number) {
    return new Promise((resolve)=>{
      this._eme.getNiveles(codigoEmpresa, codigoOficina).subscribe({
        next: (res:any)=>{
          if (res != null) {
            console.log('Imprimiendo NIveles!!!');
            console.log(res.pageContent);
            // lista de pisos
            this.floorsData=res.pageContent;
            const data = { resCode: 0 };
            resolve(data);
          }
        },
        error: (err)=>{
          const e='Ocurrio un error inesperado obteniendo los niveles';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    },
    );
  }
  async agregarFloorsData(niveles:INivel[], user: IUsuario) {
    return await new Promise((resolve)=>{
      setTimeout(resolve, 30000);
      this._eme.postNiveles(niveles, user).subscribe({

        next: (res:any)=>{
          if (res!=null) {
            console.log('POST REALIZXADO CORRECTAMENTE');
            const data = { resCode: 0 };
            resolve(data);
          }
        },
        error: (err)=>{
          console.log('DENTRO DE LA PROMESA APPEND ERROR');
          console.log(err);
          const e='Ocurrio un error inesperado agregando los niveles';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    });
  }


  async actualizarFloorsData(niveles:INivel[], user: IUsuario) {
    return await new Promise((resolve)=>{
      this._eme.putNiveles(niveles, user).subscribe({
        next: (res:any)=>{
          if (res!=null) {
            console.log('ACTUALIZACION REALIZADA CORRECTAMENTE');
            const data = { resCode: 0 };
            resolve(data);
          }
        },
        error: (err)=>{
          const e='Ocurrio un error inesperado actualizando los niveles';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    });
  }
  async eliminarFloorsData(niveles:INivel[], user: IUsuario) {
    return await new Promise((resolve)=>{
      this._eme.deleteNiveles(niveles, user).subscribe({
        next: (res:any)=>{
          if (res!=null) {
            console.log('ELIMINACION DE NIVEL REALIZADA CORRECTAMENTE');
            const data = { resCode: 0 };
            resolve(data);
          }
        },
        error: (err)=>{
          const e='Ocurrio un error inesperado eliminando los niveles';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    });
  }
}
