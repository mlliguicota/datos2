import { TestBed } from '@angular/core/testing';

import { GuardaImagenesService } from './guarda-imagenes.service';

describe('GuardaImagenesService', () => {
  let service: GuardaImagenesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GuardaImagenesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
