import { TestBed } from '@angular/core/testing';

import { GuardaInfoLocalService } from './guarda-info-local.service';

describe('GuardaInfoLocalService', () => {
  let service: GuardaInfoLocalService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GuardaInfoLocalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
