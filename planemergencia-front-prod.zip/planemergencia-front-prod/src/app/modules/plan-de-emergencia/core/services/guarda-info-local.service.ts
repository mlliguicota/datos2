import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GuardaInfoLocalService {

  constructor() { }


   guardaArray( name :string , valor :Array<any>) {
     
    localStorage.setItem(name, JSON.stringify(valor));

   }

   ObstenerArray(name :string ):Array<any> {
      
   let  array :any = localStorage.getItem(name);
    // Se parsea para poder ser usado en js con JSON.parse :)
    array = JSON.parse(array)
    return array
        
   }


}
