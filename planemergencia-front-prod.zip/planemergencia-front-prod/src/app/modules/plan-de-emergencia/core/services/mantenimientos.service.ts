import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ImantenientosOficinasPost, ImantenientosOficinasPut, ImantenimientoGet, ImantenimientosOficinasGet } from '../interfaces/seleccionMantenimiento.interface';


@Injectable({
  providedIn: 'root'
})
export class MantenimientosService {

   
  constructor(private _http : HttpClient) { }


  obtenerMantenimientos():Observable<ImantenimientoGet>   {

  
   return  this._http.get<ImantenimientoGet>(`${environment.BASE_URL_EME}${environment.EME_MANTENIMIENTO_URL}?page=1&size=20`)

  }



  obtenerMantenimientosOficinas(codigoOficina : number , codigoEmpresa : number ):Observable<ImantenimientosOficinasGet>   {

  
    return  this._http.get<ImantenimientosOficinasGet>(`${environment.BASE_URL_EME}${environment.EME_MANTENIMIENTO_OFICINA_URL}?codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`)
 
   }

   registrarMantenimientosOficinas( mantenimientosOficinas : ImantenientosOficinasPost[] )  :Observable<ImantenientosOficinasPost[]> {
          
    return this._http.post<ImantenientosOficinasPost[]>(`${environment.BASE_URL_EME}${environment.EME_MANTENIMIENTO_OFICINA_URL_VARIOS}`  ,mantenimientosOficinas)
  
  }
  actualizarMantenimientosOficinas( mantenimientosOficinas : ImantenientosOficinasPut[]  ) :Observable<ImantenientosOficinasPut[]> {
  
  return  this._http.put<ImantenientosOficinasPut[]>(`${environment.BASE_URL_EME}${environment.EME_MANTENIMIENTO_OFICINA_URL_VARIOS}`  ,mantenimientosOficinas)
  
  }
  
  


}
