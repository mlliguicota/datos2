import { TestBed } from '@angular/core/testing';

import { MesseriService } from './messeri.service';

describe('MesseriService', () => {
  let service: MesseriService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MesseriService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
