import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

import {  IMeseriGet, IMeseriPost, IMeseriPut, IplanEmergenciaMesseriPost, IplanEmergenciaMesseriPut, Meseri } from '../interfaces/messeri.interface';
import { Observable } from 'rxjs';
import { IplanEmergencia } from '../interfaces/planEmergencia.interface';

@Injectable({
  providedIn: 'root'
})
export class MesseriService {

  constructor(private _http: HttpClient) { }
   private existe : boolean = false

existeMesseri() :boolean {

       return this.existe
}


obtenerMesseri(codigoEmpresa: number, codigoOficina: number) :Observable<IMeseriGet> { 

  return  this._http.get<IMeseriGet> (`${environment.BASE_URL_EME}${environment.EME_MESSERI_URL}?codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`)

}



registrarMesseri(messeri : IMeseriPost)  { 
     
    return this._http.post(`${environment.BASE_URL_EME}${environment.EME_MESSERI_URL}` , messeri)

}

actualizarMesseri(messeri : IMeseriPut)   { 
   console.log(messeri)
  return this._http.put (`${environment.BASE_URL_EME}${environment.EME_MESSERI_URL}` , messeri)

}


registrarPlanEmergencia(messeriPlanEmergencia : IplanEmergenciaMesseriPost) :Observable<IplanEmergencia> {

  return this._http.post<IplanEmergencia>(`${environment.BASE_URL_EME}${environment.EME_PLANEMERGENCIA_URL}` ,messeriPlanEmergencia)
}


actualizarPlanEmergencia(messeriPlanEmergencia : IplanEmergenciaMesseriPut) :Observable<IplanEmergencia> {

  return this._http.put<IplanEmergencia>(`${environment.BASE_URL_EME}${environment.EME_PLANEMERGENCIA_URL}` ,messeriPlanEmergencia)
}



/*

  obtenerMesseri(codigoEmpresa: number, codigoOficina: number) : Meseri {
      let  meseri: Meseri = new Meseri();
    this._http.get<Meseri>
      (`${environment.BASE_URL}${environment.EME_MESSERI_URL}?codigo=1&codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`).subscribe(

        data => {
          console.log(data)
          meseri = data
          this.existe= true

        },
        (err: HttpErrorResponse) => {
          console.log('Ocurrio un error')
          console.log(err.message)
        },
        () => {
          console.log('Peticion finalizada')
        }
      )

       return meseri

  }

  insertarMesseri(imeseri: Imeseri) {

    var token = localStorage.getItem('bearerToken');
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + token
    });

    let options = { headers: headers };

    console.log("Insertando")
    console.log(imeseri)
    this._http.post(`${environment.BASE_URL}${environment.EME_MESSERI_URL}`, imeseri,
      options

    ).subscribe(
      data => {
        console.log("Respuesta del Insert")
        console.log(data)
      },
      (err: HttpErrorResponse) => {
        console.log('Ocurrio un error')
        console.log(err.message)
      },
      () => {
        console.log('Peticion finalizada')
      }
  

 )

}

ActualizarMesseri(imeseri : Imeseri) {

  var token = localStorage.getItem('bearerToken');
  let headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + token
  });

  let options = { headers: headers };

  console.log("Actualizando")
  console.log(imeseri)
  this._http.put(`${environment.BASE_URL}${environment.EME_MESSERI_URL}`, imeseri, options).subscribe(
    data => {
      console.log(data)
      console.log("Actualizado.........")
    },
    (err: HttpErrorResponse) => {
      console.log('Ocurrio un error')
      console.log(err.error)
    },
    () => {
      console.log('Peticion finalizada')
    }


  )

}




}


  obtenerMesseri(codigoEmpresa: number, codigoOficina: number) : Meseri {
      let  meseri: Meseri = new Meseri();
    this._http.get<Meseri>
      (`${environment.BASE_URL}${environment.EME_MESSERI_URL}?codigo=1&codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`).subscribe(

        data => {
          console.log(data)
          meseri = data
          this.existe= true

        },
        (err: HttpErrorResponse) => {
          console.log('Ocurrio un error')
          console.log(err.message)
        },
        () => {
          console.log('Peticion finalizada')
        }
      )

       return meseri

  }

  insertarMesseri(imeseri: Imeseri) {

    var token = localStorage.getItem('bearerToken');
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + token
    });

    let options = { headers: headers };

    console.log("Insertando")
    console.log(imeseri)
    this._http.post(`${environment.BASE_URL}${environment.EME_MESSERI_URL}`, imeseri,
      options

    ).subscribe(
      data => {
        console.log("Respuesta del Insert")
        console.log(data)
      },
      (err: HttpErrorResponse) => {
        console.log('Ocurrio un error')
        console.log(err.message)
      },
      () => {
        console.log('Peticion finalizada')
      }
  

 )

}

ActualizarMesseri(imeseri : Imeseri) {

  var token = localStorage.getItem('bearerToken');
  let headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + token
  });

  let options = { headers: headers };

  console.log("Actualizando")
  console.log(imeseri)
  this._http.put(`${environment.BASE_URL}${environment.EME_MESSERI_URL}`, imeseri, options).subscribe(
    data => {
      console.log(data)
      console.log("Actualizado.........")
    },
    (err: HttpErrorResponse) => {
      console.log('Ocurrio un error')
      console.log(err.error)
    },
    () => {
      console.log('Peticion finalizada')
    }


  )

}


*/

}
