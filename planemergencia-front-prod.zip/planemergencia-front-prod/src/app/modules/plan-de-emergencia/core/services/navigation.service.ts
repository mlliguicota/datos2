import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import Constantes from '../util/constantes';

@Injectable({
  providedIn: 'root',
})
export class NavigationService {
  navigationObservable: BehaviorSubject<string>=
  new BehaviorSubject<string>(Constantes.NAVIGATION_KEEP_CURRENT);

  get NavigationObservable():Observable<string> {
    return this.navigationObservable.asObservable();
  }
  set NavigationObservableData(navigation:string) {
    this.navigationObservable.next(navigation);
  }
}
