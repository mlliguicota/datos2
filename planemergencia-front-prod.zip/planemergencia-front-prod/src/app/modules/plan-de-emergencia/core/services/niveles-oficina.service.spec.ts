import { TestBed } from '@angular/core/testing';

import { NivelesOficinaService } from './niveles-oficina.service';

describe('NivelesOficinaService', () => {
  let service: NivelesOficinaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NivelesOficinaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
