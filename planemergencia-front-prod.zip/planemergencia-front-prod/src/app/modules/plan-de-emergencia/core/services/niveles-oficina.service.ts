import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { InivelOficina, InivelOficinaGet } from '../interfaces/nivelOficina.interface';

@Injectable({
  providedIn: 'root'
})
export class NivelesOficinaService {

  constructor(private _http : HttpClient) { }

  private lista_niveles : Array<InivelOficina> = new Array<InivelOficina> ();
  private numero_pisos : number = 0;


  obtenerListaNiveles() :Array<InivelOficina> {
       
     return this.lista_niveles

   }

   obtenerPisos() :number{
       
    return this.numero_pisos

  }

  obtenerNivelesOficinas(codigoEmpresa :number  , codigoOficina :number ):Observable<InivelOficinaGet >   {

    return  this._http.get<InivelOficinaGet >(`${environment.BASE_URL_EME}${environment.EME_NIVELES_OFICINA_URL}?codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`)
 
   }


  obtenerNiveles(codigoEmpresa :number  , codigoOficina :number){
     
    return new Promise((resolve)=> {

      this.obtenerNivelesOficinas(codigoEmpresa , codigoOficina).subscribe(  data  => {
        console.log('Ingrese a exitoso' + data.numberOfPages)
         
         this.lista_niveles  = data.pageContent;
         
         this.lista_niveles.sort(
          (firstObject: InivelOficina, secondObject: InivelOficina) =>
            (firstObject.numeroPiso > secondObject.numeroPiso) ? 1 : -1
      )

      this.numero_pisos = this.lista_niveles.length
         console.log( this.lista_niveles )
 
      const dataRes = { resCode: 0 };
      resolve(dataRes);

      } ,
      (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al obtener los riesgos';
        const dataErr = { resCode: -1, error: e };
        console.log(e)
        resolve(dataErr);
        
   
      }

    )


    })


  }




}
