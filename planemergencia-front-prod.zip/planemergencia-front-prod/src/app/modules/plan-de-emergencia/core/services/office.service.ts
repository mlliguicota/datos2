import { Injectable } from '@angular/core';
import { GenService } from 'src/app/core/services/gen.service';
import { IOficina } from '../interfaces/oficina.interface';
import { IUsuario } from '../interfaces/usuario.interface';

@Injectable({
  providedIn: 'root',
})
export class OfficeService {
  private officesData:any[]=[];
  private officesInformationData:any[]=[];
  private officeTypesData:any[]=[];
  constructor(private _gen: GenService) { }

  getOfficesData() {
    return this.officesData;
  }
  getOfficesInformationData() {
    return this.officesInformationData;
  }

  getOfficeTypesData() {
    return this.officeTypesData;
  }

  obtenerOfficesData(codigoTipoOficina: number) {
    return new Promise((resolve)=>{
      this._gen.getOficinas(codigoTipoOficina).subscribe({
        next: (res:any)=>{
          if (res != null) {
            console.log('Imprimiendo oficinas!!!');
            console.log(res.pageContent);
            // lista de oficinas
            this.officesData=res.pageContent;
            const data = { resCode: 0 };
            resolve(data);
          }
        },
        error: (err)=>{
          const e='Ocurrio un error inesperado obteniendo las oficinas';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    },
    );
  }

  obtenerOfficeTypesData() {
    return new Promise((resolve)=>{
      this._gen.getTiposOficinas().subscribe({
        next: (res:any)=>{
          if (res != null) {
            console.log('Imprimiendo tipos oficinas!!!');
            console.log(res.pageContent);
            // lista de oficinas
            this.officeTypesData=res.pageContent;
            const data = { resCode: 0 };
            resolve(data);
          }
        },
        error: (err)=>{
          const e='Ocurrio un error inesperado obteniendo las oficinas';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    },
    );
  }

  obtenerOfficeInformationData() {
    return new Promise((resolve)=>{
      this._gen.getTiposOficinasInformacion().subscribe({
        next: (res:any)=>{
          if (res != null) {
            console.log('Imprimiendo informacion de oficinas!!!');
            console.log(res.pageContent);
            // lista de oficinas
            this.officesInformationData=res.pageContent;
            const data = { resCode: 0 };
            resolve(data);
          }
        },
        error: (err:any)=>{
          const e='Ocurrio un error inesperado obteniendo las oficinas';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    },
    );
  }
  
  async actualizarOficina(ofi:IOficina, user:IUsuario) {
    return new Promise((resolve)=>{
      this._gen.putOficina(ofi, user).subscribe({
        next: (res:any)=>{
          if (res != null) {
            console.log('Imprimiendo oficinas!!!');
            console.log(res.pageContent);
            // lista de oficinas
            // this.officesData=res.pageContent;
            const data = { resCode: 0 };
            resolve(data);
          }
        },
        error: (err)=>{
          console.log(err);
          const e='Ocurrio un error al generar la informacion de la oficina';
          const data = { resCode: -1, error: err.error.message??e };
          resolve(data);
        },
      });
    },
    );
  }
  async crearOficina(ofi:IOficina, user:IUsuario, tipoOficina:number) {
    return new Promise((resolve)=>{
      this._gen.crearOficina(ofi, user, tipoOficina).subscribe({
        next: (res:any)=>{
          if (res != null) {
            console.log('Guardando oficinas!!!');
            console.log(res.pageContent);
            const data = { resCode: 0  , codigo: res.id.codigo  , codigoEmpresa : res.id.codigoEmpresa};
            
            resolve(data);
          }
        },
        error: (err)=>{
          console.log(err);
          const e='Ocurrio un error al agregar los datos de la oficina';
          const data = { resCode: -1, error: err.error.message??e };
          resolve(data);
        },
      });
    },
    );
  }
}
