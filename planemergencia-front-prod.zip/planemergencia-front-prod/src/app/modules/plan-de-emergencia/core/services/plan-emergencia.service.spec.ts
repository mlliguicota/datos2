import { TestBed } from '@angular/core/testing';

import { PlanEmergenciaService } from './plan-emergencia.service';

describe('PlanEmergenciaService', () => {
  let service: PlanEmergenciaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PlanEmergenciaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
