import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { RequestPLanEmergencia } from '../interfaces/planEmergencia.interface';

@Injectable({
  providedIn: 'root'
})
export class PlanEmergenciaService {

  private URL_PLAN=environment.BASE_URL_EME + environment.EME_PLANEMERGENCIA_URL;

  constructor(private _http : HttpClient) { }

  planEmergencia : RequestPLanEmergencia;


  obtenerPlanEmergenciaRequest() :RequestPLanEmergencia {

    return  this.planEmergencia
  }

  obtenerPlanEmergencia(codigoEmpresa :number  , codigoOficina :number ):Observable<RequestPLanEmergencia>   {

   return  this._http.get<RequestPLanEmergencia>(`${environment.BASE_URL_EME}${environment.EME_PLANEMERGENCIA_URL}?codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`)

  }

  putTS(codigoEmpresa :number  , codigoOficina :number, usuario : string, valorTs : number) :Observable<RequestPLanEmergencia>   {
    const body = {
        nombreEquipo: "Nombre equipo",
        fechaModificacion: new Date(),
        usuarioModificacion: usuario,
        id: {
          codigoOficina: codigoOficina,
          codigoEmpresa: codigoEmpresa
        },
        tiempoSalida: valorTs
    }

    console.log(body);

    return this._http.put<RequestPLanEmergencia>(this.URL_PLAN,body);
  }

  putObservacionEvacuacion(codigoEmpresa :number  , codigoOficina :number, usuario : string, observacion : string) :Observable<RequestPLanEmergencia>   {
    const body = {
        nombreEquipo: "Nombre equipo",
        fechaModificacion: new Date(),
        usuarioModificacion: usuario,
        id: {
          codigoOficina: codigoOficina,
          codigoEmpresa: codigoEmpresa
        },
        observacionesEvacuacion: observacion
    }

    return this._http.put<RequestPLanEmergencia>(this.URL_PLAN,body);
  }



  obtenerPlan(codigoEmpresa :number  , codigoOficina :number) {
    return new Promise((resolve)=>{
      this.obtenerPlanEmergencia(codigoEmpresa , codigoOficina).subscribe({
        next: (res: RequestPLanEmergencia)=>{
          if (res.totalItems > 0) {
            console.log('Obteniendo plan Emergencia');
            console.log(res);
            this.planEmergencia = res
            const data = { resCode: 1 };
            resolve(data);
          }
          else {
            console.log('No existe plan de Emergencia');
            const data = { resCode: 0 };
            resolve(data);

          }
        },
        error: (err)=>{
          const e='Ocurrio un error inesperado obteniendo las oficinas';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    },
    );
  }


}
