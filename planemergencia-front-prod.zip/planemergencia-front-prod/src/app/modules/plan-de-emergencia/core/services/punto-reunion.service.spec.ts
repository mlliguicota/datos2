import { TestBed } from '@angular/core/testing';

import { PuntoReunionService } from './punto-reunion.service';

describe('PuntoReunionService', () => {
  let service: PuntoReunionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PuntoReunionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
