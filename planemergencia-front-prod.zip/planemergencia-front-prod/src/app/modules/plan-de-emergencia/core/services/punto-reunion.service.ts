import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IConsecuenciaGet } from '../interfaces/consecuencias.interface';
import { IestimacionRiesgo } from '../interfaces/estimacionRiesgo.interfaces';
import { IpeligroPuntoEncuentro, IpeligroPuntoEncuentroPost, IpeligroPuntoEncuentroPut } from '../interfaces/peligroPuntoEncuentro.interface';
import { IplanEmergencia, IplanEmergenciaPuntoReunionPut } from '../interfaces/planEmergencia.interface';
import { IProbabilidadGet } from '../interfaces/probabilidades.interface';

@Injectable({
  providedIn: 'root'
})
export class PuntoReunionService {

  constructor(private _http : HttpClient) { }



  
  obtenerProbabilidades ( ):Observable<IProbabilidadGet>   {

    return  this._http.get<IProbabilidadGet>(`${environment.BASE_URL_EME}${environment.EME_PROBABILIDADES}?page=1&size=20`)
 
   }

   obtenerConsecuencias ( ):Observable<IConsecuenciaGet>   {

    return  this._http.get<IConsecuenciaGet>(`${environment.BASE_URL_EME}${environment.EME_CONSECUENCIAS}?page=1&size=20`)
 
   }
   

   obtenerEstimacionesRiesgos ( ):Observable<IestimacionRiesgo>   {

    return  this._http.get<IestimacionRiesgo>(`${environment.BASE_URL_EME}${environment.EME_ESTIMACIONES_RIESGOS}?page=1&size=20`)
 
   }

   obtenerPeligroPuntoEncuentro(codigoEmpresa: number, codigoOficina: number) :Observable<IpeligroPuntoEncuentro> { 

    return  this._http.get<IpeligroPuntoEncuentro> (`${environment.BASE_URL_EME}${environment.EME_PELIGRO_PUNTO_ENCUENTRO}?codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`)
  
  }

  registrarPeligroPuntoEncuentro( puntoEncuentro : IpeligroPuntoEncuentroPost[] ):Observable<IpeligroPuntoEncuentroPost[]>  {

    return  this._http.post<IpeligroPuntoEncuentroPost[]>(`${environment.BASE_URL_EME}${environment.EME_PELIGRO_PUNTO_ENCUENTRO}/varios`  ,puntoEncuentro)
   
   }
   actualizarPeligroPuntoEncuentro( puntoEncuentro : IpeligroPuntoEncuentroPut[]  ) :Observable<IpeligroPuntoEncuentroPut[]>  {
   
   return this._http.put<IpeligroPuntoEncuentroPut[]>(`${environment.BASE_URL_EME}${environment.EME_PELIGRO_PUNTO_ENCUENTRO}/varios`  ,puntoEncuentro)
   
   }

   actualizarPlanEmergencia(puntoReunionPlanEmergencia : IplanEmergenciaPuntoReunionPut) :Observable<IplanEmergencia> {

    return this._http.put<IplanEmergencia>(`${environment.BASE_URL_EME}${environment.EME_PLANEMERGENCIA_URL}` ,puntoReunionPlanEmergencia)
  }
}
