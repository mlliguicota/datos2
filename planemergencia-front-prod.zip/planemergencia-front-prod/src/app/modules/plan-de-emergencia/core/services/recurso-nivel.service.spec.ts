import { TestBed } from '@angular/core/testing';

import { RecursoNivelService } from './recurso-nivel.service';

describe('RecursoNivelService', () => {
  let service: RecursoNivelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RecursoNivelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
