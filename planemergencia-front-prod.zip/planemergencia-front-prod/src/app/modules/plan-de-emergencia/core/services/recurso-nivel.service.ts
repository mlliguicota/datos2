import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IRecursoNivelGet, IRecursoNivelPost, IRecursoNivelPut } from '../interfaces/recursoNivel.interface';

@Injectable({
  providedIn: 'root'
})
export class RecursoNivelService {

  constructor(private _http : HttpClient) { }


  obtenerRecursoNivel(nivel: number) :Observable<IRecursoNivelGet> { 

    return  this._http.get<IRecursoNivelGet> (`${environment.BASE_URL_EME}${environment.EME_RECURSO_NIVEL}?codigoNivel=${nivel}&page=1&size=30`)
  
  }



  registrarRecursosNiveles( recursoNivel : IRecursoNivelPost [] ) :Observable<any>  {

   return  this._http.post(`${environment.BASE_URL_EME}${environment.EME_RECURSOS_NIVELES_URL}/varios`  ,recursoNivel)
  
  }
  actualizarRecursoNiveles( recursoNivel :   IRecursoNivelPut [] ) :Observable<any>  {
  
 return this._http.put(`${environment.BASE_URL_EME}${environment.EME_RECURSOS_NIVELES_URL}/varios`  ,recursoNivel)
  
  }


}
