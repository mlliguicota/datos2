import { TestBed } from '@angular/core/testing';

import { RecursosExistentesService } from './recursos-existentes.service';

describe('RecursosExistentesService', () => {
  let service: RecursosExistentesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RecursosExistentesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
