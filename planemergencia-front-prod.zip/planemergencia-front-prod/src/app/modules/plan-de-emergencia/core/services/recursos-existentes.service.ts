import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IRecursoGet, IRecursoNivelGet, IRecursoNivelPost, IRecursoNivelPut, IrecursosExistentesPost, IrecursosExistentesPut } from '../interfaces/recursosExistentes.interface';

@Injectable({
  providedIn: 'root'
})
export class RecursosExistentesService {

  constructor(private  _http : HttpClient) { }

 
  registrarRecursoExistente( recursoExistente : IrecursosExistentesPost )  {

      this._http.post(`${environment.BASE_URL_EME}${environment.EME_PLANEMERGENCIA_URL}`  ,recursoExistente)

  }
  actualizarRecursoExistente( recursoExistente : IrecursosExistentesPut )  {

    this._http.post(`${environment.BASE_URL_EME}${environment.EME_PLANEMERGENCIA_URL}`  ,recursoExistente)

}


 obtenerRecursos():Observable<IRecursoGet>   {

  return  this._http.get<IRecursoGet>(`${environment.BASE_URL_EME}${environment.EME_RECURSOS_URL}?page=1&size=20`)

 }

 obtenerRecursosNiveles(codigoRecurso : number   , codigoNivel : number  ):Observable<IRecursoNivelGet>   {


  return  this._http.get<IRecursoNivelGet>(`${environment.BASE_URL_EME}${environment.EME_RECURSOS_NIVELES_URL}?codigoNivel=${codigoNivel}&codigoRecurso=${codigoRecurso}&page=1&size=20`)

 }





 obtenerObtenerNivelesOficina(codigoEmpresa : number   , codigoOficina : number  ):Observable<IRecursoNivelGet>   {


  return  this._http.get<IRecursoNivelGet>(`${environment.BASE_URL_EME}${environment.EME_NIVELES_OFICINA_URL}?codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`)

 }


 


  

}
