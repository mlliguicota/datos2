import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { IriesgoGet, IriesgoOficinagoGet, IriesgoOficinaPost, IriesgoOficinaPut } from  '../interfaces/seleccionRiesgo.interface'

@Injectable({
  providedIn: 'root'
})
export class RiesgosService {

  constructor(private _http : HttpClient) { }


  obtenerRiesgos():Observable<IriesgoGet>   {

   return  this._http.get<IriesgoGet>(`${environment.BASE_URL_EME}${environment.EME_RIESGOS_URL}?page=1&size=20`)

  }

  obtenerRiesgosOficinas (codigoOficina : number , codigoEmpresa : number):Observable<IriesgoOficinagoGet>   {

    return  this._http.get<IriesgoOficinagoGet>(`${environment.BASE_URL_EME}${environment.EME_RIESGOS_OFICINAS_URL}?codigoEmpresa=${codigoEmpresa}&codigoOficina=${codigoOficina}&page=1&size=20`)
 
   }

   registrarRiesgosOficinas( riesgosOficinas : IriesgoOficinaPost[] ):Observable<IriesgoOficinaPost[]>  {

   return  this._http.post<IriesgoOficinaPost[]>(`${environment.BASE_URL_EME}${environment.EME_RIESGOS_OFICINAS_URL_VARIOS}`  ,riesgosOficinas)
  
  }
  actualizarRiesgosOficinas( riesgosOficinas : IriesgoOficinaPut[]  ) :Observable<IriesgoOficinaPut[]>  {
  
  return this._http.put<IriesgoOficinaPut[]>(`${environment.BASE_URL_EME}${environment.EME_RIESGOS_OFICINAS_URL_VARIOS}`  ,riesgosOficinas)
  
  }
  

 



  
}

