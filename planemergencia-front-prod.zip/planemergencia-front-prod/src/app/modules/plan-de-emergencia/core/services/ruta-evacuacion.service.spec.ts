import { TestBed } from '@angular/core/testing';

import { RutaEvacuacionService } from './ruta-evacuacion.service';

describe('RutaEvacuacionService', () => {
  let service: RutaEvacuacionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RutaEvacuacionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
