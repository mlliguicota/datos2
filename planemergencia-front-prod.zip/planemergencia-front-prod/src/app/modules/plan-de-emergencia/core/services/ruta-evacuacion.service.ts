import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { RequestRutasEvacuacion } from '../interfaces/rutasEvacuacion.interface';

@Injectable({
  providedIn: 'root'
})
export class RutaEvacuacionService {

  constructor(private _http : HttpClient) { }


  obtenerRutasEvacuacion():Observable<RequestRutasEvacuacion>   {

   return  this._http.get<RequestRutasEvacuacion>(`${environment.BASE_URL_EME}${environment.EME_RUTAS_EVACUACION}?page=1&size=300`)

  }
}
