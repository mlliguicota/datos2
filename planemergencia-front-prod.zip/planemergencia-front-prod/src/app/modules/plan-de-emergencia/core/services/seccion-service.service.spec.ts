import { TestBed } from '@angular/core/testing';

import { PlSeccionService } from './seccion-service.service';

describe('SeccionServiceService', () => {
  let service: PlSeccionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PlSeccionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
