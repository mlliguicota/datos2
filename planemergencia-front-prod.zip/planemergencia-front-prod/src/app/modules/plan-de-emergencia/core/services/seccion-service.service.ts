import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ISeccionesGet } from '../interfaces/seccion.interface';




@Injectable({
  providedIn: 'root'
})
export class PlSeccionService {
  private EME_PLA_SECCIONES_URL=environment.BASE_URL_PLA+ environment.EME_PLA_SECCIONES_URL+"?size=200"; 

  constructor(private _http: HttpClient) { }

  getSecciones() :Observable<ISeccionesGet> {
    return this._http.get<ISeccionesGet>(this.EME_PLA_SECCIONES_URL);
}


}
