import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DescripcionEmpresaService } from './descripcion-empresa.service';

@Injectable({
  providedIn: 'root'
})



export class SeccionesService {
 
  private codigo_seccion_alcance : number ;
  private codigo_seccion_antecedente : number ;
  private tipo_plan_antecedente : number ;
  private tipo_plan_alcance : number ;

  constructor(private  _descripcionEmpresaService : DescripcionEmpresaService) { }

  obtenerPlantilla(valor : string) {
    return new Promise((resolve) => {
      this._descripcionEmpresaService.obtenerSeccion(valor).subscribe(
        datos => {
                 if (datos.totalItems == 0) {       
                 // this.messageService.add({severity:'error', summary: 'Error', detail: 'No se encontró la plantilla para antecendente'});
                      console.log('No se esta encontrando la plantilla para ' + valor)
                      const e='No se encontro la plantilla para ' + valor;
                      const dataErr = { resCode: -1, error: e };
                     resolve(dataErr);
                   } else {
  
                    console.log('Obtuve la plantilla de ' + valor)
                    console.log(datos)
                  
                    console.log( 'codigo seccion' + datos.pageContent[0].id.codigo)


                    if (valor=="Antecedentes") {
                      this.codigo_seccion_antecedente =datos.pageContent[0].id.codigo
                      this.tipo_plan_antecedente = datos.pageContent[0].id.codigoTipoPlan

                    }

                    if (valor=="Alcance") {
                      this.codigo_seccion_alcance =datos.pageContent[0].id.codigo
                      this.tipo_plan_alcance = datos.pageContent[0].id.codigoTipoPlan
                    }
            
                    //this.obtenerAntecedente();
                    const dataRes = { resCode: 0  ,
                                      seccion : {
                                               texto : datos.pageContent[0].texto ,
                                               codigoSeccion : datos.pageContent[0].id.codigo ,
                                               codigoTipoPlan : datos.pageContent[0].id.codigoTipoPlan
                                      } };
                    resolve(dataRes);
     
                  }             
               } ,
               (err: HttpErrorResponse) => {
                 const e='Ocurrio un error inesperado obteniendo la plantilla de ' + valor;
                 const dataErr = { resCode: -1, error: e };
                resolve(dataErr);
                 console.log('Error' )
             
              }
  
      )

    })
        
  
  }


  ObtenerTipoPlanAntecedente() :number{

        return this.tipo_plan_antecedente
  }

  ObtenerTipoPlanAlcance() :number{
      return this.tipo_plan_alcance
    
  }

  ObtenerCodigoSeccionAlcance() :number{
   return this.codigo_seccion_alcance
    
  }

  ObtenerCodigoSeccionAntecedente() :number{

    return this.codigo_seccion_antecedente
  }


 
  obtenerPlantillaAntecedente(valor : string){
    return new Promise((resolve) => {
      this._descripcionEmpresaService.obtenerSeccion("antecedentes").subscribe(
        datos => {
                 if (datos.totalItems == 0) {       
                 // this.messageService.add({severity:'error', summary: 'Error', detail: 'No se encontró la plantilla para antecendente'});
                      console.log('No se esta encontrando la plantilla para ' + valor)
                      const e='No se encontro la plantilla para ' + valor;
                      const dataErr = { resCode: -1, error: e };
                     resolve(dataErr);
                   } else {
  
                    console.log('Obtuve la plantilla de ' + valor)
                    console.log(datos)
                  
                    console.log( 'codigo seccion' + datos.pageContent[0].id.codigo)
            
                    //this.obtenerAntecedente();
                    const dataRes = { resCode: 0  ,
                                      seccion : {
                                               texto : datos.pageContent[0].texto ,
                                               codigoSeccion : datos.pageContent[0].id.codigo ,
                                               codigoTipoPlan : datos.pageContent[0].id.codigoTipoPlan
                                      } };
                    resolve(dataRes);
     
                  }             
               } ,
               (err: HttpErrorResponse) => {
                 const e='Ocurrio un error inesperado obteniendo la plantilla de ' + valor;
                 const dataErr = { resCode: -1, error: e };
                resolve(dataErr);
                 console.log('Error' )
             
              }
  
      )

    })
        
  
  }

}
