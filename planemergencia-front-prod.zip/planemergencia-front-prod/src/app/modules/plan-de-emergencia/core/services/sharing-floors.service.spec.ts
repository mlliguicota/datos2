import { TestBed } from '@angular/core/testing';

import { SharingFloorsService } from './sharing-floors.service';

describe('SharingFloorsService', () => {
  let service: SharingFloorsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SharingFloorsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
