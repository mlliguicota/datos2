import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ToastService } from 'src/app/core/services/toast.service';
import { INivel } from '../interfaces/nivel.interface';
import { IUsuario } from '../interfaces/usuario.interface';
import { FloorService } from './floor.service';
import { SharingOfficeService } from './sharing-office.service';

@Injectable({
  providedIn: 'root',
})
export class SharingFloorsService {
  // This is the list which will be show to the user on the screen
  // but it won't be the real changed unless they save the changes
  private floors: INivel[]=[];
  private sharingFloorsObservable: BehaviorSubject<INivel[]> =
    new BehaviorSubject<INivel[]>(this.floors);
    

  nivelesEliminar: INivel[]=[];
  nivelesActualizar: INivel[]=[];
  nivelesAgregados: INivel[]=[];
  nivelesOriginales:INivel[]=[];
  constructor(private _floorService:FloorService,
    private sharingOffice: SharingOfficeService,
    private toast: ToastService) {}

  isAModification():boolean {
    const length=this.nivelesEliminar.length+
      this.nivelesActualizar.length+
      this.nivelesAgregados.length;
    return length>0;
  }
  async deleteProcedure(user: IUsuario):Promise<boolean> {
    this.deleteTemporalFloors();
    let bool=true;
    if (this.nivelesEliminar.length>0) {
      console.log('----- PROCEDURE DELET------');
      await this._floorService.eliminarFloorsData(this.nivelesEliminar, user)
          .then((data:any)=>{
            if (data.resCode==0) {
              // Successfully message
              this.nivelesEliminar=[];
            } else {
              // TRY TO RETURN SOMETHING TO NOTIFY IF THERE IS A MISTAKE
              this.toast.mostrarToastError('Error al eliminar los niveles!!,'+
              ' intentelo de nuevo por favor.');
              bool=false;
              console.log('Error en el data.resCode al eliminar****');
            }
          }).catch((err) => {
            console.log('Error en el cath al eliminar****');
            this.toast.mostrarToastError('Error al eliminar los niveles!!,'+
              ' intentelo de nuevo por favor.');
            console.log(err);
            bool=false;
          });
    }
    console.log('Valor del boolean: ', bool);
    return bool;
  }
  async updateProcedure(user:IUsuario):Promise<boolean> {
    this.updateTemporalFloors();
    let bool=true;
    if (this.nivelesActualizar.length>0) {

      console.log('----- PROCEDURE UPDATE------');
      await this._floorService.actualizarFloorsData(this.nivelesActualizar,
          user)
          .then((data:any)=>{
            if (data.resCode==0) {
              // Successfully message
              this.nivelesActualizar=[];
            } else {
              // TRY TO RETURN SOMETHING TO NOTIFY IF THERE IS A MISTAKE
              this.toast.mostrarToastError('Error al actualizar los niveles!!,'+
              ' intentelo de nuevo por favor.');
              bool=false;
            }
          }).catch((err) => {
            this.toast.mostrarToastError('Error al actualizar los niveles!!,'+
              ' intentelo de nuevo por favor.');
            console.log(err);
            bool=false;
          });
    }
    return bool;
  }
  async appendProcedure(user:IUsuario , creado :boolean):Promise<boolean> {
    this.deleteTemporalFloors();
    let bool=true;
    if (this.nivelesAgregados.length>0) {
       // actualizo  
       if (creado) {
        for (let i = 0; i < this.nivelesAgregados.length ; i++) {
          this.nivelesAgregados[i].codigoOficina = this.sharingOffice.currentOfficeData.id.codigo  ;
          this.nivelesAgregados[i].codigoEmpresa =  this.sharingOffice.currentOfficeData.id.codigoEmpresa;
        }
   
       }
  
      console.log('----- PROCEDURE APPEND------');
      console.log(this.nivelesAgregados);
      await this._floorService.agregarFloorsData(this.nivelesAgregados, user)
          .then((data:any)=>{
            console.log(data);
            if (data.resCode==0) {
              // Successfully message
              this.nivelesAgregados=[];
            } else {
              this.toast.mostrarToastError('Error al actualizar los niveles!!,'+
              ' intentelo de nuevo por favor.');
              bool=false;
              console.log('ALSO WE CAN GET THE ERROR HERE');
            }
          }).catch((err) => {
            this.toast.mostrarToastError('Error al actualizar los niveles!!,'+
        ' intentelo de nuevo por favor.');
            console.log(' AQUI ESTA EL ERRO EN LA '+
            'SHARING FLOOR APPEND');
            console.log(err);
            bool= false;
          });
    }
    return bool;
  }


  // Getters and Setters
  get SharingFloorsObservable(): Observable<INivel[]> {
    return this.sharingFloorsObservable.asObservable();
  }
  get sharingFloorData():INivel[] {
    return this.floors;
  }

  set SharingFloorsObservableData(data: INivel[]) {
    this.floors = data;
    this.sharingFloorsObservable.next(this.floors);
  }
  // Add Floors
  set SharingAddFloorObservableData(data:INivel) {
    this.floors.push(data);
    this.sharingFloorsObservable.next(this.floors);
    this.addToJoinList(data);
  }
  // Remove Floor
  set SharingRemoveFloorObservableData(data:INivel) {
    const floors=this.floors;
    floors.forEach((value, index) => {
      if (data.id == value.id) floors.splice(index, 1);
    });
    this.floors=floors;
    this.sharingFloorsObservable.next(this.floors);
    this.addToDeleteList(data);
  }
  // Update Floor
  set SharingUpdateFloorObservableData(data:INivel) {
    const floors=this.floors;
    floors.forEach((value, index) => {
      if (data.id == value.id) floors[index]=data;
    });
    this.floors=floors;
    this.sharingFloorsObservable.next(this.floors);
    this.addToUpdateList(data);
  }
  set originalFloorList(niveles:INivel[]) {
    this.nivelesOriginales=niveles;
  }
  lastFloorNumber():number {
    let max=0;
    for (const floor of this.floors) {
      max=floor.numeroPiso>max?floor.numeroPiso:max;
    }
    return max;
  }
  restartSharing() {
    this.floors=[];
    this.nivelesActualizar=[];
    this.nivelesAgregados=[];
    this.nivelesEliminar=[];
    this.sharingFloorsObservable.next(this.floors);
  }
  private addToJoinList(nivel:INivel) {
    this.nivelesAgregados.push(nivel);
  }
  private addToDeleteList(nivel:INivel) {
    this.nivelesEliminar.push(nivel);
  }
  private addToUpdateList(nivel:INivel) {
    this.nivelesActualizar.push(nivel);
  }
  private floorEquals(nivel: INivel, nivel2:INivel) {
    return nivel.id==nivel2.id;
  }
  private floorIncludes(niveles:INivel[], nivel:INivel):boolean {
    for (const value of niveles) {
      if (value.id==nivel.id) return true;
    }
    return false;
  }
  private getIndex(niveles: INivel[], nivel:INivel) {
    const indexOfObject = niveles.findIndex((object) => {
      return object.id === nivel.id;
    });
    return indexOfObject;
  }
  private deletefromAList(niveles:INivel[], nivel:INivel):boolean {
    const ind=this.getIndex(niveles, nivel);
    if (ind!=-1) {
      niveles.splice(ind, 1);
      return true;
    }
    return false;
  }
  private updateFromAList(niveles:INivel[], nivel:INivel):boolean {
    // Take care about if we are changing the value of a
    // copy or the original List
    let bool=false;
    niveles.forEach((value, index) => {
      if (nivel.id == value.id) {
        niveles[index]=nivel;
        bool=true;
      }
    });
    return bool;
  }
  private deleteTemporalFloors() {
    // For this we do not need so much time or a loading bar
    const temporalDeleting:INivel[]=[];
    let bool=false;
    console.log('Temporal deleting list:', this.nivelesEliminar);
    for (const nivel of this.nivelesEliminar) {
      bool=bool || this.deletefromAList(this.nivelesAgregados, nivel);
      bool=bool ||this.deletefromAList(this.nivelesActualizar, nivel);
      if (bool) temporalDeleting.push(nivel);
      bool=false;
    }
    // deleting the elements from the deletingList
    for (const nivel of temporalDeleting) {
      this.deletefromAList(this.nivelesEliminar, nivel);
    }
  }
  private updateTemporalFloors() {
    const temporalDeleting:INivel[]=[];
    let bool=false;
    // For this we do not need so much time or a loading bar
    for (const nivel of this.nivelesActualizar) {
      bool=this.updateFromAList(this.nivelesAgregados, nivel);
      if (bool) temporalDeleting.push(nivel);
    }
    for (const nivel of temporalDeleting) {
      this.deletefromAList(this.nivelesActualizar, nivel);
    }
  }
}
