import { TestBed } from '@angular/core/testing';

import { SharingOfficeService } from './sharing-office.service';

describe('SharingOfficeService', () => {
  let service: SharingOfficeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SharingOfficeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
