import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { IOficina } from '../interfaces/oficina.interface';
import Constantes from '../util/constantes';

@Injectable({
  providedIn: 'root',
})
export class SharingOfficeService {
  private currentOffice: IOficina=Constantes.OFICINA_DEFAULT;
  private sharingOfficeObservable: BehaviorSubject<IOficina> =
    new BehaviorSubject<IOficina>(this.currentOffice);
    private currentOfficeType:number=-1;
    private sharingOfficeTypeCodigo: BehaviorSubject<number> =
    new BehaviorSubject<number>(this.currentOfficeType);


  // Getters and Setters
  get SharingOfficeTypeCodigo(): Observable<number> {
    return this.sharingOfficeTypeCodigo.asObservable();
  }
  get SharingOfficeObservable(): Observable<IOficina> {
    return this.sharingOfficeObservable.asObservable();
  }
  get currentOfficeData():IOficina {
    return this.currentOffice;
  }
  get currentOfficeTypeData():number {
    return this.currentOfficeType;
  }

  set SharingOfficeTypeCodigoData(tipo: number) {
    this.currentOfficeType = tipo;
    this.sharingOfficeTypeCodigo.next(this.currentOfficeType);
  }
  set SharingOfficeObservableData(data: IOficina) {
    this.currentOffice = data;
    this.sharingOfficeObservable.next(this.currentOffice);
  }
  setPoblacion(poblacion:number) {
    this.currentOffice.poblacionTrabajadora=poblacion;
    this.sharingOfficeObservable.next(this.currentOffice);
  }
  setEvacuacion(evacuacion:number) {
    this.currentOffice.rutasEvacuacion=evacuacion;
    this.sharingOfficeObservable.next(this.currentOffice);
  }
  restartSharing() {
    this.currentOffice=Constantes.OFICINA_DEFAULT;
    this.sharingOfficeObservable.next(this.currentOffice);
  }
  // Let us know if the Office is valid to do operations
  letsProceed() {
    return this.currentOffice.id.codigo!=-1 &&
      this.currentOffice.id.codigoEmpresa!=-1;
  }
}
