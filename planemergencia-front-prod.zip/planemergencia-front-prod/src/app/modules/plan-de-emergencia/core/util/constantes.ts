import { Mood } from '../enums/mood.enum';
import { INivel } from '../interfaces/nivel.interface';
import { IOficina } from '../interfaces/oficina.interface';
import { IUsuario } from '../interfaces/usuario.interface';

export default class Constantes {
  public static OFICINA_DEFAULT:IOficina={
    id: {
      codigo: -1,
      codigoEmpresa: -1,
    },
    // nombreOficina: '',
    telefono: '',
    fax: '',
    actividadEmpresa: '',
    correo: '',
    procesosOficina: '',
    rutaFachada: '',
    rutaUbicacion: '',
    rutasEvacuacion: 0,
    razonSocial: '',
    edificacionOficina: '',
    ciudadOficina: '',
    provinciaOficina: '',
    direccionOficina: '',
    totalEmpleados: 0,
    cantidadHombres: 0,
    cantidadMujeres: 0,
    liderPiso: '',
    codigoTipoOficina: 0,
    poblacionTrabajadora: 0,
    nombreOficina: ''
  };
  public static NIVEL_DEFAULT:INivel={
    id: -1,
    codigoOficina: -1,
    codigoEmpresa: -1,
    numeroPiso: 0,
    nivel: 'DEFAULT NIVEL',
    areaTotal: 0,
    areaUtil: 0,
    totalHombres: 0,
    totalMujeres: 0,
    totalEmpleados: 0,
    servicios: 0,
    visitantes: 0,
    mood: Mood.ORIGINAL,
  };
  public static USUARIO_DEFAULT:IUsuario={
    id: -1,
    usuario: 'USUARIO_DEFAULT',
    codigoRol: -1,
  };
  public static NAVIGATION_GO_NEXT:string='GN';
  public static NAVIGATION_GO_PREVIOUS:string='GP';
  public static NAVIGATION_KEEP_CURRENT:string='KC';
}
