export const text  = `<div _ngcontent-pqb-c541="" id="printMe" style="margin: 0px 50px;">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <style type="text/css">
      .style_14 { width: 7.115in;}
      .style_13 { font-family: "Times New Roman"; font-size: 12pt;}
      .style_15 { font-family: "Times New Roman"; font-style: italic; font-size: 12pt;}
      .style_8 { font-family: "Times New Roman"; font-style: italic; font-size: 12pt; color: black; background-color: white;}
      .style_9 { font-family: "Times New Roman"; font-weight: bold; font-size: 12pt;}
      .style_6 { font-family: "Times New Roman"; height: 0.396in; width: 7.135in;}
      .style_7 { font-family: "Times New Roman";  height: 0.396in;}
      .style_0 {  font-family: "Times New Roman"; normal; font-variant: normal; font-weight: normal; font-size: 10pt; color: black; text-indent: 0em; letter-spacing: normal; word-spacing: normal; text-transform: none; white-space: normal; line-height: normal;}
      .style_10 { font-family: "Times New Roman"; font-size: 12pt; padding-top: 5pt;}
      .style_12 { font-family: "Times New Roman"; font-size: 12pt; padding-top: 5pt;}
      .style_11 { font-family: "Times New Roman"; font-size: 12pt; padding-top: 5pt;}
      .style_4 { font-family: "Times New Roman"; font-size: 12pt;}
      .style_5 { font-family: "Times New Roman"; font-size: 12pt;}
      .style_2 { font-family: "Times New Roman";}
      .style_3 { width: 7.135in;}

      @import url('https://themes.googleusercontent.com/fonts/css?kit=fpjTOVmNbO4Lz34iLyptLWOEp5l7D1DtylGw-U95tLL8KJMqGWCccmuET6d1pEg7');

      .lst-kix_list_33-5>li {
        counter-increment: lst-ctn-kix_list_33-5
      }

      .lst-kix_list_21-8>li {
        counter-increment: lst-ctn-kix_list_21-8
      }

      ol.lst-kix_list_33-5.start {
        counter-reset: lst-ctn-kix_list_33-5 0
      }

      ol.lst-kix_list_9-0.start {
        counter-reset: lst-ctn-kix_list_9-0 0
      }

      ol.lst-kix_list_20-2.start {
        counter-reset: lst-ctn-kix_list_20-2 0
      }

      .lst-kix_list_5-0>li {
        counter-increment: lst-ctn-kix_list_5-0
      }

      ol.lst-kix_list_2-3.start {
        counter-reset: lst-ctn-kix_list_2-3 0
      }

      ol.lst-kix_list_23-2.start {
        counter-reset: lst-ctn-kix_list_23-2 0
      }

      ol.lst-kix_list_5-3.start {
        counter-reset: lst-ctn-kix_list_5-3 0
      }

      .lst-kix_list_29-8>li {
        counter-increment: lst-ctn-kix_list_29-8
      }

      .lst-kix_list_24-7>li {
        counter-increment: lst-ctn-kix_list_24-7
      }

      ol.lst-kix_list_8-8.start {
        counter-reset: lst-ctn-kix_list_8-8 0
      }

      ol.lst-kix_list_26-7.start {
        counter-reset: lst-ctn-kix_list_26-7 0
      }

      .lst-kix_list_24-7>li:before {
        content: ""counter(lst-ctn-kix_list_24-7, lower-latin) ". "
      }

      .lst-kix_list_1-4>li {
        counter-increment: lst-ctn-kix_list_1-4
      }

      .lst-kix_list_24-8>li:before {
        content: ""counter(lst-ctn-kix_list_24-8, lower-roman) ". "
      }

      ol.lst-kix_list_1-6.start {
        counter-reset: lst-ctn-kix_list_1-6 0
      }

      ol.lst-kix_list_9-5.start {
        counter-reset: lst-ctn-kix_list_9-5 0
      }

      .lst-kix_list_24-2>li:before {
        content: ""counter(lst-ctn-kix_list_24-2, lower-roman) ". "
      }

      ol.lst-kix_list_16-0 {
        list-style-type: none
      }

      ol.lst-kix_list_20-7.start {
        counter-reset: lst-ctn-kix_list_20-7 0
      }

      .lst-kix_list_24-3>li:before {
        content: ""counter(lst-ctn-kix_list_24-3, decimal) ". "
      }

      .lst-kix_list_24-4>li:before {
        content: ""counter(lst-ctn-kix_list_24-4, lower-latin) ". "
      }

      ol.lst-kix_list_34-2.start {
        counter-reset: lst-ctn-kix_list_34-2 0
      }
      
      .lst-kix_list_9-4>li {
        counter-increment: lst-ctn-kix_list_9-4
      }

      .lst-kix_list_24-5>li:before {
        content: ""counter(lst-ctn-kix_list_24-5, lower-roman) ". "
      }

      .lst-kix_list_24-6>li:before {
        content: ""counter(lst-ctn-kix_list_24-6, decimal) ". "
      }

      .lst-kix_list_23-6>li:before {
        content: ""counter(lst-ctn-kix_list_23-6, decimal) ". "
      }

      .lst-kix_list_6-5>li {
        counter-increment: lst-ctn-kix_list_6-5
      }

      ol.lst-kix_list_27-6 {
        list-style-type: none
      }

      ol.lst-kix_list_27-5 {
        list-style-type: none
      }

      ol.lst-kix_list_27-8 {
        list-style-type: none
      }

      .lst-kix_list_23-3>li:before {
        content: ""counter(lst-ctn-kix_list_23-3, decimal) ". "
      }

      .lst-kix_list_23-7>li:before {
        content: ""counter(lst-ctn-kix_list_23-7, lower-latin) ". "
      }

      ol.lst-kix_list_27-7 {
        list-style-type: none
      }

      ol.lst-kix_list_27-2 {
        list-style-type: none
      }

      .lst-kix_list_23-2>li:before {
        content: ""counter(lst-ctn-kix_list_23-2, lower-roman) ". "
      }

      ul.lst-kix_list_16-2 {
        list-style-type: none
      }

      ol.lst-kix_list_27-1 {
        list-style-type: none
      }

      ol.lst-kix_list_23-7.start {
        counter-reset: lst-ctn-kix_list_23-7 0
      }

      ul.lst-kix_list_16-1 {
        list-style-type: none
      }

      ol.lst-kix_list_27-4 {
        list-style-type: none
      }

      ol.lst-kix_list_27-3 {
        list-style-type: none
      }

      .lst-kix_list_23-0>li:before {
        content: ""counter(lst-ctn-kix_list_23-0, decimal) ". "
      }

      .lst-kix_list_23-8>li:before {
        content: ""counter(lst-ctn-kix_list_23-8, lower-roman) ". "
      }

      .lst-kix_list_3-6>li {
        counter-increment: lst-ctn-kix_list_3-6
      }

      ol.lst-kix_list_27-0 {
        list-style-type: none
      }

      .lst-kix_list_23-1>li:before {
        content: ""counter(lst-ctn-kix_list_23-1, lower-latin) ". "
      }

      

      .lst-kix_list_24-1>li:before {
        content: ""counter(lst-ctn-kix_list_24-1, lower-latin) ". "
      }

      ul.lst-kix_list_16-8 {
        list-style-type: none
      }

      ul.lst-kix_list_16-7 {
        list-style-type: none
      }

      ul.lst-kix_list_16-6 {
        list-style-type: none
      }

      .lst-kix_list_2-8>li {
        counter-increment: lst-ctn-kix_list_2-8
      }

      ul.lst-kix_list_16-5 {
        list-style-type: none
      }

      .lst-kix_list_24-0>li:before {
        content: ""counter(lst-ctn-kix_list_24-0, decimal) ". "
      }

      ul.lst-kix_list_16-4 {
        list-style-type: none
      }

      ul.lst-kix_list_16-3 {
        list-style-type: none
      }

      ol.lst-kix_list_26-2.start {
        counter-reset: lst-ctn-kix_list_26-2 0
      }

      .lst-kix_list_23-4>li:before {
        content: ""counter(lst-ctn-kix_list_23-4, lower-latin) ". "
      }

      .lst-kix_list_23-5>li:before {
        content: ""counter(lst-ctn-kix_list_23-5, lower-roman) ". "
      }

      .lst-kix_list_8-6>li {
        counter-increment: lst-ctn-kix_list_8-6
      }

      
      .lst-kix_list_8-6>li {
        counter-increment: lst-ctn-kix_list_8-6
      }


      ol.lst-kix_list_9-7 {
        list-style-type: none
      }

      ol.lst-kix_list_9-8 {
        list-style-type: none
      }

      ol.lst-kix_list_3-0.start {
        counter-reset: lst-ctn-kix_list_3-0 0
      }

      ol.lst-kix_list_9-3 {
        list-style-type: none
      }

      ol.lst-kix_list_9-4 {
        list-style-type: none
      }

      .lst-kix_list_5-7>li {
        counter-increment: lst-ctn-kix_list_5-7
      }

      ol.lst-kix_list_9-5 {
        list-style-type: none
      }

      ol.lst-kix_list_34-7.start {
        counter-reset: lst-ctn-kix_list_34-7 0
      }

      ol.lst-kix_list_9-6 {
        list-style-type: none
      }

      ol.lst-kix_list_9-0 {
        list-style-type: none
      }

      ol.lst-kix_list_9-1 {
        list-style-type: none
      }

      ol.lst-kix_list_9-2 {
        list-style-type: none
      }

      .lst-kix_list_22-4>li:before {
        content: "o  "
      }

      ol.lst-kix_list_25-5.start {
        counter-reset: lst-ctn-kix_list_25-5 0
      }

      ol.lst-kix_list_29-2.start {
        counter-reset: lst-ctn-kix_list_29-2 0
      }

      .lst-kix_list_25-5>li:before {
        content: ""counter(lst-ctn-kix_list_25-5, lower-roman) ". "
      }

      .lst-kix_list_25-7>li:before {
        content: ""counter(lst-ctn-kix_list_25-7, lower-latin) ". "
      }

      .lst-kix_list_3-5>li {
        counter-increment: lst-ctn-kix_list_3-5
      }

      ol.lst-kix_list_1-1.start {
        counter-reset: lst-ctn-kix_list_1-1 0
      }

      ol.lst-kix_list_24-4.start {
        counter-reset: lst-ctn-kix_list_24-4 0
      }

      ol.lst-kix_list_33-0.start {
        counter-reset: lst-ctn-kix_list_33-0 0
      }

      



      .lst-kix_list_6-4>li {
        counter-increment: lst-ctn-kix_list_6-4
      }

      ol.lst-kix_list_27-4.start {
        counter-reset: lst-ctn-kix_list_27-4 0
      }

      ol.lst-kix_list_18-0 {
        list-style-type: none
      }

      .lst-kix_list_9-3>li {
        counter-increment: lst-ctn-kix_list_9-3
      }

      ol.lst-kix_list_2-8.start {
        counter-reset: lst-ctn-kix_list_2-8 0
      }

      ol.lst-kix_list_29-8 {
        list-style-type: none
      }

      ol.lst-kix_list_29-7 {
        list-style-type: none
      }

      ol.lst-kix_list_29-4 {
        list-style-type: none
      }

      ol.lst-kix_list_29-3 {
        list-style-type: none
      }

      ol.lst-kix_list_29-6 {
        list-style-type: none
      }

      ol.lst-kix_list_29-5 {
        list-style-type: none
      }

      ol.lst-kix_list_29-0 {
        list-style-type: none
      }

      ol.lst-kix_list_5-8.start {
        counter-reset: lst-ctn-kix_list_5-8 0
      }

      ol.lst-kix_list_29-2 {
        list-style-type: none
      }

      ol.lst-kix_list_29-1 {
        list-style-type: none
      }

      .lst-kix_list_1-3>li {
        counter-increment: lst-ctn-kix_list_1-3
      }

      ul.lst-kix_list_18-8 {
        list-style-type: none
      }

      ul.lst-kix_list_18-7 {
        list-style-type: none
      }

      ul.lst-kix_list_18-6 {
        list-style-type: none
      }

      ul.lst-kix_list_18-5 {
        list-style-type: none
      }

      ul.lst-kix_list_18-4 {
        list-style-type: none
      }

      ul.lst-kix_list_18-3 {
        list-style-type: none
      }

      ul.lst-kix_list_18-2 {
        list-style-type: none
      }

      ol.lst-kix_list_6-0.start {
        counter-reset: lst-ctn-kix_list_6-0 0
      }

      ul.lst-kix_list_18-1 {
        list-style-type: none
      }

      ol.lst-kix_list_3-1 {
        list-style-type: none
      }

      ol.lst-kix_list_3-2 {
        list-style-type: none
      }

      .lst-kix_list_24-8>li {
        counter-increment: lst-ctn-kix_list_24-8
      }

      ol.lst-kix_list_3-3 {
        list-style-type: none
      }

      ol.lst-kix_list_3-4.start {
        counter-reset: lst-ctn-kix_list_3-4 0
      }

      .lst-kix_list_5-1>li {
        counter-increment: lst-ctn-kix_list_5-1
      }

      ol.lst-kix_list_3-4 {
        list-style-type: none
      }

      ol.lst-kix_list_19-0.start {
        counter-reset: lst-ctn-kix_list_19-0 0
      }

      ol.lst-kix_list_21-3.start {
        counter-reset: lst-ctn-kix_list_21-3 0
      }

      ol.lst-kix_list_3-0 {
        list-style-type: none
      }

      ol.lst-kix_list_34-6 {
        list-style-type: none
      }

      ol.lst-kix_list_34-5 {
        list-style-type: none
      }

      ol.lst-kix_list_34-8 {
        list-style-type: none
      }

      ol.lst-kix_list_34-7 {
        list-style-type: none
      }

      ol.lst-kix_list_34-2 {
        list-style-type: none
      }

      ol.lst-kix_list_34-1 {
        list-style-type: none
      }

      ol.lst-kix_list_25-6.start {
        counter-reset: lst-ctn-kix_list_25-6 0
      }

      ol.lst-kix_list_34-4 {
        list-style-type: none
      }

      ol.lst-kix_list_34-3 {
        list-style-type: none
      }

      ol.lst-kix_list_34-0 {
        list-style-type: none
      }

      .lst-kix_list_21-8>li:before {
        content: ""counter(lst-ctn-kix_list_21-8, lower-roman) ". "
      }

      .lst-kix_list_26-5>li:before {
        content: ""counter(lst-ctn-kix_list_26-5, lower-roman) ". "
      }

      .lst-kix_list_16-0>li {
        counter-increment: lst-ctn-kix_list_16-0
      }

      .lst-kix_list_8-0>li {
        counter-increment: lst-ctn-kix_list_8-0
      }

      ol.lst-kix_list_3-5 {
        list-style-type: none
      }

      ol.lst-kix_list_3-6 {
        list-style-type: none
      }

      .lst-kix_list_26-8>li:before {
        content: ""counter(lst-ctn-kix_list_26-8, lower-roman) ". "
      }

      ol.lst-kix_list_3-7 {
        list-style-type: none
      }

      ol.lst-kix_list_3-8 {
        list-style-type: none
      }

      .lst-kix_list_21-0>li:before {
        content: ""counter(lst-ctn-kix_list_21-0, decimal) ". "
      }

      .lst-kix_list_26-1>li:before {
        content: ""counter(lst-ctn-kix_list_26-1, lower-latin) ". "
      }

      .lst-kix_list_21-1>li:before {
        content: "-  "
      }

      .lst-kix_list_34-3>li {
        counter-increment: lst-ctn-kix_list_34-3
      }

      .lst-kix_list_26-4>li:before {
        content: ""counter(lst-ctn-kix_list_26-4, lower-latin) ". "
      }

      .lst-kix_list_21-5>li:before {
        content: ""counter(lst-ctn-kix_list_21-5, lower-roman) ". "
      }

      .lst-kix_list_21-4>li:before {
        content: ""counter(lst-ctn-kix_list_21-4, lower-latin) ". "
      }

      .lst-kix_list_26-0>li:before {
        content: ""counter(lst-ctn-kix_list_26-0, decimal) ". "
      }

      ol.lst-kix_list_19-5.start {
        counter-reset: lst-ctn-kix_list_19-5 0
      }

      ol.lst-kix_list_26-3.start {
        counter-reset: lst-ctn-kix_list_26-3 0
      }

      ol.lst-kix_list_27-8.start {
        counter-reset: lst-ctn-kix_list_27-8 0
      }

      .lst-kix_list_21-0>li {
        counter-increment: lst-ctn-kix_list_21-0
      }

      .lst-kix_list_25-1>li:before {
        content: ""counter(lst-ctn-kix_list_25-1, lower-latin) ". "
      }

      .lst-kix_list_25-0>li:before {
        content: ""counter(lst-ctn-kix_list_25-0, decimal) ". "
      }

      ul.lst-kix_list_12-6 {
        list-style-type: none
      }

      ol.lst-kix_list_23-6 {
        list-style-type: none
      }

      ul.lst-kix_list_12-5 {
        list-style-type: none
      }

      ol.lst-kix_list_23-5 {
        list-style-type: none
      }

      ul.lst-kix_list_12-4 {
        list-style-type: none
      }

      ol.lst-kix_list_23-8 {
        list-style-type: none
      }

      ul.lst-kix_list_12-3 {
        list-style-type: none
      }

      ol.lst-kix_list_23-7 {
        list-style-type: none
      }

      ul.lst-kix_list_12-2 {
        list-style-type: none
      }

      ol.lst-kix_list_23-2 {
        list-style-type: none
      }

      ul.lst-kix_list_12-1 {
        list-style-type: none
      }

      ol.lst-kix_list_21-4.start {
        counter-reset: lst-ctn-kix_list_21-4 0
      }

      ol.lst-kix_list_23-1 {
        list-style-type: none
      }

      ul.lst-kix_list_12-0 {
        list-style-type: none
      }

      ol.lst-kix_list_23-4 {
        list-style-type: none
      }

      ol.lst-kix_list_23-3 {
        list-style-type: none
      }

      .lst-kix_list_27-7>li {
        counter-increment: lst-ctn-kix_list_27-7
      }

      ol.lst-kix_list_23-0 {
        list-style-type: none
      }

      ul.lst-kix_list_12-8 {
        list-style-type: none
      }

      ol.lst-kix_list_20-6.start {
        counter-reset: lst-ctn-kix_list_20-6 0
      }

      ul.lst-kix_list_12-7 {
        list-style-type: none
      }

      .lst-kix_list_34-1>li {
        counter-increment: lst-ctn-kix_list_34-1
      }

      .lst-kix_list_2-2>li {
        counter-increment: lst-ctn-kix_list_2-2
      }

      ol.lst-kix_list_5-0 {
        list-style-type: none
      }

      .lst-kix_list_3-7>li {
        counter-increment: lst-ctn-kix_list_3-7
      }

      ol.lst-kix_list_5-1 {
        list-style-type: none
      }

      .lst-kix_list_26-2>li {
        counter-increment: lst-ctn-kix_list_26-2
      }

      ol.lst-kix_list_5-2 {
        list-style-type: none
      }

  
 

      .lst-kix_list_21-2>li {
        counter-increment: lst-ctn-kix_list_21-2
      }

      .lst-kix_list_22-1>li:before {
        content: "o  "
      }

      .lst-kix_list_27-4>li:before {
        content: ""counter(lst-ctn-kix_list_27-4, lower-latin) ". "
      }

      .lst-kix_list_20-2>li {
        counter-increment: lst-ctn-kix_list_20-2
      }

      .lst-kix_list_6-6>li {
        counter-increment: lst-ctn-kix_list_6-6
      }

      ul.lst-kix_list_7-5 {
        list-style-type: none
      }

      ul.lst-kix_list_7-6 {
        list-style-type: none
      }

      .lst-kix_list_23-3>li {
        counter-increment: lst-ctn-kix_list_23-3
      }

      ul.lst-kix_list_7-3 {
        list-style-type: none
      }

      ul.lst-kix_list_7-4 {
        list-style-type: none
      }

      ul.lst-kix_list_7-7 {
        list-style-type: none
      }

      ul.lst-kix_list_7-8 {
        list-style-type: none
      }

      ol.lst-kix_list_5-7 {
        list-style-type: none
      }

      ol.lst-kix_list_5-8 {
        list-style-type: none
      }

      ol.lst-kix_list_26-8.start {
        counter-reset: lst-ctn-kix_list_26-8 0
      }

      ol.lst-kix_list_5-3 {
        list-style-type: none
      }

      ul.lst-kix_list_7-1 {
        list-style-type: none
      }

      .lst-kix_list_8-7>li {
        counter-increment: lst-ctn-kix_list_8-7
      }

      .lst-kix_list_19-6>li {
        counter-increment: lst-ctn-kix_list_19-6
      }

      ol.lst-kix_list_5-4 {
        list-style-type: none
      }

      ul.lst-kix_list_7-2 {
        list-style-type: none
      }

      .lst-kix_list_27-0>li:before {
        content: ""counter(lst-ctn-kix_list_27-0, decimal) ". "
      }

      ol.lst-kix_list_5-5 {
        list-style-type: none
      }

      ol.lst-kix_list_5-6 {
        list-style-type: none
      }

      ul.lst-kix_list_7-0 {
        list-style-type: none
      }

      .lst-kix_list_20-4>li {
        counter-increment: lst-ctn-kix_list_20-4
      }

      .lst-kix_list_9-5>li {
        counter-increment: lst-ctn-kix_list_9-5
      }

      .lst-kix_list_5-8>li {
        counter-increment: lst-ctn-kix_list_5-8
      }

      .lst-kix_list_27-0>li {
        counter-increment: lst-ctn-kix_list_27-0
      }

      li.li-bullet-3:before {
        margin-left: -18.8pt;
        white-space: nowrap;
        display: inline-block;
        min-width: 18.8pt
      }

      ol.lst-kix_list_19-4.start {
        counter-reset: lst-ctn-kix_list_19-4 0
      }

      ol.lst-kix_list_33-6.start {
        counter-reset: lst-ctn-kix_list_33-6 0
      }

      ol.lst-kix_list_2-2.start {
        counter-reset: lst-ctn-kix_list_2-2 0
      }

      ol.lst-kix_list_20-1.start {
        counter-reset: lst-ctn-kix_list_20-1 0
      }

      .lst-kix_list_25-4>li:before {
        content: ""counter(lst-ctn-kix_list_25-4, lower-latin) ". "
      }

      .lst-kix_list_19-4>li {
        counter-increment: lst-ctn-kix_list_19-4
      }

      .lst-kix_list_24-1>li {
        counter-increment: lst-ctn-kix_list_24-1
      }

      .lst-kix_list_25-8>li:before {
        content: ""counter(lst-ctn-kix_list_25-8, lower-roman) ". "
      }

      ol.lst-kix_list_25-1.start {
        counter-reset: lst-ctn-kix_list_25-1 0
      }

      ol.lst-kix_list_26-6.start {
        counter-reset: lst-ctn-kix_list_26-6 0
      }

      ol.lst-kix_list_21-8.start {
        counter-reset: lst-ctn-kix_list_21-8 0
      }

      li.li-bullet-8:before {
        margin-left: -17.4pt;
        white-space: nowrap;
        display: inline-block;
        min-width: 17.4pt
      }

      .lst-kix_list_34-8>li {
        counter-increment: lst-ctn-kix_list_34-8
      }

      ol.lst-kix_list_14-0 {
        list-style-type: none
      }

      .lst-kix_list_27-5>li {
        counter-increment: lst-ctn-kix_list_27-5
      }

      .lst-kix_list_20-5>li:before {
        content: ""counter(lst-ctn-kix_list_20-5, lower-roman) ". "
      }

      .lst-kix_list_28-8>li:before {
        content: ""counter(lst-ctn-kix_list_28-8, lower-roman) ". "
      }

      .lst-kix_list_20-1>li:before {
        content: ""counter(lst-ctn-kix_list_20-1, lower-latin) ". "
      }

      .lst-kix_list_24-6>li {
        counter-increment: lst-ctn-kix_list_24-6
      }

      ol.lst-kix_list_8-4.start {
        counter-reset: lst-ctn-kix_list_8-4 0
      }

      .lst-kix_list_28-4>li:before {
        content: ""counter(lst-ctn-kix_list_28-4, lower-latin) ". "
      }

      


      ol.lst-kix_list_3-5.start {
        counter-reset: lst-ctn-kix_list_3-5 0
      }

      .lst-kix_list_28-3>li {
        counter-increment: lst-ctn-kix_list_28-3
      }

      .lst-kix_list_21-7>li {
        counter-increment: lst-ctn-kix_list_21-7
      }

      ol.lst-kix_list_25-0.start {
        counter-reset: lst-ctn-kix_list_25-0 0
      }

      ol.lst-kix_list_25-8 {
        list-style-type: none
      }

      ol.lst-kix_list_25-7 {
        list-style-type: none
      }

      ul.lst-kix_list_14-4 {
        list-style-type: none
      }

      ol.lst-kix_list_25-4 {
        list-style-type: none
      }

      ul.lst-kix_list_14-3 {
        list-style-type: none
      }

      ol.lst-kix_list_25-3 {
        list-style-type: none
      }

      ul.lst-kix_list_14-2 {
        list-style-type: none
      }

      ol.lst-kix_list_25-6 {
        list-style-type: none
      }

      ul.lst-kix_list_14-1 {
        list-style-type: none
      }

      ol.lst-kix_list_25-5 {
        list-style-type: none
      }

      ol.lst-kix_list_25-0 {
        list-style-type: none
      }

      ol.lst-kix_list_25-2 {
        list-style-type: none
      }

      ol.lst-kix_list_25-1 {
        list-style-type: none
      }

      ul.lst-kix_list_14-8 {
        list-style-type: none
      }

      ul.lst-kix_list_14-7 {
        list-style-type: none
      }

      .lst-kix_list_25-4>li {
        counter-increment: lst-ctn-kix_list_25-4
      }

      ol.lst-kix_list_8-3.start {
        counter-reset: lst-ctn-kix_list_8-3 0
      }

      ul.lst-kix_list_14-6 {
        list-style-type: none
      }

      ul.lst-kix_list_14-5 {
        list-style-type: none
      }

      .lst-kix_list_28-0>li:before {
        content: ""counter(lst-ctn-kix_list_28-0, decimal) ". "
      }

      .lst-kix_list_27-8>li:before {
        content: ""counter(lst-ctn-kix_list_27-8, lower-roman) ". "
      }

      ol.lst-kix_list_20-3.start {
        counter-reset: lst-ctn-kix_list_20-3 0
      }

      .lst-kix_list_29-1>li {
        counter-increment: lst-ctn-kix_list_29-1
      }

      .lst-kix_list_19-1>li:before {
        content: ""counter(lst-ctn-kix_list_19-0, decimal) "."counter(lst-ctn-kix_list_19-1, decimal) " "
      }

      .lst-kix_list_27-8>li {
        counter-increment: lst-ctn-kix_list_27-8
      }

      .lst-kix_list_19-4>li:before {
        content: ""counter(lst-ctn-kix_list_19-0, decimal) "."counter(lst-ctn-kix_list_19-1, decimal) "."counter(lst-ctn-kix_list_19-2, decimal) "."counter(lst-ctn-kix_list_19-3, decimal) "."counter(lst-ctn-kix_list_19-4, decimal) " "
      }

      .lst-kix_list_19-3>li:before {
        content: ""counter(lst-ctn-kix_list_19-0, decimal) "."counter(lst-ctn-kix_list_19-1, decimal) "."counter(lst-ctn-kix_list_19-2, decimal) "."counter(lst-ctn-kix_list_19-3, decimal) " "
      }

      .lst-kix_list_15-0>li {
        counter-increment: lst-ctn-kix_list_15-0
      }

      ol.lst-kix_list_24-5.start {
        counter-reset: lst-ctn-kix_list_24-5 0
      }

      ol.lst-kix_list_6-6.start {
        counter-reset: lst-ctn-kix_list_6-6 0
      }

      ol.lst-kix_list_29-6.start {
        counter-reset: lst-ctn-kix_list_29-6 0
      }

      ol.lst-kix_list_1-5.start {
        counter-reset: lst-ctn-kix_list_1-5 0
      }

      ul.lst-kix_list_32-1 {
        list-style-type: none
      }

      ul.lst-kix_list_32-2 {
        list-style-type: none
      }

      ul.lst-kix_list_32-3 {
        list-style-type: none
      }

      ul.lst-kix_list_32-4 {
        list-style-type: none
      }

      ol.lst-kix_list_9-6.start {
        counter-reset: lst-ctn-kix_list_9-6 0
      }

      ul.lst-kix_list_32-5 {
        list-style-type: none
      }

      ul.lst-kix_list_32-6 {
        list-style-type: none
      }

      ol.lst-kix_list_27-5.start {
        counter-reset: lst-ctn-kix_list_27-5 0
      }

      ul.lst-kix_list_32-7 {
        list-style-type: none
      }

      ul.lst-kix_list_32-8 {
        list-style-type: none
      }

      ul.lst-kix_list_32-0 {
        list-style-type: none
      }

      .lst-kix_list_26-7>li {
        counter-increment: lst-ctn-kix_list_26-7
      }

      .lst-kix_list_33-7>li {
        counter-increment: lst-ctn-kix_list_33-7
      }

      .lst-kix_list_5-2>li {
        counter-increment: lst-ctn-kix_list_5-2
      }

      .lst-kix_list_19-6>li:before {
        content: ""counter(lst-ctn-kix_list_19-0, decimal) "."counter(lst-ctn-kix_list_19-1, decimal) "."counter(lst-ctn-kix_list_19-2, decimal) "."counter(lst-ctn-kix_list_19-3, decimal) "."counter(lst-ctn-kix_list_19-4, decimal) "."counter(lst-ctn-kix_list_19-5, decimal) "."counter(lst-ctn-kix_list_19-6, decimal) " "
      }

      ol.lst-kix_list_8-7.start {
        counter-reset: lst-ctn-kix_list_8-7 0
      }

      .lst-kix_list_28-5>li {
        counter-increment: lst-ctn-kix_list_28-5
      }

      .lst-kix_list_20-5>li {
        counter-increment: lst-ctn-kix_list_20-5
      }

      ol.lst-kix_list_24-0.start {
        counter-reset: lst-ctn-kix_list_24-0 0
      }

      ol.lst-kix_list_33-4.start {
        counter-reset: lst-ctn-kix_list_33-4 0
      }

      .lst-kix_list_21-6>li {
        counter-increment: lst-ctn-kix_list_21-6
      }

      ol.lst-kix_list_1-0.start {
        counter-reset: lst-ctn-kix_list_1-0 0
      }

      .lst-kix_list_18-0>li:before {
        content: ""counter(lst-ctn-kix_list_18-0, decimal) ". "
      }

      .lst-kix_list_3-0>li {
        counter-increment: lst-ctn-kix_list_3-0
      }


      .lst-kix_list_26-0>li {
        counter-increment: lst-ctn-kix_list_26-0
      }

      li.li-bullet-2:before {
        margin-left: -21.6pt;
        white-space: nowrap;
        display: inline-block;
        min-width: 21.6pt
      }

      ol.lst-kix_list_27-0.start {
        counter-reset: lst-ctn-kix_list_27-0 0
      }

      .lst-kix_list_27-4>li {
        counter-increment: lst-ctn-kix_list_27-4
      }

      .lst-kix_list_27-1>li {
        counter-increment: lst-ctn-kix_list_27-1
      }

      .lst-kix_list_25-2>li {
        counter-increment: lst-ctn-kix_list_25-2
      }

      .lst-kix_list_27-1>li:before {
        content: ""counter(lst-ctn-kix_list_27-1, lower-latin) ". "
      }

      .lst-kix_list_27-3>li:before {
        content: ""counter(lst-ctn-kix_list_27-3, decimal) ". "
      }

      ol.lst-kix_list_9-4.start {
        counter-reset: lst-ctn-kix_list_9-4 0
      }

      .lst-kix_list_21-3>li {
        counter-increment: lst-ctn-kix_list_21-3
      }

   

      ol.lst-kix_list_27-3.start {
        counter-reset: lst-ctn-kix_list_27-3 0
      }

      .lst-kix_list_10-7>li:before {
        content: "o  "
      }

      .lst-kix_list_20-1>li {
        counter-increment: lst-ctn-kix_list_20-1
      }

  

      .lst-kix_list_29-3>li {
        counter-increment: lst-ctn-kix_list_29-3
      }

      ol.lst-kix_list_20-8 {
        list-style-type: none
      }

      ol.lst-kix_list_20-5 {
        list-style-type: none
      }

      ol.lst-kix_list_20-4 {
        list-style-type: none
      }

      ol.lst-kix_list_20-7 {
        list-style-type: none
      }

      ol.lst-kix_list_20-6 {
        list-style-type: none
      }

      .lst-kix_list_9-2>li:before {
        content: ""counter(lst-ctn-kix_list_9-2, lower-roman) ". "
      }

      ol.lst-kix_list_20-1 {
        list-style-type: none
      }

      ol.lst-kix_list_20-0 {
        list-style-type: none
      }

      ol.lst-kix_list_20-3 {
        list-style-type: none
      }

      ol.lst-kix_list_20-2 {
        list-style-type: none
      }

      ol.lst-kix_list_14-0.start {
        counter-reset: lst-ctn-kix_list_14-0 0
      }

      .lst-kix_list_5-5>li {
        counter-increment: lst-ctn-kix_list_5-5
      }

      .lst-kix_list_9-0>li:before {
        content: ""counter(lst-ctn-kix_list_9-0, decimal) ". "
      }

      ul.lst-kix_list_21-1 {
        list-style-type: none
      }

      ol.lst-kix_list_33-7 {
        list-style-type: none
      }

      ol.lst-kix_list_24-3.start {
        counter-reset: lst-ctn-kix_list_24-3 0
      }

      ol.lst-kix_list_33-6 {
        list-style-type: none
      }

      ol.lst-kix_list_33-8 {
        list-style-type: none
      }

      ol.lst-kix_list_33-3 {
        list-style-type: none
      }

      ol.lst-kix_list_33-2 {
        list-style-type: none
      }

      .lst-kix_list_23-5>li {
        counter-increment: lst-ctn-kix_list_23-5
      }

      ol.lst-kix_list_33-5 {
        list-style-type: none
      }

   

      ol.lst-kix_list_33-4 {
        list-style-type: none
      }

      .lst-kix_list_6-3>li {
        counter-increment: lst-ctn-kix_list_6-3
      }

      ol.lst-kix_list_33-1 {
        list-style-type: none
      }

      ol.lst-kix_list_1-3.start {
        counter-reset: lst-ctn-kix_list_1-3 0
      }

      ol.lst-kix_list_33-0 {
        list-style-type: none
      }

      ol.lst-kix_list_29-1.start {
        counter-reset: lst-ctn-kix_list_29-1 0
      }

      ol.lst-kix_list_1-2.start {
        counter-reset: lst-ctn-kix_list_1-2 0
      }

      .lst-kix_list_29-1>li:before {
        content: ""counter(lst-ctn-kix_list_29-1, lower-latin) ". "
      }

      .lst-kix_list_20-4>li:before {
        content: ""counter(lst-ctn-kix_list_20-4, lower-latin) ". "
      }

      ol.lst-kix_list_6-1.start {
        counter-reset: lst-ctn-kix_list_6-1 0
      }

      .lst-kix_list_29-3>li:before {
        content: ""counter(lst-ctn-kix_list_29-3, decimal) ". "
      }

      .lst-kix_list_20-2>li:before {
        content: ""counter(lst-ctn-kix_list_20-2, lower-roman) ". "
      }

      .lst-kix_list_9-8>li:before {
        content: ""counter(lst-ctn-kix_list_9-8, lower-roman) ". "
      }

      ul.lst-kix_list_10-0 {
        list-style-type: none
      }

      .lst-kix_list_28-6>li {
        counter-increment: lst-ctn-kix_list_28-6
      }

      ol.lst-kix_list_33-1.start {
        counter-reset: lst-ctn-kix_list_33-1 0
      }

      .lst-kix_list_28-7>li:before {
        content: ""counter(lst-ctn-kix_list_28-7, lower-latin) ". "
      }

      ul.lst-kix_list_10-8 {
        list-style-type: none
      }

      .lst-kix_list_1-7>li:before {
        content: ""counter(lst-ctn-kix_list_1-7, lower-latin) ". "
      }

      ul.lst-kix_list_10-7 {
        list-style-type: none
      }

      ul.lst-kix_list_10-6 {
        list-style-type: none
      }

      ul.lst-kix_list_10-5 {
        list-style-type: none
      }

      ul.lst-kix_list_10-4 {
        list-style-type: none
      }

      .lst-kix_list_1-5>li:before {
        content: ""counter(lst-ctn-kix_list_1-5, lower-roman) ". "
      }

      ul.lst-kix_list_10-3 {
        list-style-type: none
      }

      .lst-kix_list_28-5>li:before {
        content: ""counter(lst-ctn-kix_list_28-5, lower-roman) ". "
      }

      ul.lst-kix_list_10-2 {
        list-style-type: none
      }

      ol.lst-kix_list_9-1.start {
        counter-reset: lst-ctn-kix_list_9-1 0
      }

      ul.lst-kix_list_10-1 {
        list-style-type: none
      }

      ol.lst-kix_list_24-2.start {
        counter-reset: lst-ctn-kix_list_24-2 0
      }

      .lst-kix_list_5-6>li {
        counter-increment: lst-ctn-kix_list_5-6
      }

      .lst-kix_list_2-1>li:before {
        content: "-  "
      }

      .lst-kix_list_19-8>li {
        counter-increment: lst-ctn-kix_list_19-8
      }

      .lst-kix_list_2-3>li:before {
        content: ""counter(lst-ctn-kix_list_2-3, decimal) ". "
      }

      ol.lst-kix_list_24-8.start {
        counter-reset: lst-ctn-kix_list_24-8 0
      }

      .lst-kix_list_30-4>li:before {
        content: "o  "
      }

      .lst-kix_list_20-8>li {
        counter-increment: lst-ctn-kix_list_20-8
      }

      .lst-kix_list_9-1>li {
        counter-increment: lst-ctn-kix_list_9-1
      }

      .lst-kix_list_3-2>li:before {
        content: ""counter(lst-ctn-kix_list_3-2, lower-roman) ". "
      }

      .lst-kix_list_26-7>li:before {
        content: ""counter(lst-ctn-kix_list_26-7, lower-latin) ". "
      }

      .lst-kix_list_8-1>li:before {
        content: ""counter(lst-ctn-kix_list_8-0, decimal) "."counter(lst-ctn-kix_list_8-1, decimal) ". "
      }

      ol.lst-kix_list_1-8.start {
        counter-reset: lst-ctn-kix_list_1-8 0
      }

      .lst-kix_list_6-0>li {
        counter-increment: lst-ctn-kix_list_6-0
      }

      .lst-kix_list_3-5>li:before {
        content: ""counter(lst-ctn-kix_list_3-5, lower-roman) ". "
      }

      .lst-kix_list_18-0>li {
        counter-increment: lst-ctn-kix_list_18-0
      }

      .lst-kix_list_30-7>li:before {
        content: "o  "
      }

      .lst-kix_list_8-6>li:before {
        content: ""counter(lst-ctn-kix_list_8-0, decimal) "."counter(lst-ctn-kix_list_8-1, decimal) "."counter(lst-ctn-kix_list_8-2, decimal) "."counter(lst-ctn-kix_list_8-3, decimal) "."counter(lst-ctn-kix_list_8-4, decimal) "."counter(lst-ctn-kix_list_8-5, decimal) "."counter(lst-ctn-kix_list_8-6, decimal) ". "
      }

      .lst-kix_list_26-2>li:before {
        content: ""counter(lst-ctn-kix_list_26-2, lower-roman) ". "
      }

      .lst-kix_list_21-6>li:before {
        content: ""counter(lst-ctn-kix_list_21-6, decimal) ". "
      }

      

      ol.lst-kix_list_16-0.start {
        counter-reset: lst-ctn-kix_list_16-0 2
      }

      .lst-kix_list_33-4>li {
        counter-increment: lst-ctn-kix_list_33-4
      }

      ol.lst-kix_list_27-2.start {
        counter-reset: lst-ctn-kix_list_27-2 0
      }

      .lst-kix_list_21-3>li:before {
        content: ""counter(lst-ctn-kix_list_21-3, decimal) ". "
      }

      .lst-kix_list_25-5>li {
        counter-increment: lst-ctn-kix_list_25-5
      }

      ol.lst-kix_list_29-4.start {
        counter-reset: lst-ctn-kix_list_29-4 0
      }

      ol.lst-kix_list_6-4.start {
        counter-reset: lst-ctn-kix_list_6-4 0
      }

      .lst-kix_list_17-1>li:before {
        content: "o  "
      }

      .lst-kix_list_25-3>li:before {
        content: ""counter(lst-ctn-kix_list_25-3, decimal) ". "
      }

  

      ol.lst-kix_list_27-1.start {
        counter-reset: lst-ctn-kix_list_27-1 0
      }

      .lst-kix_list_26-6>li {
        counter-increment: lst-ctn-kix_list_26-6
      }

  

      ol.lst-kix_list_29-3.start {
        counter-reset: lst-ctn-kix_list_29-3 0
      }

      .lst-kix_list_3-3>li {
        counter-increment: lst-ctn-kix_list_3-3
      }

      ol.lst-kix_list_6-3.start {
        counter-reset: lst-ctn-kix_list_6-3 0
      }


      .lst-kix_list_2-6>li:before {
        content: ""counter(lst-ctn-kix_list_2-6, decimal) ". "
      }

   

      .lst-kix_list_27-6>li:before {
        content: ""counter(lst-ctn-kix_list_27-6, decimal) ". "
      }

      .lst-kix_list_19-5>li {
        counter-increment: lst-ctn-kix_list_19-5
      }

      .lst-kix_list_28-2>li {
        counter-increment: lst-ctn-kix_list_28-2
      }

      .lst-kix_list_22-7>li:before {
        content: "o  "
      }

      .lst-kix_list_23-2>li {
        counter-increment: lst-ctn-kix_list_23-2
      }

      .lst-kix_list_34-7>li:before {
        content: ""counter(lst-ctn-kix_list_34-0, decimal) "."counter(lst-ctn-kix_list_34-1, decimal) "."counter(lst-ctn-kix_list_34-2, decimal) "."counter(lst-ctn-kix_list_34-3, decimal) "."counter(lst-ctn-kix_list_34-4, decimal) "."counter(lst-ctn-kix_list_34-5, decimal) "."counter(lst-ctn-kix_list_34-6, decimal) "."counter(lst-ctn-kix_list_34-7, decimal) ". "
      }



      .lst-kix_list_6-7>li {
        counter-increment: lst-ctn-kix_list_6-7
      }

      .lst-kix_list_26-3>li {
        counter-increment: lst-ctn-kix_list_26-3
      }

      .lst-kix_list_1-7>li {
        counter-increment: lst-ctn-kix_list_1-7
      }

      ul.lst-kix_list_30-3 {
        list-style-type: none
      }

      ul.lst-kix_list_30-4 {
        list-style-type: none
      }

      ul.lst-kix_list_30-5 {
        list-style-type: none
      }

      ul.lst-kix_list_30-6 {
        list-style-type: none
      }

      .lst-kix_list_29-0>li {
        counter-increment: lst-ctn-kix_list_29-0
      }

      ol.lst-kix_list_24-7.start {
        counter-reset: lst-ctn-kix_list_24-7 0
      }

      ul.lst-kix_list_30-7 {
        list-style-type: none
      }

      ul.lst-kix_list_30-8 {
        list-style-type: none
      }



      ul.lst-kix_list_30-0 {
        list-style-type: none
      }

      ol.lst-kix_list_6-8.start {
        counter-reset: lst-ctn-kix_list_6-8 0
      }



      ul.lst-kix_list_30-1 {
        list-style-type: none
      }

      ul.lst-kix_list_30-2 {
        list-style-type: none
      }

      ol.lst-kix_list_1-7.start {
        counter-reset: lst-ctn-kix_list_1-7 0
      }

      .lst-kix_list_20-7>li:before {
        content: ""counter(lst-ctn-kix_list_20-7, lower-latin) ". "
      }

      ol.lst-kix_list_6-5.start {
        counter-reset: lst-ctn-kix_list_6-5 0
      }

      ol.lst-kix_list_29-8.start {
        counter-reset: lst-ctn-kix_list_29-8 0
      }

      .lst-kix_list_25-6>li:before {
        content: ""counter(lst-ctn-kix_list_25-6, decimal) ". "
      }

      ol.lst-kix_list_29-5.start {
        counter-reset: lst-ctn-kix_list_29-5 0
      }

      .lst-kix_list_34-2>li {
        counter-increment: lst-ctn-kix_list_34-2
      }

      ol.lst-kix_list_6-7.start {
        counter-reset: lst-ctn-kix_list_6-7 0
      }

      .lst-kix_list_9-5>li:before {
        content: ""counter(lst-ctn-kix_list_9-5, lower-roman) ". "
      }

      .lst-kix_list_29-6>li:before {
        content: ""counter(lst-ctn-kix_list_29-6, decimal) ". "
      }

      li.li-bullet-5:before {
        margin-left: -18.8pt;
        white-space: nowrap;
        display: inline-block;
        min-width: 18.8pt
      }

      .lst-kix_list_24-0>li {
        counter-increment: lst-ctn-kix_list_24-0
      }

      .lst-kix_list_33-3>li:before {
        content: ""counter(lst-ctn-kix_list_33-3, decimal) ". "
      }


      .lst-kix_list_32-7>li:before {
        content: "o  "
      }

      .lst-kix_list_1-2>li:before {
        content: ""counter(lst-ctn-kix_list_1-2, lower-roman) ". "
      }

      

      .lst-kix_list_1-0>li {
        counter-increment: lst-ctn-kix_list_1-0
      }

      li.li-bullet-0:before {
        margin-left: -18pt;
        white-space: nowrap;
        display: inline-block;
        min-width: 18pt
      }

      ol.lst-kix_list_29-7.start {
        counter-reset: lst-ctn-kix_list_29-7 0
      }

      .lst-kix_list_29-7>li {
        counter-increment: lst-ctn-kix_list_29-7
      }

      .lst-kix_list_28-2>li:before {
        content: ""counter(lst-ctn-kix_list_28-2, lower-roman) ". "
      }

      .lst-kix_list_14-1>li:before {
        content: "o  "
      }

      .lst-kix_list_25-8>li {
        counter-increment: lst-ctn-kix_list_25-8
      }

      .lst-kix_list_14-0>li:before {
        content: ""counter(lst-ctn-kix_list_14-0, decimal) ". "
      }

      .lst-kix_list_14-4>li:before {
        content: "o  "
      }

      .lst-kix_list_6-1>li {
        counter-increment: lst-ctn-kix_list_6-1
      }


      .lst-kix_list_14-7>li:before {
        content: "o  "
      }

      ol.lst-kix_list_15-0 {
        list-style-type: none
      }

      .lst-kix_list_17-0>li {
        counter-increment: lst-ctn-kix_list_17-0
      }

      .lst-kix_list_9-0>li {
        counter-increment: lst-ctn-kix_list_9-0
      }

      .lst-kix_list_34-6>li {
        counter-increment: lst-ctn-kix_list_34-6
      }

      ol.lst-kix_list_25-3.start {
        counter-reset: lst-ctn-kix_list_25-3 0
      }

      .lst-kix_list_20-7>li {
        counter-increment: lst-ctn-kix_list_20-7
      }

      ol.lst-kix_list_26-7 {
        list-style-type: none
      }

      ol.lst-kix_list_26-6 {
        list-style-type: none
      }

      ol.lst-kix_list_26-8 {
        list-style-type: none
      }

      ol.lst-kix_list_26-3 {
        list-style-type: none
      }

      ul.lst-kix_list_17-1 {
        list-style-type: none
      }

      ol.lst-kix_list_26-2 {
        list-style-type: none
      }

      ol.lst-kix_list_26-5 {
        list-style-type: none
      }

      ol.lst-kix_list_28-3.start {
        counter-reset: lst-ctn-kix_list_28-3 0
      }

      ol.lst-kix_list_26-4 {
        list-style-type: none
      }

      ol.lst-kix_list_26-1 {
        list-style-type: none
      }

      ol.lst-kix_list_26-0 {
        list-style-type: none
      }

      ul.lst-kix_list_17-8 {
        list-style-type: none
      }

      .lst-kix_list_32-1>li:before {
        content: "o  "
      }



      ul.lst-kix_list_17-7 {
        list-style-type: none
      }

      ol.lst-kix_list_21-6.start {
        counter-reset: lst-ctn-kix_list_21-6 0
      }

      ul.lst-kix_list_17-6 {
        list-style-type: none
      }

      ul.lst-kix_list_17-5 {
        list-style-type: none
      }

      ol.lst-kix_list_3-7.start {
        counter-reset: lst-ctn-kix_list_3-7 0
      }

      .lst-kix_list_28-7>li {
        counter-increment: lst-ctn-kix_list_28-7
      }

      ul.lst-kix_list_17-4 {
        list-style-type: none
      }

      ul.lst-kix_list_17-3 {
        list-style-type: none
      }


      ul.lst-kix_list_17-2 {
        list-style-type: none
      }

      .lst-kix_list_3-2>li {
        counter-increment: lst-ctn-kix_list_3-2
      }

      .lst-kix_list_5-0>li:before {
        content: ""counter(lst-ctn-kix_list_5-0, decimal) ". "
      }

      ol.lst-kix_list_6-0 {
        list-style-type: none
      }

      ol.lst-kix_list_6-1 {
        list-style-type: none
      }

      .lst-kix_list_5-4>li {
        counter-increment: lst-ctn-kix_list_5-4
      }

      .lst-kix_list_5-3>li:before {
        content: ""counter(lst-ctn-kix_list_5-3, decimal) ". "
      }

      ol.lst-kix_list_24-6.start {
        counter-reset: lst-ctn-kix_list_24-6 0
      }

      .lst-kix_list_5-2>li:before {
        content: ""counter(lst-ctn-kix_list_5-2, lower-roman) ". "
      }

      .lst-kix_list_8-3>li {
        counter-increment: lst-ctn-kix_list_8-3
      }

      .lst-kix_list_5-1>li:before {
        content: ""counter(lst-ctn-kix_list_5-1, lower-latin) ". "
      }

      ol.lst-kix_list_18-0.start {
        counter-reset: lst-ctn-kix_list_18-0 4
      }

      .lst-kix_list_5-7>li:before {
        content: ""counter(lst-ctn-kix_list_5-7, lower-latin) ". "
      }

      .lst-kix_list_5-6>li:before {
        content: ""counter(lst-ctn-kix_list_5-6, decimal) ". "
      }

      .lst-kix_list_5-8>li:before {
        content: ""counter(lst-ctn-kix_list_5-8, lower-roman) ". "
      }

      ol.lst-kix_list_6-6 {
        list-style-type: none
      }

      ol.lst-kix_list_6-7 {
        list-style-type: none
      }

      .lst-kix_list_5-4>li:before {
        content: ""counter(lst-ctn-kix_list_5-4, lower-latin) ". "
      }

      ol.lst-kix_list_6-8 {
        list-style-type: none
      }

      .lst-kix_list_5-5>li:before {
        content: ""counter(lst-ctn-kix_list_5-5, lower-roman) ". "
      }

      ol.lst-kix_list_6-2 {
        list-style-type: none
      }

      ol.lst-kix_list_6-3 {
        list-style-type: none
      }

      ol.lst-kix_list_6-4 {
        list-style-type: none
      }

      ol.lst-kix_list_6-5 {
        list-style-type: none
      }

      .lst-kix_list_6-1>li:before {
        content: ""counter(lst-ctn-kix_list_6-1, lower-latin) ". "
      }

      .lst-kix_list_6-3>li:before {
        content: ""counter(lst-ctn-kix_list_6-3, decimal) ". "
      }

      .lst-kix_list_6-8>li {
        counter-increment: lst-ctn-kix_list_6-8
      }

      .lst-kix_list_6-0>li:before {
        content: ""counter(lst-ctn-kix_list_6-0, decimal) ". "
      }

      .lst-kix_list_6-4>li:before {
        content: ""counter(lst-ctn-kix_list_6-4, lower-latin) ". "
      }

      .lst-kix_list_6-2>li:before {
        content: ""counter(lst-ctn-kix_list_6-2, lower-roman) ". "
      }

      ol.lst-kix_list_15-0.start {
        counter-reset: lst-ctn-kix_list_15-0 1
      }

      .lst-kix_list_2-5>li {
        counter-increment: lst-ctn-kix_list_2-5
      }

      ol.lst-kix_list_3-2.start {
        counter-reset: lst-ctn-kix_list_3-2 0
      }

      .lst-kix_list_6-8>li:before {
        content: ""counter(lst-ctn-kix_list_6-8, lower-roman) ". "
      }

      .lst-kix_list_6-5>li:before {
        content: ""counter(lst-ctn-kix_list_6-5, lower-roman) ". "
      }

      .lst-kix_list_6-7>li:before {
        content: ""counter(lst-ctn-kix_list_6-7, lower-latin) ". "
      }

      .lst-kix_list_6-6>li:before {
        content: ""counter(lst-ctn-kix_list_6-6, decimal) ". "
      }

      ol.lst-kix_list_27-6.start {
        counter-reset: lst-ctn-kix_list_27-6 0
      }

      .lst-kix_list_7-4>li:before {
        content: "o  "
      }

      ol.lst-kix_list_19-7.start {
        counter-reset: lst-ctn-kix_list_19-7 0
      }

      ol.lst-kix_list_6-2.start {
        counter-reset: lst-ctn-kix_list_6-2 0
      }

      ol.lst-kix_list_24-1.start {
        counter-reset: lst-ctn-kix_list_24-1 0
      }

      ol.lst-kix_list_17-0 {
        list-style-type: none
      }


      .lst-kix_list_27-2>li {
        counter-increment: lst-ctn-kix_list_27-2
      }

      .lst-kix_list_34-8>li:before {
        content: ""counter(lst-ctn-kix_list_34-0, decimal) "."counter(lst-ctn-kix_list_34-1, decimal) "."counter(lst-ctn-kix_list_34-2, decimal) "."counter(lst-ctn-kix_list_34-3, decimal) "."counter(lst-ctn-kix_list_34-4, decimal) "."counter(lst-ctn-kix_list_34-5, decimal) "."counter(lst-ctn-kix_list_34-6, decimal) "."counter(lst-ctn-kix_list_34-7, decimal) "."counter(lst-ctn-kix_list_34-8, decimal) ". "
      }


      .lst-kix_list_24-3>li {
        counter-increment: lst-ctn-kix_list_24-3
      }

      .lst-kix_list_13-7>li:before {
        content: "o  "
      }

      ol.lst-kix_list_34-4.start {
        counter-reset: lst-ctn-kix_list_34-4 0
      }


      ol.lst-kix_list_23-0.start {
        counter-reset: lst-ctn-kix_list_23-0 0
      }

      ol.lst-kix_list_2-5.start {
        counter-reset: lst-ctn-kix_list_2-5 0
      }

      ol.lst-kix_list_28-8 {
        list-style-type: none
      }

      ol.lst-kix_list_26-0.start {
        counter-reset: lst-ctn-kix_list_26-0 0
      }

      .lst-kix_list_9-8>li {
        counter-increment: lst-ctn-kix_list_9-8
      }

      ol.lst-kix_list_28-5 {
        list-style-type: none
      }

      ol.lst-kix_list_28-4 {
        list-style-type: none
      }

      .lst-kix_list_27-3>li {
        counter-increment: lst-ctn-kix_list_27-3
      }

      ol.lst-kix_list_28-7 {
        list-style-type: none
      }

      ol.lst-kix_list_28-6 {
        list-style-type: none
      }

      ol.lst-kix_list_28-1 {
        list-style-type: none
      }

      ol.lst-kix_list_28-0 {
        list-style-type: none
      }

      .lst-kix_list_4-1>li:before {
        content: "o  "
      }


      .lst-kix_list_31-4>li:before {
        content: "o  "
      }

      ol.lst-kix_list_28-3 {
        list-style-type: none
      }

      ol.lst-kix_list_28-2 {
        list-style-type: none
      }

      .lst-kix_list_15-7>li:before {
        content: "o  "
      }

      ol.lst-kix_list_33-3.start {
        counter-reset: lst-ctn-kix_list_33-3 0
      }


      .lst-kix_list_1-8>li {
        counter-increment: lst-ctn-kix_list_1-8
      }

      .lst-kix_list_15-1>li:before {
        content: "o  "
      }

      ol.lst-kix_list_1-4.start {
        counter-reset: lst-ctn-kix_list_1-4 0
      }

      .lst-kix_list_24-4>li {
        counter-increment: lst-ctn-kix_list_24-4
      }

      .lst-kix_list_33-1>li {
        counter-increment: lst-ctn-kix_list_33-1
      }

      .lst-kix_list_33-2>li {
        counter-increment: lst-ctn-kix_list_33-2
      }

      ol.lst-kix_list_9-2.start {
        counter-reset: lst-ctn-kix_list_9-2 0
      }

      .lst-kix_list_20-0>li {
        counter-increment: lst-ctn-kix_list_20-0
      }

      .lst-kix_list_32-4>li:before {
        content: "o  "
      }

      .lst-kix_list_26-5>li {
        counter-increment: lst-ctn-kix_list_26-5
      }

      .lst-kix_list_19-2>li {
        counter-increment: lst-ctn-kix_list_19-2
      }

      .lst-kix_list_33-8>li {
        counter-increment: lst-ctn-kix_list_33-8
      }

      .lst-kix_list_33-4>li:before {
        content: ""counter(lst-ctn-kix_list_33-4, lower-latin) ". "
      }

      ol.lst-kix_list_8-8 {
        list-style-type: none
      }


      ol.lst-kix_list_8-4 {
        list-style-type: none
      }

      .lst-kix_list_12-1>li:before {
        content: "o  "
      }

      ol.lst-kix_list_8-5 {
        list-style-type: none
      }

      .lst-kix_list_33-0>li:before {
        content: ""counter(lst-ctn-kix_list_33-0, decimal) ". "
      }

      .lst-kix_list_33-2>li:before {
        content: ""counter(lst-ctn-kix_list_33-2, lower-roman) ". "
      }

      ol.lst-kix_list_8-6 {
        list-style-type: none
      }

      ol.lst-kix_list_8-7 {
        list-style-type: none
      }

      ol.lst-kix_list_8-0 {
        list-style-type: none
      }

      ol.lst-kix_list_8-1 {
        list-style-type: none
      }

      .lst-kix_list_23-6>li {
        counter-increment: lst-ctn-kix_list_23-6
      }

      ol.lst-kix_list_8-2 {
        list-style-type: none
      }

      ol.lst-kix_list_8-3 {
        list-style-type: none
      }

      ol.lst-kix_list_25-8.start {
        counter-reset: lst-ctn-kix_list_25-8 0
      }

      .lst-kix_list_34-0>li:before {
        content: ""counter(lst-ctn-kix_list_34-0, decimal) ". "
      }

      .lst-kix_list_21-4>li {
        counter-increment: lst-ctn-kix_list_21-4
      }

      .lst-kix_list_34-4>li:before {
        content: ""counter(lst-ctn-kix_list_34-0, decimal) "."counter(lst-ctn-kix_list_34-1, decimal) "."counter(lst-ctn-kix_list_34-2, decimal) "."counter(lst-ctn-kix_list_34-3, decimal) "."counter(lst-ctn-kix_list_34-4, decimal) ". "
      }

      .lst-kix_list_28-0>li {
        counter-increment: lst-ctn-kix_list_28-0
      }

      .lst-kix_list_34-6>li:before {
        content: ""counter(lst-ctn-kix_list_34-0, decimal) "."counter(lst-ctn-kix_list_34-1, decimal) "."counter(lst-ctn-kix_list_34-2, decimal) "."counter(lst-ctn-kix_list_34-3, decimal) "."counter(lst-ctn-kix_list_34-4, decimal) "."counter(lst-ctn-kix_list_34-5, decimal) "."counter(lst-ctn-kix_list_34-6, decimal) ". "
      }

      li.li-bullet-4:before {
        margin-left: -18.8pt;
        white-space: nowrap;
        display: inline-block;
        min-width: 18.8pt
      }

      ol.lst-kix_list_28-8.start {
        counter-reset: lst-ctn-kix_list_28-8 0
      }

      .lst-kix_list_29-4>li {
        counter-increment: lst-ctn-kix_list_29-4
      }

      .lst-kix_list_12-7>li:before {
        content: "o  "
      }


      

      .lst-kix_list_33-6>li:before {
        content: ""counter(lst-ctn-kix_list_33-6, decimal) ". "
      }

      .lst-kix_list_33-8>li:before {
        content: ""counter(lst-ctn-kix_list_33-8, lower-roman) ". "
      }

      ol.lst-kix_list_29-0.start {
        counter-reset: lst-ctn-kix_list_29-0 0
      }

      .lst-kix_list_34-2>li:before {
        content: ""counter(lst-ctn-kix_list_34-0, decimal) "."counter(lst-ctn-kix_list_34-1, decimal) "."counter(lst-ctn-kix_list_34-2, decimal) ". "
      }

      .lst-kix_list_25-1>li {
        counter-increment: lst-ctn-kix_list_25-1
      }

      .lst-kix_list_13-1>li:before {
        content: "o  "
      }

      .lst-kix_list_34-5>li {
        counter-increment: lst-ctn-kix_list_34-5
      }

      .lst-kix_list_28-8>li {
        counter-increment: lst-ctn-kix_list_28-8
      }

      ol.lst-kix_list_33-2.start {
        counter-reset: lst-ctn-kix_list_33-2 0
      }

      .lst-kix_list_1-1>li {
        counter-increment: lst-ctn-kix_list_1-1
      }

      .lst-kix_list_30-1>li:before {
        content: "o  "
      }

      ol.lst-kix_list_2-6.start {
        counter-reset: lst-ctn-kix_list_2-6 0
      }

      .lst-kix_list_3-0>li:before {
        content: ""counter(lst-ctn-kix_list_3-0, decimal) ". "
      }

      ol.lst-kix_list_20-5.start {
        counter-reset: lst-ctn-kix_list_20-5 0
      }

      .lst-kix_list_3-4>li:before {
        content: ""counter(lst-ctn-kix_list_3-4, lower-latin) ". "
      }

      .lst-kix_list_3-3>li:before {
        content: ""counter(lst-ctn-kix_list_3-3, decimal) ". "
      }

      .lst-kix_list_8-0>li:before {
        content: ""counter(lst-ctn-kix_list_8-0, decimal) ". "
      }

      .lst-kix_list_8-7>li:before {
        content: ""counter(lst-ctn-kix_list_8-0, decimal) "."counter(lst-ctn-kix_list_8-1, decimal) "."counter(lst-ctn-kix_list_8-2, decimal) "."counter(lst-ctn-kix_list_8-3, decimal) "."counter(lst-ctn-kix_list_8-4, decimal) "."counter(lst-ctn-kix_list_8-5, decimal) "."counter(lst-ctn-kix_list_8-6, decimal) "."counter(lst-ctn-kix_list_8-7, decimal) ". "
      }

      .lst-kix_list_3-8>li:before {
        content: ""counter(lst-ctn-kix_list_3-8, lower-roman) ". "
      }

      .lst-kix_list_8-3>li:before {
        content: ""counter(lst-ctn-kix_list_8-0, decimal) "."counter(lst-ctn-kix_list_8-1, decimal) "."counter(lst-ctn-kix_list_8-2, decimal) "."counter(lst-ctn-kix_list_8-3, decimal) ". "
      }

      ul.lst-kix_list_13-5 {
        list-style-type: none
      }

      ul.lst-kix_list_13-4 {
        list-style-type: none
      }

      ul.lst-kix_list_13-3 {
        list-style-type: none
      }

      ul.lst-kix_list_13-2 {
        list-style-type: none
      }

      .lst-kix_list_3-7>li:before {
        content: ""counter(lst-ctn-kix_list_3-7, lower-latin) ". "
      }

      ul.lst-kix_list_13-1 {
        list-style-type: none
      }

      ul.lst-kix_list_13-0 {
        list-style-type: none
      }

      .lst-kix_list_8-4>li:before {
        content: ""counter(lst-ctn-kix_list_8-0, decimal) "."counter(lst-ctn-kix_list_8-1, decimal) "."counter(lst-ctn-kix_list_8-2, decimal) "."counter(lst-ctn-kix_list_8-3, decimal) "."counter(lst-ctn-kix_list_8-4, decimal) ". "
      }

      .lst-kix_list_19-1>li {
        counter-increment: lst-ctn-kix_list_19-1
      }

      ol.lst-kix_list_8-5.start {
        counter-reset: lst-ctn-kix_list_8-5 0
      }

      ol.lst-kix_list_26-4.start {
        counter-reset: lst-ctn-kix_list_26-4 0
      }

      ul.lst-kix_list_13-8 {
        list-style-type: none
      }

      .lst-kix_list_11-1>li:before {
        content: "o  "
      }

      ul.lst-kix_list_13-7 {
        list-style-type: none
      }

      ul.lst-kix_list_13-6 {
        list-style-type: none
      }

      ol.lst-kix_list_9-3.start {
        counter-reset: lst-ctn-kix_list_9-3 0
      }

      .lst-kix_list_8-8>li:before {
        content: ""counter(lst-ctn-kix_list_8-0, decimal) "."counter(lst-ctn-kix_list_8-1, decimal) "."counter(lst-ctn-kix_list_8-2, decimal) "."counter(lst-ctn-kix_list_8-3, decimal) "."counter(lst-ctn-kix_list_8-4, decimal) "."counter(lst-ctn-kix_list_8-5, decimal) "."counter(lst-ctn-kix_list_8-6, decimal) "."counter(lst-ctn-kix_list_8-7, decimal) "."counter(lst-ctn-kix_list_8-8, decimal) ". "
      }

      ol.lst-kix_list_2-2 {
        list-style-type: none
      }

      ol.lst-kix_list_2-3 {
        list-style-type: none
      }

      ol.lst-kix_list_2-4 {
        list-style-type: none
      }

      .lst-kix_list_16-7>li:before {
        content: "o  "
      }

      ol.lst-kix_list_2-5 {
        list-style-type: none
      }

      ol.lst-kix_list_2-0 {
        list-style-type: none
      }
	  
      .lst-kix_list_21-5>li {
        counter-increment: lst-ctn-kix_list_21-5
      }

      .lst-kix_list_4-7>li:before {
        content: "o  "
      }

      ol.lst-kix_list_20-0.start {
        counter-reset: lst-ctn-kix_list_20-0 0
      }

      .lst-kix_list_17-0>li:before {
        content: ""counter(lst-ctn-kix_list_17-0, decimal) ". "
      }

   
 
      li.li-bullet-7:before {
        margin-left: -17.4pt;
        white-space: nowrap;
        display: inline-block;
        min-width: 17.4pt
      }

      ul.lst-kix_list_4-8 {
        list-style-type: none
      }

      .lst-kix_list_16-0>li:before {
        content: ""counter(lst-ctn-kix_list_16-0, decimal) ". "
      }

      ul.lst-kix_list_4-6 {
        list-style-type: none
      }

      ul.lst-kix_list_4-7 {
        list-style-type: none
      }

      .lst-kix_list_8-4>li {
        counter-increment: lst-ctn-kix_list_8-4
      }

      ul.lst-kix_list_4-0 {
        list-style-type: none
      }

      .lst-kix_list_16-4>li:before {
        content: "o  "
      }

      ul.lst-kix_list_4-1 {
        list-style-type: none
      }

      ol.lst-kix_list_3-3.start {
        counter-reset: lst-ctn-kix_list_3-3 0
      }

      ul.lst-kix_list_4-4 {
        list-style-type: none
      }

      ol.lst-kix_list_2-6 {
        list-style-type: none
      }

      ul.lst-kix_list_4-5 {
        list-style-type: none
      }

      ol.lst-kix_list_2-7 {
        list-style-type: none
      }

      ul.lst-kix_list_4-2 {
        list-style-type: none
      }

      ol.lst-kix_list_2-8 {
        list-style-type: none
      }

      ul.lst-kix_list_4-3 {
        list-style-type: none
      }

      ol.lst-kix_list_8-6.start {
        counter-reset: lst-ctn-kix_list_8-6 0
      }

      .lst-kix_list_17-7>li:before {
        content: "o  "
      }

      .lst-kix_list_33-0>li {
        counter-increment: lst-ctn-kix_list_33-0
      }

      .lst-kix_list_17-4>li:before {
        content: "o  "
      }

      ol.lst-kix_list_8-0.start {
        counter-reset: lst-ctn-kix_list_8-0 0
      }

      .lst-kix_list_7-0>li:before {
        content: "-  "
      }

      ol.lst-kix_list_27-7.start {
        counter-reset: lst-ctn-kix_list_27-7 0
      }

      ol.lst-kix_list_19-6.start {
        counter-reset: lst-ctn-kix_list_19-6 0
      }

      ol.lst-kix_list_9-7.start {
        counter-reset: lst-ctn-kix_list_9-7 0
      }

      .lst-kix_list_2-4>li:before {
        content: ""counter(lst-ctn-kix_list_2-4, lower-latin) ". "
      }

      .lst-kix_list_2-8>li:before {
        content: ""counter(lst-ctn-kix_list_2-8, lower-roman) ". "
      }

      .lst-kix_list_9-7>li {
        counter-increment: lst-ctn-kix_list_9-7
      }

      ol.lst-kix_list_21-7.start {
        counter-reset: lst-ctn-kix_list_21-7 0
      }

      .lst-kix_list_31-1>li:before {
        content: "o  "
      }

      .lst-kix_list_18-7>li:before {
        content: "o  "
      }

      ol.lst-kix_list_3-8.start {
        counter-reset: lst-ctn-kix_list_3-8 0
      }

      .lst-kix_list_7-7>li:before {
        content: "o  "
      }

      ol.lst-kix_list_8-1.start {
        counter-reset: lst-ctn-kix_list_8-1 0
      }

      .lst-kix_list_15-4>li:before {
        content: "o  "
      }

      ol.lst-kix_list_19-1.start {
        counter-reset: lst-ctn-kix_list_19-1 0
      }

      ol.lst-kix_list_24-8 {
        list-style-type: none
      }

      .lst-kix_list_10-4>li:before {
        content: "o  "
      }

      ol.lst-kix_list_20-4.start {
        counter-reset: lst-ctn-kix_list_20-4 0
      }

      .lst-kix_list_4-0>li:before {
        content: "-  "
      }

      ol.lst-kix_list_24-5 {
        list-style-type: none
      }

      ul.lst-kix_list_15-3 {
        list-style-type: none
      }

      ol.lst-kix_list_24-4 {
        list-style-type: none
      }

      ul.lst-kix_list_15-2 {
        list-style-type: none
      }

      ol.lst-kix_list_24-7 {
        list-style-type: none
      }

      ol.lst-kix_list_25-2.start {
        counter-reset: lst-ctn-kix_list_25-2 0
      }

      .lst-kix_list_15-0>li:before {
        content: ""counter(lst-ctn-kix_list_15-0, decimal) ". "
      }

      ul.lst-kix_list_15-1 {
        list-style-type: none
      }

      ol.lst-kix_list_24-6 {
        list-style-type: none
      }

      ol.lst-kix_list_24-1 {
        list-style-type: none
      }

      ol.lst-kix_list_24-0 {
        list-style-type: none
      }

      ol.lst-kix_list_24-3 {
        list-style-type: none
      }

      ol.lst-kix_list_24-2 {
        list-style-type: none
      }

      .lst-kix_list_4-4>li:before {
        content: "o  "
      }

      ul.lst-kix_list_15-8 {
        list-style-type: none
      }

      ul.lst-kix_list_15-7 {
        list-style-type: none
      }

      ul.lst-kix_list_15-6 {
        list-style-type: none
      }

      .lst-kix_list_9-3>li:before {
        content: ""counter(lst-ctn-kix_list_9-3, decimal) ". "
      }

      ul.lst-kix_list_15-5 {
        list-style-type: none
      }

      ul.lst-kix_list_15-4 {
        list-style-type: none
      }

      ol.lst-kix_list_33-7.start {
        counter-reset: lst-ctn-kix_list_33-7 0
      }

      .lst-kix_list_9-7>li:before {
        content: ""counter(lst-ctn-kix_list_9-7, lower-latin) ". "
      }

      .lst-kix_list_2-4>li {
        counter-increment: lst-ctn-kix_list_2-4
      }

      .lst-kix_list_29-4>li:before {
        content: ""counter(lst-ctn-kix_list_29-4, lower-latin) ". "
      }

      .lst-kix_list_29-8>li:before {
        content: ""counter(lst-ctn-kix_list_29-8, lower-roman) ". "
      }

      ol.lst-kix_list_3-6.start {
        counter-reset: lst-ctn-kix_list_3-6 0
      }

      .lst-kix_list_11-4>li:before {
        content: "o  "
      }

      .lst-kix_list_12-4>li:before {
        content: "o  "
      }

      .lst-kix_list_5-3>li {
        counter-increment: lst-ctn-kix_list_5-3
      }

      .lst-kix_list_29-0>li:before {
        content: ""counter(lst-ctn-kix_list_29-0, decimal) ". "
      }

      .lst-kix_list_33-1>li:before {
        content: ""counter(lst-ctn-kix_list_33-1, lower-latin) ". "
      }

      .lst-kix_list_1-0>li:before {
        content: ""counter(lst-ctn-kix_list_1-0, decimal) ". "
      }

      ol.lst-kix_list_19-2.start {
        counter-reset: lst-ctn-kix_list_19-2 0
      }

      ol.lst-kix_list_2-0.start {
        counter-reset: lst-ctn-kix_list_2-0 0
      }

      .lst-kix_list_1-4>li:before {
        content: ""counter(lst-ctn-kix_list_1-4, lower-latin) ". "
      }

      .lst-kix_list_1-6>li {
        counter-increment: lst-ctn-kix_list_1-6
      }

      .lst-kix_list_13-4>li:before {
        content: "o  "
      }

      .lst-kix_list_34-5>li:before {
        content: ""counter(lst-ctn-kix_list_34-0, decimal) "."counter(lst-ctn-kix_list_34-1, decimal) "."counter(lst-ctn-kix_list_34-2, decimal) "."counter(lst-ctn-kix_list_34-3, decimal) "."counter(lst-ctn-kix_list_34-4, decimal) "."counter(lst-ctn-kix_list_34-5, decimal) ". "
      }

      ol.lst-kix_list_26-5.start {
        counter-reset: lst-ctn-kix_list_26-5 0
      }

      .lst-kix_list_33-5>li:before {
        content: ""counter(lst-ctn-kix_list_33-5, lower-roman) ". "
      }

      ol.lst-kix_list_19-3.start {
        counter-reset: lst-ctn-kix_list_19-3 0
      }

      .lst-kix_list_2-0>li:before {
        content: ""counter(lst-ctn-kix_list_2-0, decimal) ". "
      }

      ol.lst-kix_list_33-8.start {
        counter-reset: lst-ctn-kix_list_33-8 0
      }

      ol.lst-kix_list_9-8.start {
        counter-reset: lst-ctn-kix_list_9-8 0
      }

      .lst-kix_list_1-8>li:before {
        content: ""counter(lst-ctn-kix_list_1-8, lower-roman) ". "
      }

      .lst-kix_list_34-1>li:before {
        content: ""counter(lst-ctn-kix_list_34-0, decimal) "."counter(lst-ctn-kix_list_34-1, decimal) ". "
      }

      .lst-kix_list_8-2>li {
        counter-increment: lst-ctn-kix_list_8-2
      }

      .lst-kix_list_19-0>li:before {
        content: ""counter(lst-ctn-kix_list_19-0, decimal) ". "
      }

      .lst-kix_list_23-8>li {
        counter-increment: lst-ctn-kix_list_23-8
      }

      .lst-kix_list_8-1>li {
        counter-increment: lst-ctn-kix_list_8-1
      }

      ol.lst-kix_list_8-2.start {
        counter-reset: lst-ctn-kix_list_8-2 0
      }

      ol.lst-kix_list_26-1.start {
        counter-reset: lst-ctn-kix_list_26-1 0
      }

      .lst-kix_list_19-2>li:before {
        content: ""counter(lst-ctn-kix_list_19-0, decimal) "."counter(lst-ctn-kix_list_19-1, decimal) "."counter(lst-ctn-kix_list_19-2, decimal) " "
      }

      ol.lst-kix_list_3-1.start {
        counter-reset: lst-ctn-kix_list_3-1 0
      }

      ol.lst-kix_list_21-0.start {
        counter-reset: lst-ctn-kix_list_21-0 0
      }

      .lst-kix_list_19-0>li {
        counter-increment: lst-ctn-kix_list_19-0
      }

      .lst-kix_list_29-6>li {
        counter-increment: lst-ctn-kix_list_29-6
      }

      .lst-kix_list_2-3>li {
        counter-increment: lst-ctn-kix_list_2-3
      }

      ol.lst-kix_list_19-8.start {
        counter-reset: lst-ctn-kix_list_19-8 0
      }

      .lst-kix_list_1-2>li {
        counter-increment: lst-ctn-kix_list_1-2
      }

      .lst-kix_list_19-8>li:before {
        content: ""counter(lst-ctn-kix_list_19-0, decimal) "."counter(lst-ctn-kix_list_19-1, decimal) "."counter(lst-ctn-kix_list_19-2, decimal) "."counter(lst-ctn-kix_list_19-3, decimal) "."counter(lst-ctn-kix_list_19-4, decimal) "."counter(lst-ctn-kix_list_19-5, decimal) "."counter(lst-ctn-kix_list_19-6, decimal) "."counter(lst-ctn-kix_list_19-7, decimal) "."counter(lst-ctn-kix_list_19-8, decimal) " "
      }

      ol.lst-kix_list_20-8.start {
        counter-reset: lst-ctn-kix_list_20-8 0
      }

      .lst-kix_list_19-5>li:before {
        content: ""counter(lst-ctn-kix_list_19-0, decimal) "."counter(lst-ctn-kix_list_19-1, decimal) "."counter(lst-ctn-kix_list_19-2, decimal) "."counter(lst-ctn-kix_list_19-3, decimal) "."counter(lst-ctn-kix_list_19-4, decimal) "."counter(lst-ctn-kix_list_19-5, decimal) " "
      }

      ol.lst-kix_list_34-8.start {
        counter-reset: lst-ctn-kix_list_34-8 0
      }

      .lst-kix_list_19-7>li:before {
        content: ""counter(lst-ctn-kix_list_19-0, decimal) "."counter(lst-ctn-kix_list_19-1, decimal) "."counter(lst-ctn-kix_list_19-2, decimal) "."counter(lst-ctn-kix_list_19-3, decimal) "."counter(lst-ctn-kix_list_19-4, decimal) "."counter(lst-ctn-kix_list_19-5, decimal) "."counter(lst-ctn-kix_list_19-6, decimal) "."counter(lst-ctn-kix_list_19-7, decimal) " "
      }

      .lst-kix_list_9-2>li {
        counter-increment: lst-ctn-kix_list_9-2
      }

      ol.lst-kix_list_23-8.start {
        counter-reset: lst-ctn-kix_list_23-8 0
      }

      .lst-kix_list_24-5>li {
        counter-increment: lst-ctn-kix_list_24-5
      }

      ol.lst-kix_list_21-5.start {
        counter-reset: lst-ctn-kix_list_21-5 0
      }

      li.li-bullet-6:before {
        margin-left: -17.4pt;
        white-space: nowrap;
        display: inline-block;
        min-width: 17.4pt
      }

      .lst-kix_list_19-7>li {
        counter-increment: lst-ctn-kix_list_19-7
      }

      .lst-kix_list_25-6>li {
        counter-increment: lst-ctn-kix_list_25-6
      }

      ul.lst-kix_list_31-2 {
        list-style-type: none
      }

      ul.lst-kix_list_31-3 {
        list-style-type: none
      }

      ul.lst-kix_list_31-4 {
        list-style-type: none
      }

      ul.lst-kix_list_31-5 {
        list-style-type: none
      }

      ul.lst-kix_list_31-6 {
        list-style-type: none
      }

      ul.lst-kix_list_31-7 {
        list-style-type: none
      }

      ul.lst-kix_list_31-8 {
        list-style-type: none
      }

      .lst-kix_list_18-1>li:before {
        content: "o  "
      }

      .lst-kix_list_33-3>li {
        counter-increment: lst-ctn-kix_list_33-3
      }

      ul.lst-kix_list_31-0 {
        list-style-type: none
      }

      ul.lst-kix_list_31-1 {
        list-style-type: none
      }

      ol.lst-kix_list_25-4.start {
        counter-reset: lst-ctn-kix_list_25-4 0
      }

      .lst-kix_list_23-4>li {
        counter-increment: lst-ctn-kix_list_23-4
      }

      ol.lst-kix_list_23-1.start {
        counter-reset: lst-ctn-kix_list_23-1 0
      }

      ol.lst-kix_list_34-3.start {
        counter-reset: lst-ctn-kix_list_34-3 0
      }

      ol.lst-kix_list_2-4.start {
        counter-reset: lst-ctn-kix_list_2-4 0
      }

      .lst-kix_list_23-1>li {
        counter-increment: lst-ctn-kix_list_23-1
      }

      .lst-kix_list_34-4>li {
        counter-increment: lst-ctn-kix_list_34-4
      }

      ol.lst-kix_list_1-3 {
        list-style-type: none
      }

      ul.lst-kix_list_22-0 {
        list-style-type: none
      }

      ol.lst-kix_list_1-4 {
        list-style-type: none
      }

      .lst-kix_list_2-7>li:before {
        content: ""counter(lst-ctn-kix_list_2-7, lower-latin) ". "
      }

      .lst-kix_list_2-7>li {
        counter-increment: lst-ctn-kix_list_2-7
      }

      ul.lst-kix_list_22-1 {
        list-style-type: none
      }

      ol.lst-kix_list_1-5 {
        list-style-type: none
      }

      ul.lst-kix_list_22-2 {
        list-style-type: none
      }

      .lst-kix_list_24-2>li {
        counter-increment: lst-ctn-kix_list_24-2
      }

      ol.lst-kix_list_1-6 {
        list-style-type: none
      }

      ul.lst-kix_list_22-3 {
        list-style-type: none
      }

      ul.lst-kix_list_22-4 {
        list-style-type: none
      }

      ol.lst-kix_list_1-0 {
        list-style-type: none
      }

      .lst-kix_list_2-5>li:before {
        content: ""counter(lst-ctn-kix_list_2-5, lower-roman) ". "
      }

      ul.lst-kix_list_22-5 {
        list-style-type: none
      }

      ol.lst-kix_list_1-1 {
        list-style-type: none
      }

      ul.lst-kix_list_22-6 {
        list-style-type: none
      }

      ol.lst-kix_list_1-2 {
        list-style-type: none
      }

      ul.lst-kix_list_22-7 {
        list-style-type: none
      }

      ol.lst-kix_list_17-0.start {
        counter-reset: lst-ctn-kix_list_17-0 3
      }

      .lst-kix_list_27-5>li:before {
        content: ""counter(lst-ctn-kix_list_27-5, lower-roman) ". "
      }

      .lst-kix_list_10-1>li:before {
        content: "o  "
      }

      .lst-kix_list_18-4>li:before {
        content: "o  "
      }

      ul.lst-kix_list_22-8 {
        list-style-type: none
      }

      ol.lst-kix_list_1-7 {
        list-style-type: none
      }

      ol.lst-kix_list_1-8 {
        list-style-type: none
      }

      li.li-bullet-1:before {
        margin-left: -21.6pt;
        white-space: nowrap;
        display: inline-block;
        min-width: 21.6pt
      }

      ul.lst-kix_list_11-7 {
        list-style-type: none
      }

      .lst-kix_list_2-6>li {
        counter-increment: lst-ctn-kix_list_2-6
      }

      ul.lst-kix_list_11-6 {
        list-style-type: none
      }

      ul.lst-kix_list_11-5 {
        list-style-type: none
      }

      ul.lst-kix_list_11-4 {
        list-style-type: none
      }

      ul.lst-kix_list_11-3 {
        list-style-type: none
      }

      ul.lst-kix_list_11-2 {
        list-style-type: none
      }

      ul.lst-kix_list_11-1 {
        list-style-type: none
      }

      .lst-kix_list_34-0>li {
        counter-increment: lst-ctn-kix_list_34-0
      }

      ul.lst-kix_list_11-0 {
        list-style-type: none
      }

      .lst-kix_list_28-1>li {
        counter-increment: lst-ctn-kix_list_28-1
      }

      .lst-kix_list_26-4>li {
        counter-increment: lst-ctn-kix_list_26-4
      }

      ol.lst-kix_list_5-7.start {
        counter-reset: lst-ctn-kix_list_5-7 0
      }

      ol.lst-kix_list_28-7.start {
        counter-reset: lst-ctn-kix_list_28-7 0
      }
    
      
      ul.lst-kix_list_11-8 {
        list-style-type: none
      }

      .lst-kix_list_20-8>li:before {
        content: ""counter(lst-ctn-kix_list_20-8, lower-roman) ". "
      }

      .lst-kix_list_3-4>li {
        counter-increment: lst-ctn-kix_list_3-4
      }

      .lst-kix_list_29-7>li:before {
        content: ""counter(lst-ctn-kix_list_29-7, lower-latin) ". "
      }

      .lst-kix_list_29-5>li:before {
        content: ""counter(lst-ctn-kix_list_29-5, lower-roman) ". "
      }

      .lst-kix_list_20-0>li:before {
        content: ""counter(lst-ctn-kix_list_20-0, decimal) ". "
      }

      .lst-kix_list_9-6>li:before {
        content: ""counter(lst-ctn-kix_list_9-6, decimal) ". "
      }

      li.li-bullet-9:before {
        margin-left: -17.4pt;
        white-space: nowrap;
        display: inline-block;
        min-width: 17.4pt
      }

      .lst-kix_list_9-4>li:before {
        content: ""counter(lst-ctn-kix_list_9-4, lower-latin) ". "
      }

      ol.lst-kix_list_34-5.start {
        counter-reset: lst-ctn-kix_list_34-5 0
      }

      .lst-kix_list_20-6>li:before {
        content: ""counter(lst-ctn-kix_list_20-6, decimal) ". "
      }

      .lst-kix_list_23-0>li {
        counter-increment: lst-ctn-kix_list_23-0
      }

      ol.lst-kix_list_21-2.start {
        counter-reset: lst-ctn-kix_list_21-2 0
      }

      ul.lst-kix_list_2-1 {
        list-style-type: none
      }

      .lst-kix_list_20-6>li {
        counter-increment: lst-ctn-kix_list_20-6
      }

      .lst-kix_list_1-1>li:before {
        content: ""counter(lst-ctn-kix_list_1-1, lower-latin) ". "
      }

      .lst-kix_list_11-7>li:before {
        content: "o  "
      }

      .lst-kix_list_8-5>li {
        counter-increment: lst-ctn-kix_list_8-5
      }

      ol.lst-kix_list_25-7.start {
        counter-reset: lst-ctn-kix_list_25-7 0
      }

      .lst-kix_list_1-3>li:before {
        content: ""counter(lst-ctn-kix_list_1-3, decimal) ". "
      }

      ol.lst-kix_list_34-6.start {
        counter-reset: lst-ctn-kix_list_34-6 0
      }

      .lst-kix_list_28-3>li:before {
        content: ""counter(lst-ctn-kix_list_28-3, decimal) ". "
      }

      ol.lst-kix_list_21-8 {
        list-style-type: none
      }

      ol.lst-kix_list_21-7 {
        list-style-type: none
      }

      ol.lst-kix_list_2-7.start {
        counter-reset: lst-ctn-kix_list_2-7 0
      }

      ol.lst-kix_list_21-4 {
        list-style-type: none
      }

      ol.lst-kix_list_21-3 {
        list-style-type: none
      }

      ol.lst-kix_list_21-6 {
        list-style-type: none
      }

      ol.lst-kix_list_21-5 {
        list-style-type: none
      }

      ol.lst-kix_list_21-0 {
        list-style-type: none
      }

      ol.lst-kix_list_21-2 {
        list-style-type: none
      }

      .lst-kix_list_27-7>li:before {
        content: ""counter(lst-ctn-kix_list_27-7, lower-latin) ". "
      }

      .lst-kix_list_25-7>li {
        counter-increment: lst-ctn-kix_list_25-7
      }

      .lst-kix_list_28-1>li:before {
        content: ""counter(lst-ctn-kix_list_28-1, lower-latin) ". "
      }

      ol.lst-kix_list_19-6 {
        list-style-type: none
      }

      ol.lst-kix_list_19-7 {
        list-style-type: none
      }

      .lst-kix_list_3-1>li {
        counter-increment: lst-ctn-kix_list_3-1
      }

      ol.lst-kix_list_19-8 {
        list-style-type: none
      }

      ol.lst-kix_list_19-2 {
        list-style-type: none
      }

      ol.lst-kix_list_34-0.start {
        counter-reset: lst-ctn-kix_list_34-0 0
      }

      .lst-kix_list_26-8>li {
        counter-increment: lst-ctn-kix_list_26-8
      }

      ol.lst-kix_list_19-3 {
        list-style-type: none
      }

      ol.lst-kix_list_19-4 {
        list-style-type: none
      }

      ol.lst-kix_list_19-5 {
        list-style-type: none
      }

      ol.lst-kix_list_19-0 {
        list-style-type: none
      }

      ol.lst-kix_list_19-1 {
        list-style-type: none
      }

      .lst-kix_list_3-1>li:before {
        content: ""counter(lst-ctn-kix_list_3-1, decimal) ". "
      }

      .lst-kix_list_26-6>li:before {
        content: ""counter(lst-ctn-kix_list_26-6, decimal) ". "
      }

      .lst-kix_list_14-0>li {
        counter-increment: lst-ctn-kix_list_14-0
      }

      .lst-kix_list_33-6>li {
        counter-increment: lst-ctn-kix_list_33-6
      }

      .lst-kix_list_8-2>li:before {
        content: ""counter(lst-ctn-kix_list_8-0, decimal) "."counter(lst-ctn-kix_list_8-1, decimal) "."counter(lst-ctn-kix_list_8-2, decimal) ". "
      }

      .lst-kix_list_21-2>li:before {
        content: ""counter(lst-ctn-kix_list_21-2, lower-roman) ". "
      }

      .lst-kix_list_8-5>li:before {
        content: ""counter(lst-ctn-kix_list_8-0, decimal) "."counter(lst-ctn-kix_list_8-1, decimal) "."counter(lst-ctn-kix_list_8-2, decimal) "."counter(lst-ctn-kix_list_8-3, decimal) "."counter(lst-ctn-kix_list_8-4, decimal) "."counter(lst-ctn-kix_list_8-5, decimal) ". "
      }

      .lst-kix_list_2-0>li {
        counter-increment: lst-ctn-kix_list_2-0
      }

      ol.lst-kix_list_28-0.start {
        counter-reset: lst-ctn-kix_list_28-0 0
      }

      .lst-kix_list_26-3>li:before {
        content: ""counter(lst-ctn-kix_list_26-3, decimal) ". "
      }

      .lst-kix_list_3-6>li:before {
        content: ""counter(lst-ctn-kix_list_3-6, decimal) ". "
      }

      .lst-kix_list_21-7>li:before {
        content: ""counter(lst-ctn-kix_list_21-7, lower-latin) ". "
      }

      ol.lst-kix_list_5-0.start {
        counter-reset: lst-ctn-kix_list_5-0 0
      }

      .lst-kix_list_25-2>li:before {
        content: ""counter(lst-ctn-kix_list_25-2, lower-roman) ". "
      }

      .lst-kix_list_29-5>li {
        counter-increment: lst-ctn-kix_list_29-5
      }

      ol.lst-kix_list_5-6.start {
        counter-reset: lst-ctn-kix_list_5-6 0
      }

      .lst-kix_list_16-1>li:before {
        content: "o  "
      }

      .lst-kix_list_25-0>li {
        counter-increment: lst-ctn-kix_list_25-0
      }

      ol.lst-kix_list_28-6.start {
        counter-reset: lst-ctn-kix_list_28-6 0
      }

      .lst-kix_list_19-3>li {
        counter-increment: lst-ctn-kix_list_19-3
      }

      ol.lst-kix_list_28-5.start {
        counter-reset: lst-ctn-kix_list_28-5 0
      }

      .lst-kix_list_23-7>li {
        counter-increment: lst-ctn-kix_list_23-7
      }

      .lst-kix_list_34-7>li {
        counter-increment: lst-ctn-kix_list_34-7
      }


      ol.lst-kix_list_5-5.start {
        counter-reset: lst-ctn-kix_list_5-5 0
      }

      .lst-kix_list_6-2>li {
        counter-increment: lst-ctn-kix_list_6-2
      }

      .lst-kix_list_27-2>li:before {
        content: ""counter(lst-ctn-kix_list_27-2, lower-roman) ". "
      }


      .lst-kix_list_7-1>li:before {
        content: "o  "
      }

      .lst-kix_list_9-6>li {
        counter-increment: lst-ctn-kix_list_9-6
      }

      .lst-kix_list_29-2>li {
        counter-increment: lst-ctn-kix_list_29-2
      }

      ol.lst-kix_list_28-4.start {
        counter-reset: lst-ctn-kix_list_28-4 0
      }

      ol.lst-kix_list_23-3.start {
        counter-reset: lst-ctn-kix_list_23-3 0
      }

      ol.lst-kix_list_5-4.start {
        counter-reset: lst-ctn-kix_list_5-4 0
      }

      ol.lst-kix_list_5-1.start {
        counter-reset: lst-ctn-kix_list_5-1 0
      }

      .lst-kix_list_20-3>li {
        counter-increment: lst-ctn-kix_list_20-3
      }

      .lst-kix_list_25-3>li {
        counter-increment: lst-ctn-kix_list_25-3
      }

      ol.lst-kix_list_28-1.start {
        counter-reset: lst-ctn-kix_list_28-1 0
      }

      .lst-kix_list_31-7>li:before {
        content: "o  "
      }

      ol.lst-kix_list_34-1.start {
        counter-reset: lst-ctn-kix_list_34-1 0
      }

      .lst-kix_list_3-8>li {
        counter-increment: lst-ctn-kix_list_3-8
      }

      .lst-kix_list_1-5>li {
        counter-increment: lst-ctn-kix_list_1-5
      }

      .lst-kix_list_28-4>li {
        counter-increment: lst-ctn-kix_list_28-4
      }


      ol.lst-kix_list_23-6.start {
        counter-reset: lst-ctn-kix_list_23-6 0
      }

      .lst-kix_list_26-1>li {
        counter-increment: lst-ctn-kix_list_26-1
      }

      .lst-kix_list_9-1>li:before {
        content: ""counter(lst-ctn-kix_list_9-1, lower-latin) ". "
      }

      .lst-kix_list_20-3>li:before {
        content: ""counter(lst-ctn-kix_list_20-3, decimal) ". "
      }

      .lst-kix_list_27-6>li {
        counter-increment: lst-ctn-kix_list_27-6
      }

      .lst-kix_list_29-2>li:before {
        content: ""counter(lst-ctn-kix_list_29-2, lower-roman) ". "
      }

      ol.lst-kix_list_23-5.start {
        counter-reset: lst-ctn-kix_list_23-5 0
      }

      .lst-kix_list_8-8>li {
        counter-increment: lst-ctn-kix_list_8-8
      }

      .lst-kix_list_28-6>li:before {
        content: ""counter(lst-ctn-kix_list_28-6, decimal) ". "
      }

      .lst-kix_list_1-6>li:before {
        content: ""counter(lst-ctn-kix_list_1-6, decimal) ". "
      }

      ol.lst-kix_list_28-2.start {
        counter-reset: lst-ctn-kix_list_28-2 0
      }

      .lst-kix_list_33-7>li:before {
        content: ""counter(lst-ctn-kix_list_33-7, lower-latin) ". "
      }


      ol.lst-kix_list_23-4.start {
        counter-reset: lst-ctn-kix_list_23-4 0
      }

      .lst-kix_list_34-3>li:before {
        content: ""counter(lst-ctn-kix_list_34-0, decimal) "."counter(lst-ctn-kix_list_34-1, decimal) "."counter(lst-ctn-kix_list_34-2, decimal) "."counter(lst-ctn-kix_list_34-3, decimal) ". "
      }

      .lst-kix_list_2-2>li:before {
        content: ""counter(lst-ctn-kix_list_2-2, lower-roman) ". "
      }

      ol.lst-kix_list_5-2.start {
        counter-reset: lst-ctn-kix_list_5-2 0
      }

      ol {
        margin: 0;
        padding: 0
      }

      table td,
      table th {
        padding: 0
      }

      .c22 {
        border-right-style: solid;
        padding: 0pt 3.5pt 0pt 3.5pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: bottom;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        background-color: #b8cce4;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 60pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c111 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        background-color: #d99594;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 203.8pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c60 {
        border-right-style: solid;
        padding: 0pt 3.5pt 0pt 3.5pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: bottom;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        background-color: #b8cce4;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 72pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c116 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 0pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        background-color: #fde9d9;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 132pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c120 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 0pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        background-color: #fde9d9;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 203.8pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c107 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 0pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        background-color: #fde9d9;
        border-left-style: solid;
        border-bottom-width: 0pt;
        width: 203.8pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c37 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 0pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        background-color: #fde9d9;
        border-left-style: solid;
        border-bottom-width: 0pt;
        width: 132pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c110 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        background-color: #fde9d9;
        border-left-style: solid;
        border-bottom-width: 0pt;
        width: 203.8pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c106 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        background-color: #fde9d9;
        border-left-style: solid;
        border-bottom-width: 0pt;
        width: 132pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c101 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        background-color: #d99594;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 132pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c58 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 92.2pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c38 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 67.8pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c82 {
        border-right-style: solid;
        padding: 0pt 3.5pt 0pt 3.5pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: bottom;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 72pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c26 {
        border-right-style: solid;
        padding: 0pt 3.5pt 0pt 3.5pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: middle;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 19.2pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c61 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 90.5pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c85 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 67pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c105 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 320.6pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c51 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 141.8pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c28 {
        border-right-style: solid;
        padding: 0pt 3.5pt 0pt 3.5pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: middle;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 23.8pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c83 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 52.6pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c27 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 80.5pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c113 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 125.9pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c32 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 63.8pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c121 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 130.7pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c78 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 198.4pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c41 {
        border-right-style: solid;
        padding: 0pt 3.5pt 0pt 3.5pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: bottom;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 60pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c25 {
        border-right-style: solid;
        padding: 0pt 3.5pt 0pt 3.5pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: middle;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 190.7pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c9 {
        border-right-style: solid;
        padding: 0pt 3.5pt 0pt 3.5pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: middle;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 23.7pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c103 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 82.5pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c34 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 71.6pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c6 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 304.8pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c77 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 133pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c67 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 68.2pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c2 {
        border-right-style: solid;
        padding: 0pt 3.5pt 0pt 3.5pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: middle;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 23.6pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c99 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 89.8pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c44 {
        border-right-style: solid;
        padding: 0pt 3.5pt 0pt 3.5pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: middle;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 32.8pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c81 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 115pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c100 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 319.6pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c64 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 127.5pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c18 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 70.8pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c63 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 106.3pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }

      .c36 {
        border-right-style: solid;
        padding: 0pt 5.8pt 0pt 5.8pt;
        border-bottom-color: #000000;
        border-top-width: 1pt;
        border-right-width: 1pt;
        border-left-color: #000000;
        vertical-align: top;
        border-right-color: #000000;
        border-left-width: 1pt;
        border-top-style: solid;
        border-left-style: solid;
        border-bottom-width: 1pt;
        width: 101.5pt;
        border-top-color: #000000;
        border-bottom-style: solid
      }


      
      .c1 {
        -webkit-text-decoration-skip: none;
        color: #000000;
        font-weight: 700;
        text-decoration: underline;
        vertical-align: baseline;
        text-decoration-skip-ink: none;
        font-size: 12pt;
        font-family: "Calibri";
        font-style: normal
      }
      /*MODIFICADO SUD-BC - 4/01/2024 -- ARREGLOS EN FORMATO CALIBRI RIESGOS*/
      .ql-align-center{
        text-align:center;
        display:block;
        font-family: "Calibri"

      }

      .c0 {
        color: #000000;
        font-weight: 400;
        text-decoration: none;
        font-size: 12pt;
        font-family: "Calibri";
        font-style: normal
      }

      .c10 {
        color: #000000;
        font-weight: 400;
        text-decoration: none;
        vertical-align: baseline;
        font-size: 12pt;
        font-family: "Calibri";
        font-style: italic
      }

      .c12 {
        color: #000000;
        font-weight: 400;
        text-decoration: none;
        vertical-align: baseline;
        font-size: 10pt;
        font-family: "Calibri";
        font-style: normal
      }

      .c15 {
        color: #000000;
        font-weight: 400;
        text-decoration: none;
        vertical-align: baseline;
        font-size: 11pt;
        font-family: "Calibri";
        font-style: normal
      }

      .c62 {
        color: #000000;
        font-weight: 400;
        text-decoration: none;
        vertical-align: baseline;
        font-size: 12pt;
        font-family: "Times New Roman";
        font-style: normal
      }

      .c55 {
        -webkit-text-decoration-skip: none;
        color: #1155cc;
        text-decoration: underline;
        vertical-align: baseline;
        text-decoration-skip-ink: none;
        font-size: 12pt;
        font-style: normal
      }

      .c13 {
        color: #000000;
        font-weight: 700;
        text-decoration: none;
        vertical-align: baseline;
        font-size: 12pt;
        font-family: "Calibri";
        font-style: normal
      }

      .c5 {
        color: #000000;
        font-weight: 700;
        text-decoration: none;
        vertical-align: baseline;
        font-size: 11pt;
        font-family: "Calibri";
        font-style: normal
      }

      .c86 {
        font-weight: 700;
        text-decoration: none;
        vertical-align: baseline;
        font-size: 12pt;
        font-family: "Arial";
        font-style: normal
      }

      .c73 {
        -webkit-text-decoration-skip: none;
        text-decoration: underline;
        vertical-align: baseline;
        text-decoration-skip-ink: none;
        font-size: 12pt;
        font-style: normal
      }

      .c8 {
        margin-left: 35.4pt;
        padding-top: 0pt;
        padding-bottom: 0pt;
        line-height: 1.0;
        text-align: left;
        height: 12pt
      }

      .c16 {
        padding-top: 0pt;
        padding-bottom: 0pt;
        line-height: 1.0;
        orphans: 2;
        widows: 2;
        text-align: center
      }

      .c71 {
        font-weight: 400;
        text-decoration: none;
        vertical-align: baseline;
        font-size: 11pt;
        font-family: "Arial";
        font-style: normal
      }

      .c94 {
        font-weight: 400;
        text-decoration: none;
        vertical-align: baseline;
        font-size: 12pt;
        font-family: "Cambria Math";
        font-style: normal
      }

      .c3 {
        margin-left: 18pt;
        padding-top: 0pt;
        padding-bottom: 0pt;
        line-height: 1.0;
        text-align: justify
      }

      .c11 {
        padding-top: 0pt;
        padding-bottom: 0pt;
        line-height: 1.0;
        text-align: center;
        height: 12pt
      }
      
      /*MODIFICADO SUD-BC - 4/01/2024 -- ARREGLOS EN FORMATO CALIBRI RIESGOS*/
      .c4 {
        padding-top: 0pt;
        padding-bottom: 0pt;
        line-height: 1.0;
        text-align: justify;
        font-family: "Calibri"
      }

      .c68 {
        text-decoration: none;
        vertical-align: baseline;
        font-size: 12pt;
        font-style: italic
      }

      .c114 {
        text-decoration: none;
        vertical-align: baseline;
        font-size: 12pt;
        font-style: normal
      }

      .c21 {
        padding-top: 0pt;
        padding-bottom: 0pt;
        line-height: 1.0;
        text-align: center
      }

      .c39 {
        padding-top: 0pt;
        padding-bottom: 0pt;
        line-height: 1.0;
        text-align: left
      }

      .c74 {
        text-decoration: none;
        vertical-align: super;
        font-size: 10pt;
        font-style: normal
      }

      .c7 {
        margin-left: 72pt;
        padding-left: 0pt;
        orphans: 2;
        widows: 2
      }

      .c69 {
        text-decoration: none;
        vertical-align: super;
        font-size: 12pt;
        font-style: normal
      }

      .c89 {
        margin-left: auto;
        border-spacing: 0;
        border-collapse: collapse;
        margin-right: auto
      }

      .c57 {
        margin-left: 20.9pt;
        border-spacing: 0;
        border-collapse: collapse;
        margin-right: auto
      }

      .c56 {
        padding-top: 0pt;
        padding-bottom: 0pt;
        line-height: 1.15;
        text-align: left
      }

      .c115 {
        margin-left: -0.8pt;
        border-spacing: 0;
        border-collapse: collapse;
        margin-right: auto
      }

      .c118 {
        margin-left: -5.8pt;
        border-spacing: 0;
        border-collapse: collapse;
        margin-right: auto
      }

      .c70 {
        background-color: #ffffff;
        max-width: 467.8pt;
        padding: 111.4pt 56.7pt 72pt 70.9pt
      }

      .c42 {
        font-weight: 700;
        font-family: "Calibri"
      }

      .c54 {
        margin-left: 36pt;
        padding-left: 0.8pt
      }

      .c95 {
        margin-left: 36pt;
        padding-left: -0.5pt
      }

      .c30 {
        orphans: 2;
        widows: 2
      }

      .c119 {
        margin-left: 14.2pt;
        text-indent: -14.2pt
      }

      .c20 {
        margin-left: 36pt;
        padding-left: 0pt
      }

      .c46 {
        margin-left: 24.1pt;
        text-indent: -11.9pt
      }

      .c17 {
        margin-left: 77.8pt;
        padding-left: 0pt
      }

      .c49 {
        font-weight: 400;
        font-family: "Calibri"
      }

      .c108 {
        color: inherit;
        text-decoration: inherit
      }

      .c40 {
        margin-left: 36pt;
        padding-left: 3.6pt
      }

      .c88 {
        margin-left: 35.5pt;
        text-indent: -17.4pt
      }

      .c52 {
        margin-left: 42pt;
        text-indent: -11.9pt
      }

      .c23 {
        border: 1px solid black;
        margin: 5px
      }

      .c47 {
        padding: 0;
        margin: 0
      }

      .c45 {
        background-color: #95b3d7
      }

      .c24 {
        height: 15.8pt
      }

      .c92 {
        height: 18pt
      }

      .c35 {
        background-color: #ffff00
      }

      .c97 {
        margin-left: 47.6pt
      }

      .c75 {
        margin-left: 24.4pt
      }

      .c93 {
        vertical-align: super
      }

      .c96 {
        margin-left: 39.3pt
      }

      .c59 {
        margin-left: 54pt
      }

      .c90 {
        font-style: italic
      }

      .c65 {
        margin-left: 18pt
      }

      .c112 {
        font-size: 11pt
      }

      .c102 {
        margin-left: 108pt
      }

      .c104 {
        margin-left: 36pt
      }

      .c31 {
        margin-left: 30.1pt
      }

      .c91 {
        margin-left: 48.1pt
      }

      .c79 {
        background-color: #c0c0c0
      }

      .c19 {
        height: 0pt
      }

      .c14 {
        height: 12pt
      }

      .c87 {
        margin-left: 12.2pt
      }

      .c43 {
        padding-left: 0pt
      }

      .c29 {
        background-color: #00ffff
      }

      .c33 {
        margin-left: 21.3pt
      }

      .c109 {
        color: #ff0000
      }

      .c76 {
        padding-left: 0.8pt
      }

      .c66 {
        color: #000000
      }

      .c117 {
        margin-left: 39.6pt
      }

      .c50 {
        background-color: #c6d9f1
      }

      .c53 {
        background-color: #ff0000
      }

      .c80 {
        text-indent: -24.4pt
      }

      .c72 {
        margin-left: 84.2pt
      }

      .c84 {
        font-size: 10pt
      }

      .c98 {
        margin-left: 36.8pt
      }

      .c48 {
        height: 15pt
      }

      .title {
        padding-top: 24pt;
        color: #000000;
        font-weight: 700;
        font-size: 36pt;
        padding-bottom: 6pt;
        font-family: "Times New Roman";
        line-height: 1.0;
        page-break-after: avoid;
        text-align: left
      }
      
      .subtitle {
        padding-top: 18pt;
        color: #666666;
        font-size: 24pt;
        padding-bottom: 4pt;
        font-family: "Calibri";
        line-height: 1.0;
        page-break-after: avoid;
        font-style: italic;
        text-align: left
      }

      li {
        color: #000000;
        font-size: 12pt;
        font-family: "Times New Roman"
      }
      p {
        margin: 0;
        color: #000000;
        font-size: 12pt;
        font-family: "Calibri"
      }

      h1 {
        padding-top: 24pt;
        color: #000000;
        font-weight: 700;
        font-size: 24pt;
        padding-bottom: 6pt;
        font-family: "Times New Roman";
        line-height: 1.0;
        page-break-after: avoid;
        text-align: left
      }

      h2 {
        padding-top: 18pt;
        color: #000000;
        font-weight: 700;
        font-size: 18pt;
        padding-bottom: 4pt;
        font-family: "Times New Roman";
        line-height: 1.0;
        page-break-after: avoid;
        text-align: left
      }

      h3 {
        padding-top: 14pt;
        color: #000000;
        font-weight: 700;
        font-size: 14pt;
        padding-bottom: 4pt;
        font-family: "Times New Roman";
        line-height: 1.0;
        page-break-after: avoid;
        text-align: left
      }

      h4 {
        padding-top: 12pt;
        color: #000000;
        font-weight: 700;
        font-size: 12pt;
        padding-bottom: 2pt;
        font-family: "Times New Roman";
        line-height: 1.0;
        page-break-after: avoid;
        text-align: left
      }

      h5 {
        padding-top: 11pt;
        color: #000000;
        font-weight: 700;
        font-size: 11pt;
        padding-bottom: 2pt;
        font-family: "Times New Roman";
        line-height: 1.0;
        page-break-after: avoid;
        text-align: left
      }

      h6 {
        padding-top: 10pt;
        color: #000000;
        font-weight: 700;
        font-size: 10pt;
        padding-bottom: 2pt;
        font-family: "Times New Roman";
        line-height: 1.0;
        page-break-after: avoid;
        text-align: left
      }


  </style>
  <script type="text/javascript">
   //<![CDATA[
     function redirect(target, url){
         if (target =='_blank'){
             open(url);
         }
         else if (target == '_top'){
             window.top.location.href=url;
         }
         else if (target == '_parent'){
             location.href=url;
         }
         else if (target == '_self'){
             location.href =url;
         }
         else{
             open(url);
         }
        }
   //]]>
  </script>


 
 
  <body class="c70 doc-content">
  <div>
    <p class="c39">
        <img alt="" width="80" height="80" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCACgAJ8DASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9U6KKKACiiigAopKKAFpKWmNIqdSBQAn5Uu4CuZ8QfETwv4Tj3614g0vSh/0+XccX/oTVw19+1h8IbFtkvxF0Et/0zvkb/wBBNTKUY/EdVPB4mr/DpSl8j18/54qLB/2a8p0/9qr4SapJ5UHxD8Ps/wDdkv41/wDQjXfaD4y8P+KIfN0rWdP1RP79ncpL/wCg0RnGRNTCV6X8SEo/I36WkBHY0ZqjnFopKWgAooooAKKKKACiiigAoopKAGn0rG8TeKdI8I6VcalrWo22lafbpuluruVY0T6s1eS/tHftTeF/2etDBu3OqeIbpT9h0W3f99Jz99v7kef4v++a/Lb4xfHjxl8eNe/tDxPqTS26tvttMt/ltLX/AHV/vf7T/NXBiMXDD6faPtMj4XxWcP2kvdpfzH2t8Yf+Cl2iaPJcaf8ADrSX124X5f7V1DdFaf8AAV+8/wD47XyN49/an+K3xMll/tTxff2to3Sx0lvskX/jnzN/wJ64vwZ4A1LxhqUNnYwNNKzV9h/Cv9j/AEPTYorvxNP9suP+fdPuLXz9TGVasj9cp5Tk3D9LmnHnl/4FI+J4fDeoaxceb5E95K333dXd2roLP4P+KLxd0Wi3bp/1wev0/wDD/gXwn4chSLT9LtYNv/TKulhksIV2rFEn/Aax5J9zhqcVQh/Bw5+UE3wQ8VQrul0O7/79Viv4V1rwxdefFFd6bcL92aHdE6/8DWv18kmsJPvJF/3zWJrXhPw14gt3ivtNt5kb++tHs5fzkU+KoT/jYc/Oz4f/ALYvxh+GMipD4nuNbsl/5ctdX7Sv/fbfOv8A33X2D8Gf+CkHg/xo1vpfji1bwdqjfJ9sLebZO3+996L/AIH/AN9Vw/xa/Y/0PWLe4vPDTfY7v732f+Bq+LfGfgbUPCWqS2d9A0MsTfx100sdVo/EdM8mybiClzUo8sv7vuyP3J03UrXVrOG6sbqK7tZk3xywvuVlP8StV3I61+MXwB/ak8afs/aki6XcNqXh1m/f6Ddy/um/65f88m/3f+B1+pvwO+PHhb4+eFhq/h26PmRnZd6fJ8txayddjr/7N91u1fQUMVDEH5FnXDmKyefNL3qf8x6rRSUtdh8oFFFFABRRRQBHxxXgX7WH7Tmmfs7+DXMfl3/ijUVZdNsGfAz/AM9ZPSNf/Hvu16j8TfH2mfC/wTqvifWJhBp+nQtNJ/ebsqr/ALTN8o92r8Wviz8TtY+NHj7VfFWtSMLq8bbFb7vktoF+7Ev+yv8A9nXnYvE+whyx+I+34XyB5xiPaVP4cTF8T+KtY8d+I7zXNcv5tT1a+k8ya6k6N/8AEJ/sVc8PaK1/dRR/3mrPs7Ou78JIls26vlZT59z+lKOHhQo2ge9/DG50/wADWCeQq/a2+89elW3xX/2q+dLbVW/vVeh1hv71YxPnMTlscRLmqH0bD8V1/vVYT4qL/er5yTW2/vVL/bz/AN+teaZwf2NSPo1PipF/eo/4Wiv97/x6vnX+3n/v0f28/wDfo5pEf2JTPoh/igv96vJPjTZ6f4/0151iVNQiX5X/AL1ce+vN/eqpNrzvv+asZHZhst+rVfa0j5/1jSmtrh027GVq1vhl8UPEPwe8ZWviPw5dtb3kHyywtxFdRfxRSr/EtbXjC2V795V/irjbyzralOcPePpcRhYYqlyVo+7I/Zn4A/HLQ/j/AOBbbxDpLeVcJ+7vrCRsy2c/Rkb/ANlb+Ja9TzX4s/s0/HnUf2ffiZa6zG8kuh3W2DV7Jf8AlrB/f/3k+8v/AHz/AB1+ymi61aeINHsdSsZo7qzvIlnhmjOVdGXcrfjX1uFxP1iH94/mbiXI55PirR/hy+E1qKSlrvPkQppHvQKzdY1aDRdJvb+7kENvawPPK391VXcxo2HGPO7I/PT/AIKWfGZtU8R6X8NtOn/0SxVb/U9jfflb/VRf8BX5/wDgaV8UW1t/FW1468XXfxG8e6/4nvXbz9WvJbr/AHUZ/kT/AIAmxf8AgFU4Ur43FVPa1eY/q3h7LY5bgaVH/wACLFtDW7ptxsWsq2T5atW7bGrhPrTpra8rShvK5q2ua0Euq0OaVI3UvP8Aap/2v/arE+1e1H2r2p6mPsze+1/7VMe8/wBqsT7V7U37V7UF+zNV7+tvTPBfizxFpbajpPhzU9U05d266tbZmi+X73zVxL3VfoD+x6ySfsu6lIwy3m32P++a6cNQjiJcsj5biDMp5PhoV6Uebmlyn53aw/2lt9YU0Na0zeYq17D+zX+zLqvx61z7Tc+ZpvhGzl/0u9X707f88ov9r+838Nc1OlOrPkgfQYzMqGX4X6xiJcsYnzheW38Vfot/wTb+NDeIvBl98PtSm33uhHz9P3dWs3b7v/AG/wDQ1rwj9t/4a/D34deMrGy8ITx2ur+Qq3+k23zRQJt+SXd/A7f3f+B/73mP7MHxBf4U/Hjwtq7SeTay3K2F5/1wn+Vv++H2N/wCu+hKWEr8kj4vN6NPiPI/rFOFn8UT9oaWmRtvjB9RTq+sP5tE7mvDP2zvFLeFP2bfGlxHJsmurZbBfpO6xN/467V7izY/Ovkz/gpTeta/AWygRsC51q2R/wDdVZX/APZa58RLlpSZ7OS0o4jMqFKX80T8w7aHZXc/Df4Y+JPit4ii0Twvp0mo3jfMz/cigX+9K38K1xyfu/mr9Qvhdpmh/sj/ALLa+Jby0SbU5LOO/vto2vc3Uu0RRbv9ncqZ9t1fK4aj9Ylefwn9IZ9nE8moQp4ePNVqe7E8h0H/AIJq6wbON9X8a2tpe7ceVaWLSov/AAJnXd/3zXmXxj/Y28cfCXTp9Xi8nxNoUHzSXWnoyTQL/eeL+7/tLurmPFv7WXxU8YaxJqcvi290hWffFZaU3kRRL/d/2/8Agde//s9/t4NDY3WjfFO+E0SxZttXW2dmk/vxyIqdv71dv+yVfcj7p8xU/wBasuj9bnKNVfaifOPwC+FZ+NnxEg8LDVG0gywS3H2pYPN+7/s7lrT/AGgfhCfgT46Tw3/ajavvs4rr7Q0Hlfed027dzf3K9n/Z5j8JTftnSXfge6Fz4dvLG5uIkELxfZ2ZfnjCt/Du5/4HUX7Y/g278f8A7Vmg+HLN1SfU9OtoVmb/AJZfvZdz/wDAE3tUfVY+w5ofFzHX/bmI/tmMKkuWl7Lm5T5U+2VKl5X3/r3wy/Z6/Zs0HS4/FmnWt/d3m5UlvYGvLi5Zfvtt5x979ai179mn4R/HX4ZTeJPh1bRaZcNFI1reWStEpkX/AJZyxN/3zWf9ny/m940jxrhrxlKhKNOXu83L7p8C/bKZ9q9q+qf2M/2ffBnxi8N+ILnxVpsl3dWF4tvHtuZYtq7Q38L16NN8Dfgj8CdNurbxdfaXfa7eRySwf2tJuMa/NtWKI/wL/ex81RHAynHmv7p24ni/B4fEywcISnUifBzzV798Hf2t3+Efw0n8If8ACNf2oJDO32n7X5X+tz/Dsr0D9mD9jvS/Evhe38a+P1LWM8f2i002R/LTyuvmTt9M/L0217Bp+gfsyePb4+FtPtvCtxqJ/dxx2YSKV2/2JU27m/3WrbDYWvD3ublPEzjiLLcZJ4erh5VIw+Ll+yz4l/Z1+E1l8ZPiTY+H9S1aHTLJV8+Vd2y4uUX/AJZRf7X/AKCtfXv7SH7R2h/s4eE7bwF8PoraPX1g8uOKJf3OmRf32/vN/s/8Cb/a+df2m/2db39nPxJpuveHL25fw/cT/wCh3e7/AEiznX5kRn/9Bb/YrzPwt8HPiH8Y49Q13QtCuvEatcstze/aIt7T/effvf5m+anGVXDxlShH3joq4bB55UpZpXxH+yx+zL+b+8efaleXOpXlxfX08l5e3ErSy3Ezb3lZv43rHud27crfP/C9e3XH7Ifxk25bwJeAev2q3/8AjteKXkMtndSwTrslibY6f3Wrz5RnCd5n3dHF4LF03Tw04y5f5T9tPhH4lHjX4W+FtcLbn1HTLe4f/eaNS1dlg/N9a8P/AGLb3+0P2aPBJZt+y2kiz/uyuv8ASvculfZ05c8IyP5Hx9L2GLq0v5ZS/MQ9vc18if8ABS+3ab4F6ZIv/LPXIC3/AH6lr67/AKV8+ft2eGz4i/Zp8TlF3zWBgv1/7ZyqX/8AHd1RiP4UjuyGp7HNKE5fzRPydT/U1+pHxh0WX9oL9jm3m8NL9ruprK11K3t4jzK8e13i/wB7hl/3q/LhPuV9Lfsn/tb3PwN36BrsE+qeEriTzFWH/W2bN951/vqx/hr5vB1Yw5oVfhkf0JxRluJxdOljcH71ShLm5f5j57RGTerKyMnyMj/wtXp3wU/Z98V/He8vF8PxQ29rYr+8vb3ckW7/AJ5blVtzV9v32t/sv/Fi4GvalN4XuLyQbpZbxhazP/11VtrN/wACrE+If7ZHw/8AhT4bbQ/hjaWmqXir5UCWUPl2Vt/tM38X+6vNbLCUoPnqS908OrxRmONh9XweDlGr/e+GJ5Z+y/8ADe++Ev7W1v4Z1S9sr/ULXTJ2mazZ2RHZUbb838W3/wBDrT/au8D6v8Qv2uNA0LQrl7DUrvTIES7V3UwLvuGZ/l/ururhf2SvF0dn+0AfE/ijWIonuoLmW5v76RE3ysf71evfE74paPon7VWg+NdPuIdZ0u109YJ5bKVJflbzVbbj+Jd26tISpew/7ePKxkMdSzj2tuar7H/yYt+NPgr8Dfg1Z2C/EfV9Y8V65LHuiTUL24uJWX+LZErfKu6vdPgPr/hbX/hP53gvRX0Tw9E88FvavGqH5Sd7YDNwzV558WtC+DnxuurDxHqni+OyntYPJBtbpEeSLltrKy7t3zNXafDv4ifDbQfAq6N4c1S207S7PzLeCG9l8p5P4mf5zubczH5q7ocsan2eU+IxcquJwsHUVSVXm96/wo8u/wCCe9u1t4W8a/8AYSX/ANFCvj/4z3V3r/xW8X39/K00ranOm9v7iO6In/AESvsj9kfxHoXgrw94li1TVLPTWuL1XiW4uFTcuz/ar5f+IOjx3/jPX7mELLFcahPKrJ9xlaV/nrycTP8A2enFH3uTRk83xdScekT66/a0F8v7K8n/AAjO7+zvLtPP+zdPseV/8d+7/wABzX5tw/akurf7H5n2vzV8jyfv+b/Bs/2t9fdf7Pv7S2neG/C9v4O8cDbZQR+RbagyeZEYunlSr7DK7v7td9a3P7NvgC+PimybwtaX4HmRyW7rK6P/ANMolLbW/wBxa66kY4rkqxmcOX46vw9Gtg6uFlU55e7KP2il+2AHf9kvb4i2f2zssd2P+fnem7b/AOP18h/BD9qnxH8BPDd7o2kaPp2o291cvdNNdPLvVtiLs+X/AHK3P2qP2lJfjlqlppumQyWnhfTpfNgWX5ZbmT7okZf4f9lf9qvn54flrixOL/f81I+s4d4fi8rdDMo/HLm5T6muP+CkXjhoXQ+GNEx/11n/AMK+PtVuWv7+4vGXY9xK0rJ/vPV267Vm3L7N9cdStVrfFI+rweT4HK1OeDp8vMfrX+w9bG3/AGY/Bgf+KOd/++p5K95+8w9q85+AXhtvB/wR8FaTImya30u3WVfR9gLf+PE16KpwzfWvs6UeWnE/lLMqiqY2rUX2pS/Mf2rnvG/he28ZeEda0O75ttRs5bWQf7LoVNdBSe1anDCUqclOPQ/CjWNHufDes6hpF8uy9sJ5bWdf9pX2PTIa+mf+CgPwkbwP8Wk8UWcBTSvEiCR3X7q3S/I6f8CXa3/fdfMkL18PiKXsqvIf2BkmYRzLAUsTH7Rq2cO9q6CzsN9Y+mvXW6Um/ZUandUaNPR9KX5Ny12em6au37tZOlQ/NXXabD9ylyng15dQh01d33a0IdNX+7WhZ2fmVpJYfLV8p4kqiOdmsP8AZqjc6au37tdg9hWbeWdHKOFQ4HUtNX+7XJarpv3/AJa9I1K2+WuS1K2+/Ucp7VCSPP7nTfmesy5tti11d+ipXL6rc/frE9ylLmMG8+St/wCD3geX4mfFjwr4biiZ0vr6JZ9v/Punzy/+Oo9cxeTfNX2t/wAE2fhK9xqmtfES9g/dxq2m6bu/ibO6V/8A0Ff++67cJT9rVjE8TiPMoZbllWs/i+yfoFbxLDCiBdqqu2pqKK+1P5MbvqFJS0lAjyz9ob4O2Pxw+GOp+G7krDdsvn2V23/LCdfuN9P4W/2Xavx71jRdQ8La9qGjavbNZ6lYTtBc27ffVlr90MDzFIbn0r5D/bg/ZTk+Jdk3jfwpa7vFdjFtubWPj+0YF7f9dU/h/vfd/u48vHYX2seaPxH6ZwZxFHLK/wBUxEv3Uv8AyWR+eumzbGrttHm+5Xm9tM0Mu11ZHVtjK/31aut0PUq+Xj5n9BVGqkLwPU9H/grstKT7tedaJqS/J81egaPeK6pXSfM4k62whrYhhrHsJlfZW3DNV8p89UGTW3y1lXifK9bE01Y9/MqUcoUzl9VRa4zWPk311esXipv+avP9e1Jfn+esj6HCxOa1ibZvridSufmrY1rUvv1zlvZ3fiDVLXTdNtpr6/upVigt7ddzys38K1jq9D6anOFCHPM1/hv8PdW+LPjnS/C+jxb7y+k2vL/DBF/HK3+yq1+yPw18A6b8MvBeleGdIi8qx06BYlyPmf8AvM3+0zEsa8f/AGQ/2ZYPgL4VN7qqRXPjLVVVr24X51gXGVt0b+6v8TfxNz/dr6NOef0r6nBYb6vHml8R/OHF2f8A9sYr2dD+FD8R9LSUtekfABRRRQAlBAPUZpaSgD47/au/Yit/iVLdeLfBCw6d4rb5rmzf5bfUf/iJf9r+L+L+9X5531jqXhPW7rStZsbnStStW2z2l2u11av3JbdtU7q8w+NH7PPgz456UIfEWlq99Em221K3/dXUHX7r/wDsrfLXl4nAxq+9H4j9L4d4xq5dGOFxnvUv/Jon5TaPr2zZ81ehaJ4nX5Pmrqfir+wV8Qvh68t54aZfGekL93yP3V6i/wC1H/H/AMA/74rwSa81DwzfvY6rZ3Om3sX3re7ieJ1/4C1eJKjOj8Z+wUMwwGax5sNV5j6K0rxIr/xV0EPiGLb96vnLTfGGz+KugtvG3y/62lzGNTAHttz4hXb96uf1XxIu1/mrzKbxzvX/AFtYWpeM9+/56Ap4A7LW/E6/P81eea3r27f81Q6ZHrfjbUFsNC0u91m8brBp8DSt/wCO19HfCX/gnt4u8WPHfeOr5PDOm5z9gtWWW8kX/f8Auxf+P04Uatb4QxOZYDKo82Jq8rPmfwv4R8QfE7xJBoXhnTZ9X1Wf7sUS/Iq/32b7qr/tNX6U/st/shaT8CrNNZ1Z4tY8a3EW2W82ZitU/wCeUA7f7T/eavWvhf8AB7wr8HdBXS/C2lQ6fE3MkoXdLO396Rz8zH613I+8efwr3cNgo0fel8R+NcQ8XV82/cUPdpf+lEmKWiivSPz8KKKKACiiigAooooASilooAjxxzzXO+LPAPh3xtZ/Ztd0TT9Yt/8AnnfWqSj/AMeFdLxik49aC41J05c0HY+cPEP7Bnwi1yR5ItCm0aRv+WmmXssP/jmdtcncf8E2vATNutvEXiS3X+6LiJv/AGlX11zRmuZ4elLeJ7NLPs0o/BXkfJFp/wAE3fh/C2+417xJd/8AbzEv/oMVdv4a/Yb+EPh10c+Gv7VmX+PU7iW4H/fDPt/8dr6AoxTjQpw2iFXPMyrfHXl95i6B4T0jwvZraaTpVnpdqvSG0gSJfyWtrA9KPu07PFdB4kpSm+abCilooEFFFFABRRRQB//Z"  title="">
    </p>
  </div>
  <p class="c11">
    <span class="c1"></span>
  </p>
  <p class="c21">
    <span class="c1">PLAN DE EMERGENCIA</span>
  </p>
  <p class="c39 c14">
    <span class="c13"></span>
  </p>
  <p class="c21">
    <span class="c13">CONSORCIO ECUATORIANO DE TELECOMUNICACIONES S.A. CONECEL</span>
  </p>
  <p class="c11">
    <span class="c13"></span>
  </p>
  <p class="c21">
    <span class="c68 c42 c66">$Tag_oficina</span>
  </p>
  <p class="c4 c14">
    <span class="c13"></span>
  </p>
  <p class="c21">

  $Tag_portada
  </p>
  <p class="c4 c14">
    <span class="c13"></span>
  </p>
  <p class="c4 c14">
    <span class="c13"></span>
  </p>
  <p class="c4 c14">
    <span class="c13"></span>
  </p>
  <p class="c4">
    <span class="c13">Direcci&oacute;n.- $Tag_oficina: </span>
    <span class="c0">$Tag_direccion.</span>
  </p>
  <p class="c4 c14">
    <span class="c13"></span>
  </p>
  <p class="c4">
    <span class="c42">Representante de la Empresa.- </span>
    <span class="c49">C.P.</span>
    <span class="c42">&nbsp;</span>
    <span class="c0">Marco Antonio Campos Garc&iacute;a</span>
  </p>
  <p class="c4 c14">
    <span class="c0"></span>
  </p>
  <p class="c4">
    <span class="c13">Responsable de Seguridad Industrial.- </span>
    <span class="c0">Ing. V&iacute;ctor Hugo Guerrero Flores</span>
  </p>
  <p class="c4 c14">
    <span class="c0"></span>
  </p>
  <p class="c4">
    <span class="c13">Fecha de Actualizaci&oacute;n.- </span>
    <span class="c0">$tag_fecha_actualizacion</span>
  </p>
  <p class="c4 c14">
    <span class="c0"></span>
  </p>
  <p class="c4 c14">
    <span class="c0"></span>
  </p>
  <p class="c4 c14">
    <span class="c0"></span>
  </p>
  <br>
  <br>
  <br>
  <p class="c4">
    <span class="c13">MAPA DE GEO-REFERENCIACI&Oacute;N</span>
  </p>
  <p class="c4 c14">
    <span class="c13 c35"></span>
  </p>
  <p class="c4">
  
  $Tag_geolocalizacion
   <br>

  </p>
  <p class="c4 c14">
    <span class="c13 c35"></span>
  </p>
  <p class="c4 c14">
    <span class="c13 c35"></span>
  </p>
  <p class="c4 c14">
    <span class="c13 c35"></span>
  </p>
  <p class="c4 c14">
    <span class="c13 c35"></span>
  </p>
  <p class="c4 c14">
    <span class="c13 c35"></span>
  </p>
  <p class="c4 c14">
    <span class="c13 c35"></span>
  </p>
  <p class="c4 c14">
    <span class="c13 c35"></span>
  </p>
  <p class="c3 c14">
    <span class="c0"></span>
  </p>
  <p class="c21">
    <span class="c0">ELABORADO POR:</span>
  </p>
  <p class="c11">
    <span class="c0"></span>
  </p>
  <p class="c11">
    <span class="c0"></span>
  </p>
  <p class="c11">
    <span class="c0"></span>
  </p>
  <p class="c21">
    <span class="c49 c66 c73">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
  </p>
  <p class="c21">
    <span class="c0">$ELABORADOR</span>
  </p>
  <p class="c21">
    <span class="c0">$CARGO_ELABORADOR</span>
  </p>
  <p class="c11">
    <span class="c0"></span>
  </p>
  <p class="c39">
    <span class="c0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
  </p>
  <p class="c11">
    <span class="c0"></span>
  </p>
  <p class="c11">
    <span class="c0"></span>
  </p>
  <p class="c11">
    <span class="c0"></span>
  </p>
  <p class="c11">
    <span class="c0"></span>
  </p>
  <p class="c11">
    <span class="c0"></span>
  </p>
  <p class="c11">
    <span class="c0"></span>
  </p>
  
    $CONTENIDO
  

</body>


</div>`;

