export const info_general_empresa =`
<div style="text-align: center;">
<table class="c57">
<thead>
  <tr class="c19">
    <td class="c64" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c13">Raz&oacute;n Social:</span>
      </p>
    </td>
    <td class="c100" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c0">$RAZON_SOCIAL_EMPRESA</span>

      </p>
    </td>
  </tr>
  <tr class="c19">
    <td class="c64" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c13">Edificaci&oacute;n:</span>
      </p>
    </td>
    <td class="c100" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c0">$EDIFICACION</span>
      </p>
    </td>
  </tr>
  <tr class="c19">
    <td class="c64" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c13">Ciudad:</span>
      </p>
    </td>
    <td class="c100" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c0">$CIUDAD</span>

      </p>
    </td>
  </tr>
  <tr class="c19">
    <td class="c64" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c13">Provincia:</span>
      </p>
    </td>
    <td class="c100" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c0">$PROVINCIA</span>
      </p>
    </td>
<tbody></tbody>
</tr>
<tr class="c19">
  <td class="c64" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c13">Direcci&oacute;n:</span>
    </p>
  </td>
  <td class="c100" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$DIRECCION</span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c64" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c13">Tel&eacute;fono:</span>
    </p>
  </td>
  <td class="c100" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0 c35">$TELEFONO</span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c64" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c13">Fax:</span>
    </p>
  </td>
  <td class="c100" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0 c35">$FAX</span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c64" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c13">Correo Electr&oacute;nico:</span>
    </p>
  </td>
  <td class="c100" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c49 c55">
        <a class="c108" >$CORREO</a>
      </span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c64" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c13">Actividad de la empresa:</span>
    </p>
  </td>
  <td class="c100" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$ACTIVIDAD</span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c64" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c13">Procesos en el lugar:</span>
    </p>
  </td>
  <td class="c100" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$PROCESOS</span>
    </p>
  </td>
</tr>
</thead>
</table>
</div>
<br>`


export const contacto_emergencia =`
<br>
<div style="text-align: center;">
<table class="c57">
<tr class="c19">
  <td class="c83" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c13">Orden</span>
    </p>
  </td>
  <td class="c36" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c13">Nombre</span>
    </p>
  </td>
  <td class="c51" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c13">Correo electr&oacute;nico</span>
    </p>
  </td>
  <td class="c67" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c13">Extensi&oacute;n telef&oacute;nica</span>
    </p>
  </td>
  <td class="c103" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c13">Tel&eacute;fono M&oacute;vil</span>
    </p>
  </td>
</tr

 $CONTACTOS_EMERGENCIA

</table>
</div>
<br>
`

export const descripcion_area_oficina =`
<br>
<div style="text-align: center;">
<table class="c57">
<tr class="c19">
  <td class="c113" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">Configuraci&oacute;n:</span>
    </p>
  </td>
  <td class="c105" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$CONFIGURACION</span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c113" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">Accesos exteriores:</span>
    </p>
  </td>
  <td class="c105" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$ACCESOS_EXTERIORES</span>
    </p>

  </td>
</tr>
<tr class="c19">
  <td class="c113" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">Ayuda Exterior:</span>
    </p>
  </td>
  <td class="c105" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$AYUDA_EXTERIOR</span>
    </p>

  </td>
</tr>
</table>
</div>
` ;

export const caracteristicas_edificio =`
<br>
<div style="text-align: center;">
<table class="c57">
<tr class="c19">
  <td class="c77" colspan="1" rowspan="6">
    <p class="c4">
      <span class="c0">Dimensiones del edificio:</span>
    </p>
  </td>
  <td class="c81" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">Superficie total construida:</span>
    </p>
  </td>
  <td class="c78" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$SUPERFICIE_TOTAL_CONSTRUIDA</span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c81" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">N&uacute;mero de plantas sobre rasante:</span>
    </p>
  </td>
  <td class="c78" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$PLANTAS_SOBRERAZANTES</span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c81" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">N&uacute;mero de plantas bajo rasante:</span>
    </p>
  </td>
  <td class="c78" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0 c35">$PLANTAS_BAJO_RAZANTES</span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c81" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">N&uacute;mero de pisos ocupados por CONECEL:</span>
    </p>
  </td>
  <td class="c78" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$NUMERO_PISOS_OCUPADOS</span>
    </p>
    <p class="c39 c14">
      <span class="c0"></span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c81" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">Superficie de cada sector ocupado por CONECEL:</span>
    </p>
  </td>
  <td class="c78" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$SUPERFICIE_OCUPADO</span>
    </p>

  </td>
</tr>
<tr class="c19">
  <td class="c81" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">Altura:</span>
    </p>
  </td>
  <td class="c78" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$ALTURA</span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c77" colspan="1" rowspan="4">
    <p class="c4">
      <span class="c0">Elementos estructurales:</span>
    </p>
  </td>
  <td class="c81" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">Pilares:</span>
    </p>
  </td>
  <td class="c78" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$PILARES</span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c81" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">Vigas:</span>
    </p>
  </td>
  <td class="c78" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$VIGAS</span>

    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c81" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">Cerramientos exteriores:</span>
    </p>
  </td>
  <td class="c78" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0 c35">$CERRAMIENTOS_EXTERIORES</span>
    </p>
  </td>
</tr>
<tr class="c19">
  <td class="c81" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">Cerramientos interiores:</span>
    </p>
  </td>
  <td class="c78" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">$CERRAMIENTOS_INTERIORES</span>
    </p>
  </td>
</tr>
</table>
</div>
`

export const  equipos_instalaciones =`
<br>
<div style="text-align: center;">
<table class="c57">
$DETALLE
</table>
</div>
`

export const sistema_emergencia =`
<div style="text-align: center;">
<br>
<table class="c118">
  <tr class="c19">
    <td class="c61" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c13">Etapa</span>
      </p>
    </td>
    <td class="c99" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c13">Gerente de SSO</span>
      </p>
    </td>
    <td class="c27" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c13">Consola de Seguridad</span>
      </p>
    </td>
    <td class="c67" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c13">L&iacute;deres de Piso</span>
      </p>
    </td>
    <td class="c58" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c13">Organismos de Emergencia</span>
      </p>
    </td>
    <td class="c34" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c13">Cualquier persona</span>
      </p>
    </td>
  </tr>
  <tr class="c19">
    <td class="c61" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c12">Detecci&oacute;n</span>
      </p>
    </td>
    <td class="c99" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c27" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c67" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c58" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c34" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Puede detectar</span>
      </p>
    </td>
  </tr>
  <tr class="c19">
    <td class="c61" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c12">Confirmaci&oacute;n</span>
      </p>
    </td>
    <td class="c99" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c27" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Solicita confirmaci&oacute;n</span>
      </p>
    </td>
    <td class="c67" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c58" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c34" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Confirma</span>
      </p>
    </td>
  </tr>
  <tr class="c19">
    <td class="c61" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c12">Declaraci&oacute;n de tipo de Emergencia</span>
      </p>
    </td>
    <td class="c99" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Declara</span>
      </p>
    </td>
    <td class="c27" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c67" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c58" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c34" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
  </tr>
  <tr class="c19">
    <td class="c61" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c12">Comunicaci&oacute;n </span>
      </p>
      <p class="c4">
        <span class="c12">de la</span>
      </p>
      <p class="c4">
        <span class="c12">Emergencia</span>
      </p>
    </td>
    <td class="c99" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Ordena</span>
      </p>
    </td>
    <td class="c27" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Comunica</span>
      </p>
    </td>
    <td class="c67" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c58" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c34" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
  </tr>
  <tr class="c19">
    <td class="c61" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c12">Intervenci&oacute;n</span>
      </p>
    </td>
    <td class="c99" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Dirige</span>
      </p>
    </td>
    <td class="c27" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c67" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Interviene en 1ra</span>
      </p>
      <p class="c21">
        <span class="c12">instancia</span>
      </p>
    </td>
    <td class="c58" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Interviene en 2da</span>
      </p>
      <p class="c21">
        <span class="c12">instancia</span>
      </p>
    </td>
    <td class="c34" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Acciones auxiliares de apoyo</span>
      </p>
    </td>
  </tr>
  <tr class="c19">
    <td class="c61" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c12">Evacuaci&oacute;n</span>
      </p>
    </td>
    <td class="c99" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Declara</span>
      </p>
    </td>
    <td class="c27" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Comunica</span>
      </p>
    </td>
    <td class="c67" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Anuncia y dirige</span>
      </p>
    </td>
    <td class="c58" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c34" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
  </tr>
  <tr class="c19">
    <td class="c61" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c12">Ayuda exterior</span>
      </p>
    </td>
    <td class="c99" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Ordena</span>
      </p>
    </td>
    <td class="c27" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Comunica</span>
      </p>
    </td>
    <td class="c67" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c58" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c34" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
  </tr>
  <tr class="c19">
    <td class="c61" colspan="1" rowspan="1">
      <p class="c4">
        <span class="c12">Fin de</span>
      </p>
      <p class="c4">
        <span class="c12">Emergencia</span>
      </p>
    </td>
    <td class="c99" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Declara</span>
      </p>
    </td>
    <td class="c27" colspan="1" rowspan="1">
      <p class="c21">
        <span class="c12">Comunica</span>
      </p>
    </td>
    <td class="c67" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c58" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
    <td class="c34" colspan="1" rowspan="1">
      <p class="c11">
        <span class="c12"></span>
      </p>
    </td>
  </tr>
</table>
</div>
<br>
`

export const instituciones_emergencia = `
<div style="text-align: center;">
<table class="c89">
<tr class="c19">
  <td class="c111" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c13">Instituciones</span>
    </p>
  </td>
  <td class="c101" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c13">Tel&eacute;fono</span>
    </p>
  </td>
</tr>

 $CONTENIDO

</table>
</div>
`

export const cantidad_poblacion =`
<br>
<div style="text-align: center;">
<table class="c57">
<tr class="c19">
  <td class="c63 c45" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c13">Actividad Sector/Planta</span>
    </p>
  </td>
  <td class="c18 c45" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c13">Empleados</span>
    </p>
  </td>
  <td class="c63 c45" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c13">Trabajadores de servicios complementarios</span>
    </p>
  </td>
  <td class="c38 c45" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c13">Total</span>
    </p>
  </td>
  <td class="c38 c45" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c13">Promedios de visitantes al d&iacute;a</span>
    </p>
  </td>
</tr>


   $CONTENIDO
</table>
</div>
<br>
`
