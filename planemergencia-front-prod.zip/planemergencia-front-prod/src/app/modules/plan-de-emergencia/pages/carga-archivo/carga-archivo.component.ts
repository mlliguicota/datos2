import { Component, OnInit } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';
import { AuthService } from 'src/app/core/services/auth.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { IArchivo, IArchivoPost, IArchivoPut, IDocumento } from '../../core/interfaces/descargarArchivo.interface';
import { ArchivosoficinasService } from '../../core/services/archivosoficinas.service';
import { NavigationService } from '../../core/services/navigation.service';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';

@Component({
  selector: 'app-carga-archivo',
  templateUrl: './carga-archivo.component.html',
  styleUrls: ['./carga-archivo.component.scss']
})
export class CargaArchivoComponent implements OnInit {

  /// se deben setear al inicio
  codigoOficina: number = 2
  codigoEmpresa: number = 1;
  usuario: string = 'jonathan';
  loading: boolean = false
  toastKey: any;
  uploadedFiles: any[] = [];
  multiple: boolean = true;
  maxFileSize: number = 10000000;
  lista_archivo_planes: IArchivo[] = new Array<IArchivo>()
  lista_put: IArchivoPut[] = new Array<IArchivoPut>()
  lista_post: IArchivoPost[] = new Array<IArchivoPost>()
  existePost: boolean
  existePut: boolean
  file: File[]
  error_nombre: boolean
  nombre_archivo_error: string
  displayModal: boolean = false
  lista_documentos: IDocumento[] = new Array<IDocumento>()


  constructor(private _oficina: SharingOfficeService,
    private toast: ToastService,
    private navigationService: NavigationService,
    private _authService: AuthService,
    private _archivosoficinasService: ArchivosoficinasService) {
    console.log("ingrese")
  }


  ngOnInit(): void {
    this.inicializar()

  }


  async inicializar() {

    this.usuario = this._authService.getUsuarioData().usuarioIngreso
    console.log("Usuario =>>>>>>>>>>>>>" + this.usuario)
    this.codigoOficina = this._oficina.currentOfficeData.id.codigo
    this.codigoEmpresa = this._oficina.currentOfficeData.id.codigoEmpresa
    this.loading = true

    let responseArchivosOficinas: any = await this._archivosoficinasService.obtenerArchivosOficinas(this.codigoOficina, this.codigoEmpresa).toPromise()
    this.lista_archivo_planes = responseArchivosOficinas.pageContent
    console.log(this.lista_archivo_planes)
    this.loading = false
  }



  cargar() {
    this.existePost = false
    this.existePut = false

    for (let file of this.uploadedFiles) {
      let rutaArchivo: string = this.ObtieneRutaArchivo(file.name)
      let nombreOficinaArchivo: string = this.obtieneNombreOficina(file.name)
      //   this.convertToBas64(file , rutaArchivo)  
      if (this.existeArchivo(nombreOficinaArchivo)) {
        this.existePut = true
        var codigoArchivo: number = this.obtieneCodigo(nombreOficinaArchivo)
        this.lista_put.push({
          codigo: codigoArchivo,
          codigoOficina: this.codigoOficina,
          codigoEmpresa: this.codigoEmpresa,
          nombreEquipo: 'Prueba',
          usuarioModificacion: this.usuario,
          estado: "A",
          nombre: nombreOficinaArchivo,
          ruta: rutaArchivo,
          tipoArchivo: 'archivo'
        })
      } else {

        if (!this.ValidarNombreArchivos(file.name)) {
          this.error_nombre = true
          this.nombre_archivo_error = file.name

          break

        }

        this.existePost = true
        this.lista_post.push({
          codigoOficina: this.codigoOficina,
          codigoEmpresa: this.codigoEmpresa,

          nombreEquipo: 'Prueba',
          usuarioIngreso: this.usuario,
          estado: "A",
          nombre: nombreOficinaArchivo,
          ruta: rutaArchivo,
          tipoArchivo: 'archivo'
        }
        )

      }

    }

  }


  /*ObtieneRutaArchivo(nombre: string): string {
    let valor: string = ""
    let nombre_archivo = this.obtenerNombreArchivo(nombre)

    if (nombre_archivo.substring(0, 5).toUpperCase() == 'PLANO') {
      nombre_archivo = 'PLANO'
    }

    switch (nombre_archivo.toUpperCase()) {
      case "METODO_MESERI":
        //case nombre_archivo.startsWith("METODO_MESERI"):
        valor = "/archivos/Metodo_Meseri/"
        break;
      case "METODO_INSHT":
        valor = "/archivos/Metodo_Insht"
        break;
      case "PUNTO_REUNION":
        valor = "/archivos/Punto_Reunion"
        break;
      case "PLAN_EMERGENCIA":
        valor = "/archivos/Plan_Emergencia"
        break;
      case "PLANO":
        valor = "/archivos/Planos"
        break;
      default:
        valor = "/archivos/Otros"
        console.log("ninguna opcion");
        break;
    }

    return valor

  }*/

  ObtieneRutaArchivo(nombre: string): string {
    let valor: string = ""
    let nombre_archivo = this.obtenerNombreArchivo(nombre).toUpperCase()

    if (nombre_archivo.substring(0, 5).toUpperCase() == 'PLANO') {
      nombre_archivo = 'PLANO'
    }

    switch (true) {
      case nombre_archivo.startsWith("METODO_MESERI"):
        valor = "/archivos/Metodo_Meseri/"
        break;
      case nombre_archivo.startsWith("METODO_INSHT"):
        valor = "/archivos/Metodo_Insht"
        break;
      case nombre_archivo.startsWith("PUNTO_REUNION"):
        valor = "/archivos/Punto_Reunion"
        break;
      case nombre_archivo.startsWith("PLAN_EMERGENCIA"):
        valor = "/archivos/Plan_Emergencia"
        break;
      case nombre_archivo.startsWith("PLANO"):
        valor = "/archivos/Planos"
        break;
      default:
        valor = "/archivos/Otros"
        console.log("ninguna opcion");
        break;
    }

    return valor

  }

  existeArchivo(nombre: string): boolean {
    let valor: boolean = false
    for (const archivo of this.lista_archivo_planes) {
      if (archivo.nombre == nombre) {
        valor = true
        break
      }
    }
    return valor
  }

  obtieneCodigo(nombre: string): number {
    let valor: number = 0
    for (const archivo of this.lista_archivo_planes) {
      if (archivo.nombre == nombre) {
        valor = archivo.codigo
        break
      }
    }
    return valor
  }

  /* antesCargar(event  : any) {
               console.log(event.currentFiles) 
               for(let archivo  of event.currentFiles) {
                
                if (!this.ValidarNombreArchivos(archivo.name)) {      
                  this.error_nombre = true
                  this.nombre_archivo_error = archivo.name
                  this.displayModal = true
                  break 
       
                }else{
                  this.uploadedFiles.push(archivo);     
  
                }
  
                     
            } 
      } */

      antesCargar(event: any) {
        console.log(event.currentFiles);
      
        // Reiniciar estado de error y no limpiar this.uploadedFiles aquí
        this.error_nombre = false;
      
        for (let archivo of event.currentFiles) {
          if (this.ValidarNombreArchivos(archivo.name)) {
            // Agrega el archivo a la lista si es válido
            this.uploadedFiles.push(archivo);
          } else {
            // Configura el estado de error si el archivo no es válido
            this.error_nombre = true;
            this.nombre_archivo_error = archivo.name;
            this.displayModal = true;
            if (event.currentFiles.length != 0) {
              event.currentFiles.pop(); //21/6/2024
          }

            // No se agrega el archivo inválido a la lista
          }
        }
      
      }

  /*Fin de modificación para antes de cargar MichaelM */


  /*ValidarNombreArchivos(nombre: string): boolean {
    let valor: boolean
    let nombre_archivo = this.obtenerNombreArchivo(nombre)

    if (nombre_archivo.substring(0, 5).toUpperCase() == 'PLANO') {
      nombre_archivo = 'PLANO'
    }

    switch (nombre_archivo.toUpperCase()) {
      case "METODO_MESERI":
        valor = true
        break;
      case "METODO_INSHT":
        valor = true
        break;
      case "PUNTO_REUNION":
        valor = true
        break;
      case "PLAN_EMERGENCIA":
        valor = true
        console.log('planes');
        break;
      case "PLANO":
        valor = true
        break;
      default:
        valor = false
        console.log("ninguna opcion");
        break;
    }
    return valor

  }*/
 
    ValidarNombreArchivos(nombre: string): boolean {
      let valor: boolean;
      let nombre_archivo = this.obtenerNombreArchivo(nombre).toUpperCase();
    
      switch (true) {
        case nombre_archivo.startsWith("METODO_MESERI"):
          valor = true;
          break;
        case nombre_archivo.startsWith("METODO_INSHT"):
          valor = true;
          break;
        case nombre_archivo.startsWith("PUNTO_REUNION"):
          valor = true;
          break;
        case nombre_archivo.startsWith("PLAN_EMERGENCIA"):
          valor = true;
          console.log('planes');
          break;
        case nombre_archivo.startsWith("PLANO"):
          valor = true;
          break;
        default:
          valor = false;
          console.log("ninguna opcion");
          break;
      }
      return valor;
    }
    
    


  goPrevious() {
    this.navigationService.NavigationObservableData = Constantes.NAVIGATION_GO_PREVIOUS;
  }

  /*  async saveContinue(){
    this.loading= true
    this.error_nombre = false
    this.lista_documentos  = new Array<IDocumento>()
      this.cargar()
      if (this.error_nombre) { // existe error de nombre de archivo
        this.displayModal = true
      
  
      } else {
  
        if (this.existePut) {
          await  this._archivosoficinasService.actualizarArchivosOficinas(this.lista_put).toPromise()
        }
        if (this.existePost) {
         await  this._archivosoficinasService.registrarArchivosOficinas(this.lista_post).toPromise()
        }
       
         
        for(const file  of this.uploadedFiles) {
          let  rutaArchivo : string  =  this.ObtieneRutaArchivo(file.name)
          const data : any  =  await this._archivosoficinasService.convertToBas64(file )
         let nombreArchivo : string = this.obtenerNombreArchivo(file.name)
         console.log("nombre guardado" + nombreArchivo)
          console.log("desde el controlador")
          console.log(data.archivoBase64)
           await this._archivosoficinasService.RegistrarArchivo({
            archivoBase64 : data.archivoBase64 ,
            nombreArchivo : nombreArchivo.toLowerCase() + "_" +this.codigoOficina,
            rutaArchivo :rutaArchivo.substring(1)
           }).toPromise()
      }
       
       this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;   
      
        
      }
      this.loading = false
    
    } */

  async saveContinue() {
    try {
      this.loading = true;
      this.error_nombre = false;
      this.lista_documentos = [];

      this.cargar();

      if (this.error_nombre) {
        // Existe un error de nombre de archivo
        this.displayModal = true;
      } else {
        if (this.existePut) {
          await this._archivosoficinasService.actualizarArchivosOficinas(this.lista_put).toPromise();
        }

        if (this.existePost) {
          await this._archivosoficinasService.registrarArchivosOficinas(this .lista_post).toPromise();
        }

        for (const file of this.uploadedFiles) {
          const rutaArchivo: string = this.ObtieneRutaArchivo(file.name);
          const data: any = await this._archivosoficinasService.convertToBas64(file);
          const nombreArchivo: string = this.obtenerNombreArchivo(file.name);

          console.log("Nombre guardado: " + nombreArchivo);
          console.log("Desde el controlador:");
          console.log(data.archivoBase64);

          await this._archivosoficinasService.RegistrarArchivo({
            archivoBase64: data.archivoBase64,
            nombreArchivo: nombreArchivo.toLowerCase() + "_" + this.codigoOficina,
            rutaArchivo: rutaArchivo.substring(1),
          }).toPromise();
        }

        this.navigationService.NavigationObservableData = Constantes.NAVIGATION_GO_NEXT;
      }
    } catch (error) {
      console.error("Error en saveContinue:", error);

      // Puedes agregar lógica adicional aquí para manejar el error, como mostrar un mensaje al usuario.
    } finally {
      this.loading = false;
    }
  }







  /*Fin carga de archivos MichaelM*/
  obtenerNombreArchivo(nombre_archivo: string): string {
    return nombre_archivo.substring(0, nombre_archivo.indexOf("."))
  }

  obtieneNombreOficina(nombre_archivo: string): string {

    return (nombre_archivo.substring(0, nombre_archivo.indexOf("."))
      + "_" +
      this.codigoOficina
      + nombre_archivo.substring(nombre_archivo.indexOf("."))).toLowerCase()
  }
}
