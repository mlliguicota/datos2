import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DescargarArchivoComponent } from './descargar-archivo.component';

describe('DescargarArchivoComponent', () => {
  let component: DescargarArchivoComponent;
  let fixture: ComponentFixture<DescargarArchivoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DescargarArchivoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DescargarArchivoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
