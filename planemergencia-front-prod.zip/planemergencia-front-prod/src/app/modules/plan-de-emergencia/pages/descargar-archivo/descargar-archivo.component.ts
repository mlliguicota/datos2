import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { Archivo, IArchivo, IDocumento } from '../../core/interfaces/descargarArchivo.interface';
import { ArchivosoficinasService } from '../../core/services/archivosoficinas.service';
import { NavigationService } from '../../core/services/navigation.service';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-descargar-archivo',
  templateUrl: './descargar-archivo.component.html',
  styleUrls: ['./descargar-archivo.component.scss']
})
export class DescargarArchivoComponent implements OnInit {

  constructor(private _oficina: SharingOfficeService  ,
    private toast: ToastService,
    private navigationService: NavigationService,
    private _authService : AuthService ,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private _archivosoficinasService :ArchivosoficinasService) { }

 listaArchivos : Array<Archivo> ;
 valorBuscar : string ;
 listaArchivosTmp : Array<Archivo> ;
 listaArchivosInicial :Array<Archivo> ;
 loading : boolean = false
 toastKey: any;

 codigoOficina : number = 0
 codigoEmpresa : number = 0 ;
 usuario : string = 'jonathan' ;

 lista_archivo_planes : IArchivo[] = new Array<IArchivo>()
 cantidad_archivos : number = 0



  ngOnInit(): void {
    this.listaArchivosInicial = this.listaArchivos;
    this.listaArchivosTmp = new Array<Archivo>()
    this.usuario =  this._authService.getUsuarioData().usuarioIngreso
    console.log("Usuario =>>>>>>>>>>>>>" + this.usuario)
    this.codigoOficina = this._oficina.currentOfficeData.id.codigo
    this.codigoEmpresa =  this._oficina.currentOfficeData.id.codigoEmpresa
   this.cantidad_archivos = 0
    this.cargarArchivos();
    console.log('Ingrese On Init')

  }

  buscar() {
    console.log('Ingrese Buscar')
    this.listaArchivosTmp = new Array<Archivo>()
    if (this.valorBuscar =="") {
       
      this.listaArchivos = this.listaArchivosInicial; 
    } else {

      this.listaArchivos.forEach(archivo => {
        if (  archivo.nombreArchivo.toUpperCase().includes(this.valorBuscar.toUpperCase())) {
             this.listaArchivosTmp.push(archivo);
        }    
       this.listaArchivos = this.listaArchivosTmp; 
 
     })
      
    }
     
    
  
  /*  this.listaArchivos.forEach( archivo => {      
      console.log('Muestro riesgo oficina seleccionado')  
      console.log(riesgosOficinas)                
     let indice = this.lista_riesgos.findIndex(riesgo => riesgo.key== riesgosOficinas.id.codigoRiesgo.toString() && riesgosOficinas.estado == 'A'  )                     
     console.log('indice encontrado => ' +indice )                    
  
    this.selectedRiesgosTmp.push( this.lista_riesgos[indice])
 //  this.selectedMantenimientoTmp = this.lista_mantenimientos.slice(1,3)

    })*/

  }

  eliminar(archivo : Archivo){
    console.log("ingrese")

    this.confirmationService.confirm({
      message: 'Estas seguro que deseaa eliminar el archivo '+ archivo.nombreArchivo+'?',
      header: 'Confirmacion',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
          this.listaArchivos = this.listaArchivos.filter(archivo2 => {
                   return archivo2.nombreArchivo !== archivo.nombreArchivo

          });
          
          this.messageService.add({severity:'success', summary: 'Successful', detail: 'Archivo borrado exitoso', life: 3000});
      }
  });
     

  }

  imprimir(){}

 async descargar(archivo : Archivo){
  
  let ruta=    archivo.rutaArchivo.substring(1).replace('/',  `%2F`)     
//let ruta = `/%2Farchivos%2FMetodo_Insht`
 console.log(ruta)
     let documento :any = await this._archivosoficinasService.obtenerArchivo(archivo.nombreArchivo , ruta ).toPromise()

    this.downloadPdf(documento.archivoBase64 ,documento.nombreArchivo  )
    console.log(documento.nombreArchivo)
  
    console.log(documento.archivoBase64)

  }
  downloadPdf(pdf :string, fileName :string) {

    const link = document.createElement("a");
    link.href = pdf;
    link.download = fileName
    link.click();
  }

  goPrevious() {
    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
  }

  async cargarArchivos(   ){

       // Obtengo informacion de rutas Evacuacion  
       this.loading =true
       let responseArchivosOficinas :any = await  this._archivosoficinasService.obtenerArchivosOficinas(this.codigoOficina , this.codigoEmpresa).toPromise()
       this.lista_archivo_planes = responseArchivosOficinas.pageContent  
       console.log(this.lista_archivo_planes)

       this.listaArchivos = new Array<Archivo>();
  if (this.lista_archivo_planes.length > 0) {
      this.lista_archivo_planes.forEach((archivo ) => {
        this.cantidad_archivos =    this.cantidad_archivos +1
        let tipo = this.obtieneTipo(archivo.nombre)
       this.listaArchivos.push({ tipo :  tipo , 
        nombreArchivo: archivo.nombre  ,
        rutaArchivo : archivo.ruta
       })
     })
    }


  // por pruebas
 /* this.cantidad_archivos =    this.cantidad_archivos +1
    this.listaArchivos.push({ tipo :  'PDF' , 
      nombreArchivo: 'prueba'  ,
      rutaArchivo : 'prueba'
     })*/

     this.loading = false
       console.log('cantidad de archivos' + this.listaArchivos.length)
   }

 /*
   descargaPDF( ) {

    this._archivosoficinasService.obtenerArchivo(nombre_archivo)
    this
      .getDescargaFactura(datos.IdContratoDocumento)
      .subscribe(
        data => {
          const file = new Blob([data], { type: 'application/pdf' });
          const fileURL = URL.createObjectURL(file);
          window.open(fileURL);
        }
      );
  }
*/

   obtieneTipo(nombre_archivo : string)  : string{
    return  ( nombre_archivo.substring(nombre_archivo.indexOf(".") +1)).toUpperCase()
  }

}
