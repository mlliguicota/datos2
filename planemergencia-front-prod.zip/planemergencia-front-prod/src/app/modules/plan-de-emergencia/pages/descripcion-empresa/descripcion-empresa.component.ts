import { Component, OnInit } from '@angular/core';

import {  Router } from '@angular/router';
import { DescripcionEmpresaService } from '../../core/services/descripcion-empresa.service';
import { json } from 'express';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import { HttpErrorResponse } from '@angular/common/http';
import { SeccionesService } from '../../core/services/secciones.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { NavigationService } from '../../core/services/navigation.service';
import Constantes from '../../core/util/constantes';
import { ToastService } from 'src/app/core/services/toast.service';
import { Console } from 'console';



@Component({
  selector: 'app-descripcion-empresa',
  templateUrl: './descripcion-empresa.component.html',
  styleUrls: ['./descripcion-empresa.component.scss'] ,

})
export class DescripcionEmpresaComponent implements OnInit {

  constructor( 
               private route:Router  ,
               private _oficina: SharingOfficeService ,
               private _descripcionEmpresaService : DescripcionEmpresaService ,
               private _seccion : SeccionesService ,
               private navigationService: NavigationService,
               private toast: ToastService,
               private _authService : AuthService) { 
                this.toastKey = this.toast.genToastKey();
               }

  antecedente : string= "";
  antecedenteTmp : string= "";
  antecedenteCodSeccion : number ;
  antecedenteCodTipoPlan : number ;

  alcance : string = "";
  alcanceTmp : string = "";
  alcanceCodSeccion : number ;
  alcanceCodTipoPlan : number ;

  codigoAntecedente : number =0;
  codigoAlcance : number =0;
  existeAntecedente : boolean = false;
   oficina : string  = ''
   edificacion : string  = ''

   ciudad : string = ''
   existeAlcance : boolean = false;
   

   /// se deben setear al inicio
   codigoOficina : number = 0
   codigoEmpresa : number = 0 ;
   usuario : string = 'jonathan' ;
  loading : boolean = true;
  loadingAlcance  : boolean = true;
  loadingAntecedente  : boolean = true;
  toastKey: any;

  ngOnInit(): void {

    // obtengo la plantilla  antecedente
    this.loading = true;    
    this.usuario =  this._authService.getUsuarioData().usuarioIngreso
    console.log("Usuario =>>>>>>>>>>>>>" + this.usuario)
    this.codigoOficina = this._oficina.currentOfficeData.id.codigo
    this.codigoEmpresa =  this._oficina.currentOfficeData.id.codigoEmpresa
    this.ciudad =    this._oficina.currentOfficeData.ciudadOficina
   this.edificacion =  this._oficina.currentOfficeData.edificacionOficina
   this.oficina = this._oficina.currentOfficeData.nombreOficina
    this.inicializar()
    console.log( "Oficina =>" + this.oficina )
    console.log( "Ciudad =>" + this.ciudad )
    console.log( "Edificio =>" + this.edificacion )


/*
   //   this.oficina   Obtener Oficina 
   //   this.ciudad Obtener ciudad

     this.antecedente= this.antecedente.replace(/OFICINA/gi , this.oficina )
     this.antecedente= this.antecedente.replace(/CIUDAD/gi , this.ciudad )

      this.alcance= this.alcance.replace('OFICINA' , this.oficina )
      this.alcance= this.alcance.replace('CIUDAD' , this.oficina )
*/

    }

    inicializarLoading(){
       this.loading = true
       this.loadingAlcance = true;
       this.loadingAntecedente  = true;
    } 

    finalizarLoading(){
        
        if (!this.loadingAlcance && !this.loadingAntecedente ) {
                
          this.loading = false
        }

    }


    inicializarGuardado(){
      this.loading = true
      this.loadingAlcance = true;
      this.loadingAntecedente  = true;
   } 

   finalizarGuardado(){
        
    if (!this.loadingAlcance && !this.loadingAntecedente ) {  
      this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;   
      this.toast.mostrarToastSuccess('Los datos han sido cargados'+
      ' correctamente!!', this.toastKey);  
      this.loading = false
    }

}


  inicializar(){
       
    this.inicializarLoading()
    this.obtenerPlantillaAlcance()
      
    this.obtenerPlantillaAntecedente()
   
  } 

   
  async  obtenerPlantillaAlcance(){      
    const data : any  =  await this._seccion.obtenerPlantilla('Alcance') 
    if (data.resCode == 0) { // repondio ok y existe data
      this.alcanceTmp = data.seccion.texto
      this.alcanceCodSeccion =  data.seccion.codigoSeccion  // codigo seccion 
      this.alcanceCodTipoPlan = data.seccion.codigoTipoPlan 
      console.log(this.alcanceTmp)
    } else if(data.resCode == 0){
  
      this.toast.mostrarToastError('Hubo un problema al cargar los datos de plantilla de alcance' +
      ', por favor intentelo mas tarde', this.toastKey);
       console.log(data.error)
    }
    
      this.ObtenerAlcance(); 
  }
  
  
   async obtenerPlantillaAntecedente(){
       const data : any  =  await this._seccion.obtenerPlantilla('Antecedentes')   
        if (data.resCode == 0) { // repondio ok y existe data
          this.antecedenteTmp = data.seccion.texto
          this.antecedenteCodSeccion =  data.seccion.codigoSeccion  // codigo seccion 
          this.antecedenteCodTipoPlan = data.seccion.codigoTipoPlan 
          console.log(this.antecedenteTmp)
        } else if(data.resCode == 0){
          this.toast.mostrarToastError('Hubo un problema al cargar los datos de plantilla de antecente' +
          ', por favor intentelo mas tarde', this.toastKey);
           console.log(data.error)
        }    
       
         this.obtenerAntecedente()  

        
    }
  
  
    obtenerAntecedente(){
      return new Promise((resolve) => {     
        this._descripcionEmpresaService.obtenerDescripcion(this.codigoOficina ,this.codigoEmpresa , 
          this.antecedenteCodTipoPlan , this.antecedenteCodSeccion).subscribe(
          datos => {
                     if (datos.totalItems == 0) {  
                            this.existeAntecedente = false
                            console.log('No existe realizar post')
                            console.log(datos)
                           this.antecedente =  this.antecedenteTmp 

                        

                           this.antecedente= this.antecedente.replace('$Tag_oficina' , this.oficina )
                           this.antecedente= this.antecedente.replace('$Tag_ciudad' , this.ciudad )
                           this.antecedente= this.antecedente.replace('$Tag_edificio' , this.edificacion )
                           
                           
                     } else {
                      console.log('Si existe antecedente realizar put')
                      console.log(datos)
                      this.existeAntecedente = true
                      this.antecedente = datos.pageContent[0].valor
                      this.codigoAntecedente =   datos.pageContent[0].id.codigo  
                     }
                     this.loadingAntecedente = false
                       this.finalizarLoading()
                     const dataRes = { resCode: 0 };
                     resolve(dataRes);
          }  ,
          (err: HttpErrorResponse) => {
            const e='Ocurrio un error inesperado obteniendo la plantilla de antecedente';
            this.toast.mostrarToastError('Hubo un problema al cargar los datos  de antecente para la oficina' +  this.codigoOficina +
            ', por favor intentelo mas tarde', this.toastKey);
            const dataErr = { resCode: -1, error: e };
            this.loadingAntecedente = false
           this.finalizarLoading()
           resolve(dataErr);
            console.log('Error' )        
         }  
       )  
      })
    }
  
    ObtenerAlcance() {    
      return new Promise((resolve) => { 
        this._descripcionEmpresaService.obtenerDescripcion(this.codigoOficina ,this.codigoEmpresa , 
          this.alcanceCodTipoPlan , this.alcanceCodSeccion).subscribe(
          datos => {             
                     if (datos.totalItems == 0) {
                            this.existeAlcance = false
                            console.log('No existe alcnace realizar post')
                            console.log(datos)
                           this.alcance =  this.alcanceTmp 

                           this.alcance= this.alcance.replace('$Tag_oficina' , this.oficina )
                           this.alcance= this.alcance.replace('$Tag_ciudad' , this.ciudad )
                           this.alcance= this.alcance.replace('$Tag_edificio' , this.edificacion )
                           console.log( "Oficina =>" + this.oficina )
                           console.log( "Ciudad =>" + this.ciudad )
                           console.log( "Edificio =>" + this.edificacion )
                     } else {
                      console.log('Si existe alcance asociado a la oficina realizar put')
                      console.log(datos)
                      this.existeAlcance = true
                      this.alcance = datos.pageContent[0].valor
                      this.codigoAlcance =   datos.pageContent[0].id.codigo   
                     }

                     this.loadingAlcance = false
                      this.finalizarLoading()
                      const dataRes = { resCode: 0 };
                      resolve(dataRes);
          } ,
          (err: HttpErrorResponse) => {
            const e='Ocurrio un error inesperado obteniendo al obtener el alccance asociado a la oficina';
            this.toast.mostrarToastError('Hubo un problema al cargar los datos  de alcance para la oficina' +  this.codigoOficina +
            ', por favor intentelo mas tarde', this.toastKey);
            const dataErr = { resCode: -1, error: e };
            this.loadingAlcance = false
            this.finalizarLoading()
           resolve(dataErr);
            console.log('Error' )
        
         }   
       )
       })
    }




    saveContinue(){
      this.inicializarGuardado()
   this.guardarAlcance()
   this.guardarAntecedente()


   

  }

  goPrevious() {
    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
  }


  guardarAlcance() {
   
      // realizar put 
 if(this.existeAlcance) {
       console.log('Put a alcance')
this._descripcionEmpresaService.actualizar( { 
   
  nombreEquipo : 'PRUEBA'    ,
  usuarioModificacion :  this.usuario ,
  valor : this.alcance ,
  id : {
      codigo : this.codigoAlcance ,
      codigoEmpresa : this.codigoEmpresa ,
      codigoOficina : this.codigoOficina ,
      codigoSeccion : this.alcanceCodSeccion ,
      codigoTipoPlan : this.alcanceCodTipoPlan
}   }  ).subscribe( datos => {console.log(datos )
  this.loadingAlcance = false
  this.finalizarGuardado()
})  ;

  }else {  // realizar Post
    console.log('Post a alcance')
    this._descripcionEmpresaService.registrar( { 
      estado :  'A' ,
      nombreEquipo : 'PRUEBA'    ,
      usuarioIngreso : this.usuario  ,
      valor : this.alcance ,
      id : {
          codigoEmpresa : this.codigoEmpresa ,
          codigoOficina : this.codigoOficina ,
          codigoSeccion : this.alcanceCodSeccion ,
          codigoTipoPlan : this.alcanceCodTipoPlan
  }   }  ).subscribe( datos => {
         console.log(datos )
          this.loadingAlcance = false
          this.finalizarGuardado()
          } )  ;

  }


  }

  guardarAntecedente() {
     // realizar Put
   if(this.existeAntecedente) {
    console.log('Put a antecedente')
    this._descripcionEmpresaService.actualizar( { 
      
      nombreEquipo : 'PRUEBA'    ,
      usuarioModificacion :  this.usuario ,
      valor : this.antecedente ,
      id : {
          codigo : this.codigoAntecedente ,
          codigoEmpresa : this.codigoEmpresa ,
          codigoOficina : this.codigoOficina ,
          codigoSeccion : this.antecedenteCodSeccion ,
          codigoTipoPlan : this.antecedenteCodTipoPlan
  }   }  ).subscribe( datos =>  {   
                                  this.loadingAntecedente = false
                                    console.log(datos )
                                    this.finalizarGuardado()})  ;
  

   
 }else {  // realizar Post
  console.log('Post a antecedente')

this._descripcionEmpresaService.registrar( { 
  estado :  'A' ,
  nombreEquipo : 'PRUEBA'    ,
  usuarioIngreso : this.usuario  ,
  valor : this.antecedente ,
  id : {
      codigoEmpresa : this.codigoEmpresa ,
      codigoOficina : this.codigoOficina ,
      codigoSeccion : this.antecedenteCodSeccion ,
      codigoTipoPlan : this.antecedenteCodTipoPlan
}   }  ).subscribe( datos => { console.log(datos )
                        this.loadingAntecedente = false
                        this.finalizarGuardado()} )  ;

 }

  }






}
