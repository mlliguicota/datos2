import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DistribucionEvacuacionComponent } from './distribucion-evacuacion.component';

describe('DistribucionEvacuacionComponent', () => {
  let component: DistribucionEvacuacionComponent;
  let fixture: ComponentFixture<DistribucionEvacuacionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DistribucionEvacuacionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DistribucionEvacuacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
