import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { AuthService } from 'src/app/core/services/auth.service';
import { OficinaService } from 'src/app/modules/admin/core/services/Oficina.service';
import { NavigationService } from '../../core/services/navigation.service';
import { PlanEmergenciaService } from '../../core/services/plan-emergencia.service';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';
import { NivelOficinaContent } from '../../../admin/core/models/NivelOficinaContent';
import { NivelesOficinaService } from 'src/app/modules/admin/core/services/NivelesOficina.service';
import { RutasEvacuacionContent } from '../../../admin/core/models/RutasEvacuacionContent';
import { RutasNivelService } from 'src/app/modules/admin/core/services/RutasNivel.service';
import { RutasNivelContent } from '../../../admin/core/models/RutasNivelContent';
import { CeldaRutaEvacuacion } from '../../../admin/core/models/CeldaRutaEvacuacion';
import { RutasEvacuacionService } from 'src/app/modules/admin/core/services/RutasEvacuacion.service';

@Component({
  selector: 'app-distribucion-evacuacion',
  templateUrl: './distribucion-evacuacion.component.html',
  styleUrls: ['../estilos.scss']
})
export class DistribucionEvacuacionComponent implements OnInit {

  observacion     : string;
  observacionGuardar : string;

  loading         : boolean = true;
  codigoOficina   : number;
  codigoEmpresa   : number;
  usuario         : string;

  numeroDeRutasOficina : number;
  
  noError : boolean = false;

  listNivelesOficina  : NivelOficinaContent[];
  listRutasNivel      : RutasNivelContent[];
  listRutasEvacuacion : RutasEvacuacionContent[]; //Esta la lleno a partir de la lista de rutas nivel (un solo piso porque en teoria todos tienen el mismo numero de titulos)

  //Para hacer la tabla los indices que contengan cero seran los cuadrados que tengan las descripciones
  /*
  nivel     ruta 1    ruta 2    ruta 3    ....    ruta n
  nivel 1   0         0         0         ....    0
  nivel 2   0         0         0         ....    0
  .......   ....      ....      ....      ....    ....
  nivel m   0         0         0         ....    0
  */
  
  //varibles para generar la tabla hay que sumarle uno a las dimensiones por la fila de rutas y la columna de niveles
  
  filas    : number;
  columnas : number;

  tablaMostrar : any;

  listaCodigosRutasEvacuacionCrear : number[]; //lista cuando voy a crear mas (solo se llena si el primer nivel necesita mas rutas)
  listaCodigosRutasEvacuacion      : number[]; //lista en la que cargo todos los codigos de las rutas de evacuacion

  goNext : boolean = false;



  /* Clase que representara cada cuadro de 
    codigo : id de la tabla en la que debe grabarse
    tabla  : tabla en la que se debe guardar (EME_RUTAS_EVACUACION y EME_RUTAS_NIVEL)
    valor  : valor editable
    fila   : indice de la fila     (no realmente necesario)
    columna: indice de la columna  (no realmente necesario)
  */
  
  /*
  actualizar EME_RUTAS_EVACUACION (titulo)
  {
  "ip": "1111",
  "nombreEquipo": "1111",
  "fechaModificacion": "2023-01-05",
  "usuarioModificacion": "1111",
  "codigo": codigo,
  "descripcion": valor
  }
  insertar EME_RUTAS_EVACUACION (titulo)
  {
  "ip": "1",
  "nombreEquipo": "1",
  "estado": "A",
  "fechaIngreso": "2022-03-10",
  "usuarioIngreso": "1",
  "descripcion": valor
  } 
  */

  constructor(private _oficina               : SharingOfficeService ,
              private _authService           : AuthService ,
              private navigationService      : NavigationService,
              private messageService         : MessageService,
              private _planEmergenciaService : PlanEmergenciaService,
              private _oficinaService        : OficinaService,
              private _nivelOficinaService   : NivelesOficinaService,
              private _rutasNivelService     : RutasNivelService,
              private _rutasEvacuacionService : RutasEvacuacionService) {
  }

  ngOnInit(): void {
    this.loading = false;

    this.codigoOficina = this._oficina.currentOfficeData.id.codigo;
    this.codigoEmpresa = this._oficina.currentOfficeData.id.codigoEmpresa;

    this.usuario =  this._authService.getUsuarioData().usuarioIngreso;
    this.comprobarPrepararData();
  }

  goPrevious() {
    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
  }

  saveContinue(){
    this.guardarDatosTabla();
  }

  //funcion para comprobar si a la oficina se le deben crear las rutas nivel / rutas de evacuacion
  async comprobarPrepararData(){
    this.loading = true;
    await this.getCantidadRutas(this.codigoOficina).then((data: any) => {
      if (data.resCode == 0) {
        console.log("NUMERO DE RUTAS DE LA OFICINA");
        console.log(this.numeroDeRutasOficina);
        this.noError = true;
      } else {
        this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener el numero de rutas de oficina'});
        this.noError = false;
        this.loading = false;
      }
    });

    //obtener los niveles de oficina (Pisos)
    if(this.noError){
      await this.getNivelesOficina(this.codigoOficina).then((data: any) => {
        if (data.resCode == 0) {
          console.log("LISTA NIVELES OFICINAS");
          console.log(this.listNivelesOficina);
        } else {
          this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener los niveles de la oficina'});
          this.noError = false;
          this.loading = false;
        }
      });
    }


    //Primero compruebo / creo los titulos (eme_rutas_evacuacion)
    if(this.noError){
      console.log("PRIMER NIVEL PARA VERIFICAR LOS TITULOS",this.listNivelesOficina[0]);
      await this.getRutasNivel(this.listNivelesOficina[0].codigo).then((data: any) => { //Tomo solo el primer nivel ya que solo necesito uno para comprobar los titulos
        if (data.resCode == 0) {
          console.log(this.listRutasNivel);
        } else {
          this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener la ruta nivel 0'});
          this.noError = false;
          this.loading = false;
        }
      });
    }

    let cantRutasCrear = 0;

    if(this.noError){
      let cantRutasNivel = this.listRutasNivel.length;
      cantRutasCrear = this.numeroDeRutasOficina - cantRutasNivel; 
      console.log("CANTIDAD DE RUTAS A CREAR",cantRutasCrear);
      if(cantRutasCrear>0){
        this.listaCodigosRutasEvacuacionCrear = new Array<number>(cantRutasCrear);//Aqui guardare el codigo del nuevo registro EME_RUTAS_EVACUACION para luego poder guardarlo en EME_RUTAS_NIVEL
        for (let contador = 0; contador < cantRutasCrear; contador++) {
          if(this.noError){
            await this.postRutaEvacuacion().then((data: any) => { //Tomo solo el primer nivel ya que solo necesito uno para comprobar los titulos
              if (data.resCode == 0) {
                this.listaCodigosRutasEvacuacionCrear[contador] = data.codigo;
              } else {
                this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al crear el registro en rutas de evacuacion'});
                this.noError = false;
                this.loading = false;
              }
            });
          }
        }
      }

    }

    //Por cada nivel tengo que crear las rutas nivel
    if(cantRutasCrear>0){
      for (let indiceFila = 0; indiceFila < this.listNivelesOficina.length; indiceFila++) {
        for (let contador = 0; contador < cantRutasCrear; contador++) {
          if(this.noError){
            await this.postRutaNivel(this.listNivelesOficina[indiceFila].codigo,this.listaCodigosRutasEvacuacionCrear[contador]).then((data: any) => { //Tomo solo el primer nivel ya que solo necesito uno para comprobar los titulos
              if (data.resCode != 0) {
                this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al crear la ruta nivel'});
                this.noError = false;
                this.loading = false;
              }
            });
          }
        }
      }
    }

    //Escenario cuando se crea un nuevo nivel

    
    //Como para este momento estoy seguro que se crearon todas las rutas de evacuacion las obtengo del primer nivel
    if(this.noError){
      await this.getRutasNivel(this.listNivelesOficina[0].codigo).then((data: any) => { 
        if (data.resCode == 0) {
          console.log(this.listRutasNivel);
        } else {
          this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener la ruta nivel 0'});
          this.noError = false;
          this.loading = false;
        }
      });
    }

    //Lleno la lista que tendra los codigos de las rutas de evacuacion
    this.listaCodigosRutasEvacuacion = new Array<number>(this.listRutasNivel.length);
    for (let index = 0; index < this.listRutasNivel.length; index++) {
      const element : RutasNivelContent = this.listRutasNivel[index];
      this.listaCodigosRutasEvacuacion[index] = element.rutas.codigo;
    }
    console.log("this.listaCodigosRutasEvacuacion",this.listaCodigosRutasEvacuacion);

    //Recorro cada nivel con el fin de ver si para algun nivel no encuentro rutas de evacuacion
    for (let indiceFila = 0; indiceFila < this.listNivelesOficina.length; indiceFila++) {
      if(this.noError){
        await this.getRutasNivel(this.listNivelesOficina[indiceFila].codigo).then((data: any) => {
          if (data.resCode == 0) {
            console.log(this.listRutasNivel);
          } else {
            this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener la ruta nivel 0'});
            this.noError = false;
            this.loading = false;
          }
        });
      }


      if(this.noError){
        //Si un nivel no encuentro rutas nivel quiere decir que ese nivel se creo luego de que se inicializaran todos los niveles en base
        if (this.listRutasNivel.length == 0){
          //Entonces para este nivel se le crea todas las rutas nivel
          for (let contador = 0; contador < this.listaCodigosRutasEvacuacion.length; contador++) {
            if(this.noError){
              await this.postRutaNivel(this.listNivelesOficina[indiceFila].codigo,this.listaCodigosRutasEvacuacion[contador]).then((data: any) => { 
                if (data.resCode != 0) {
                  this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al crear la ruta nivel'});
                  this.noError = false;
                  this.loading = false;
                }
              });
            }
          }
        }
      }
      
    }


    this.loading = false;
    this.cargarMostrar();
  }

  async cargarMostrar(){
    this.loading = true;

    //obtener cantidad de rutas de evacuacion de la oficina
    await this.getObservacion(this.codigoEmpresa,this.codigoOficina).then((data: any) => {
      if (data.resCode == 0) {
        console.log(this.observacion);
        this.noError = true;
      } else {
        this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener la observacion'});
        this.noError = false;
        this.loading = false;
      }
    });

    //Obtener la observacion de la ruta de evacuacuion de la oficina
    if(this.noError){
      await this.getCantidadRutas(this.codigoOficina).then((data: any) => {
        if (data.resCode == 0) {
          this.columnas = this.numeroDeRutasOficina+1; //se le suma uno por ser los headers horizontales y verticales
          console.log(this.numeroDeRutasOficina);
        } else {
          this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener la observacion'});
          this.noError = false;
          this.loading = false;
        }
      });
    }

    //obtener los niveles de oficina (Pisos)
    if(this.noError){
      await this.getNivelesOficina(this.codigoOficina).then((data: any) => {
        if (data.resCode == 0) {
          console.log(this.listNivelesOficina);
        } else {
          this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener la observacion'});
          this.noError = false;
          this.loading = false;
        }
      });
    }

    if(this.listNivelesOficina.length==0){
      this.messageService.add({severity:'error', summary:'Información pagina', detail:'No existen niveles para esta oficina'});
      this.noError = false;
      this.loading = false;
    }else{
      this.filas = this.listNivelesOficina.length+1; //se le suma uno por ser los headers horizontales y verticales
      this.cargarMostrarData();
    }
  }

  async cargarMostrarData(){
    this.loading = true;
    console.log('Mostrando el primer nivel');
    var actual : CeldaRutaEvacuacion;
    //Obtener las rutas de evacuacion (titulos)
    if(this.noError){
      await this.getRutasNivel(this.listNivelesOficina[0].codigo).then((data: any) => {
        if (data.resCode == 0) {
          console.log(this.listRutasNivel);
        } else {
          this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener la observacion'});
          this.noError = false;
          this.loading = false;
        }
      });
    }

    if(this.noError && this.listRutasNivel.length > 0){ //busco las rutas evacuacion y aprovecho para llenar la primera fila con sus valores y la segunda fila (que representaria el primer nivel)
      this.tablaMostrar = new Array<CeldaRutaEvacuacion>(this.filas);
      this.tablaMostrar[0] =  new Array<CeldaRutaEvacuacion>(this.columnas);

      actual = new CeldaRutaEvacuacion();
      actual.fila     = 0;
      actual.columna  = 0;
      actual.tabla    = 'NINGUNA';
      actual.codigo   = -1;
      actual.valor    = 'PISOS';

      this.tablaMostrar[0][0]= actual;

      let indiceColumna = 0;
      //Primero lleno la primera fila que corresponde a los titulos
      for (let indxColumna = 0; indxColumna < this.columnas-1; indxColumna++) {
        
        indiceColumna++;
        actual          = new CeldaRutaEvacuacion();
        actual.fila     = 0;
        actual.columna  = indiceColumna;
        actual.tabla    = 'EME_RUTAS_EVACUACION';
        actual.codigo   = this.listRutasNivel[indxColumna].rutas.codigo;
        actual.valor    = this.listRutasNivel[indxColumna].rutas.descripcion;
        console.log('for titulos',actual);
        this.tablaMostrar[0][indiceColumna]= actual;
      }
      
      indiceColumna = 0;

      //Como a esta altura tengo cargado la info del primer nivel nivel, tambien lleno la segunda fila de la tabla a mostrar (primer nivel)
      this.tablaMostrar[1] =  new Array<CeldaRutaEvacuacion>(this.columnas);
      actual          = new CeldaRutaEvacuacion();
      actual.fila     = 1;
      actual.columna  = 0;
      actual.tabla    = 'NINGUNA';
      actual.codigo   = -1;
      actual.valor    = this.listNivelesOficina[0].descripcion;
      this.tablaMostrar[1][0]= actual;

      for (let indxColumna = 0; indxColumna < this.columnas-1; indxColumna++) {
        indiceColumna++;
        actual          = new CeldaRutaEvacuacion();
        actual.fila     = 1;
        actual.columna  = indiceColumna;
        actual.tabla    = 'EME_RUTAS_NIVEL';
        actual.codigo   = this.listRutasNivel[indxColumna].id.codigo;
        actual.valor    = this.listRutasNivel[indxColumna].cantidad;
        this.tablaMostrar[1][indiceColumna]= actual;
      }

      indiceColumna  = 0;
      //desde el segundo nivel en adelante se hace recorriendo la lista de niveles de oficinas
      for (let indiceFila = 0; indiceFila < this.listNivelesOficina.length; indiceFila++) {
        if(indiceFila>0){
          if(this.noError){
            await this.getRutasNivel(this.listNivelesOficina[indiceFila].codigo).then((data: any) => {
              if (data.resCode == 0) {
                console.log(this.listRutasNivel);
              } else {
                this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener la observacion'});
                this.noError = false;
                this.loading = false;
              }
            });
          }

          if(this.noError && this.listRutasNivel.length > 0){
            //En la tabla a mostrar el indice de la fila sera +1 porque ya se llenaron las 2 primeras
            this.tablaMostrar[indiceFila+1] =  new Array<CeldaRutaEvacuacion>(this.columnas);

            //Siempre lleno la columna cero con la descripcion del nivel
            actual          = new CeldaRutaEvacuacion();
            actual.fila     = indiceFila+1;
            actual.columna  = 0;
            actual.tabla    = 'NINGUNA';
            actual.codigo   = -1;
            actual.valor    = this.listNivelesOficina[indiceFila].descripcion;
            this.tablaMostrar[indiceFila+1][0]= actual;
            
            for (let indxColumna = 0; indxColumna < this.columnas-1; indxColumna++) {
              indiceColumna++;
              actual          = new CeldaRutaEvacuacion();
              actual.fila     = indiceFila+1;
              actual.columna  = indiceColumna;
              actual.tabla    = 'EME_RUTAS_NIVEL';
              actual.codigo   = this.listRutasNivel[indxColumna].id.codigo;
              actual.valor    = this.listRutasNivel[indxColumna].cantidad;
              this.tablaMostrar[indiceFila+1][indiceColumna]= actual;
            
            }
          }

        }
        indiceColumna  = 0;
        
      }
      
      
      
    }

    this.loading = false;
  }

  async guardarDatosTabla(){
    var actual : CeldaRutaEvacuacion;
    this.loading = true;
    this.noError = true;
    let codeNivel : number = 0;
    let codeRuta  : number = 0;

    console.log("filas",this.filas);
    console.log("columnas",this.columnas);

    console.log(" obsevacion: ",this.observacion);
      console.log(" obsevacionguardar: ",this.observacionGuardar);
    if(this.observacion != this.observacionGuardar)
    await this.putObservacion(this.codigoEmpresa,this.codigoOficina,this.observacionGuardar).then((data: any) => {
      
      if (data.resCode != 0){
        this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de la observacion'});
        this.noError = false;
      }else{
        console.log("respuesta de guardar obsevacion: ",data.resData);
      }
    });

    for (let indiceFila = 0; indiceFila < this.filas; indiceFila++) {
      for (let indiceColumna = 0; indiceColumna < this.columnas; indiceColumna++) {
        if(indiceColumna !=0){
          actual = this.tablaMostrar[indiceFila][indiceColumna];

          //console.log("actual:",actual);

          if(actual.tabla == 'EME_RUTAS_EVACUACION' && actual.modificado){
            //actualizo por codigo la descripcion de la ruta de evacuacion
            if(this.noError){
              await this.putDescripcionRutaEvacuacion(actual.codigo,actual.valor).then((data: any) => {
                if (data.resCode != 0) {
                  this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de titulo de ruta'});
                  this.noError = false;
                  this.loading = false;
                }
              });
            }
          }

          if(actual.tabla == 'EME_RUTAS_NIVEL' && actual.modificado){
            //debo buscar codigo nivel y codigo ruta

            if(this.noError){
              console.log('BUSCANDO RUTA NIVEL CODIGO',actual.codigo);
              await this.getRutaNivelbyCode(actual.codigo).then((data: any) => {
                if (data.resCode == 0){
                  console.log('respuesta al buscar por codigo',data.resData);
                  codeNivel = data.resData[0].id.codigoNivel;
                  codeRuta  = data.resData[0].id.codigoRuta;
                } else {
                  this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de rutas nivel'});
                  this.noError = false;
                  this.loading = false;
                }
              });
            }
            //console.log('codeNivel,codeRuta',codeNivel+","+codeRuta);
            if(this.noError && codeNivel!=0 && codeRuta!=0){
              //console.log('actual.codigo,codeNivel,codeRuta,actual.valor',actual.codigo,codeNivel,codeRuta,actual.valor);
              await this.putValorRutasNivel(actual.codigo,codeNivel,codeRuta,actual.valor).then((data: any) => {
                if (data.resCode != 0) {
                  this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de rutas nivel'});
                  this.noError = false;
                  this.loading = false;
                }
              });
            }
            codeNivel = 0;
            codeRuta  = 0;

          }

        }

        /*
        console.log("indiceFila:",indiceFila);
        console.log("filas -1:",this.filas-1);
        console.log("indiceColumna :",indiceColumna);
        console.log("columnas -1:",this.columnas-1);

        if (indiceFila == this.filas-1 && this.noError && indiceColumna == this.columnas-1){
          
          this.loading = false;
          this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;
        }
        */

      }
    }

    
    
    
    this.loading = false;

    console.log("LLegue a seguir",Constantes.NAVIGATION_GO_NEXT);
    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;
    
  }

  getObservacion(codigoEmpresa:number,codigoOficina:number){
    return new Promise((resolve)=>{
      this._planEmergenciaService.obtenerPlanEmergencia(codigoEmpresa,codigoOficina).subscribe({
          next: (res:any)=>{
            if(res.pageContent[0].observacionesEvacuacion != undefined){
              this.observacion = res.pageContent[0].observacionesEvacuacion;
            }
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.obtenerPlanEmergencia';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    },
    );
  }

  putObservacion(codigoEmpresa:number,codigoOficina:number,observacion:string){
    return new Promise((resolve)=>{
      this._planEmergenciaService.putObservacionEvacuacion(codigoEmpresa,codigoOficina,this.usuario,observacion).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData:res };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.putObservacionEvacuacion';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    },
    );
  }

  getCantidadRutas(idOficina : number){
    return new Promise((resolve)=>{
      this._oficinaService.getOficinaById(idOficina).subscribe({
          next: (res:any)=>{
            if(res.pageContent[0].rutasEvacuacion != undefined){
              this.numeroDeRutasOficina = res.pageContent[0].rutasEvacuacion;
            }
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.obtenerPlanEmergencia';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    },
    );
  }

  getNivelesOficina(idOficina : number){
    return new Promise((resolve)=>{
      this._nivelOficinaService.getRequest(idOficina).subscribe({
          next: (res:any)=>{
            this.listNivelesOficina = res.pageContent;
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.obtenerPlanEmergencia';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    },
    );
  }

  getRutasNivel(idNivel : number){
    return new Promise((resolve)=>{
      this._rutasNivelService.getRequest(idNivel).subscribe({
          next: (res:any)=>{
            this.listRutasNivel = res.pageContent;
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.obtenerPlanEmergencia';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    },
    );
  }

  putDescripcionRutaEvacuacion(codigoRutaNivel : number , cantidad :number|string){
    return new Promise((resolve)=>{
      this._rutasEvacuacionService.putDescripcionByCodigo(codigoRutaNivel,cantidad,this.usuario).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.obtenerPlanEmergencia';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    },
    );
  }

  postRutaEvacuacion(){
    return new Promise((resolve)=>{
      this._rutasEvacuacionService.postMetodo('RUTA GENERICA',this.usuario).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, codigo: res.codigo};
            console.log('Prueba creacion: ',data);
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.obtenerPlanEmergencia';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    },
    );
  }

  postRutaNivel(codigoNivel:number,codigoRuta:number){
    return new Promise((resolve)=>{
      this._rutasNivelService.postRequest(codigoNivel,codigoRuta,this.usuario).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.obtenerPlanEmergencia';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    },
    );
  }


  putValorRutasNivel(codigoRutaNivel : number , codigoNivel : number, codigoRuta: number, cantidad :number|string){
    return new Promise((resolve)=>{
      this._rutasNivelService.putByCodigo(codigoRutaNivel,codigoNivel,codigoRuta,cantidad,this.usuario).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.obtenerPlanEmergencia';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    }
    );
  }

  getRutaNivelbyCode(codigoRutaNivel : number){
    return new Promise((resolve)=>{
      this._rutasNivelService.getRequestByCodigo(codigoRutaNivel).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData : res.pageContent };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.obtenerPlanEmergencia';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    }
    );
    
    
  }

  cambiarValorCeldad(evento:any){
    let identificacion : string = evento.target.id;
    let arreglo : string[] = identificacion.split("-");
    let fila    : number = +arreglo[0];
    let columna : number = +arreglo[1];
    
    this.tablaMostrar[fila][columna].modificado= true;
    this.tablaMostrar[fila][columna].valor = evento.target.value;
  }

  cambiarValorObservacion(evento:any){
    this.observacionGuardar = evento.target.value;
  }
  



}
