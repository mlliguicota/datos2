import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EvaluacionPrevencionComponent } from './evaluacion-prevencion.component';

describe('EvaluacionPrevencionComponent', () => {
  let component: EvaluacionPrevencionComponent;
  let fixture: ComponentFixture<EvaluacionPrevencionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EvaluacionPrevencionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EvaluacionPrevencionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
