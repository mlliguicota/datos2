import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { IEvaluacionCuantitativa, IEvaluacionCuantitativaGet, IEvaluacionTaxativa, IEvaluacionTaxativaGet } from '../../core/interfaces/evaluacionPrevencion.interface';
import { RequestPLanEmergencia } from '../../core/interfaces/planEmergencia.interface';
import { EvaluacionPrevencionService } from '../../core/services/evaluacion-prevencion.service';
import { NavigationService } from '../../core/services/navigation.service';
import { PlanEmergenciaService } from '../../core/services/plan-emergencia.service';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';

@Component({
  selector: 'app-evaluacion-prevencion',
  templateUrl: './evaluacion-prevencion.component.html',
  styleUrls: ['./evaluacion-prevencion.component.scss']
})
export class EvaluacionPrevencionComponent implements OnInit {

  constructor( private _evaluacionPrevencionService : EvaluacionPrevencionService ,
    private _planEmergencia : PlanEmergenciaService ,
    private _oficina: SharingOfficeService , 
    private toast: ToastService,
    private navigationService: NavigationService,
    private _authService : AuthService) {
      this.toastKey = this.toast.genToastKey();
      
     }

  otros_factores: string ;
  valor_p : string ;
  riesgo : string = ' riesgo muy leve';

  toastKey: any;
 
  planEmergencia : RequestPLanEmergencia;
  

  evaluacionCuantitativa : IEvaluacionCuantitativa []
  evaluacionTaxativa : IEvaluacionTaxativa []

     /// se deben setear al inicio
     codigoOficina : number = 0
     codigoEmpresa : number = 0 
     usuario : string = 'jonathan' ;
     loading :boolean = true ;

  async ngOnInit() {

    this.codigoOficina = this._oficina.currentOfficeData.id.codigo
    this.codigoEmpresa =  this._oficina.currentOfficeData.id.codigoEmpresa
    this.usuario =  this._authService.getUsuarioData().usuarioIngreso
    console.log("Usuario =>>>>>>>>>>>>>" + this.usuario)

    await  this.obtenerDatos()
  }


   async obtenerDatos() {
    this.loading = true
    await this._planEmergencia.obtenerPlan( this.codigoEmpresa ,this.codigoOficina ).then((data: any) => {
      if (data.resCode == 1) { // existe plan de Emergencia
         this.planEmergencia = this._planEmergencia.obtenerPlanEmergenciaRequest()
           console.log( this.planEmergencia)
         this.valor_p=  this.planEmergencia.pageContent[0].valorMeseri.toFixed(2)
         this.riesgo = this.planEmergencia.pageContent[0].categoriaMeseri
         this.otros_factores =this.planEmergencia.pageContent[0].otrosFactores
      

      } else {
        this.toast.mostrarToastError('Hubo un problema al cargar los datos' +
          ', por favor intentelo mas tarde', this.toastKey);
      }
    });

    await this.obtenerEvaluacionCuantitativa()
      .then((data: any) => {
        if (data.resCode == 0) {
           
           this.evaluacionCuantitativa.sort(
            (firstObject: IEvaluacionCuantitativa, secondObject: IEvaluacionCuantitativa) =>
              (firstObject.rangoInicio > secondObject.rangoInicio) ? 1 : -1
        )
         
        } else {
          this.toast.mostrarToastError('Hubo un problema al cargar los datos' +
            ', por favor intentelo mas tarde', this.toastKey);
        }
      });


      await this.obtenerEvaluacionTaxativa()
      .then((data: any) => {
        if (data.resCode == 0) {
           
           this.evaluacionTaxativa.sort(
            (firstObject: IEvaluacionTaxativa, secondObject: IEvaluacionTaxativa) =>
              (firstObject.rangoInicio > secondObject.rangoInicio) ? 1 : -1
        )
          
        } else {
          this.toast.mostrarToastError('Hubo un problema al cargar los datos' +
            ', por favor intentelo mas tarde', this.toastKey);
        }
      });

      this.loading = false

  }


   
  obtenerEvaluacionCuantitativa() {
    return new Promise((resolve)=>{
      this._evaluacionPrevencionService.obtenerEvaluacionCuantitativa().subscribe({
        next: (res: IEvaluacionCuantitativaGet)=>{
          if (res.totalItems > 0) {
            console.log('Obteniendo evaluaciacion Cuantitativas');
            console.log(res);
          this.evaluacionCuantitativa = res.pageContent;
            const data = { resCode: 0 };
            resolve(data);
          }
        },
        error: (err)=>{
          const e='Ocurrio un error inesperado obteniendo las oficinas';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    },
    );
  }


  
  obtenerEvaluacionTaxativa() {
    return new Promise((resolve)=>{
      this._evaluacionPrevencionService.obtenerEvaluacionTaxativa().subscribe({
        next: (res: IEvaluacionTaxativaGet)=>{
          if (res.totalItems > 0) {
            console.log('Obteniendo evaluaciacion Taxativa');
            console.log(res);
          this.evaluacionTaxativa = res.pageContent;
            const data = { resCode: 0 };
            resolve(data);
          }
        },
        error: (err)=>{
          const e='Ocurrio un error inesperado obteniendo las oficinas';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    },
    );
  }

  
  goPrevious() {
    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
  }

  async saveContinue() {
      this.loading= true
     await this.actualizarOtrosFactores()
     this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;   
     this.toast.mostrarToastSuccess('Los datos han sido cargados'+
     ' correctamente!!', this.toastKey);  
      this.loading=false
  }
  



  actualizarOtrosFactores(){
    return new Promise((resolve)=> {
      this._evaluacionPrevencionService.actualizarPlanEmergencia(
        {
          nombreEquipo : 'PRUEBA' , //
          usuarioModificacion : this.usuario , // usuario
          otrosFactores : this.otros_factores ,
          id : {
           codigoEmpresa : this.codigoEmpresa,
          codigoOficina : this.codigoOficina
         } 
        }

      ).subscribe( datos =>  { 
        console.log(datos)
        const data = { resCode: 0 };
        resolve(data);
      } ,   (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al actualizar otros factores';
        const dataErr = { resCode: -1, error: e };
        console.log(e)
        resolve(dataErr);
      })  
    
    })
   }



}
