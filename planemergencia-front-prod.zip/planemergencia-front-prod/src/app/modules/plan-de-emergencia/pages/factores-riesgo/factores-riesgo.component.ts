import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { FactoresRiesgoService } from '../../core/services/factores-riesgo.service';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthService } from 'src/app/core/services/auth.service';
import { ToastService } from 'src/app/core/services/toast.service';
import Constantes from '../../core/util/constantes';
import { NavigationService } from '../../core/services/navigation.service';
import { NivelesOficinaService } from '../../core/services/niveles-oficina.service';
import { InivelOficina } from '../../core/interfaces/nivelOficina.interface';
import { IEquipo } from '../../core/interfaces/equipos.interfaces';
import { IEquipoOficina, IEquipoOficinaPost, IEquipoOficinaPut } from '../../core/interfaces/equiposOficinas.interface';
import { timeStamp } from 'console';
import { PlanEmergenciaService } from '../../core/services/plan-emergencia.service';






@Component({
  selector: 'app-factores-riesgo',
  templateUrl: './factores-riesgo.component.html',
  styleUrls: ['./factores-riesgo.component.scss']
})
export class FactoresRiesgoComponent implements OnInit {


 /*Areas Oficinas*/
  //Descripcion del area de oficinas
  configuracion : string ="";
  accesos_exteriores : string ="";
  ayuda_exterior : string ="";
 // Varios
 tipo_materiales_almacenados : string ="";
 desechos_generados : string ="";
 materiales_peligrosos  : string ="";
/* Fin de Areas Oficcinas */



/* Caracteristicas Edificios */
        // Caracteristicas contructivas del edificio / Dimensiones del edificio
        superficieTotalConstruida : string ="";
        pisos_ocupados : string ="";   
        plantasSobreRasantes : string ="";
        superficie_ocupada : string ="";  
        plantas_bajo_rasantes : string ="";
        altura  : string =""; 

          // carasteristicas contructivas del edificio / Elementos estructurales
        pilares  : string ="";
        cerramientos_exteriores : string ="";
        vigas : string ="";
        cerramientos_interiores : string ="";

/* Caracteristicas Edificios */


  //Equipos e instalaciones
  instalacion_electrica : string ="";
  liquidos_inflamables : string ="";
  ventilacion : string ="";
  calderas : string ="";
  calefaccion : string ="";
  aire_comprimido : string ="";
  almacenamiento_gases : string ="";
  otros : string ="";

  id_instalacion_electrica : number ;
  id_liquidos_inflamables : number;
  id_ventilacion : number;
  id_calderas : number;
  id_calefaccion : number;
  id_aire_comprimido : number;
  id_almacenamiento_gases : number;
  id_otros : number;

 



   
  existenArea : boolean = false;
  existeCaracteristica : boolean = false ;
  lb_existePlanEmergencia : boolean;

   /// se deben setear al inicio
   codigoOficina : number = 0
   codigoEmpresa : number = 0 ;
   usuario : string = 'jonathan' ;
   loading : boolean = true;
   toastKey: any;
   cantidad_lineas :number = 0

   lista_niveles : Array<InivelOficina> = new Array<InivelOficina> ();
  listaEquipos :Array<IEquipo> = new Array<IEquipo>()
  listaEquiposOficinas :Array<IEquipoOficina> = new Array<IEquipoOficina>()
  listaPost : Array<IEquipoOficinaPost> = new Array<IEquipoOficinaPost>()
  listaPut : Array<IEquipoOficinaPut> = new Array<IEquipoOficinaPut>()


  constructor(private location:Location ,
    private route:Router ,
    private _factoresRiesgoService : FactoresRiesgoService ,
    private _oficina: SharingOfficeService ,
    private toast: ToastService,
    private navigationService: NavigationService,
    private _authService : AuthService , 
    private _niveleOficina : NivelesOficinaService,    
    private _PlanEmergenciaService : PlanEmergenciaService  ,

     ) { 

      this.toastKey = this.toast.genToastKey();

     }

  ngOnInit(): void {
   this.loading = true;
    this.codigoOficina = this._oficina.currentOfficeData.id.codigo
    this.codigoEmpresa =  this._oficina.currentOfficeData.id.codigoEmpresa
    this.usuario =  this._authService.getUsuarioData().usuarioIngreso
    console.log("Usuario =>>>>>>>>>>>>>" + this.usuario)
   
    this.inicializar();

  }

  async inicializar(){

    await this.VerificarPlanEmergencia()

     this._niveleOficina.obtenerNiveles(this.codigoEmpresa , this.codigoOficina)

    let response : any = await this._factoresRiesgoService.obtenerEquipos().toPromise() 
    this.listaEquipos =response.pageContent

    let response2 :any = await this._factoresRiesgoService.obtenerEquiposOficinas(this.codigoOficina ,this.codigoEmpresa).toPromise()
    this.listaEquiposOficinas = response2.pageContent
   console.log( "Equipos Oficinas "+this.listaEquiposOficinas)
    this.LlenarEquiposOficina()
  
    this.cantidad_lineas = 0
   await  this.obtenerAreaOficinas()
   await  this.obtenerCaracteristicas()
   this.lista_niveles = this._niveleOficina.obtenerListaNiveles()
   this.pisos_ocupados = this._niveleOficina.obtenerPisos().toString();
   this.lista_niveles.forEach(valor => {
    this.cantidad_lineas  =   this.cantidad_lineas  +1
    this.superficie_ocupada =  this.superficie_ocupada + "Area de " + valor.descripcion + " : " + valor.areaUtil + " M2 \n"
    
   })




    this.loading =false;

  }

 llenaEquiposOficinaPost(){   
    

  this.listaEquipos.forEach(equipo => {
    let detalle : string = this.obtieneValorEquipo(equipo.codigo)
    this.listaPost.push({
      detalle : detalle ,
      estado  : "A",
      nombreEquipo : "PRUEBA",
      usuarioIngreso : this.usuario ,
     id : {
         codigoEmpresa : this.codigoEmpresa ,
         codigoEquipo : equipo.codigo ,
         codigoOficina :this.codigoOficina 
       }
    }) 


  })
  

    console.log('Lista Post')
    console.log(this.listaPost)

 }


obtieneValorEquipo(codigoEquipo : number) :string {
  let valor : string = ""
  switch (codigoEquipo) {
    case 1: //Instalación Eléctrica
    valor =  this.instalacion_electrica
        break;
    case 2: // Ventilación
    valor =  this.ventilacion 
        break;
    case 3: //Calefacción
    valor =  this.calefaccion 
        break;
    case 4: //Almacenamiento de gases
    valor =  this.almacenamiento_gases 
        break;
    case 5: //Almacenamiento de líquidos inflamables
    valor =  this.liquidos_inflamables 
        break;
    case 6: //Calderas
    valor =  this.calderas
        break;
    case 7: //Aire comprimido
    valor =  this.aire_comprimido 
        break;
  
            break;
    case 8: //OTros
    valor =  this.otros  
           break;
    default:
        console.log("No existe equipo mapeado");
        break;
  }   

  return valor

}

 

 llenaEquiposOficinaPut(){   
    
   this.listaEquiposOficinas.forEach(equipo => {
    console.log(equipo)
    let detalle : string = this.obtieneValorEquipo(equipo.id.codigoEquipo)
    this.listaPut.push({
      detalle : detalle,    
      nombreEquipo : "PRUEBA",
      usuarioModificacion:  this.usuario ,
     id : {
       codigo : equipo.id.codigo ,
         codigoEmpresa : this.codigoEmpresa ,
         codigoEquipo : equipo.id.codigoEquipo ,
         codigoOficina :this.codigoOficina 
       }
    }) 

   })

   console.log('Lista Put')
   console.log(this.listaPut)

 }



 LlenarEquiposOficina()
 {
 
   this.listaEquiposOficinas.forEach(equipos =>  {
     console.log(equipos)
     switch (equipos.id.codigoEquipo) {
       case 1: //Instalación Eléctrica
       this.instalacion_electrica = equipos.detalle 
  
           break;
       case 2: // Ventilación
       this.ventilacion = equipos.detalle

           break;
       case 3: //Calefacción
       this.calefaccion = equipos.detalle
   
           break;
       case 4: //Almacenamiento de gases
     this.almacenamiento_gases =equipos.detalle

           break;
       case 5: //Almacenamiento de líquidos inflamables
       this.liquidos_inflamables = equipos.detalle

           break;
       case 6: //Calderas
       this.calderas = equipos.detalle

           break;
       case 7: //Aire comprimido
       this.aire_comprimido = equipos.detalle

           break;
     
               break;
       case 8: //OTros
       this.otros = equipos.detalle  
 
              break;
       default:
           console.log("No existe equipo mapeado");
           break;
     }            
   })
  
 }




  SeteaEquiposOficina()
{

      if (this.instalacion_electrica=="") {
        this.instalacion_electrica ="N/A"
      }
         
      if (this.ventilacion=="") {
        this.ventilacion ="N/A"
      }
         
      if (this.calefaccion=="") {
        this.calefaccion ="N/A"
      }
        
    if (this.almacenamiento_gases=="") {
      this.almacenamiento_gases ="N/A"
    }
       
      if (this.liquidos_inflamables=="") {
        this.liquidos_inflamables ="N/A"
      }
    
      if (this.calderas=="") {
        this.calderas ="N/A"
      }
    
      if (this.aire_comprimido=="") {
        this.aire_comprimido ="N/A"
      }
      
      if (this.otros=="") {
        this.otros ="N/A"
      }   
         
 
}

  obtenerAreaOficinas() {

 return new Promise((resolve) => {  
      this._factoresRiesgoService.ObtenerAreasOficinas(this.codigoOficina ,this.codigoEmpresa).subscribe(
        datos => {
          if (datos.totalItems == 0) {                 
                 console.log('No existe areasOficinasConfiguradas')
                 this.existenArea = false;            
              } else {
                this.existenArea = true;
               console.log('Existe areas Oficinas Configuradas')
               console.log(datos)
               this.configuracion = datos.pageContent[0].configuracion ;
               this.accesos_exteriores = datos.pageContent[0].accesos;
               this.ayuda_exterior = datos.pageContent[0].ayudaExterior;
               this.tipo_materiales_almacenados = datos.pageContent[0].materialesAlmacenados ;
               this.desechos_generados = datos.pageContent[0].desechosGenerados;
               this.materiales_peligrosos  = datos.pageContent[0].materialesPeligrosos;

             } 

             const dataRes = { resCode: 0 };
             resolve(dataRes);

        } ,
        (err: HttpErrorResponse) => {
          const e='Ocurrio un error inesperado obteniendo el area de oficina';
          const dataErr = { resCode: -1, error: e };
         resolve(dataErr);
          console.log('Error' )        
       }  

    )

    })  
     
  }


  obtenerCaracteristicas() {

    return new Promise((resolve) => { 
      this._factoresRiesgoService.obtenerCaracteristicasEdificio(this.codigoOficina ,this.codigoEmpresa).subscribe(
        datos => {
          if (datos.totalItems == 0) {         
            // this.messageService.add({severity:'error', summary: 'Error', detail: 'No se encontró la plantilla para antecendente'});
                 console.log('No existe Carateristicas')
                 this.existeCaracteristica = false;
            
              } else {
                 this.existeCaracteristica = true ;

               console.log('Existen caracteristicas')
               console.log(datos)


               this.superficieTotalConstruida =datos.pageContent[0].superficieTotal;
            //   this.pisos_ocupados = '9';  // preguntar de donde se llena
               this.plantasSobreRasantes =  datos.pageContent[0].plantasSobre.toString();
             //  this.superficie_ocupada =  '' // se debe de llenar de algun lado del  archivo
               this.plantas_bajo_rasantes = datos.pageContent[0].plantasBajo.toString();
               this.altura  = datos.pageContent[0].altura.toString();

               this.pilares  = datos.pageContent[0].pilares;
               this.cerramientos_exteriores = datos.pageContent[0].cerramientosExt;
               this.vigas = datos.pageContent[0].vigas;
               this.cerramientos_interiores  =  datos.pageContent[0].cerramientosInt;
             } 
            
             const dataRes = { resCode: 0 };
             resolve(dataRes);
        } ,
        (err: HttpErrorResponse) => {
          const e='Ocurrio un error inesperado obteniendo las Caracteristicas de la oficina';
          const dataErr = { resCode: -1, error: e };
         resolve(dataErr);
          console.log('Error' )        
       }  

    )
     })
   
}


async saveContinue(){
  // se guarda

  this.loading =true;

  if (!this.lb_existePlanEmergencia) { // No existe el plan de Emergencia

    await this._factoresRiesgoService.registrarPlanEmergencia({
      id : {
        codigoEmpresa : this.codigoEmpresa,
       codigoOficina : this.codigoOficina
      } ,
      estado : 'A' ,
      nombreEquipo : 'PRUEBA' ,
      usuarioIngreso : this.usuario ,
      aprobador : 'Por definir' ,
      cargoElaborador : 'Por definir' ,
      elaborador : this.usuario  ,
      cargoAprobador : 'Por definir',
      otrosFactores : 'Por definir'
    } 
      ).toPromise()
  }


  if(this.existenArea) {
    console.log('Put a Area de oficina') 
   await  this.actualizarAreaOficina()  
   }else {  // realizar Post

    await   this.registrarAreaOficina()
     console.log('Post a Areas de Oficinas') 
  }


  
if(this.existeCaracteristica) {
  console.log('Put a Caracteristicas')
  
  await  this.actualizarCaracteristicas()
 
 
 }else {  // realizar Post
  await this.registrarCaracteristicas();
 console.log('Post a Caracteristicas')
 
 
 
 }

 this.SeteaEquiposOficina()
 
 console.log("Lista Equipos Oficinas " + this.listaEquiposOficinas + "tamaño" + this.listaEquiposOficinas.length)
 if (this.listaEquiposOficinas.length > 0){ // Existe hacer Put
  this.llenaEquiposOficinaPut()
 let response : any = this._factoresRiesgoService.actualizarEquiposOficinas(this.listaPut).toPromise()

 }else { // hacer post
  this.llenaEquiposOficinaPost()
  let response : any = this._factoresRiesgoService.registrarEquiposOficinas(this.listaPost).toPromise()


 }



 this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;   
 this.toast.mostrarToastSuccess('Los datos han sido cargados'+
 ' correctamente!!', this.toastKey);  

   this.loading = false


 //  this.route.navigateByUrl('/principal/hazards/metodoMeseri');

}

 
VerificarPlanEmergencia () {
  return new Promise((resolve)=> {
    this._PlanEmergenciaService.obtenerPlanEmergencia(this.codigoEmpresa , this.codigoOficina).subscribe(
      
      datos => {
        if(datos.totalItems==0){
              console.log('No existe Plan de Emergencia Cofigurado')
              this.lb_existePlanEmergencia = false
        }else {
            this.lb_existePlanEmergencia = true
          console.log('Existe Plan de Emergencia Configurado')
          console.log(datos)

        }
        const dataRes = { resCode: 0 };
        resolve(dataRes);

      },     (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al obtener los datos Messeri plan de emergencia';
        const dataErr = { resCode: -1, error: e };
        console.log(e)
        resolve(dataErr);
        
   
      }
     )


  }
  
  
  
  )

}


setearAreasOficinas(){

  if (this.accesos_exteriores =="") {
    this.accesos_exteriores ="N/A"
  }

  if (this.ayuda_exterior  =="") {
    this.ayuda_exterior  ="N/A"
  }

  if (this.configuracion  =="") {
    this.configuracion  ="N/A"
  }

  if (this.desechos_generados  =="") {
    this.desechos_generados  ="N/A"
  }
  if (this.tipo_materiales_almacenados  =="") {
    this.tipo_materiales_almacenados  ="N/A"
  }
  if (this.materiales_peligrosos  =="") {
    this.materiales_peligrosos  ="N/A"
  }


}

registrarAreaOficina(){

  this.setearAreasOficinas()
  return new Promise((resolve) => {
    this._factoresRiesgoService.registrarAreasOficinas( { 
      estado :  'A' ,
      nombreEquipo : 'PRUEBA'    ,
      usuarioIngreso : this.usuario  ,
      accesos  : this.accesos_exteriores ,
      ayudaExterior :  this.ayuda_exterior ,
      configuracion : this.configuracion ,
      desechosGenerados : this.desechos_generados ,
      materialesAlmacenados : this.tipo_materiales_almacenados ,
      materialesPeligrosos :   this.materiales_peligrosos ,
      id : {
         codigoEmpresa : this.codigoEmpresa ,
         codigoOficina : this.codigoOficina
      }  }  ).subscribe( datos =>  {
        console.log(datos )  
        const dataRes = { resCode: 0 };
        resolve(dataRes)
      } ,
        (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al Registrar Areas de Oficinas';
        const dataErr = { resCode: -1, error: e };
        console.log(e)
        resolve(dataErr); 
      
      } 
      
      )   ;

   })

}


actualizarAreaOficina(){
     
  return new Promise((resolve) => { 
     
    this._factoresRiesgoService.actualizarAreasOficinas( { 
      accesos  : this.accesos_exteriores ,
      ayudaExterior :  this.ayuda_exterior ,
      configuracion : this.configuracion ,
      desechosGenerados : this.desechos_generados ,
      materialesAlmacenados : this.tipo_materiales_almacenados ,
      materialesPeligrosos :   this.materiales_peligrosos ,
      nombreEquipo : 'PRUEBA' ,
      usuarioModificacion : this.usuario ,
      id : {
         codigoEmpresa : this.codigoEmpresa ,
         codigoOficina : this.codigoOficina
      }
       
     }).subscribe( datos => {console.log(datos ) 
      const dataRes = { resCode: 0 };
      resolve(dataRes);

    } ,  (err: HttpErrorResponse) => {
      const e='Ocurrio un error inesperado al Actualizar Areas de Oficinas';
      const dataErr = { resCode: -1, error: e };
      console.log(e)
      resolve(dataErr); 
    
    }  )  ;

  })

} 


actualizarCaracteristicas(){
  return new Promise((resolve) => { 
    this._factoresRiesgoService.actualizarCaracteristicasEdificio( { 
      altura :  Number(this.altura)  ,
      cerramientosExt : this.cerramientos_exteriores ,
      cerramientosInt : this.cerramientos_interiores ,
      pilares :  this.pilares  ,
      plantasBajo :  Number(this.plantas_bajo_rasantes) ,
      plantasSobre :   Number(this.plantasSobreRasantes)  ,
      superficieTotal :  this.superficieTotalConstruida ,
      vigas  : this.vigas  ,
      id : {
         codigoEmpresa : this.codigoEmpresa ,
         codigoOficina : this.codigoOficina
      } ,
      nombreEquipo : 'PRUEBA'   ,
      usuarioModificacion : this.usuario 
       
     }).subscribe( datos => { console.log(datos )
      const dataRes = { resCode: 0 };
      resolve(dataRes);
    }  ,  (err: HttpErrorResponse) => {
      const e='Ocurrio un error inesperado al Actualizar Caracteristicas  de Oficinas';
      const dataErr = { resCode: -1, error: e };
      console.log(e)
      resolve(dataErr); 
    
    } 
    )  ;

    
  }  
  )

}



setearCaracteristicasOficinas(){

  if (this.cerramientos_exteriores =="") {
    this.cerramientos_exteriores ="N/A"
  }

  if (this.cerramientos_interiores  =="") {
    this.cerramientos_interiores  ="N/A"
  }

  if (this.pilares  =="") {
    this.pilares  ="N/A"
  }

  if (this.superficieTotalConstruida  =="") {
    this.superficieTotalConstruida  ="N/A"
  }

  if (this.vigas  =="") {
    this.vigas  ="N/A"
  }


}

registrarCaracteristicas(){
  this.setearCaracteristicasOficinas()
  return new Promise((resolve) => { 
    this._factoresRiesgoService.registrarCaracteristicasEdificio( { 
      usuarioIngreso : this.usuario  ,
      estado :  'A' ,
    nombreEquipo : 'PRUEBA'    ,
    altura :  Number(this.altura)  ,
    cerramientosExt : this.cerramientos_exteriores ,
    cerramientosInt : this.cerramientos_interiores ,
    pilares :  this.pilares  ,
    plantasBajo :  Number(this.plantas_bajo_rasantes) ,
    plantasSobre :   Number(this.plantasSobreRasantes)  ,
    superficieTotal :  this.superficieTotalConstruida ,
    vigas  : this.vigas  ,
    id : {
       codigoEmpresa : this.codigoEmpresa ,
       codigoOficina : this.codigoOficina
    } 
      
     }  ).subscribe( datos =>    {
      console.log(datos )
      const dataRes = { resCode: 0 };
      resolve(dataRes);
     } ,
        (err: HttpErrorResponse) => {
      const e='Ocurrio un error inesperado al Registrar Caracteristicas  de Oficinas';
      const dataErr = { resCode: -1, error: e };
      console.log(e)
      resolve(dataErr);    
    }  )  ; 

  })
 

}


goPrevious() {
  this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
}



}
