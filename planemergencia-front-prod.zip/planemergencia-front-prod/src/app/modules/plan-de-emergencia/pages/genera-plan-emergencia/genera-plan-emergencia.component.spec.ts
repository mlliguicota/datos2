import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GeneraPlanEmergenciaComponent } from './genera-plan-emergencia.component';

describe('GeneraPlanEmergenciaComponent', () => {
  let component: GeneraPlanEmergenciaComponent;
  let fixture: ComponentFixture<GeneraPlanEmergenciaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GeneraPlanEmergenciaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GeneraPlanEmergenciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
