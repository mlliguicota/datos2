import { Component, OnInit } from '@angular/core';

import Constantes from '../../core/util/constantes';
import { asBlob } from 'html-docx-js-typescript';
import { saveAs } from 'file-saver';
import {text } from '../../core/util/planEmergencia';
import {info_general_empresa , contacto_emergencia ,descripcion_area_oficina , 
 equipos_instalaciones , caracteristicas_edificio ,sistema_emergencia ,
 instituciones_emergencia , cantidad_poblacion} from '../../core/util/tablas';
 import {deteccion , alarmas , sistema_s ,actuar_emergencia  , formula, alarma2} from '../../core/util/imagenes'
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { NavigationService } from '../../core/services/navigation.service';
import { PlSeccionService } from '../../core/services/seccion-service.service';
import { SeccionDocumentos } from '../../core/interfaces/seccion.interface';
import { HttpErrorResponse } from '@angular/common/http';
import { AdminVariosService } from '../../core/services/admin-varios.service';
import { ContactoEmergenciaContent, ContactoOficinaContent ,InstitucionEmergenciaContent } from '../../core/interfaces/adminVarios.interface';
import { RiesgosService } from '../../core/services/riesgos.service';
import { Iriesgo, IriesgoOficina } from '../../core/interfaces/seleccionRiesgo.interface';
import { NivelesOficinaService } from '../../core/services/niveles-oficina.service';
import { InivelOficina, InivelOficinaGet } from '../../core/interfaces/nivelOficina.interface';
import { MesseriService } from '../../core/services/messeri.service';
import { IMeseri, Meseri } from '../../core/interfaces/messeri.interface';
import { PlanEmergenciaService } from '../../core/services/plan-emergencia.service';
import { IplanEmergencia } from '../../core/interfaces/planEmergencia.interface';
import { FactoresRiesgoService } from '../../core/services/factores-riesgo.service';
import { IEquipo } from '../../core/interfaces/equipos.interfaces';
import { IEquipoOficina } from '../../core/interfaces/equiposOficinas.interface';
import { SeccionesService } from '../../core/services/secciones.service';
import { DescripcionEmpresaService } from '../../core/services/descripcion-empresa.service';
import { EvaluacionPrevencionService } from '../../core/services/evaluacion-prevencion.service';
import { RecursoNivelService } from '../../core/services/recurso-nivel.service';
import { RecursosExistentesService } from '../../core/services/recursos-existentes.service';
import { IRecursos } from '../../core/interfaces/recursosExistentes.interface';
import { recursoNivel } from '../../core/interfaces/recursoNivel.interface';
import { RutaEvacuacionService } from '../../core/services/ruta-evacuacion.service';
import { IrutasEvacuacion, nivel } from '../../core/interfaces/rutasEvacuacion.interface';
import { ArchivosoficinasService } from '../../core/services/archivosoficinas.service';
import { IArchivo, IDocumento } from '../../core/interfaces/descargarArchivo.interface';
import { MantenimientosService } from '../../core/services/mantenimientos.service';
import { Imantenimiento, ImantenimientosOficinas } from '../../core/interfaces/seleccionMantenimiento.interface';
import { ContactoEmergenciaService } from 'src/app/modules/admin/core/services/Contacto-Emergencia.service';
import { forkJoin, of, interval, firstValueFrom } from 'rxjs';


@Component({
  selector: 'app-genera-plan-emergencia',
  templateUrl: './genera-plan-emergencia.component.html',
  styleUrls: ['./genera-plan-emergencia.component.scss']
})
export class GeneraPlanEmergenciaComponent implements OnInit {


  lista_Secciones: SeccionDocumentos[] = new Array<SeccionDocumentos>();
  lista_Titulos1: SeccionDocumentos[] = new Array<SeccionDocumentos>();
  lista_Titulos2: SeccionDocumentos[] = new Array<SeccionDocumentos>();
  lista_Subtitulo3: SeccionDocumentos[] = new Array<SeccionDocumentos>();
  toastKey: any;

  contenido :string;
  documento : string;

// Variables info general Empresa
  tabla_infor_general :string="";
  razon_social_empresa :string ="";
  edificacion :string ="";
  ciudad :string="";
  provincia :string="";
  direccion :string="";
  telefono :string="";
  fax :string="";
  correo :string="";
  actividad :string="";
  procesos :string="";
  oficina : string=""


  // Variables contacto de Emergencia
  tabla_contactos_Emergencia :string= "";
  tabla_contactos_Emergencia_det :string= "";
  listContactosEmergencia   : ContactoEmergenciaContent [] = [];
  listContactosEmergencia2   : ContactoEmergenciaContent [] = [];
  listContactosOficina      : ContactoOficinaContent [] = [];


  // descripcion Area d Emergencia
  tabla_area_oficina :string =""
  configuracion :string ="Conato de Emergencia: situación de emergencia controlable con los recursos existentes en CONECEL. Organismos de Emergencia (OE): entidades que presten ayuda externa en situaciones de emergencia y que están especialmente entrenados para aquello. Se consideran aquí a Bomberos, Policía Nacional, Defensa Civil, Cruz Roja, entre los principales. ";
  accesos_exteriores : string="";
  ayuda_exterior : string ="";
  tipos_materiales : string = ""
  desechos : string = ""
  materiales_peligrosos :string = "";

  // caracteristicas edificio
  
  tabla_caracteristica_edificio :string =""
  superficieTotalConstruida :string =""
  plantasSobrerazantes :string =""
  plantasBajoRazantes :string =""
  numeroPisosOcupados :string =""
  superficieOcupada :string =""
  altura :string =""
  pilares :string =""
  vigas :string =""
  cerramientos_exteriores :string = ""
  cerramientos_interiores :string = ""

  // equipos Instalaciones
  tabla_equipos_instalaciones :string = ""
  tabla_equipos_instalaciones_det : string = "";
  ventilacion : string = "";
  instalacion_electrica : string = "";
  calefacccion : string = "";
  almacenamiento_gases : string = "";
  alamacenamiento_liquidos : string = "";
  calderas : string = "";
  aire_comprimido : string = "";
  otros : string = "";


  /// se deben setear al inicio
  codigoOficina : number = 0
  codigoEmpresa : number = 0 ;
  usuario : string = 'prueba' ;
 loading : boolean = true;
 loadingAlcance  : boolean = true;
 loadingAntecedente  : boolean = true;

 // InstitucionesEmergencia

 tabla_instituciones_emergencia : string = "";
 tabla_instituciones_emergencia_det : string = "";
 listContactosInstituciones  : InstitucionEmergenciaContent [] = [];
 
// Riesgos
lista_riesgos_response: Iriesgo[] =  new Array<Iriesgo>() ;
lista_riesgos_oficinas : IriesgoOficina[] = new Array<IriesgoOficina>();
lista_riesgos : Iriesgo[] =  new Array<Iriesgo>() ;
detalleRiesgo : string = "" ;

// Mantenimiento 
lista_mantenimientos_response: Imantenimiento[] =new Array<Imantenimiento>();
lista_mantenimientos: Imantenimiento[] =new Array<Imantenimiento>();
lista_mantenimientos_oficinas : ImantenimientosOficinas[] =new Array<ImantenimientosOficinas>();

// info inveles Oficionas
lista_niveles_oficinas : InivelOficina[] = new Array<InivelOficina>();
total_mujeres : number 
total_hombre : number
area_total : number
total_trabajador : number 
porcentaje_mujeres : number 
porcentaje_hombres : number 
total_trabajadores_final : number
total_visitantes : number
total_suplementarios : number 
tabla_poblacion :string
tabla_poblacion_det :string 


// Equipos Oficinas
listaEquipos :Array<IEquipo> = new Array<IEquipo>()
listaEquiposOficinas :Array<IEquipoOficina> = new Array<IEquipoOficina>()

// Niveles Oficinas
 lista_niveles : Array<InivelOficina> = new Array<InivelOficina> ();
 observacion : string

// Alcance , Antecedentes
alcance : string
antecedente : string


// info Mssseri
lista_planEmergencia : IplanEmergencia[] = new Array<IplanEmergencia>()
elaborador :string 
cargo_elaborador :string
evaluacionTaxativa : number

//Recursos Existentes 

lista_recursos : IRecursos[] = new Array<IRecursos>()
listaRecursoNivel: recursoNivel[] = new Array<recursoNivel>()
listaRecursosExistentes : any[] = new Array<any>()
listaTotalRecuroNivel :  recursoNivel[] = new Array<recursoNivel>()

// imagenes
 Im_portada :any ;
 Im_geolocalizacion :any;
 localizacion : any
 lista_archivo_planes : IArchivo[] = new Array<IArchivo>()

 // rutas evacuacion   
  lista_rutasEvacuacion : IrutasEvacuacion[] = new Array<IrutasEvacuacion>()
  lista_Evacuacion : any[] = new Array<any>()
  lista_rutaEvacuacionNivel : nivel[] = new Array<nivel>()



  constructor(   private _oficina: SharingOfficeService ,
    private _authService : AuthService ,
    private toast: ToastService,
    private _PlSeccionService : PlSeccionService,
    private navigationService: NavigationService,
    private _adminVariosService :AdminVariosService ,
    private _riesgoService : RiesgosService  , 
    private _nivelesOficiona : NivelesOficinaService ,
    private _planEmergenciaService  :PlanEmergenciaService ,
    private _factoresRiesgoService : FactoresRiesgoService ,
    private _niveleOficina : NivelesOficinaService ,
    private _seccionesService : SeccionesService ,
    private  _descripcionEmpresaService :DescripcionEmpresaService ,
    private _evaluacionPrevencionService  : EvaluacionPrevencionService,
    private _recursoNivelService : RecursoNivelService  ,
    private _recursosExistenteService : RecursosExistentesService ,
    private _rutaEvacuacionService :RutaEvacuacionService ,
    private _archivosoficinasService :ArchivosoficinasService,
    private _mantenimientoService :  MantenimientosService ,
    private _ContactoEmergenciaService : ContactoEmergenciaService
    ) { }

  ngOnInit(): void {
         
       // obtengo la plantilla  antecedente
       //this.loading = true;    
       this.usuario =  this._authService.getUsuarioData().usuarioIngreso
       console.log("Usuario =>>>>>>>>>>>>>" + this.usuario)
       this.codigoOficina = this._oficina.currentOfficeData.id.codigo
       this.codigoEmpresa =  this._oficina.currentOfficeData.id.codigoEmpresa
       this.oficina =  this._oficina.currentOfficeData.nombreOficina


     
       this.razon_social_empresa = this._oficina.currentOfficeData.razonSocial ;
       this.edificacion  = this._oficina.currentOfficeData.edificacionOficina;
       this.ciudad = this._oficina.currentOfficeData.ciudadOficina;
       this.provincia = this._oficina.currentOfficeData.provinciaOficina;
       this.direccion =  this._oficina.currentOfficeData.direccionOficina ;
       this.telefono =  this._oficina.currentOfficeData.telefono ;
       this.fax =  this._oficina.currentOfficeData.fax ;
       this.correo =  this._oficina.currentOfficeData.correo ;
       this.actividad  =  this._oficina.currentOfficeData.actividadEmpresa ;
       this.procesos  =  this._oficina.currentOfficeData.procesosOficina ;

     /*  this.codigoOficina = 1
       this.codigoEmpresa = 1*/
       this.loading  = false
  }


  ObtenerTitulos(){

    return new Promise((resolve)=> {

      this._PlSeccionService.getSecciones().subscribe(  data  => {
        console.log('Ingrese a exitoso' + data.numberOfPages)
         
         this.lista_Secciones = data.pageContent;  
         console.log( this.lista_Secciones )
        this.lista_Secciones.forEach( (seccion) => {
            
           if (seccion.identificadorCampo=='TITULO' &&  seccion.nivel ==1 ) {
            console.log ('TITULO 1') 
            this.lista_Titulos1.push(seccion);
            console.log(seccion)

           }

           if (seccion.identificadorCampo=='TITULO' &&  seccion.nivel ==2 ) {
            console.log ('TITULO 2') 
            this.lista_Titulos2.push(seccion);
            console.log(seccion)

           }

           if (seccion.identificadorCampo=='SUBTITULO' &&  seccion.nivel == 3 ) {
            console.log ('SUBTITULO 3') 
            this.lista_Subtitulo3.push(seccion);
            console.log(seccion.titulo  +  seccion.texto)

           }

                

      })
   
     // console.log( this.lista_riesgos )
      const dataRes = { resCode: 0 };
      resolve(dataRes);

      } ,
      (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al obtener los riesgos';
        const dataErr = { resCode: -1, error: e };
        console.log(e)
        resolve(dataErr);
        
   
      }

    )


    })


  }


 async generarDocumento(){
  this.loading = true

  /// Obtiene titulos y subtitulos 
  console.log('prueba')
  const data : any  =  await this.ObtenerTitulos()
  if (data.resCode == -1) { //  huno errores
    this.toast.mostrarToastError('Hubo un problema al cargar los datos de plantilla de alcance' +
    ', por favor intentelo mas tarde', this.toastKey);
     console.log(data.error)
     return
  }

/* revisar este tramo de codigo que hace referencia */

 // Obtener contacto de Emergencia
 /*
 this.listContactosEmergencia =[];
 this.listContactosEmergencia2 =[];
 const responseContactosOficina = await this._adminVariosService.getContactosOficina(this.codigoOficina).toPromise();
 console.log(responseContactosOficina)
 this.listContactosOficina = responseContactosOficina.pageContent;
let responseContactoEmergencia = await this._adminVariosService.getContactoEmergencia().toPromise();
//let responseContactoEmergencia = await this._ContactoEmergenciaService.getContactoEmergenciaAll().toPromise();
this.listContactosEmergencia = responseContactoEmergencia.pageContent;
console.log('Lista de contactos 2', this.listContactosEmergencia)
this.listContactosOficina.forEach(contacto => {
  console.log('Ejemplo de contacto 3de oficina:', this.listContactosOficina[0]);

    this.listContactosEmergencia.forEach(contacEmergencia=> {
        if (contacto.id.codigoContacto == contacEmergencia.codigo){
          this.listContactosEmergencia2.push(contacEmergencia);

          console.log('contactos_emergencia'+ contacEmergencia)
        }
    })
})
*/
/*CORRECCION DE GUARDADO EN EL WORD DE LOS CONTACTOS DE OFICINA - BCALVOPIÑA - 17/01/2024 */
/*
this.listContactosEmergencia2 = [];
const responseContactosOficina = await this._adminVariosService.getContactosOficina(this.codigoOficina).toPromise();
console.log('Respuesta de contactos de oficina:', responseContactosOficina);
this.listContactosOficina = responseContactosOficina.pageContent;
console.log('Listado de contactos de oficina:', this.listContactosOficina);

// Utiliza un bucle para iterar sobre los contactos de oficina y obtener los contactos de emergencia correspondientes
for (const contactoOficina of this.listContactosOficina) {
    try {
        //  ID del contacto de oficina es el mismo que el código del contacto de emergencia
        const codigoContactoOficina = contactoOficina.id?.codigoContacto;
        if (codigoContactoOficina) {
            const responseContactoEmergencia = await this._adminVariosService.getContactoEmergencia2(codigoContactoOficina).toPromise();
            // getContactoEmergencia
            const contactoEmergencia = responseContactoEmergencia.pageContent.find((contacto: { codigo: number; }) => contacto.codigo === codigoContactoOficina);
            if (contactoEmergencia) {
                this.listContactosEmergencia2.push(contactoEmergencia);
                console.log('Contacto de emergencia coincidente:', contactoEmergencia);
            }
        }
    } catch (error) {
        console.error('Error al obtener el contacto de emergencia:', error);
    }
}
*/

this.listContactosEmergencia2 = [];
const responseContactosOficina = await this._adminVariosService.getContactosOficina(this.codigoOficina).toPromise();
console.log('Respuesta de contactos de oficina:', responseContactosOficina);
this.listContactosOficina = responseContactosOficina.pageContent;
console.log('Listado de contactos de oficina:', this.listContactosOficina);

// Utiliza un bucle para iterar sobre los contactos de oficina y obtener los contactos de emergencia correspondientes
for (const contactoOficina of this.listContactosOficina) {
    try {
        //  ID del contacto de oficina es el mismo que el código del contacto de emergencia
        const codigoContactoOficina = contactoOficina.id?.codigoContacto;
        if (codigoContactoOficina) {
            const responseContactoEmergencia = await this._adminVariosService.getContactoEmergencia2(codigoContactoOficina).toPromise();
            // getContactoEmergencia
            const contactoEmergencia = responseContactoEmergencia.pageContent.find((contacto: { codigo: number; }) => contacto.codigo === codigoContactoOficina);
            if (contactoEmergencia && contactoEmergencia.estado === 'A') {
                this.listContactosEmergencia2.push(contactoEmergencia);
                console.log('Contacto de emergencia coincidente:', contactoEmergencia);
            }
        }
    } catch (error) {
        console.error('Error al obtener el contacto de emergencia:', error);
    }
}

console.log("pase contacto de Emergencia")



// Obtener Intituciones Emergencia
this.listContactosInstituciones = []
let responseContactoInstituciones = await this._adminVariosService.getInstitucionesEmergencia().toPromise();
this.listContactosInstituciones =responseContactoInstituciones.pageContent

console.log("pase Intituciones Emergencia")

// Obtener Riesgos 

   let  responseRiesgosOficinas :any =  await this._riesgoService.obtenerRiesgosOficinas(this.codigoOficina , this.codigoEmpresa).toPromise()  
  this.lista_riesgos_oficinas = responseRiesgosOficinas.pageContent;

  let  responseRiesgos :any =  await this._riesgoService.obtenerRiesgos().toPromise()  
  this.lista_riesgos_response = responseRiesgos.pageContent;

  console.log("pase Riesgos")
  this.lista_riesgos_oficinas.forEach( riesgosOficinas => {      
    console.log('Muestro riesgo oficina seleccionado')  
    console.log(riesgosOficinas)                
   let indice = this.lista_riesgos_response.findIndex(riesgo => riesgo.codigo== riesgosOficinas.id.codigoRiesgo && riesgosOficinas.estado == 'A'  )                     
   console.log('indice encontrado => ' +indice )                    
   if (indice >= 0) {
    this.lista_riesgos.push( this.lista_riesgos_response[indice])
   }

  })


// obtener Mantenimeinto  
const codigo =  await this.obtenerMantenimientos()
const codigo2 = await this.seleccionarMantenimientos()

// Obtener info pisos
let responseInfoPisos :any = await this._nivelesOficiona.obtenerNivelesOficinas(this.codigoEmpresa, this.codigoOficina).toPromise();
this.lista_niveles_oficinas = responseInfoPisos.pageContent;

// Obtener info plan Emergencia
let responseInfoPlanEmergencia :any = await this._planEmergenciaService.obtenerPlanEmergencia(this.codigoEmpresa, this.codigoOficina).toPromise()
this.lista_planEmergencia = responseInfoPlanEmergencia.pageContent;
console.log("pase info plan Emergencia")

//Obtener info Areas Oficinas 
let responseAreasOficinas :any = await this._factoresRiesgoService.ObtenerAreasOficinas(this.codigoOficina , this.codigoEmpresa).toPromise()
this.configuracion = responseAreasOficinas.pageContent[0].configuracion ;
this.accesos_exteriores = responseAreasOficinas.pageContent[0].accesos;
this.ayuda_exterior = responseAreasOficinas.pageContent[0].ayudaExterior;
this.materiales_peligrosos = responseAreasOficinas.pageContent[0].materialesPeligrosos ;
this.tipos_materiales = responseAreasOficinas.pageContent[0].materialesAlmacenados ;
this.desechos = responseAreasOficinas.pageContent[0].desechosGenerados ;




// Obtener evaluacion taxativa 
let responseevaluaciontaxativa : any = await   this._evaluacionPrevencionService.obtenerEvaluacionTaxativa().toPromise()
this.evaluacionTaxativa = responseevaluaciontaxativa.pageContent[0].rangoInicio

console.log("pase evaluacion taxativaa")

// Caracteristicas del Edificio 
let responseCaracteristicas :any = await this._factoresRiesgoService.obtenerCaracteristicasEdificio(this.codigoOficina , this.codigoEmpresa).toPromise()
this.superficieTotalConstruida =responseCaracteristicas.pageContent[0].superficieTotal;

this.plantasSobrerazantes =  responseCaracteristicas.pageContent[0].plantasSobre.toString();

this.plantasBajoRazantes = responseCaracteristicas.pageContent[0].plantasBajo.toString();
this.altura  = responseCaracteristicas.pageContent[0].altura.toString();

this.pilares  = responseCaracteristicas.pageContent[0].pilares;
this.cerramientos_exteriores = responseCaracteristicas.pageContent[0].cerramientosExt;
this.vigas = responseCaracteristicas.pageContent[0].vigas;
this.cerramientos_interiores  =  responseCaracteristicas.pageContent[0].cerramientosInt;

// Obtener informacion Equipo 
let response : any = await this._factoresRiesgoService.obtenerEquipos().toPromise() 
this.listaEquipos =response.pageContent

let response2 :any = await this._factoresRiesgoService.obtenerEquiposOficinas(this.codigoOficina ,this.codigoEmpresa).toPromise()
this.listaEquiposOficinas = response2.pageContent

console.log("===DESCARGA DE IMAGENES===")

const imagenes = [{archivo: 'geoubicacion_' + this.codigoOficina + '.png', path: 'imagenes_plan'},
                  {archivo: 'localidad_' + this.codigoOficina + '.png', path: 'imagenes_plan'}];


  for(let imagen of imagenes){
    try{
      let imagenServicio = await this._archivosoficinasService.obtenerImagenesArchivo(imagen.archivo, imagen.path);

      if(imagenServicio.nombreArchivo.startsWith('geoubicacion_')){
        this.Im_geolocalizacion = imagenServicio.archivoBase64;
        
      }else if(imagenServicio.nombreArchivo.startsWith('localidad_')){
        this.Im_portada = imagenServicio.archivoBase64;
      }
    }catch(err){
      this.toast.mostrarToastError('Hubo un problema al obtener la imagen ' +  imagen.archivo + '. ' + err, this.toastKey);
    }
  }
  
  
  console.log("===FIN DESCARGA DE IMAGENES===")


/*
    console.log("LlenaGeoubicacion Func.")
     this.LlenaGeoubicacion()

     // obtengo informacion de Imagenes
     console.log("LlenaPortada Func.")
     this.LlenaPortada()


     

     console.log("==IMAGEN PORTADA==: " + this.Im_portada)

*/

// Obtener niveles y pisos 
this.lista_niveles = this._niveleOficina.obtenerListaNiveles()
this.numeroPisosOcupados = this._niveleOficina.obtenerPisos().toString();
this.lista_niveles.forEach(valor => {
 this.superficieOcupada =  this.superficieOcupada + "Área de " + valor.descripcion + " " + valor.areaUtil + " M2" +" "  //cambio prueba
 
}) 
console.log("pase niveles y pisosa")
// obtener Antecedentes Y Alcance
let responseALcance : any = await  this._descripcionEmpresaService.obtenerDescripcion(this.codigoOficina ,this.codigoEmpresa , 
  this._seccionesService.ObtenerTipoPlanAlcance(), this._seccionesService.ObtenerCodigoSeccionAlcance()).toPromise()
  this.alcance = responseALcance.pageContent[0].valor

  let responseAntecedente : any = await  this._descripcionEmpresaService.obtenerDescripcion(this.codigoOficina ,this.codigoEmpresa , 
    this._seccionesService.ObtenerTipoPlanAntecedente(), this._seccionesService.ObtenerCodigoSeccionAntecedente()).toPromise()
    this.antecedente = responseAntecedente.pageContent[0].valor 

    console.log("Alcance" +this.alcance)
    console.log( "Antecedente" + this.antecedente)

console.log("Alancance")
    // info recuros 

    let responseRecursos :any = await  this._recursosExistenteService.obtenerRecursos().toPromise()
    this.lista_recursos = responseRecursos.pageContent  

    this.lista_niveles_oficinas.sort(
      (firstObject: InivelOficina, secondObject: InivelOficina) =>
        (firstObject.numeroPiso > secondObject.numeroPiso) ? 1 : -1
     );


  
   
   // obtengo recurosNiveles
   for(const nivel of this.lista_niveles_oficinas){
     let responseRecursosNivel : any = await this._recursoNivelService.obtenerRecursoNivel(nivel.codigo).toPromise()
     if (responseRecursosNivel.totalItems > 0 ) {
       this.listaRecursoNivel =   responseRecursosNivel.pageContent;
       this.listaTotalRecuroNivel = this.listaTotalRecuroNivel.concat(this.listaRecursoNivel)
      }
     }


     // Obtengo informacion de rutas Evacuacion  
     let responseRutasEvacuacion :any = await  this._rutaEvacuacionService.obtenerRutasEvacuacion().toPromise()
     this.lista_rutasEvacuacion = responseRutasEvacuacion.pageContent  
     console.log("Rutas evacua", this.lista_rutaEvacuacionNivel)
     for(const rutasEvacuacion of this.lista_rutasEvacuacion){       
      let indice = rutasEvacuacion.nivel.findIndex(ruta =>  ruta.id.codigoNivel == this.lista_niveles_oficinas[0].codigo   )      // se busca si la ruta de evacuacion pertenece a cualquier nivel de la oficnina                
      if (indice  >= 0) {
               
        this.lista_Evacuacion.push({
          codigo :   rutasEvacuacion.codigo ,
          descripcion : rutasEvacuacion.descripcion,
        })

        for(const niveles_oficina of this.lista_niveles_oficinas){  
          let indice2 = rutasEvacuacion.nivel.findIndex(ruta =>  ruta.id.codigoNivel == niveles_oficina.codigo   )      // se busca si la ruta de evacuacion pertenece a cualquier nivel de la oficnina                
          // se agregan solo los nivel
          if (indice  >= 0) {        
            this.lista_rutaEvacuacionNivel.push(
              rutasEvacuacion.nivel[indice2]            
            )
        }
      }
      console.log("Rutas evacuacion nivel", this.lista_rutaEvacuacionNivel)

      }
     }

     // Ordenamos
     this.lista_Evacuacion.sort(
      (firstObject: any, secondObject: any) =>
        (firstObject.codigo > secondObject.codigo) ? 1 : -1
     );


     this.loading =true
   /* 
     let documento :any = await this._archivosoficinasService.obtenerArchivo('localidad_' +this.codigoOficina + '.png',
      'imagenes_plan' ).toPromise()
   
          this.Im_portada = documento.archivoBase64
          console.log("Imagen de portada")
          console.log(this.Im_portada)

    let documento2 :any = await this._archivosoficinasService.obtenerArchivo('geoubicacion_' +this.codigoOficina+'.png' , 'imagenes_plan' ).toPromise()
        this.Im_geolocalizacion = documento2.archivoBase64
        console.log("Imagen de geoubicacion")
        console.log(this.Im_geolocalizacion)


     let responseArchivosOficinas :any = await  this._archivosoficinasService.obtenerArchivosOficinas(this.codigoOficina , this.codigoEmpresa).toPromise()
     this.lista_archivo_planes = responseArchivosOficinas.pageContent  
     console.log(this.lista_archivo_planes)
     */


/*
     if (this.lista_archivo_planes.length> 0) {
      let ruta = `imagenes_plan`
      console.log(ruta)
      for(const archivo of this.lista_archivo_planes){
        if (archivo.nombre.substring(0,9) == 'localidad') {
          let documento :any = await this._archivosoficinasService.obtenerArchivo(archivo.nombre, ruta ).toPromise()
          this.Im_portada = documento.archivoBase64
          console.log("Imagen de portada")
          console.log(this.Im_portada)
        }

        if (archivo.nombre.substring(0,12) == 'geoubicacion') {
          
        let documento2 :any = await this._archivosoficinasService.obtenerArchivo(archivo.nombre , ruta ).toPromise()
        this.Im_geolocalizacion = documento2.archivoBase64
        console.log("Imagen de geoubicacion")
        console.log(this.Im_geolocalizacion)
        }

      }


     } 
     */

        
      
   // obtener Imagenes Portada y geolocalizacion
    this.obtenerImagenes()
  
  

 // Arma html para titulos y subtitulos
  this.generarTitulos()

  // LLena Tablas
  this.llenaTablas()

  // Llena Imagenes
  this.llenaImagenes()

  // llena campos adicionales
  this.llenaCamposAdicionales()

 // Llena el los tag del docuemnto a cambia
  this.LlenaDocumento()

  // Genera el documento
  this.export();


  this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;

  this.loading = false

   
  this.toast.mostrarToastSuccess('Archivo generado correctamente', this.toastKey);  

  }

  
  async LlenaPortada(){
    try {
      //let datos = await firstValueFrom(this._archivosoficinasService.obtenerArchivo('localidad_' +this.codigoOficina + '.png', 'imagenes_plan'));
      let datos = await firstValueFrom(this._archivosoficinasService.obtenerArchivo('localidad_' +this.codigoOficina, 'imagenes_plan'));
      console.log("===EXITO===: " + datos);
  
    }catch(error){
      console.log("===ERROR===: " + error);
    }
    /*
    return new Promise((resolve) => {     
      this._archivosoficinasService.obtenerArchivo('localidad_' +this.codigoOficina + '.png',
      'imagenes_plan' ).subscribe(
        datos => {
          console.log("==LLENAPORTADA-DATOS==: " + datos)
          this.toast.mostrarToastInfo("Observer-LlenaPortada", this.toastKey)
          this.Im_portada = datos.archivoBase64
          console.log("Imagen de portada")
          console.log(this.Im_portada)     
                   const dataRes = { resCode: 0 };
                   resolve(dataRes);
        }  ,
        (err: HttpErrorResponse) => {
          const e='Ocurrio un error inesperado obteniendo la portada de la oficina';
          this.toast.mostrarToastError('Hubo un problema al obtener la portada de la Oficina' +  this.codigoOficina +
          ', por favor intentelo mas tarde', this.toastKey);
          const dataErr = { resCode: -1, error: e };
         resolve(dataErr);
          console.log('Error')        
       }  
     )  
    })*/
  }


  
  
  async LlenaGeoubicacion(){
    try {
    //let datos = await firstValueFrom(this._archivosoficinasService.obtenerArchivo('geoubicacion_' +this.codigoOficina+'.png', 'imagenes_plan'));
    let datos = await firstValueFrom(this._archivosoficinasService.obtenerArchivo('geoubicacion_' +this.codigoOficina, 'imagenes_plan'));
      console.log("===EXITO===: " + datos);

  }catch(error){
    console.log("===ERROR===: " + error);
  }
    /*return new Promise((resolve) => {     
      this._archivosoficinasService.obtenerArchivo('geoubicacion_' +this.codigoOficina+'.png',
      'imagenes_plan' ).subscribe(
        datos => {
          console.log("==LLENAGEO-DATOS==: " + datos)
          this.toast.mostrarToastInfo("Observer-LlenaGeoubicacion", this.toastKey)
          this.Im_geolocalizacion = datos.archivoBase64
          console.log("Imagen de Geoubicacion")
          console.log(this.Im_geolocalizacion)     
                   const dataRes = { resCode: 0 };
                   resolve(dataRes);
        }  ,
        (err: HttpErrorResponse) => {
          const e='Ocurrio un error inesperado obteniendo la portada de la geoubicacion';
          this.toast.mostrarToastError('Hubo un problema al obtener la geoubicacion de la Oficina' +  this.codigoOficina +
          ', por favor intentelo mas tarde', this.toastKey);
          const dataErr = { resCode: -1, error: e };
         resolve(dataErr);
          console.log('Error' )        
       }  
     )  
    })*/
  }


 llenaCamposAdicionales(){


  this.contenido = this.contenido.replace('$Tag_Antecedente', this.antecedente)
  this.contenido = this.contenido.replace('$Tag_Alcance', this.alcance)
  this.contenido = this.contenido.replace(/\$Tag_oficina/g,  this.oficina )
  this.contenido = this.contenido.replace(/\$Tag_ciudad/g,  this.ciudad )

  let valor :number =  this.lista_planEmergencia[0].tiempoSalida
  let minutos : number = Math.trunc(valor/60) 
  let segundos : number = valor%60

  let tiempo_salida = ` <br> <p class="c21">
  <span class="c68 c42 c66">TS  &#61; `+  minutos.toString() +`&#39;` +segundos.toString()+`&#34;</span>
</p> <br>`

  this.contenido = this.contenido.replace('$Tag_TS',  tiempo_salida.toString() )
  this.contenido = this.contenido.replace('$Tag_TS_MINUTOS',  minutos.toString() )
  this.contenido = this.contenido.replace('$Tag_TS_SEGUNDOS',  segundos.toString() )
  this.contenido = this.contenido.replace('$Tag_Tipos_Materiales',  this.tipos_materiales )
  this.contenido = this.contenido.replace('$Tag_Desechos',  this.desechos )
  this.contenido = this.contenido.replace('$Tag_Materiales_Warnign',  this.materiales_peligrosos )
 
  
  
 
   
 }

  generarTitulos(){
     
   var titulo1 : number;
   var titulo2 : number;
   var Subtitulo1 : number;
   var codigo1 : number;
   var codigo2 : number;
   var codigo3 : number;
     /// ordeno titulo 1
     this.lista_Titulos1.sort(
      (firstObject: SeccionDocumentos, secondObject: SeccionDocumentos) =>
        (firstObject.orden > secondObject.orden) ? 1 : -1
     );

     // Ordeno titulo 2
     console.log(this.lista_Titulos2)
     this.lista_Titulos2.sort(
      (firstObject: SeccionDocumentos, secondObject: SeccionDocumentos) =>
        (firstObject.orden > secondObject.orden) ? 1 : -1
     );


    // Ordeno subtitulo 3
     this.lista_Subtitulo3.sort(
      (firstObject: SeccionDocumentos, secondObject: SeccionDocumentos) =>
        (firstObject.orden > secondObject.orden) ? 1 : -1
     );

     this.contenido= ""
     this.lista_Titulos1.forEach((seccion)=> {
        
    //    console.log( seccion.orden + ".- " + seccion.titulo )
        
        titulo1 = seccion.orden;
        codigo1 =  seccion.id.codigo ;
      /*  this.contenido = this.contenido + `<ol class="c47 lst-kix_list_8-0 start" start="`+seccion.orden+`">
        <li class="c3 c43 li-bullet-0">
          <span class="c1">` + seccion.titulo  +`</span>
        </li>
      </ol>`*/

      this.contenido = this.contenido +
      `<br>
      <div class="c4 c40 li-bullet-1">
        <span class="c13"><u>` +  seccion.orden+  ".-" + seccion.titulo +` </u></span>
      </div>
      `;
         

         this.lista_Titulos2.filter(secc => secc.codigoSeccionPadre == codigo1 ).forEach( (seccion2)=> {
          
//console.log(  titulo1 + "." + seccion2.orden + ".-" + seccion2.titulo  )
           
          titulo2 = seccion2.orden;
          codigo2 =  seccion2.id.codigo ;

          this.contenido = this.contenido +
          `<br>
          <div class="c4 c40 li-bullet-1">
            <span class="c13">&nbsp;&nbsp;` +  titulo1 + "." + seccion2.orden + ".-" + seccion2.titulo  +` </span>
          </div>
          `;
          if (seccion2.texto == null) {
            console.log("es null");
            this.contenido = this.contenido + `<br>`
          } else {
            this.contenido = this.contenido +   `<p class="c4 c33">
            <span class="c0">`+seccion2.texto+`</span>
            </p> 
            `
          }

        


         this.lista_Subtitulo3.filter(secc3 => secc3.codigoSeccionPadre == codigo2).forEach( (seccion3)=> {
         // console.log(  titulo1 + "." + titulo2 + "." + seccion3.orden  + ".-" + seccion3.titulo )
          
          codigo3 = seccion3.id.codigo
               Subtitulo1 = seccion3.orden
            //  console.log( seccion3.orden + " " + seccion3.titulo + " " +seccion3.texto)
            this.contenido = this.contenido +
            `  <br>
                 <p class="c4 c33">
                <span class="c13">&nbsp;&nbsp;&nbsp;&nbsp;` + titulo1 + "." + titulo2 + "." + seccion3.orden  + ".-" + seccion3.titulo +`</span>
                </p>
                <br>` ;

                if (seccion3.texto == null) {
                  console.log("es null");
                } else {
                  this.contenido = this.contenido +     
                   `<p class="c4 c33">
            <span class="c0">`+seccion3.texto+`</span>
            </p> 
            `

                }
               
              

            }) 
 
         }

         );
     })

  }


LlenaDocumento(){

  this.llenaSeccionRiesgos()
  this.llenaMantenimiento()
  this.obtiene_info_poblacion()
  this.obtiene_info_Plan_Emergencia()
  this.documento =text 
  
  this.documento = this.documento.replace('$ELABORADOR' ,  this.elaborador.toUpperCase())
  this.documento = this.documento.replace('$CARGO_ELABORADOR' ,  this.cargo_elaborador.toUpperCase())



  const portada  = `<br>  <div style="text-align: center;"> <img  width="600" height="600"  src="${this.Im_portada}">
  </div>
   <br>`

   const geolocalizacion  = `<br> <div style="text-align: center;"> <img  width="400" height="400"  src="${this.Im_geolocalizacion}">
   </div>
    <br>`

    console.log("==HTML PORTADA==" + portada)
    console.log("==HTML GEO==" + geolocalizacion)

   this.documento = this.documento.replace(/\$Tag_oficina/g,  this.oficina )
   this.documento = this.documento.replace('$Tag_direccion',this.direccion)

   let date: Date = new Date();
   let fechaEvaluacion = date.getDate() + "-" + (date.getMonth()+1)  +"-" +  date.getFullYear() ;
   this.documento = this.documento.replace('$tag_fecha_actualizacion',fechaEvaluacion)


  this.documento = this.documento.replace('$Tag_portada' ,  portada)
  this.documento = this.documento.replace('$Tag_geolocalizacion' ,  geolocalizacion)

  this.documento = this.documento.replace('$CONTENIDO' ,  this.contenido)


}

llenaTablas(){

   this.llenaTablaInfoGeneral()
   this.llenaTablaContactosEmergencia();
   this.llenaTablaAreaOficina()
   this.llenaTablaCaracteristicasEdificio()
   this.llenaTablasEquiposInstalaciones()
   this.llenaTablasSistemaEmergencia()
   this.llenaTablaInstitucionesEmergencia()
   this.llenaTablaRecursosExistentes()
   this.llenaTablaRutaEvacuacion()

}




llenaTablaInfoGeneral(){
  
  this.tabla_infor_general = info_general_empresa;
  this.tabla_infor_general=  this.tabla_infor_general.replace('$RAZON_SOCIAL_EMPRESA',this.razon_social_empresa)
  this.tabla_infor_general=  this.tabla_infor_general.replace('$EDIFICACION',this.edificacion)
  this.tabla_infor_general=  this.tabla_infor_general.replace('$CIUDAD',this.ciudad)
  this.tabla_infor_general=  this.tabla_infor_general.replace('$PROVINCIA',this.provincia)
  this.tabla_infor_general=  this.tabla_infor_general.replace('$DIRECCION',this.direccion)
  this.tabla_infor_general=  this.tabla_infor_general.replace('$TELEFONO',this.telefono)
  this.tabla_infor_general=  this.tabla_infor_general.replace('$FAX',this.fax)
  this.tabla_infor_general=  this.tabla_infor_general.replace('$CORREO',this.correo)
  this.tabla_infor_general=  this.tabla_infor_general.replace('$ACTIVIDAD',this.actividad)
  this.tabla_infor_general=  this.tabla_infor_general.replace('$PROCESOS',this.procesos)
  this.tabla_infor_general=  this.tabla_infor_general.replace('$CERRAMIENTOS_EXTERIORES',this.cerramientos_exteriores)
  this.tabla_infor_general=  this.tabla_infor_general.replace('$CERRAMIENTOS_INTERIORES',this.cerramientos_interiores)


  this.contenido = this.contenido.replace('$Tag_table_info_gnral_empre', this.tabla_infor_general)

 
  

}


/*
llenaTablaContactosEmergencia(){

  this.tabla_contactos_Emergencia=  contacto_emergencia ;
  let id = 1;

  //muestro contactos de mergencia
  console.log('inicio de cobtener contacto de Emergencia')
//  this.obtenerContactosEmergencia(this.codigoOficina);
this.tabla_contactos_Emergencia_det = "";
   this.listContactosEmergencia2.forEach(contacto => {
    
  this.tabla_contactos_Emergencia_det =  this.tabla_contactos_Emergencia_det + `     <tr class="c19">
  <td class="c83" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c0"> `+ id +`</span>
    </p>
  </td>
  <td class="c36" colspan="1" rowspan="1">
    <p class="c39">
      <span class="c0">` +contacto.primerNombre + ` ` + contacto.primerApellido +`</span>
    </p>
  </td>
  <td class="c51" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c0">`+ contacto.correo+`</span>
    </p>
  </td>
  <td class="c67" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c0">`+contacto.extensionTelefono+`</span>
    </p>
  </td>
  <td class="c103" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c0">`+ contacto.telefono+`</span>
    </p>
  </td>
</tr>`

  id++
 
   })

   this.tabla_contactos_Emergencia = this.tabla_contactos_Emergencia.replace('$CONTACTOS_EMERGENCIA', this.tabla_contactos_Emergencia_det)
  
   this.contenido = this.contenido.replace('$Tag_table_contact_emer', this.tabla_contactos_Emergencia) 
}
*/

llenaTablaContactosEmergencia() {
  this.tabla_contactos_Emergencia = contacto_emergencia;
  let id = 1;

  // Mensaje para verificar si listContactosEmergencia2 tiene datos antes de la iteración
  console.log('Listado de contactos de emergencia antes de la iteración:', this.listContactosEmergencia2);

  // Inicia la construcción de la tabla
  this.tabla_contactos_Emergencia_det = "";
  this.listContactosEmergencia2.forEach(contacto => {
      // Mensaje para verificar cada contacto durante la iteración
      console.log('Contacto actual:', contacto);

      this.tabla_contactos_Emergencia_det = this.tabla_contactos_Emergencia_det + `     <tr class="c19">
          <td class="c83" colspan="1" rowspan="1">
              <p class="c21">
                  <span class="c0"> `+ id + `</span>
              </p>
          </td>
          <td class="c36" colspan="1" rowspan="1">
              <p class="c39">
                  <span class="c0">` + contacto.primerNombre + ` ` + contacto.primerApellido + `</span>
              </p>
          </td>
          <td class="c51" colspan="1" rowspan="1">
              <p class="c21">
                  <span class="c0">` + contacto.correo + `</span>
              </p>
          </td>
          <td class="c67" colspan="1" rowspan="1">
              <p class="c21">
                  <span class="c0">` + contacto.extensionTelefono + `</span>
              </p>
          </td>
          <td class="c103" colspan="1" rowspan="1">
              <p class="c21">
                  <span class="c0">` + contacto.telefono + `</span>
              </p>
          </td>
      </tr>`

      id++;
  });

  // Mensaje para verificar el contenido de la tabla después de la iteración
  console.log('Detalle de contactos de emergencia después de la iteración:', this.tabla_contactos_Emergencia_det);

  this.tabla_contactos_Emergencia = this.tabla_contactos_Emergencia.replace('$CONTACTOS_EMERGENCIA', this.tabla_contactos_Emergencia_det);

  // Mensaje para ver el contenido asociado con '$Tag_table_contact_emer' antes del reemplazo
  console.log('Contenido de "$Tag_table_contact_emer" antes del reemplazo:', this.contenido);

  this.contenido = this.contenido.replace('$Tag_table_contact_emer', this.tabla_contactos_Emergencia);

  // Mensaje para verificar el contenido final
  console.log('Contenido final:', this.contenido);
}


llenaTablaRutaEvacuacion(){

  // llenar cabecera  
  let detalle = `<br> <br>
  <table class="c89">
  <tr class="c48">
    <td class="c60" colspan="1" rowspan="1">
      <p class="c16">
        <span class="c15">&nbsp;PISO</span>
      </p>
    </td>
  `
  console.log("Lista incial", this.lista_Evacuacion)
  for(const evacuacion of this.lista_Evacuacion){    
     
    detalle = detalle + `  <td class="c22" colspan="1" rowspan="1">
    <p class="c16">
      <span class="c15">`+ evacuacion.descripcion+`</span>
    </p>
  </td>`
     
  }

  detalle = detalle + `  </tr>`
  console.log("Descripcion evacuacion", detalle)
  for(const niveles of this.lista_niveles_oficinas){   
    let piso = ""
    if (niveles.numeroPiso == 0) {
      piso = "SOTANO"     
    }

    if (niveles.numeroPiso == 1) {
      piso = "PLANTA BAJA"      
    }

    if (niveles.numeroPiso > 1) {       
      piso = "PISO" + (niveles.numeroPiso -1).toString()
    }

    detalle = detalle + `
    <tr class="c48">
    <td class="c82" colspan="1" rowspan="1">
      <p class="c16">
        <span class="c15">`+ piso +`</span>
      </p>
    </td>`
  

    for(const evacuacion of this.lista_Evacuacion){    
      let valor = this.obtenerValorRutaEvaluacion(niveles.codigo , evacuacion.codigo)
      detalle = detalle + `   <td class="c82" colspan="1" rowspan="1">
      <p class="c16">
        <span class="c15">`+ valor +`</span>
      </p>
    </td>`
       
    }
   
    detalle = detalle + `  </tr>`


  }

  detalle = detalle + `  <tr class="c48">
  <td class="c60" colspan="1" rowspan="1">
    <p class="c16">
      <span class="c15">TOTAL&nbsp;</span>
    </p>
  </td `
  console.log("Lista evacuacion", this.lista_Evacuacion)
  for(const evacuacion of this.lista_Evacuacion){    
    let valor = this.ObstenerValorTotal( evacuacion.codigo)
    detalle = detalle + ` <td class="c22" colspan="1" rowspan="1">
    <p class="c16">
      <span class="c15"> ` + valor +`</span>
    </p>
  </td>`
     
  }
  detalle = detalle + `  </tr> </table>`
  console.log("Evacuacion", detalle)
  this.contenido = this.contenido.replace('$Tag_table_distri_personal', detalle) 
}

ObstenerValorTotal(ruta: number ){
  
  let valor : number = 0
  for(const nivel of this.lista_rutaEvacuacionNivel){   
      if ( nivel.id.codigoRuta == ruta ) {
          valor  = nivel.cantidad +valor    
      }

}

return valor
  
}
obtenerValorRutaEvaluacion( cod_nivel :number , ruta: number ){
  
    let valor : number = 0
    for(const nivel of this.lista_rutaEvacuacionNivel){   
        if (nivel.id.codigoNivel == cod_nivel && nivel.id.codigoRuta == ruta ) {
            valor  = nivel.cantidad
            break
        }

  }

  return valor


}


llenaTablaRecursosExistentes(){


 let contador = 1

// Cabecera
let  detalle = ` <br><div style="text-align: center;"> <table class="c115">
 <tr class="c92">
   <td class="c26" colspan="1" rowspan="1">
     <p class="c4 c30">
       <span class="c42 c66">N</span>
     </p>
   </td>
   <td class="c25" colspan="1" rowspan="1">
     <p class="c4 c30">
       <span class="c42 c66">Recurso</span>
     </p>
   </td>`

 
 for(const nivel of this.lista_niveles_oficinas){         
    let piso = ""
    if (nivel.numeroPiso == 0) {
      piso = "S1"     
     
    }

    if (nivel.numeroPiso == 1) {
      piso = "PB"      
    }

    if (nivel.numeroPiso > 1) {       
      piso = "P" + (nivel.numeroPiso -1).toString()
    }
  
    detalle = detalle + `<td class="c9" colspan="1" rowspan="1">
    <p class="c16">
      <span class="c13">`+ piso +`</span>
    </p>
  </td>`

     
 }

 detalle = detalle + `</tr>`


  for (const recursos of this.lista_recursos) {
  
     detalle = detalle + `<tr class="c24">
    <td class="c26" colspan="1" rowspan="1">
    <p class="c4 c30">
      <span class="c0"> `+ contador +`</span>
    </p>
  </td>
  <td class="c25" colspan="1" rowspan="1">
    <p class="c4 c30">
      <span class="c0">`+ recursos.descripcion +`</span>
    </p>
  </td>`   

    contador = contador +1 
       
    for(const nivel of this.lista_niveles_oficinas){
      

        let valor  = "-"
        let indice = this.listaTotalRecuroNivel.findIndex(recursoTotal =>  recursoTotal.id.codigoNivel == nivel.codigo && recursoTotal.id.codigoRecurso == recursos.codigo  )                     
 
          if (indice  >= 0) {
            valor =     this.listaTotalRecuroNivel[indice].cantidad.toString()    
            this.observacion = this.listaTotalRecuroNivel[indice].observacion
          }

          detalle = detalle + `<td class="c26" colspan="1" rowspan="1">
          <p class="c4 c30">
            <span class="c0"> `+ valor +`</span>
          </p>
        </td>`
    }

    detalle = detalle + `</tr>`

   }
 
   detalle = detalle + `</table> </div>`


   this.contenido = this.contenido.replace('$Tag_table_recur_exist', detalle) 
   this.contenido = this.contenido.replace('$Tag_Observacion_Recursos_Niveles', this.observacion) 

}



llenaTablaInstitucionesEmergencia(){

  this.tabla_instituciones_emergencia=  instituciones_emergencia  ;

  //muestro contactos de mergencia
  console.log('Muestro las intituciones')
  console.log(this.listContactosInstituciones)
 // this.obtenerContactosEmergencia(this.codigoOficina);
this.tabla_instituciones_emergencia_det = ""; // ca,biar
   this.listContactosInstituciones.forEach(contacto => {  // cambia
    
  this.tabla_instituciones_emergencia_det =  this.tabla_instituciones_emergencia_det + `  <tr class="c19">
  <td class="c110" colspan="1" rowspan="1">
    <p class="c4">
      <span class="c0">`+ contacto.institucion+` </span>
    </p>
  </td>
  <td class="c106" colspan="1" rowspan="1">
    <p class="c21">
      <span class="c0">`+contacto.telefono +`</span>
    </p>
  </td>
</tr> `
 
   })

   this.tabla_instituciones_emergencia = this.tabla_instituciones_emergencia.replace('$CONTENIDO', this.tabla_instituciones_emergencia_det)
  
   this.contenido = this.contenido.replace('$Tag_table_institu_emergen', this.tabla_instituciones_emergencia) 
}

llenaTablaAreaOficina(){

  this.tabla_area_oficina = descripcion_area_oficina;

  this.tabla_area_oficina=  this.tabla_area_oficina.replace('$CONFIGURACION',this.configuracion)
  this.tabla_area_oficina=  this.tabla_area_oficina.replace('$ACCESOS_EXTERIORES',this.accesos_exteriores)
  this.tabla_area_oficina=  this.tabla_area_oficina.replace('$AYUDA_EXTERIOR',this.ayuda_exterior)

  this.contenido = this.contenido.replace('$Tag_table_descrip_area_ofi', this.tabla_area_oficina)

}

llenaTablaCaracteristicasEdificio(){
 
  this.tabla_caracteristica_edificio = caracteristicas_edificio;

  this.tabla_caracteristica_edificio=  this.tabla_caracteristica_edificio.replace('$SUPERFICIE_TOTAL_CONSTRUIDA',this.superficieTotalConstruida)
  this.tabla_caracteristica_edificio=  this.tabla_caracteristica_edificio.replace('$PLANTAS_SOBRERAZANTES',this.plantasSobrerazantes)
  this.tabla_caracteristica_edificio=  this.tabla_caracteristica_edificio.replace('$PLANTAS_BAJO_RAZANTES',this.plantasBajoRazantes)
  this.tabla_caracteristica_edificio=  this.tabla_caracteristica_edificio.replace('$NUMERO_PISOS_OCUPADOS',this.numeroPisosOcupados)
  this.tabla_caracteristica_edificio=  this.tabla_caracteristica_edificio.replace('$SUPERFICIE_OCUPADO',this.superficieOcupada)
  this.tabla_caracteristica_edificio=  this.tabla_caracteristica_edificio.replace('$ALTURA',this.altura)
  this.tabla_caracteristica_edificio=  this.tabla_caracteristica_edificio.replace('$PILARES',this.pilares)
  this.tabla_caracteristica_edificio=  this.tabla_caracteristica_edificio.replace('$VIGAS',this.vigas)
  this.tabla_caracteristica_edificio=  this.tabla_caracteristica_edificio.replace('$CERRAMIENTOS_EXTERIORES',this.cerramientos_exteriores)
  this.tabla_caracteristica_edificio=  this.tabla_caracteristica_edificio.replace('$CERRAMIENTOS_INTERIORES',this.cerramientos_interiores)

  this.contenido = this.contenido.replace('$Tag_table_caract_construc_edifi', this.tabla_caracteristica_edificio)

}

llenaTablasEquiposInstalaciones(){

  this.tabla_equipos_instalaciones = equipos_instalaciones;


  this.tabla_equipos_instalaciones_det  = ""

  this.listaEquipos.sort(
    (firstObject: IEquipo, secondObject: IEquipo) =>
      (firstObject.codigo > secondObject.codigo) ? 1 : -1
   );
  
   this.listaEquipos.forEach(equipo => {

    let indice = this.listaEquiposOficinas.findIndex(valor => valor.id.codigoEquipo == equipo.codigo && valor.id.codigoEmpresa == this.codigoEmpresa &&  valor.id.codigoOficina== this.codigoOficina)     
    let valor :string =""
    if (indice > -1 ){
     
       valor = this.listaEquiposOficinas[indice].detalle
   }

   this.tabla_equipos_instalaciones_det =  this.tabla_equipos_instalaciones_det +
   `  <tr class="c19">
   <td class="c51" colspan="1" rowspan="1">
     <p class="c4">
       <span class="c0">`+ equipo.nombre +`:</span>
     </p>
   </td>
   <td class="c6" colspan="1" rowspan="1">
     <p class="c4">
       <span class="c0">`+ valor + `</span>
     </p>
   </td>
 </tr>` ;

   
   })


  this.tabla_equipos_instalaciones=  this.tabla_equipos_instalaciones.replace('$DETALLE',this.tabla_equipos_instalaciones_det)


  this.contenido = this.contenido.replace('$Tag_table_equi_insta', this.tabla_equipos_instalaciones)


}


llenaTablasSistemaEmergencia(){
       this.contenido= this.contenido.replace('$Tag_table_estruct_sist_emer', sistema_emergencia)    

}


llenaImagenes(){

  console.log('lleno la imagen')
  this.contenido= this.contenido.replace('$Tag_img_detect_emer', deteccion)  
  this.contenido= this.contenido.replace('$Tag_img_aplicar_alarm', alarma2)  
  this.contenido= this.contenido.replace('$Tag_img_sistema_señali', sistema_s) 
  this.contenido= this.contenido.replace('$Tag_img_form_actuar_emer', actuar_emergencia) 
  this.contenido= this.contenido.replace('$Tag_Imagen_Formula', formula)   

  
  
   


}

/*
llenaSeccionRiesgos(){

  this.detalleRiesgo = "";
  this.lista_riesgos.forEach(riesgo => {
    let valor = riesgo.descripcionRiesgo
    // reemplaza hast 6 imagenes
    valor= valor.replace(`class="ql-align-center"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )
    valor= valor.replace(`class="ql-align-center"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )
    valor= valor.replace(`class="ql-align-center"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )
    valor= valor.replace(`class="ql-align-center"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )
    valor= valor.replace(`class="ql-align-center"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )
    valor= valor.replace(`class="ql-align-center"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )



    this.detalleRiesgo = this.detalleRiesgo + 
  ` <p class="c4">
</p class="c4" >`  + valor + `<br>`
          

  })

 
  this.detalleRiesgo= this.detalleRiesgo.replace(/ql-align-justify/gi , 'c0' )
  //this.detalleRiesgo= this.detalleRiesgo.replace(/ql-align-center/gi , 'c0' )
 // this.detalleRiesgo= this.detalleRiesgo.replace(`class="ql-align-center"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )
  
  
 


  console.log ('OJOOOOOO' + this.detalleRiesgo)

  this.contenido= this.contenido.replace('$Tag_declaracion_Riesgo', this.detalleRiesgo)    

}
*/

/*MODIFICADO SUD-BCALVOPIÑA - 4/01/2024 -- ARREGLOS EN FORMATO CALIBRI RIESGOS*/
llenaSeccionRiesgos(){

  this.detalleRiesgo = "";
  this.lista_riesgos.forEach(riesgo => {
    let valor = riesgo.descripcionRiesgo
    // reemplaza hast 6 imagenes
    valor= valor.replace(`class="ql-align-center" style="font-family: 'Calibri';"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )
    valor= valor.replace(`class="ql-align-center"style="font-family: 'Calibri';"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )
    valor= valor.replace(`class="ql-align-center" style="font-family: 'Calibri';"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )
    valor= valor.replace(`class="ql-align-center" style="font-family: 'Calibri';"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )
    valor= valor.replace(`class="ql-align-center" style="font-family: 'Calibri';"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )
    valor= valor.replace(`class="ql-align-center" style="font-family: 'Calibri';"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )


/*MODIFICADO SUD-BC - 4/01/2024 -- ARREGLOS EN FORMATO CALIBRI RIESGOS*/
this.detalleRiesgo = this.detalleRiesgo + 
  ` <p style="font-family: 'Calibri';" class="c4">
</p class="c4" style="font-family: 'Calibri';" >`  + valor + `<br>`
          

  })

 
  this.detalleRiesgo= this.detalleRiesgo.replace(/ql-align-justify/gi , 'c0' )
  //this.detalleRiesgo= this.detalleRiesgo.replace(/ql-align-center/gi , 'c0' )
 // this.detalleRiesgo= this.detalleRiesgo.replace(`class="ql-align-center"><img src` , `style="text-align: center;padding: 0px;margin: 0px;"><img src` )


  console.log ('OJOOOOOO' + this.detalleRiesgo)

  this.contenido= this.contenido.replace('$Tag_declaracion_Riesgo', this.detalleRiesgo)    

}



llenaMantenimiento(){

     
  let detalleMantenimiento = "";
  this.lista_mantenimientos.forEach(manten => {
    detalleMantenimiento = detalleMantenimiento + 
  ` <p class="c4 c33">
  <span class="c0"><b>`+ manten.nombre  +`</b> </span>
</p> 

<p class="c0">
`  + manten.detalle +  `</p> <br> `
          



  })

  
  detalleMantenimiento= detalleMantenimiento.replace(/ql-align-justify/gi , 'c0' )
  detalleMantenimiento= detalleMantenimiento.replace(/ql-align-center/gi , 'c0' )

  this.contenido= this.contenido.replace('$Tag_Mantenimientos', detalleMantenimiento)    

}

  
goPrevious() {
  this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
   
}

  saveContinue(){
   

    
    //this.export()

   this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;
     
  }

  async export() {
    console.log('Imprimo el documento')
    console.log(this.documento)
    var converted :any = await asBlob(this.documento, {
      orientation: 'portrait',
      margins: { top: 720  ,left : 550 , right : 550}
    });
    saveAs(converted, 'Plan_Emergencia.docx');
  }


 obtiene_info_poblacion(){
  
    this.total_hombre = 0;
    this.total_mujeres = 0;
    this.total_trabajador =0  
    this.total_suplementarios = 0
    this.total_trabajadores_final = 0
    this.total_visitantes = 0
    this.tabla_poblacion = cantidad_poblacion;
    this.tabla_poblacion_det = ""
    this.area_total = 0

    this.lista_niveles_oficinas.forEach(niveles =>  {
    
    let total2 = niveles.totalEmpleadosPiso + niveles.serviciosComplementarios

      this.tabla_poblacion_det =  this.tabla_poblacion_det + `
      <tr class="c19">
      <td class="c63" colspan="1" rowspan="1">
        <p class="c21" id="h.1fob9te">
          <span class="c0">`+ niveles.descripcion +`</span>
        </p>
      </td>
      <td class="c18" colspan="1" rowspan="1">
        <p class="c21">
          <span class="c0">`+ niveles.totalEmpleadosPiso +`</span>
        </p>
      </td>

      <td class="c63" colspan="1" rowspan="1">
      <p class="c21" id="h.1fob9te">
        <span class="c0">`+ niveles.serviciosComplementarios +`</span>
      </p>
    </td>
      
      <td class="c38 c50" colspan="1" rowspan="1">
        <p class="c21">
          <span class="c0">`+ total2 +`</span>
        </p>
      </td>
      <td class="c38" colspan="1" rowspan="1">
        <p class="c21">
          <span class="c0">`+ niveles.visitantes+ `</span>
        </p>
      </td>
    </tr>
      `
      

    this.area_total =   this.area_total + niveles.areaTotal
    this.total_hombre = this.total_hombre + niveles.totalHombres
    this.total_mujeres = this.total_mujeres + niveles.totalMujeres
   this.total_trabajador = this.total_trabajador + niveles.totalEmpleadosPiso
   this.total_trabajadores_final =  this.total_trabajadores_final + niveles.totalEmpleadosPiso + niveles.serviciosComplementarios
   this.total_suplementarios = this.total_suplementarios + niveles.serviciosComplementarios 
   this.total_visitantes = this.total_visitantes + niveles.visitantes
})

this.porcentaje_mujeres =  (this.total_mujeres / this.total_trabajador) *100
this.porcentaje_hombres =  (this.total_hombre / this.total_trabajador) *100

this.tabla_poblacion_det = this.tabla_poblacion_det + `
<tr class="c19">
<td class="c63 c45" colspan="1" rowspan="1">
  <p class="c21">
    <span class="c13">TOTAL</span>
  </p>
</td>
<td class="c18 c45" colspan="1" rowspan="1">
  <p class="c21">
    <span class="c13">`+ this.total_trabajador+`</span>
  </p>
</td>

<td class="c63 c45" colspan="1" rowspan="1">
  <p class="c21">
    <span class="c13">`+ this.total_suplementarios+`</span>
  </p>
</td>

<td class="c38 c45" colspan="1" rowspan="1">
  <p class="c21">
    <span class="c13">`+  this.total_trabajadores_final +`</span>
  </p>
</td>
<td class="c38 c45" colspan="1" rowspan="1">
  <p class="c21">
    <span class="c13">` + this.total_visitantes +`</span>
  </p>
</td>
</tr>
`


if (this.porcentaje_mujeres> this.porcentaje_hombres) {

  this.contenido= this.contenido.replace('$Tag_porcen_genero', this.porcentaje_mujeres.toFixed(2))  
  this.contenido= this.contenido.replace('$Tag_genero', 'femenino')   
  
} else {
  this.contenido= this.contenido.replace('$Tag_porcen_genero', this.porcentaje_hombres.toFixed(2))   
  this.contenido= this.contenido.replace('$Tag_genero', 'masculino')   
  
}

this.tabla_poblacion = this.tabla_poblacion.replace('$CONTENIDO', this.tabla_poblacion_det)
  
this.contenido = this.contenido.replace('$Tag_table_cant_pobla', this.tabla_poblacion) 

this.contenido = this.contenido.replace('$Tag_cantidad_mtrs', this.area_total.toString()) 



  }

 

  obtiene_info_Plan_Emergencia(){
    
    let  plan_emergencia :IplanEmergencia =  this.lista_planEmergencia[0]


    console.log("Jorge: Plan emergencia",this.lista_planEmergencia[0]);


    this.elaborador = this.lista_planEmergencia[0].elaborador
    this.cargo_elaborador = this.lista_planEmergencia[0].cargoElaborador
    let otros_factores = this.lista_planEmergencia[0].otrosFactores
    let observacion_evacuacion = this.lista_planEmergencia[0].observacionesEvacuacion
     

    console.log("valor normal " +plan_emergencia.valorMeseri)
    
    let tipo_riesgo = ""
    let valor_messeri :string = plan_emergencia.valorMeseri.toFixed(2)
    console.log("valor redondeado " + valor_messeri)

    this.contenido= this.contenido.replace('$Tag_valor_meseri',  valor_messeri )  
    this.contenido= this.contenido.replace('$Tag_categ_riesgo', plan_emergencia.categoriaMeseri.toString())  
    this.contenido= this.contenido.replace('$Tag_Otros_Factores',`<br>`+otros_factores +`<br>`) 
    this.contenido= this.contenido.replace('$Tag_Observacion_Rutas_Evacuacion',`<br>`+observacion_evacuacion +`<br>`)   
     
      
    
   if (plan_emergencia.valorMeseri > this.evaluacionTaxativa) {
    tipo_riesgo = "Riesgo aceptable"
   } else {
    tipo_riesgo = "Riesgo no aceptable"
   }
  
   this.contenido= this.contenido.replace('$Tag_Riesgo_interpre',  tipo_riesgo )  

  }


  Descargar(){
    console.log("Descargando")
    this.generarDocumento();
  }



  obtenerImagenes(){



  }



  
  obtenerMantenimientos(){
    return new Promise((resolve) => {    
        this._mantenimientoService.obtenerMantenimientos().subscribe(  data  => {
            console.log('Ingrese a exitoso Cargando' + data.numberOfPages)   
             this.lista_mantenimientos_response = data.pageContent;  
           /*  this.lista_mantenimientos_response.forEach( 
              (mantenimiento) => {
                 console.log('muestro manteniemiento')
                 console.log(mantenimiento)
           this.lista_mantenimientos.push ({
              key : mantenimiento.codigo.toString()  ,
              name : mantenimiento.nombre ,
              visible_detalle : false  ,
              detalle : mantenimiento.detalle

     })

   }
)*/

const dataRes = { resCode: 0 };
resolve(dataRes);
    
} ,
(err: HttpErrorResponse) => {
  const e='Ocurrio un error inesperado obteniendo las oficinas';
  const dataErr = { resCode: -1, error: e };
 resolve(dataErr);
  console.log('Error' )

})

    })

  }  

 seleccionarMantenimientos(){

  return new Promise((resolve) => {
    this._mantenimientoService.obtenerMantenimientosOficinas(this.codigoOficina , this.codigoEmpresa).subscribe(
      datos => {
               console.log('muestro mantenimeinto oficina')
               console.log(datos)
               if (datos.totalItems==0)
               {
                  console.log('No existen  manteniemientos asociados')
               } else {
                  console.log('Existen  manteniemientos asociados')

                  this.lista_mantenimientos_oficinas = datos.pageContent
                   datos.pageContent.forEach( mantOficinas => {      
                     console.log('Muestro manetnemiento oficina seleccionado')  
                     console.log(mantOficinas)                
                    let indice = this.lista_mantenimientos_response.findIndex(mant => mant.codigo== mantOficinas.id.codigoMantenimiento && mantOficinas.estado == 'A'  )                     
                    console.log('indice encontrado => ' +indice )     
                    if (indice  >= 0) {
                      this.lista_mantenimientos.push( this.lista_mantenimientos_response[indice])
                    }               
                   })           
               }
               const dataRes = { resCode: 0 };
               resolve(dataRes);
       }
       ,
       (err: HttpErrorResponse) => {
         const e='Ocurrio un error inesperado obteniendo las oficinas';
         const dataErr = { resCode: -1, error: e };
        resolve(dataErr);
         console.log('Error' )
     
      }
     )
  })




  
  

 }   







}
