import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KeepEmergencyContactComponent } from './keep-emergency-contact.component';

describe('KeepEmergencyContactComponent', () => {
  let component: KeepEmergencyContactComponent;
  let fixture: ComponentFixture<KeepEmergencyContactComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KeepEmergencyContactComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KeepEmergencyContactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
