import { Component, OnInit } from '@angular/core';
import { LideresPisoContent } from 'src/app/modules/admin/core/models/LideresPisoContent';
import { NavigationService } from '../../core/services/navigation.service';
import Constantes from '../../core/util/constantes';
import { LideresPisoService } from '../../../admin/core/services/LideresPiso.service';
import { MessageService } from 'primeng/api';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { ContactoEmergenciaService } from 'src/app/modules/admin/core/services/Contacto-Emergencia.service';
import { ContactoOficinaContent } from 'src/app/modules/admin/core/models/ContactoOficinaContent';
import { ContactoEmergenciaContent } from 'src/app/modules/admin/core/models/ContactoEmergenciaContent';
import { LideresPisoExtendido } from 'src/app/modules/admin/core/models/LideresPisoExtendido';
import { OficinaService } from 'src/app/modules/admin/core/services/Oficina.service';
import { GenOficinaContent } from 'src/app/modules/admin/core/models/GenOficinaContent';

@Component({
  selector: 'app-keep-emergency-contact',
  templateUrl: './keep-emergency-contact.component.html',
  // styleUrls: ['./keep-emergency-contact.component.scss']
})
export class KeepEmergencyContactComponent implements OnInit {
  
  listaLideresPiso                  : LideresPisoContent        [] = [];
  listContactosEmergencia           : ContactoEmergenciaContent [] = [];
  listaContactosEmergenciaExtendida : LideresPisoExtendido      [] = [];

  listContactosOficina : any[];

  loading         : boolean = true;
  usuario         : string;
  noError         : boolean = true;
  codigoOficina   : number;
  nombreOficina   : string;
  busque          : boolean = false;
  esPrimeraCarga: boolean = true;
  
  constructor(private _oficina                     : SharingOfficeService ,
              private _OficinaService              : OficinaService,
              private _authService                 : AuthService,
              private navigationService            : NavigationService,
              private _lideresPisoService          : LideresPisoService,
              private messageService               : MessageService,
              private _contactosEmergenciaService  : ContactoEmergenciaService) {
  }

  getPromesa(codigo : number){
    return new Promise((resolve)=>{
        this._OficinaService.getOficinaById(codigo).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData : res.pageContent };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _tipoOficinaService.postRequest';
            const data = { resCode: -1, error: e };
            resolve(data);
          }
        });
    });
  }

  async obtenerOficina(codigoOficina: number){
    await this.getPromesa(codigoOficina).then((data: any) => {
      if (data.resCode == 0) {
        this.nombreOficina = data.resData[0].nombreOficina;
        this.cargarLideresPiso();
      } else {
        this.messageService.add({severity:'error', summary:'Información', detail:"No se pudo obtener informacion de oficina"});
      }
    });
  }
  
  ngOnInit(): void {
    this.codigoOficina = this._oficina.currentOfficeData.id.codigo;
    this.obtenerOficina(this.codigoOficina);
    this.usuario =  this._authService.getUsuarioData().usuarioIngreso;
  }

  saveContinue() {
    console.log(this.listaContactosEmergenciaExtendida);
    this.guardarContactos();
  }

  goPrevious() {
    
    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
  }

  async cargarLideresPiso(){
    await this.getLideresPiso().then((data: any) => {
      if (data.resCode == 0){
        this.listaLideresPiso = data.resData;
        this.obtenerContactosEmergencia(this.codigoOficina);
      } else {
        this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de rutas nivel'});
        this.noError = false;
        this.loading = false;
      }
    });
  }


  getLideresPiso(){
    return new Promise((resolve)=>{
      this._lideresPisoService.getLideres(this.nombreOficina).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData : res.pageContent};
            resolve(data);
          },
          error: (err)=>{
            const e='Error _lideresPisoService.getLideres';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    });
  }

/*  armarListaLideresPisoExtendida(){
    for (let index = 0; index < this.listaLideresPiso.length; index++) {
      let actual = new LideresPisoExtendido();
      actual.existeEnBase = false;
      actual.seleccionado = false;
      actual.identificacion      = this.listaLideresPiso[index].identificacion     ;
      actual.primerNombre        = this.listaLideresPiso[index].primerNombre       ;
      actual.segundoNombre       = this.listaLideresPiso[index].segundoNombre      ;
      actual.primerApellido      = this.listaLideresPiso[index].primerApellido     ;
      actual.segundoApellido     = this.listaLideresPiso[index].segundoApellido    ;
      actual.correo              = this.listaLideresPiso[index].correo             ;
      actual.extensionTelefonica = this.listaLideresPiso[index].extensionTelefonica;
      actual.telefonoCelular     = this.listaLideresPiso[index].telefonoCelular    ;
      actual.usuarioSfsf         = this.listaLideresPiso[index].usuarioSfsf        ;
      actual.tipoRelacion        = this.listaLideresPiso[index].tipoRelacion       ;
      actual.nombre              = this.listaLideresPiso[index].nombre             ;

      for (let index1 = 0; index1 < this.listContactosEmergencia.length; index1++) {
        if(this.listaLideresPiso[index].correo ==  this.listContactosEmergencia[index1].correo && this.listContactosEmergencia[index1].estado == "A"){
          actual.existeEnBase = true;
          actual.seleccionado = true;
          break;
        }
      }

      this.listaContactosEmergenciaExtendida.push(actual);
    }
    console.log("lista extendida", this.listaContactosEmergenciaExtendida);
    this.busque  = true;
    this.loading = false;
  }
*/

/* Metodo actualizado para arreglar los check y que no guarden diferenciando los estados para luego agg a la base  SUD-BCALVOPIÑA 21/01/2014 */
armarListaLideresPisoExtendida() {
  const estadoContactosMap = new Map(this.listContactosEmergencia.map(contacto => [contacto.correo, contacto.estado]));
  this.listaContactosEmergenciaExtendida = [];

  // Determinar si la lista de contactos de emergencia está vacía
  const listaVacia = this.listContactosEmergencia.length === 0;

  this.listaLideresPiso.forEach(lider => {
    let actual = new LideresPisoExtendido();
    const contactoEstado = estadoContactosMap.get(lider.correo);
    
    actual.existeEnBase = contactoEstado !== undefined;
    // Seleccionar todos los contactos si la lista de contactos de emergencia está vacía
    // De lo contrario, seleccionar según el estado 'A' (Activo)
    actual.seleccionado = listaVacia || contactoEstado === 'A';

    // Copiar el resto de las propiedades del líder de piso.
    actual.identificacion = lider.identificacion;
    actual.primerNombre = lider.primerNombre;
    actual.segundoNombre = lider.segundoNombre;
    actual.primerApellido = lider.primerApellido;
    actual.segundoApellido = lider.segundoApellido;
    
    actual.correo = lider.correo;
/*
    actual.correo = lider.correo;
    actual.extensionTelefonica = lider.extensionTelefonica;
    actual.telefonoCelular = lider.telefonoCelular;
*/
 // Validar y asignar el valor por defecto para el teléfono y la extensión telefónica
    actual.telefonoCelular = lider.telefonoCelular || '----------';
    actual.extensionTelefonica = lider.extensionTelefonica || '----';

    actual.usuarioSfsf = lider.usuarioSfsf;
    actual.tipoRelacion = lider.tipoRelacion;
    actual.nombre = lider.nombre;

    this.listaContactosEmergenciaExtendida.push(actual);
  });

  console.log("lista extendida", this.listaContactosEmergenciaExtendida);
  this.busque = true;
  this.loading = false;
}

  async obtenerContactosEmergencia(codigoOficina : number){
    let listaContactosOficinas : ContactoOficinaContent[]=[];

    await this.getContactosOficina(codigoOficina).then((data: any) => {
      if (data.resCode == 0){
        listaContactosOficinas = data.resData;
      } else {
        this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de rutas nivel'});
        this.noError = false;
        this.loading = false;
      }
    });

    for (let indiceFila = 0; indiceFila < listaContactosOficinas.length; indiceFila++){
      if(listaContactosOficinas[indiceFila].estado=="A"){
        await this.getContactosEmergencia(listaContactosOficinas[indiceFila].id.codigoContacto).then((data: any) => {
          if (data.resCode == 0){
            this.listContactosEmergencia.push(data.resData[0]);
          } else {
            this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de rutas nivel'});
            this.noError = false;
            this.loading = false;
          }
        });
      }
    }
    console.log("listaLideresPiso", this.listaLideresPiso);
    console.log("listContactosEmergencia", this.listContactosEmergencia);
    this.armarListaLideresPisoExtendida();
}


  async guardarContactos(){
    //tengo que guardar los contactos de la lista extendida
    let codigoContacto: number = 0;
    
    for (let index = 0; index < this.listaContactosEmergenciaExtendida.length; index++) {
      const element : LideresPisoExtendido = this.listaContactosEmergenciaExtendida[index];

      if(!element.existeEnBase && element.seleccionado){
        for (let indexCO = 0; indexCO < this.listContactosOficina.length; indexCO++) {
          const element1 = this.listContactosOficina[indexCO];

          if(element1.contacto.correo == this.listaContactosEmergenciaExtendida[index].correo){
            codigoContacto = element1.contacto.codigo; //Si se setea es porque existe y hay que actualizar los estados a A
            break;
          }
        }

        if(codigoContacto != 0){//Se actualizan los estados a A
          console.log("actualizando estado a A");
          await this.actualizarEstadoContactoOficina(codigoContacto,this.codigoOficina,"A").then((data: any) => {
            if (data.resCode != 0){this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de rutas nivel'});
              this.noError = false;
              this.loading = false;
            }
          });

          if(this.noError){
            await this.actualizarEstadoContactoEmergencia(codigoContacto,"A").then((data: any) => {
              if (data.resCode != 0){
                this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de rutas nivel'});
                this.noError = false;
                this.loading = false;
              }
            });
          }
        }else{//Se crean
          await this.postContactoEmergencia(element).then((data: any) => {
            if (data.resCode != 0){
              this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de rutas nivel'});
              this.noError = false;
              this.loading = false;
            }else{
              codigoContacto = data.resData.codigo; //Aqui consigo el codigo que se le da al nuevo contacto
              console.log("el nuevo contacto tiene codigo",codigoContacto);
            }
          });

          if(this.noError){
            await this.postContactoOficina(codigoContacto,this.codigoOficina).then((data: any) => {
              if (data.resCode != 0){
                this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de rutas nivel'});
                this.noError = false;
                this.loading = false;
              }
            });
          }

        }
      }else if(element.existeEnBase && !element.seleccionado){
        console.log("inactivando")
        console.log(this.listContactosOficina)
        for (let indexCO = 0; indexCO < this.listContactosOficina.length; indexCO++) {
          const element = this.listContactosOficina[indexCO];

          if(element.contacto.correo == this.listaContactosEmergenciaExtendida[index].correo){
            codigoContacto = element.contacto.codigo; //De ley se setea porque existe en base y hay que actualizar los estados a I
            break;
          }
        }
        console.log("codigo contacto oficina",codigoContacto)

        if(codigoContacto != 0){//Se actualizan los estados a I
          await this.actualizarEstadoContactoOficina(codigoContacto,this.codigoOficina,"I").then((data: any) => {
            if (data.resCode != 0){this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de rutas nivel'});
              this.noError = false;
              this.loading = false;
            }
          });

          if(this.noError){
            await this.actualizarEstadoContactoEmergencia(codigoContacto,"I").then((data: any) => {
              if (data.resCode != 0){this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al grabar la informacion de rutas nivel'});
                this.noError = false;
                this.loading = false;
              }
            });
          }
        }
      }
      codigoContacto = 0;
    }
    //Aqui pasa la pagina
    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;
  }

  getContactosOficina(codigoOficina : number){
    return new Promise((resolve)=>{
      this._contactosEmergenciaService.getContactosOficina(codigoOficina).subscribe({
          next: (res:any)=>{
            this.listContactosOficina = res.pageContent;
            const data = { resCode: 0, resData : res.pageContent};
            resolve(data);
          },
          error: (err)=>{
            const e='Error _lideresPisoService.getLideres';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
    });

  }

  getContactosEmergencia(codigoContacto : number){
    return new Promise((resolve)=>{
      this._contactosEmergenciaService.getContactoEmergencia(codigoContacto).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData : res.pageContent};
            resolve(data);
          },
          error: (err)=>{
            const e='Error _lideresPisoService.getLideres';
            const data = { resCode: -1, error: e };
            resolve(data);
          }
        });
    });
  }

  actualizarEstadoContactoOficina(codigoContacto:number,codigoOficina:number,estado:string){
    return new Promise((resolve)=>{
      this._contactosEmergenciaService.putEstadoContactoOficina(codigoContacto,codigoOficina,estado,this.usuario).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData : res};
            resolve(data);
          },
          error: (err)=>{
            const e='Error _lideresPisoService.getLideres';
            const data = { resCode: -1, error: e };
            resolve(data);
          }
        });
    });
  }

  actualizarEstadoContactoEmergencia(codigoContacto:number,estado:string){
    return new Promise((resolve)=>{
      this._contactosEmergenciaService.putEstadoContactoEmergencia(codigoContacto,estado,this.usuario).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData : res};
            resolve(data);
          },
          error: (err)=>{
            const e='Error _lideresPisoService.getLideres';
            const data = { resCode: -1, error: e };
            resolve(data);
          }
        });
    });
  }

  postContactoEmergencia(objetoIn: LideresPisoExtendido){
    return new Promise((resolve)=>{
      this._contactosEmergenciaService.postContactoEmergencia(objetoIn,this.usuario).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData : res};
            resolve(data);
          },
          error: (err)=>{
            const e='Error _lideresPisoService.getLideres';
            const data = { resCode: -1, error: e };
            resolve(data);
          }
        });
    });
  }

  postContactoOficina(codigoContacto:number,codigoOficina:number){
    return new Promise((resolve)=>{
      this._contactosEmergenciaService.postContactoOficina(codigoContacto,codigoOficina,this.usuario).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0, resData : res};
            resolve(data);
          },
          error: (err)=>{
            const e='Error _lideresPisoService.getLideres';
            const data = { resCode: -1, error: e };
            resolve(data);
          }
        });
    });
  }

}
