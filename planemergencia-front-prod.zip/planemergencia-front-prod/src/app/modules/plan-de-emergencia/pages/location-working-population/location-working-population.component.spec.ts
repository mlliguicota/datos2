import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LocationWorkingPopulationComponent } from
  './location-working-population.component';

describe('LocationWorkingPopulationComponent', () => {
  let component: LocationWorkingPopulationComponent;
  let fixture: ComponentFixture<LocationWorkingPopulationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LocationWorkingPopulationComponent],
    })
        .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LocationWorkingPopulationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
