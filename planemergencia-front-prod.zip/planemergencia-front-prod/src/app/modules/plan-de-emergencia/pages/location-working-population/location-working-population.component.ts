import { Component, OnInit, ViewChild } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { IOficina } from '../../core/interfaces/oficina.interface';
import { IUsuario } from '../../core/interfaces/usuario.interface';
import { OfficeService } from '../../core/services/office.service';
import { NavigationService } from '../../core/services/navigation.service';
import { SharingFloorsService } from '../../core/services/sharing-floors.service';
import { SharingOfficeService } from
  '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';
import { HazardFooterComponent } from '../../components/hazard-footer/hazard-footer.component';
import { ArchivosoficinasService } from '../../core/services/archivosoficinas.service';
import { IArchivoPost } from '../../core/interfaces/descargarArchivo.interface';
import { GenService } from 'src/app/core/services/gen.service';
@Component({
  selector: 'app-location-working-population',
  templateUrl: './location-working-population.component.html',
  styleUrls: ['./location-working-population.component.scss'],
})
export class LocationWorkingPopulationComponent implements OnInit {
  currentOffice: IOficina = Constantes.OFICINA_DEFAULT;
  showBody: boolean = false;
  loading: boolean = false;
  toastKey: any;
  showButtons: boolean = false;
 existePortada : boolean = false ;
 existeGeolocalizacion : boolean = false ;
 lista_post : IArchivoPost[] = new Array<IArchivoPost>()

  @ViewChild(HazardFooterComponent) hijo: HazardFooterComponent;


  
  constructor(public sharingOffice: SharingOfficeService,
    private navigationService: NavigationService,
    private sharingFloor: SharingFloorsService,
    private toast: ToastService,
    private officeService: OfficeService,
    private _archivosoficinasService: ArchivosoficinasService ,
    private _genService : GenService ,
    private authService: AuthService) {
    this.toastKey = this.toast.genToastKey();
  }
 async  ngOnInit() {
    this.sharingOffice.SharingOfficeObservable.subscribe((office) => {
      if (office != Constantes.OFICINA_DEFAULT) {
        this.showButtons = true;
      } else {
        this.showButtons = false;
      }
    });



  }
  obtenerCurrentOffice(defaultOffice: boolean) {
    this.showBody = !defaultOffice;
    this.currentOffice = this.sharingOffice.currentOfficeData;
  }

  activeLoading(event: boolean) {
    this.loading = event;
  }
  private buildUserData(user: any): IUsuario {
    const usuario: IUsuario = {
      id: user.codigo,
      usuario: user.usuario,
      codigoRol: user.codigoRol,
    };
    return usuario;
  }




  async saveContinue() {
    const user: IUsuario = this.buildUserData(this.authService.getUsuarioData());
    this.loading = true;
  console.log("Inici de guardar")

/**INicicio de guardar oficina */
  const office = this.sharingOffice.currentOfficeData;
  let officeEdit: boolean = false;
  let creado :boolean= false
  let showMensajeGenerico: boolean = true; //** Ini JGilces | 15/08/2024 -> Cambio por error de mensajes en ingreso de informacion al crear una nueva oficina */
  let officeErrorMessage = 'Ocurrio un error al actualizar la oficina';
  if (office?.id.codigo) {
    await this.officeService.actualizarOficina(office, user).then((data: any) => {
      if (data.resCode == 0) {
        console.log('La actualizacion fue exitosa');
        officeEdit = true;
        creado =false
      } else {
        console.log(data.error);
        officeErrorMessage = data.error ?? officeErrorMessage;
      }
    }).catch((error: any) => {
      console.log(error);
      officeErrorMessage = error.message ?? officeErrorMessage;
    });
  } else {
    const tipoOficina = this.sharingOffice.currentOfficeTypeData;
    await this.officeService.crearOficina(office, user, tipoOficina).then((data: any) => {
      if (data.resCode == 0) {
        console.log('La craeacion fue exitosa');
        this.sharingOffice.currentOfficeData.id.codigo =  data.codigo
        this.sharingOffice.currentOfficeData.id.codigoEmpresa = data.codigoEmpresa
        officeEdit = true;
        creado =true
      } else {
        console.log(data.error);
        /*officeErrorMessage = data.error ?? officeErrorMessage;*/
        //** Ini JGilces | 15/08/2024 -> Cambio por error de mensajes en ingreso de informacion al crear una nueva oficina */
        console.log('error oficina 1', officeErrorMessage);
        let mensajesSplit = data.error.replace("[","").replace("]","").split(",");
        showMensajeGenerico = false;
        this.toast.mostrarToastError(mensajesSplit[0], this.toastKey);
        //** Fin JGilces -> Cambio por error de mensajes en ingreso de informacion al crear una nueva oficina */
      }
    }).catch((error: any) => {
      console.log(error);
      officeErrorMessage = error.message ?? officeErrorMessage;
      console.log('error oficina 2 , ',officeErrorMessage);
    });

     if (creado) {
      // obtenrgo la oficina creada
      let  response :any =   await this._genService.getOficinaNombre(office.edificacionOficina).toPromise() 
      this.sharingOffice.currentOfficeData.id.codigo =  response.pageContent[0].id.codigo
      this.sharingOffice.currentOfficeData.nombreOficina=  response.pageContent[0].nombreOficina
     }
   

  }

  console.log('EDITAR OFICINA: ', officeEdit);
  if (!officeEdit && showMensajeGenerico) { //** Ini JGilces | 15/08/2024 -> Cambio por error de mensajes en ingreso de informacion al crear una nueva oficina */
    this.toast.mostrarToastError(officeErrorMessage, this.toastKey);
    this.loading = false;
  }

  if(!showMensajeGenerico) this.loading = false; //** Ini JGilces | 15/08/2024 -> Cambio por error de mensajes en ingreso de informacion al crear una nueva oficina */

  /**Fin de guardar oficina */

    console.log( this.hijo.filesLocalidad.length)
    console.log( this.hijo.filesGeoubicacion.length)

    if (this.hijo.filesLocalidad.length > 0) {
      let archivo = "localidad_" +this.sharingOffice.currentOfficeData.id.codigo 
      await this._archivosoficinasService.RegistrarArchivo({
        
        archivoBase64 : this.hijo.filesLocalidad[0].url ,
        nombreArchivo :  archivo,
        rutaArchivo :"imagenes_plan"
       }).toPromise()

  /*     if (!this.existePortada) {
        await  this._archivosoficinasService.registrarArchivo({
          id: {
              codigoOficina:  this.sharingOffice.currentOfficeData.id.codigo ,
              codigoEmpresa:  this.sharingOffice.currentOfficeData.id.codigoEmpresa
            } ,
            nombreEquipo : 'Prueba' ,
            usuarioIngreso :user.usuario ,
            estado : "A",
            nombre :  archivo ,
            ruta : "/imagenes_plan" ,
            tipoArchivo :'imagen'
            }
        ).toPromise()
        
       }*/

    }
    if (this.hijo.filesGeoubicacion.length > 0) {
      let archivo2 = "geoubicacion_" +this.sharingOffice.currentOfficeData.id.codigo 
      await this._archivosoficinasService.RegistrarArchivo({
        archivoBase64 : this.hijo.filesGeoubicacion[0].url ,
        nombreArchivo : archivo2 ,
        rutaArchivo :"imagenes_plan"
       }).toPromise()
      
    /*  if (!this.existeGeolocalizacion) {
        await  this._archivosoficinasService.registrarArchivo({
          id: {
              codigoOficina:  this.sharingOffice.currentOfficeData.id.codigo ,
              codigoEmpresa:  this.sharingOffice.currentOfficeData.id.codigoEmpresa
            } ,
            nombreEquipo : 'Prueba' ,
            usuarioIngreso :user.usuario ,
            estado : "A",
            nombre :  archivo2 ,
            ruta : "/imagenes_plan" ,
            tipoArchivo :'imagen'
            }).toPromise()
      } */

    }
    

    console.log("FIn de guardar")

   // const user: IUsuario = this.buildUserData(this.authService.getUsuarioData());
    const post = await this.sharingFloor.appendProcedure(user ,creado);
    const put = await this.sharingFloor.updateProcedure(user);
    const remove = await this.sharingFloor.deleteProcedure(user);
 

  
    const bool = post && put && remove;
    console.log('IMPRIMIENDO REQUEST: ', bool);
    const badRequest = (!post ? 'Agregar\n' : '') +
      (!put ? 'Actualizar\n' : '') +
      (!remove ? 'Eliminar\n' : '');

    if (!bool) {
      this.toast.mostrarToastError('Ocurrio un error al procesar su peticion' +
        ' al : {{' + badRequest + '}}, por favor intentelo de nuevo.', this.toastKey);
      this.loading = false;
    }

    if (bool && officeEdit) {
      this.navigationService.NavigationObservableData = Constantes.NAVIGATION_GO_NEXT;
      this.toast.mostrarToastSuccess('Los datos han sido cargados' +
        ' correctamente!!', this.toastKey);
      this.loading = false;
    }
  }
}
