import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MetodoMeseriComponent } from './metodo-meseri.component';

describe('MetodoMeseriComponent', () => {
  let component: MetodoMeseriComponent;
  let fixture: ComponentFixture<MetodoMeseriComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MetodoMeseriComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MetodoMeseriComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
