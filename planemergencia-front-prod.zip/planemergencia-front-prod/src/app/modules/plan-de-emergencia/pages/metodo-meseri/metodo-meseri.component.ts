import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import {  Router } from '@angular/router';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import { MesseriService } from '../../core/services/messeri.service';


import { Meseri, MesseriDropdown } from '../../core/interfaces/messeri.interface';
import { PlanEmergenciaService } from '../../core/services/plan-emergencia.service';
import { AuthService } from 'src/app/core/services/auth.service';
import { HttpErrorResponse } from '@angular/common/http';
import { EvaluacionPrevencionService } from '../../core/services/evaluacion-prevencion.service';
import { IEvaluacionCuantitativaGet  , IEvaluacionCuantitativa} from '../../core/interfaces/evaluacionPrevencion.interface';
import { ToastService } from 'src/app/core/services/toast.service';
import { NavigationService } from '../../core/services/navigation.service';
import Constantes from '../../core/util/constantes';
import { DocumentoPdfService } from '../../core/services/documento-pdf.service';

@Component({
  selector: 'app-metodo-meseri',
  templateUrl: './metodo-meseri.component.html',
  styleUrls: ['./metodo-meseri.component.scss']
})


export class MetodoMeseriComponent implements OnInit {

  messeriPisos: MesseriDropdown[] = [];
  selectedMesseriPisos: MesseriDropdown ;

  messeriSuperficioMayor: MesseriDropdown[] = [];
  selectedmesseriSuperficioMayor : MesseriDropdown;

  messeriResistenciaFuego: MesseriDropdown[] = [];
  selectedMesseriResistenciaFuego : MesseriDropdown;

  messeriFalsosTechos: MesseriDropdown[] = [];
  selectedMesseriFalsostechos : MesseriDropdown;

  messeriDistanciasBomberos: MesseriDropdown[] = [];
  selectedMesseriDistanciasBomberos : MesseriDropdown;

  messeriAccesabilidadEdificios: MesseriDropdown[] = [];
  selectedMesseriAccesabilidadEdificios : MesseriDropdown;

  messeriPeligroActivacion: MesseriDropdown[] = [];
  selectedMesseriPeligroActivacion : MesseriDropdown;

  messeriCargaTermica: MesseriDropdown[] = [];
  selectedmesseriCargaTermica : MesseriDropdown;

  messeriCombustibilidad: MesseriDropdown[] = [];
  selectedMesseriCombustibilidad : MesseriDropdown;

  messeriOrdenLimpieza: MesseriDropdown[] = [];
  selectedOrdenLimpieza : MesseriDropdown;

  messeriAlmacenamientoAltura: MesseriDropdown[] = [];
  selectedMesseriAlmacenamientoAltura: MesseriDropdown;

  messeriAlmacenamientoAlturaFc: MesseriDropdown[] = [];
  selectedMesseriAlmacenamientoAlturaFc: MesseriDropdown;

  messeriPropagabilidadVertical: MesseriDropdown[] = [];
  selectedMesseriPropagabilidadVertical: MesseriDropdown;

  messeriPropagabilidadHorizontal: MesseriDropdown[] = [];
  selectedMesseriPropagabilidadHorizontal: MesseriDropdown;

  messeriDestructibilidadCalor: MesseriDropdown[] = [];
  selectedMesseriDestructibilidadCalor: MesseriDropdown;

  messeriDestructibilidadHumo: MesseriDropdown[] = [];
  selectedMesseriDestructibilidadHumo: MesseriDropdown;

  messeriDestructibilidadCorrosion: MesseriDropdown[] = [];
  selectedMesseriDestructibilidadCorrosion: MesseriDropdown;

  messeriDestructibilidadAgua: MesseriDropdown[] = [];
  selectedMesseriDestructibilidadAgua: MesseriDropdown;


  
  empresa: string = "";
  ubicacion: string = "";
  direccion: string = "";
  fecha: string = "";

  // Metodo Messeri
  // subtotal x
      mess_pisos : number = 0;
      mess_superficie_mayor  : number = 0;
      mess_resistencia_fuego : number = 0;
      mess_falsos_techos : number = 0;
      mess_distancia_bomberos : number = 0;
      mess_accesabilidad : number= 0;
      mess_peligro_activacion : number= 0;
      mess_carga_termica : number=0;
      mess_combustibilidad : number=0;
      mess_orden_limpieza : number=0;
      mess_almacenamiento_altura : number=0;
      mess_almacenamiento_altura_fc : number=0;
      mess_propagabilidad_vertical : number =0;
      mess_propagabilidad_horizontal : number =0;
      mess_destructibilidad_calor : number =0;
      mess_destructibilidad_humo : number=0;
      mess_destructibilidad_corrosion : number=0;
      mess_destructibilidad_agua : number=0;


  mess_subtotalx: number= 0;
  valor : number= 0;

  /// subtotal y 
  messeriExtintores: MesseriDropdown[] = [];
  selectedExtintores : MesseriDropdown;

  messeriBocasIncendio: MesseriDropdown[] = [];
  selectedBocasIncendio : MesseriDropdown;

  messeriColumnasHidratantes: MesseriDropdown[] = [];
  selectedColumnasHidratantes : MesseriDropdown;

  messeriDetectoresIncendios: MesseriDropdown[] = [];
  selectedDetectoresIncendios : MesseriDropdown;

  messeriRoceadoresAutomaticos: MesseriDropdown[] = [];
  selectedRoceadoresAutomaticos : MesseriDropdown;

  messeriAgentesGasesos: MesseriDropdown[] = [];
  selectedAgentesGaseosos : MesseriDropdown;

 /* mess_extintores : number=0;
  mess_bocas_incendio  : number=0; 
  mess_columnas_hidratantes  : number=0; 
  mess_detectores_incendio  : number=0; 
  mess_roceadores_automaticos : number = 0;
  mess_agentes_gaseosos : number = 0;*/
  mess_subtotal_y: number= 0;
  valor_y : number= 0;


  accion: string = 'INSERTAR';

  minimo : number = 0
  maximo : number = 4

     /// se deben setear al inicio
     codigoOficina : number = 2
     codigoEmpresa : number = 1 ;
     usuario : string = 'prueba' ;
  



     codigo : number;
     lb_existePlanEmergencia : boolean;
     valorMesseri :number;
     categoriaMesseri : string;

     evaluacionCuantitativa : IEvaluacionCuantitativa [];

  tipo5 : string="[05]"
  loading : boolean = true
  toastKey: any;

  constructor(private location:Location ,
    private route:Router ,
    private _oficina: SharingOfficeService ,
    private _messeriService : MesseriService ,
    private _PlanEmergenciaService : PlanEmergenciaService  ,
    private _authService : AuthService ,
    private toast: ToastService,
    private navigationService: NavigationService,
    private _evaluacionPrevencionService : EvaluacionPrevencionService ,
    private _documentoPdfService :DocumentoPdfService , ) { 


}


 inicializarCombo(){


  console.log('Inicializo Variables')
  this.messeriPisos = [
    { code: '0' ,  name : '0'},
    {code: '1' ,  name : '1'},
    {code: '2' ,  name : '2'},
    {code: '3' ,  name : '3'}
 ]

 this.messeriSuperficioMayor = [
   { code: '0' ,  name : '0'},
   {code: '1' ,  name : '1'},
   {code: '2' ,  name : '2'},
   {code: '3' ,  name : '3'},
   {code: '4' ,  name : '4'},
   {code: '5' ,  name : '5'}/*,
   {code: '6' ,  name : '6'}*/
]

this.messeriResistenciaFuego = [
 { code: '0' ,  name : '0'},
 {code: '5' ,  name : '5'},
 {code: '10' ,  name : '10'}
] 

this.messeriFalsosTechos = [
 { code: '0' ,  name : '0'},
 {code: '3' ,  name : '3'},
 {code: '5' ,  name : '5'}

]


this.messeriDistanciasBomberos = [
 { code: '0' ,  name : '0'},
 {code: '2' ,  name : '2'},
 {code: '6' ,  name : '6'} ,
 {code: '8' ,  name : '8'} ,
 {code: '10' ,  name : '10'} ,

]


this.messeriAccesabilidadEdificios = [
 { code: '0' ,  name : '0'},
 {code: '1' ,  name : '1'},
 {code: '3' ,  name : '3'} ,
 {code: '5' ,  name : '5'} 

]
this.messeriPeligroActivacion =  [
 { code: '0' ,  name : '0'},
 {code: '5' ,  name : '5'},
 {code: '10' ,  name : '10'} 

]

this.messeriCargaTermica =  [
 { code: '0' ,  name : '0'},
 {code: '5' ,  name : '5'},
 {code: '10' ,  name : '10'} 

]



this.messeriCombustibilidad=   [
{ code: '5' ,  name : '5'},
{code: '3' ,  name : '3'},
{code: '0' ,  name : '0'} 

]

this.messeriOrdenLimpieza=  [
{ code: '0' ,  name : '0'},
{code: '5' ,  name : '5'},
{code: '10' ,  name : '10'} 

]

this.messeriAlmacenamientoAltura =   [
{ code: '0' ,  name : '0'},
{code: '2' ,  name : '2'},
{code: '3' ,  name : '3'} 

]

this.messeriAlmacenamientoAlturaFc  =   [
{ code: '0' ,  name : '0'},
{code: '2' ,  name : '2'},
{code: '3' ,  name : '3'} 
]

this.messeriPropagabilidadVertical =   [
{ code: '0' ,  name : '0'},
{code: '3' ,  name : '3'},
{code: '5' ,  name : '5'}  
]

this.messeriPropagabilidadHorizontal =   [
{ code: '0' ,  name : '0'},
{code: '3' ,  name : '3'},
{code: '5' ,  name : '5'}  
]


this.messeriDestructibilidadCalor=   [
{ code: '0' ,  name : '0'},
{code: '5' ,  name : '5'},
{code: '10' ,  name : '10'}  
]

this.messeriDestructibilidadHumo =  [
{ code: '0' ,  name : '0'},
{code: '5' ,  name : '5'},
{code: '10' ,  name : '10'}  
]

this.messeriDestructibilidadCorrosion=  [
{ code: '0' ,  name : '0'},
{code: '5' ,  name : '5'},
{code: '10' ,  name : '10'}  
]

this.messeriDestructibilidadCorrosion=  [
{ code: '0' ,  name : '0'},
{code: '5' ,  name : '5'},
{code: '10' ,  name : '10'}  
]

this.messeriDestructibilidadAgua =  [
{ code: '0' ,  name : '0'},
{code: '5' ,  name : '5'},
{code: '10' ,  name : '10'}  
]

this.messeriExtintores=  [
{code: '0' ,  name : '0 (no tiene)'},
{ code: '1' ,  name : '1'},
{code: '2' ,  name : '2'}
]

this.messeriBocasIncendio =  [
{ code: '0' ,  name : '0 (no tiene)'},
{ code: '2' ,  name : '2'},
{code: '4' ,  name : '4'}
]


this.messeriColumnasHidratantes =  [
{ code: '0' ,  name : '0 (no tiene)'},
{ code: '2' ,  name : '2'},
{code: '4' ,  name : '4'}
]


this.messeriDetectoresIncendios =  [
{ code: '0' ,  name : '0'},
{code: '4' ,  name : '4'}
]


this.messeriRoceadoresAutomaticos =  [
{ code: '0' ,  name : '0 (no tiene)'},
{ code: '5' ,  name : '5'},
{code: '8' ,  name : '8'}
]


this.messeriAgentesGasesos =  [
{ code: '0' ,  name : '0 (no tiene)'},
{ code: '2' ,  name : '2'},
{code: '4' ,  name : '4'}
]
 }

 setearVariables(){

  console.log('seteo Variables')
  this.selectedMesseriPisos =  { code: '0' ,  name : '0'}
  this.selectedmesseriSuperficioMayor = { code: '0' ,  name : '0'}
  this.selectedMesseriResistenciaFuego = { code: '0' ,  name : '0'}
  this.selectedMesseriFalsostechos = { code: '0' ,  name : '0'}
  this.selectedMesseriDistanciasBomberos =  { code: '0' ,  name : '0'}
  this.selectedMesseriAccesabilidadEdificios =  { code: '0' ,  name : '0'}
  this.selectedMesseriPeligroActivacion = { code: '0' ,  name : '0'}
  this.selectedmesseriCargaTermica = { code: '0' ,  name : '0'}
  this.selectedMesseriCombustibilidad = { code: '0' ,  name : '0'}
  this.selectedOrdenLimpieza = { code: '0' ,  name : '0'}
  this.selectedMesseriAlmacenamientoAltura= { code: '0' ,  name : '0'}

   // setea variable factor de riesgo en 2 -- SUD BCALVOPIÑA
  this.selectedMesseriAlmacenamientoAlturaFc= { code: '0' ,  name : '0'}

  this.selectedMesseriPropagabilidadVertical= { code: '0' ,  name : '0'}
  this.selectedMesseriPropagabilidadHorizontal= { code: '0' ,  name : '0'}
  this.selectedMesseriDestructibilidadCalor= { code: '0' ,  name : '0'}
  this.selectedMesseriDestructibilidadHumo= { code: '0' ,  name : '0'}
  this.selectedMesseriDestructibilidadCorrosion= { code: '0' ,  name : '0'}
  this.selectedMesseriDestructibilidadAgua = { code: '0' ,  name : '0'}


  this.selectedExtintores = { code: '1' ,  name : '1'}
  this.selectedBocasIncendio = { code: '2' ,  name : '2'} 
  this.selectedColumnasHidratantes =  { code: '2' ,  name : '2'} 
  this.selectedDetectoresIncendios = { code: '0' ,  name : '0'} 
  this.selectedRoceadoresAutomaticos =  { code: '5' ,  name : '5'}  
  this.selectedAgentesGaseosos =  { code: '2' ,  name : '2'};

 }


  nuevoMeserri(){
    this.setearVariables()
  }

  ngOnInit(): void {
    
    this.InicializarMesseri();

    }



  async  InicializarMesseri(){
    this.loading = true;
    this.obtenerEvaluacionCuantitativa() ; // no necesito que se demeore en cargar
    this.inicializarCombo();
 // setea variables
    this.codigoOficina = this._oficina.currentOfficeData.id.codigo
    this.codigoEmpresa =  this._oficina.currentOfficeData.id.codigoEmpresa

    this.usuario =  this._authService.getUsuarioData().usuarioIngreso
    console.log("Usuario =>>>>>>>>>>>>>" + this.usuario)

    // setea datos de  cabecera
    console.log('usuario' + this._authService.getUsuarioData().usuarioIngreso)
   this.empresa = this._oficina.currentOfficeData.razonSocial;
    this.ubicacion = this._oficina.currentOfficeData.edificacionOficina;
    this.direccion = this._oficina.currentOfficeData.direccionOficina
    let date: Date = new Date();
    this.fecha = date.getDate() + "-" + (date.getMonth()+1) +"-" +  date.getFullYear() ;

    await this.VerificaMesseri()
    await this.VerificarPlanEmergencia()
    this.sumar()
    this.sumar_y()
    this.loading = false;
           
    }

 

    obtenerEvaluacionCuantitativa() {
    
        this._evaluacionPrevencionService.obtenerEvaluacionCuantitativa().subscribe({
          next: (res: IEvaluacionCuantitativaGet)=>{
            if (res.totalItems > 0) {
              console.log('Obteniendo evaluaciacion Cuantitativas');
              console.log(res);
            this.evaluacionCuantitativa = res.pageContent;
            this.evaluacionCuantitativa.sort(
              (firstObject: IEvaluacionCuantitativa, secondObject: IEvaluacionCuantitativa) =>
                (firstObject.rangoInicio > secondObject.rangoInicio) ? 1 : -1 )
              
            }
          },
          error: (err)=>{
            const e='Ocurrio un error inesperado obteniendo las oficinas';
          
          },
        });
    
    }


    VerificaMesseri () {
      return new Promise((resolve)=> {
          
     this._messeriService.obtenerMesseri(this.codigoEmpresa ,this.codigoOficina).subscribe(
      datos => { if(datos.totalItems==0){
                 console.log('No existe Messeri configurado'); 
                 console.log(datos)  
                 this.accion  = 'INSERTAR';
               this.nuevoMeserri()

            } else {
              console.log('Existe Messeri configurado'); 
              console.log(datos); 
              this.accion  = 'ACTUALIZAR';
              // inicializar variables 
             this.codigo = datos.pageContent[0].codigo
              this.selectedMesseriPisos =  { code: datos.pageContent[0].altura.toString() ,  name : datos.pageContent[0].altura.toString()}
              this.selectedmesseriSuperficioMayor = { code: datos.pageContent[0].superficieIncendios.toString() ,  name : datos.pageContent[0].superficieIncendios.toString()}
              this.selectedMesseriResistenciaFuego = { code: datos.pageContent[0].resistenciaFuego.toString() ,  name : datos.pageContent[0].resistenciaFuego.toString()}
              this.selectedMesseriFalsostechos = { code: datos.pageContent[0].falsoTecho.toString() ,  name : datos.pageContent[0].falsoTecho.toString()}
              this.selectedMesseriDistanciasBomberos =  { code: datos.pageContent[0].distanciaBomberos.toString() ,  name : datos.pageContent[0].distanciaBomberos.toString() }
              this.selectedMesseriAccesabilidadEdificios =  { code: datos.pageContent[0].accesibilidadEdificio.toString() ,  name : datos.pageContent[0].accesibilidadEdificio.toString()}
              this.selectedMesseriPeligroActivacion = { code: datos.pageContent[0].peligroActivacion.toString() ,  name : datos.pageContent[0].peligroActivacion.toString()}
              this.selectedmesseriCargaTermica = { code: datos.pageContent[0].cargaTermica.toString() ,  name : datos.pageContent[0].cargaTermica.toString() }
              this.selectedMesseriCombustibilidad = { code: datos.pageContent[0].combustibilidad.toString() ,  name : datos.pageContent[0].combustibilidad.toString()}
              this.selectedOrdenLimpieza = { code: datos.pageContent[0].ordenLimpieza.toString() ,  name : datos.pageContent[0].ordenLimpieza.toString()}
             
     // almacenamientoAltura variable modificada -- SUD BCALVOPIÑA
           
              this.selectedMesseriAlmacenamientoAltura= { code: datos.pageContent[0].almacenamientoAltura.toString() ,  name : datos.pageContent[0].almacenamientoAltura.toString()}

   // factorConcentracion variable agregada -- SUD BCALVOPIÑA
              this.selectedMesseriAlmacenamientoAlturaFc= { code: datos.pageContent[0].factorConcentracion.toString() ,  name : datos.pageContent[0].factorConcentracion.toString()}
              
              
              
              
              
              this.selectedMesseriPropagabilidadVertical= { code: datos.pageContent[0].propagabilidadVertical.toString() ,  name : datos.pageContent[0].propagabilidadVertical.toString()}
              this.selectedMesseriPropagabilidadHorizontal= { code: datos.pageContent[0].propagabilidadHorizontal.toString() ,  name : datos.pageContent[0].propagabilidadHorizontal.toString()}
              this.selectedMesseriDestructibilidadCalor= { code: datos.pageContent[0].destructibilidadCalor.toString() ,  name : datos.pageContent[0].destructibilidadCalor.toString()}
              this.selectedMesseriDestructibilidadHumo= { code: datos.pageContent[0].destructibilidadHumo.toString() ,  name : datos.pageContent[0].destructibilidadHumo.toString()}
              this.selectedMesseriDestructibilidadCorrosion= { code: datos.pageContent[0].destructibilidadCorrosion.toString() ,  name : datos.pageContent[0].destructibilidadCorrosion.toString()}
              this.selectedMesseriDestructibilidadAgua = { code: datos.pageContent[0].destructibilidadAgua.toString() ,  name : datos.pageContent[0].destructibilidadAgua.toString()}
            
            
              this.selectedExtintores = { code: datos.pageContent[0].extintores.toString() ,  name : datos.pageContent[0].extintores.toString()}
              this.selectedBocasIncendio = { code: datos.pageContent[0].bocasIncendio.toString() ,  name : datos.pageContent[0].bocasIncendio.toString()} 
              this.selectedColumnasHidratantes =  { code: datos.pageContent[0].columnasHidratantes.toString() ,  name : datos.pageContent[0].columnasHidratantes.toString()} 
              this.selectedDetectoresIncendios = { code: datos.pageContent[0].detectoresIncendio.toString() ,  name : datos.pageContent[0].detectoresIncendio.toString()} 
              this.selectedRoceadoresAutomaticos =  { code: datos.pageContent[0].rociadoresAutomaticos.toString() ,  name : datos.pageContent[0].rociadoresAutomaticos.toString()}  
              this.selectedAgentesGaseosos =  { code: datos.pageContent[0].extincionGaseosos.toString() ,  name : datos.pageContent[0].extincionGaseosos.toString()};

            }

            const dataRes = { resCode: 0 };
            resolve(dataRes);

      }  ,     (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al obtener los datos Messeri';
        const dataErr = { resCode: -1, error: e };
        console.log(e)
        resolve(dataErr);
        
   
      }


     )
      })

    }

    VerificarPlanEmergencia () {
      return new Promise((resolve)=> {
        this._PlanEmergenciaService.obtenerPlanEmergencia(this.codigoEmpresa , this.codigoOficina).subscribe(
          
          datos => {
            if(datos.totalItems==0){
                  console.log('No existe Plan de Emergencia Cofigurado')
                  this.lb_existePlanEmergencia = false
            }else {
                this.lb_existePlanEmergencia = true
                this.valorMesseri = datos.pageContent[0].valorMeseri;
                this.categoriaMesseri = datos.pageContent[0].categoriaMeseri;
              console.log('Existe Plan de Emergencia Configurado')
              console.log(datos)
    
            }
            const dataRes = { resCode: 0 };
            resolve(dataRes);
   
          },     (err: HttpErrorResponse) => {
            const e='Ocurrio un error inesperado al obtener los datos Messeri plan de emergencia';
            const dataErr = { resCode: -1, error: e };
            console.log(e)
            resolve(dataErr);
            
       
          }
         )

    
      }
      
      
      
      )

    }


   
 
   async saveContinue(){
    this.loading = true 
   
  if (this.accion == 'ACTUALIZAR') {
    console.log("Actualizanco ...................")
   await this.ActualizarMesseri()


  } else {
     console.log("Insertando ...................")
   await this. registrarMesseri()
    
  }
      

  this.categoriaMesseri = this.calculaCategoriaMesseri()
  this.valorMesseri = this.calculaMesseri();

  if ( this.lb_existePlanEmergencia){
    await  this.actualizarPlanEmergencia()
   
  }else {
    console.log('Registrando Plan Emergencia')
   await  this.registrarPlanEmergencia();


  }
  
  this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT; 

  this.toast.mostrarToastSuccess('Los datos han sido cargados'+
  ' correctamente!!', this.toastKey);  
     // LLAMO AL SERVCIO DE ACTUALIZAR EN EL PLAN DE EMERGENCIA
     this.loading = false

  
   }

   downloadPDF() {
    // Extraemos  
    let nombreArchivo :string = 'Metodo_meseri.pdf'
    this._documentoPdfService.downloadPDFMesseri( nombreArchivo , document.getElementById('htmlData') )
   // this._documentoPdfService.generarPDF( nombreArchivo )
    
  }

   actualizarPlanEmergencia(){
    return new Promise((resolve)=> {
      this._messeriService.actualizarPlanEmergencia({
        categoriaMeseri : this.categoriaMesseri,
        valorMeseri :this.valorMesseri ,
        id : {
               codigoEmpresa : this.codigoEmpresa,
              codigoOficina : this.codigoOficina
        } ,
         nombreEquipo : 'PRUEBA' ,
         usuarioModificacion : this.usuario
  
      }).subscribe( datos => {
        console.log(datos)
        const dataRes = { resCode: 0 };
        resolve(dataRes);

      },  (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al Actualizar en Plan de emergencia';
        const dataErr = { resCode: -1, error: e };
        console.log(e)
        resolve(dataErr); 
      
      })  
    
    })
   }

   registrarPlanEmergencia(){
    return new Promise((resolve)=> {  
    this._messeriService.registrarPlanEmergencia({
      categoriaMeseri : this.categoriaMesseri,
      valorMeseri :this.valorMesseri ,
      id : {
             codigoEmpresa : this.codigoEmpresa,
            codigoOficina : this.codigoOficina
      } ,
        estado : 'A' ,
        nombreEquipo : 'PRUEBA' ,
        usuarioIngreso : this.usuario
    }).subscribe( datos => {
      console.log(datos)
      const dataRes = { resCode: 0 };
      resolve(dataRes);
    
    } ,
    (err: HttpErrorResponse) => {
      const e='Ocurrio un error inesperado al Insertar en Plan de emergencia';
      const dataErr = { resCode: -1, error: e };
      console.log(e)
      resolve(dataErr); 
    
    }
    )

    })

   }
 
   ActualizarMesseri(){
    return new Promise((resolve)=> {
           this._messeriService.actualizarMesseri(
            {
              accesibilidadEdificio: Number(this.selectedMesseriAccesabilidadEdificios.code ),
        altura  : Number(this.selectedMesseriPisos.code ) ,  //Number(this.selectedMesseriAlmacenamientoAltura.code ) ,
        almacenamientoAltura: Number(this.selectedMesseriAlmacenamientoAltura.code ),
        bocasIncendio : Number(this.selectedBocasIncendio.code ) ,
        cargaTermica : Number(this.selectedmesseriCargaTermica.code ) ,
        codigoEmpresa : this.codigoEmpresa,  
        codigoOficina : this.codigoOficina , 
        columnasHidratantes : Number(this.selectedColumnasHidratantes.code ),
        combustibilidad : Number(this.selectedMesseriCombustibilidad.code ) ,
        destructibilidadAgua : Number(this.selectedMesseriDestructibilidadAgua.code ),
        destructibilidadCalor: Number(this.selectedMesseriDestructibilidadCalor.code ) ,
        destructibilidadCorrosion : Number(this.selectedMesseriDestructibilidadCorrosion.code ) ,
        destructibilidadHumo : Number(this.selectedMesseriDestructibilidadHumo.code )  ,
        detectoresIncendio : Number(this.selectedDetectoresIncendios.code ),
        distanciaBomberos : Number(this.selectedMesseriDistanciasBomberos.code ) ,
        extincionGaseosos : Number(this.selectedAgentesGaseosos.code )  ,
        extintores : Number(this.selectedExtintores.code )  ,


           // factorConcentracion variable agregada -- SUD BCALVOPIÑA
        factorConcentracion :  Number(this.selectedMesseriAlmacenamientoAlturaFc.code ),
        falsoTecho : Number(this.selectedMesseriFalsostechos.code ) ,
        ordenLimpieza : Number(this.selectedOrdenLimpieza.code ) ,
        peligroActivacion : Number(this.selectedMesseriPeligroActivacion.code )  ,
        propagabilidadHorizontal : Number(this.selectedMesseriPropagabilidadHorizontal.code )  ,
        propagabilidadVertical :  Number(this.selectedMesseriPropagabilidadVertical.code )  ,
        resistenciaFuego : Number(this.selectedMesseriResistenciaFuego.code ) ,
        rociadoresAutomaticos :  Number(this.selectedRoceadoresAutomaticos.code ) ,
        superficieIncendios : Number(this.selectedmesseriSuperficioMayor.code ) ,
        usuarioModificacion : this.usuario ,
        nombreEquipo : 'Prueba' ,
        codigo :  this.codigo
            }

           ).subscribe( (datos : any )=> {
             console.log(datos)
            const dataRes = { resCode: 0 };
            resolve(dataRes);
            

           } ,     (err: HttpErrorResponse) => {
            const e='Ocurrio un error inesperado al actualizar Messeri';
            const dataErr = { resCode: -1, error: e };
            console.log(e)
            resolve(dataErr);
          }
           )
    })

   }


    registrarMesseri(){

      return new Promise((resolve)=> {
        this._messeriService.registrarMesseri({
      
          accesibilidadEdificio: Number(this.selectedMesseriAccesabilidadEdificios.code ),
         altura  : Number(this.selectedMesseriPisos.code ) ,  //Number(this.selectedMesseriAlmacenamientoAltura.code ) ,
 
         // almacenamientoAltura variable modificada -- SUD BCALVOPIÑA
         almacenamientoAltura: Number(this.selectedMesseriAlmacenamientoAltura.code ),


         bocasIncendio : Number(this.selectedBocasIncendio.code ) ,
         cargaTermica : Number(this.selectedmesseriCargaTermica.code ) ,
         codigoEmpresa : this.codigoEmpresa,  
         codigoOficina : this.codigoOficina , 
         columnasHidratantes : Number(this.selectedColumnasHidratantes.code ),
         combustibilidad : Number(this.selectedMesseriCombustibilidad.code ) ,
         destructibilidadAgua : Number(this.selectedMesseriDestructibilidadAgua.code ),
         destructibilidadCalor: Number(this.selectedMesseriDestructibilidadCalor.code ) ,
         destructibilidadCorrosion : Number(this.selectedMesseriDestructibilidadCorrosion.code ) ,
         destructibilidadHumo : Number(this.selectedMesseriDestructibilidadHumo.code )  ,
         detectoresIncendio : Number(this.selectedDetectoresIncendios.code ),
         distanciaBomberos : Number(this.selectedMesseriDistanciasBomberos.code ) ,
         extincionGaseosos : Number(this.selectedAgentesGaseosos.code )  ,
         extintores : Number(this.selectedExtintores.code )  ,

        // factorConcentracion variable agregada -- SUD BCALVOPIÑA
         factorConcentracion :  Number(this.selectedMesseriAlmacenamientoAlturaFc.code ),


         falsoTecho : Number(this.selectedMesseriFalsostechos.code ) ,
         ordenLimpieza : Number(this.selectedOrdenLimpieza.code ) ,
         peligroActivacion : Number(this.selectedMesseriPeligroActivacion.code )  ,
         propagabilidadHorizontal : Number(this.selectedMesseriPropagabilidadHorizontal.code )  ,
         propagabilidadVertical :  Number(this.selectedMesseriPropagabilidadVertical.code )  ,
         resistenciaFuego : Number(this.selectedMesseriResistenciaFuego.code ) ,
         rociadoresAutomaticos :  Number(this.selectedRoceadoresAutomaticos.code ) ,
         superficieIncendios : Number(this.selectedmesseriSuperficioMayor.code ) ,
         usuarioIngreso : this.usuario ,
         nombreEquipo : 'Prueba' ,
         estado : 'A'
 
       }).subscribe((datos : any) => {
        const dataRes = { resCode: 0 };
            resolve(dataRes);
        console.log(datos)

      } ,    (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al registrar Messeri';
        const dataErr = { resCode: -1, error: e };
        console.log(e)
        resolve(dataErr);
      })


      })

    }


  
    goPrevious() {
      this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
    }
    
   

   sumar() {

    console.log('Suo Variables')

      this.valor = Number(this.selectedMesseriDestructibilidadAgua.code ) + Number(this.selectedMesseriDestructibilidadCorrosion.code) +
      Number(this.selectedMesseriPisos.code  ) + Number(this.selectedmesseriSuperficioMayor.code )     +
      Number(this.selectedMesseriResistenciaFuego.code  ) + Number(this.selectedMesseriFalsostechos.code ) +
      Number(this.selectedMesseriDistanciasBomberos.code  ) + Number(this.selectedMesseriAccesabilidadEdificios.code  ) +
      Number(this.selectedMesseriPeligroActivacion.code  ) + Number(this.selectedmesseriCargaTermica.code )+
      Number(this.selectedMesseriCombustibilidad.code  ) + Number(this.selectedOrdenLimpieza.code  )+
      Number(this.selectedMesseriAlmacenamientoAltura.code  ) + Number(this.selectedMesseriAlmacenamientoAlturaFc.code  )+
      Number(this.selectedMesseriPropagabilidadVertical.code  ) + Number(this.selectedMesseriPropagabilidadHorizontal.code  ) +
      Number(this.selectedMesseriDestructibilidadCalor.code  ) + Number(this.selectedMesseriDestructibilidadHumo.code ) ;
      
      this.mess_subtotalx = this.valor;

   }


   sumar_y() {
    console.log('Suo Variables Y')
      
     console.log(this.selectedExtintores.code)
    
    this.valor_y = Number(this.selectedExtintores.code  ) + Number(this.selectedBocasIncendio.code ) +
    Number(this.selectedColumnasHidratantes.code ) + Number(this.selectedDetectoresIncendios.code )     +
    Number(this.selectedRoceadoresAutomaticos.code ) + Number(this.selectedAgentesGaseosos.code )  ;   
    this.mess_subtotal_y = this.valor_y;

 }


  calculaMesseri(): number{
  
    return  ((5*this.mess_subtotalx)/129) + ((5*this.mess_subtotal_y)/26) +1;

  }


  
  calculaCategoriaMesseri(): string {
    this.sumar()
    this.sumar_y()
    let valor :number = this.calculaMesseri();
    let categoria : string = "" ;

     for (let index = 0; index <  this.evaluacionCuantitativa.length; index++) {
         categoria = this.evaluacionCuantitativa[index].categoria   
         if (valor >= this.evaluacionCuantitativa[index].rangoInicio  && valor<= this.evaluacionCuantitativa[index].rangoFin){    
                break
        }           
      
     }
      
    return categoria

}

}
