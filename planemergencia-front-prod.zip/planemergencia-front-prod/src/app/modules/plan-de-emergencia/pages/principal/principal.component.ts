import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';
import { NavigationService } from '../../core/services/navigation.service';
import Constantes from '../../core/util/constantes';

@Component({
  selector: 'app-principal',
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.scss'],
})
export class PrincipalComponent implements OnInit {
  menuItems: Array<any> = [];
  ind_current = 0;
  toastKey: any;
  showButtons: boolean = false;
  constructor(private _router: Router,
    private _activatedRoute: ActivatedRoute,
    private navigationService: NavigationService,
    private toast: ToastService) {
    this.toastKey = this.toast.genToastKey();
    this.menuItems = [
    
      {
        name: 'Ubicación y población trabajadora',
        path: 'location-working-population',
    //  path: 'puntoReunion',
      },
      
      {
        name: 'Contactos de emergencia',
        path: 'keep-emergency-contact',
      },
     
      {
        name: 'Descripción de la empresa',
        path: 'descripcionEmpresa',
      },
      
      {
        name: 'Identificación de factores de riesgos ' +
          'propios de la organización',
        path: 'factorRiesgo',
      },
      
      {//tiene un error en la funcion suma 
        name: 'Método Meseri',
        path: 'metodoMeseri',
      },

      //
     {
        name: 'Evaluación prevención y control de ' +
        'factores de riesgos detectados',
        path: 'evaluacionPrevencion',
      },
      
     
      {
        name: 'Recursos existentes para la prevención,' +
        ' detección, protección y control de incendios',
        path: 'recursosExistentes',
      },
      
      {
          name: 'Selección de Mantenimiento',
          path: 'seleccionarMantenimiento',
      },
      {
        name: 'Selección de Riesgos',
        path: 'seleccionarRiesgos',
      },
      
      
      {
        name: 'Tiempo de Salida',
        path: 'tiempoSalida',
      }, 
      
      {//Access to XMLHttpRequest at 'http://claro-eme-pec-eme.openshift-apps.conecel.com/pec/eme/emeMetodoInsht?codigoOficina=282&factoresRiesgo=Deslaves' from origin 'http://localhost:4200' has been blocked by CORS policy: No 'Access-Control-Allow-Origin' header is present on the requested resource.
        name: 'Evaluación cualitativa de riesgos naturales - Método INSHT',
        path: 'evaluacionCualiRiesgo',
      },

      
      {
        name: 'Distrubución del personal rutas de evacuación',
        path: 'distribucionEvacuacion',
      },


     {
        name: 'Formulario de Evacuación  punto de reunion',
            path: 'puntoReunion',
           
      },

      //
      
      {
        name: 'Carga Archivo',
            path: 'cargaArchivo',
           
      },
      
      { 
        name: 'Plan de Emergencia',
        path: 'planEmergencia',

      },

      {
        name: 'Descarga Archivo',
            path: 'descargarArchivo',
              
      },

    ];
  }
  // Angular Live cycle
  ngOnInit(): void {
    this.navigationService.navigationObservable.subscribe((navigate) => {
      if (navigate == Constantes.NAVIGATION_GO_NEXT) {
        this.goNext();
        this.navigationService.NavigationObservableData = Constantes.NAVIGATION_KEEP_CURRENT;
      } else if (navigate == Constantes.NAVIGATION_GO_PREVIOUS) {
        this.goPrevious();
        this.navigationService.NavigationObservableData = Constantes.NAVIGATION_KEEP_CURRENT;
      }
    });
  }
  // Methods
  changeSelected(index: number) {
    this.ind_current = index;
  }
  navigate(path: string) {
    this._router.navigate([path], { relativeTo: this._activatedRoute });
  }
  goNext() {
    const pathNext = this.menuItems[this.ind_current + 1].path;
    this.ind_current += 1;
    this.navigate(pathNext);
    this.toast.mostrarToastSuccess('Los datos han sido cargados' +
        ' correctamente!!', this.toastKey);
  }

  navigateNext() {
    const pathNext = this.menuItems[this.ind_current + 1].path;
    this.ind_current += 1;
    this.navigate(pathNext);
  }
  goPrevious() {
    const pathPrevious = this.menuItems[this.ind_current - 1].path;
    this.ind_current -= 1;
    this.navigate(pathPrevious);
  }
  isThereNext(): boolean {
    return this.ind_current != (this.menuItems.length - 1);
  }
  isTherePrevious(): boolean {
    return this.ind_current != 0;
  }
}
