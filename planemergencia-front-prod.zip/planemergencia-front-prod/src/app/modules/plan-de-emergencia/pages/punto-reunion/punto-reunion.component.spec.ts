import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PuntoReunionComponent } from './punto-reunion.component';

describe('PuntoReunionComponent', () => {
  let component: PuntoReunionComponent;
  let fixture: ComponentFixture<PuntoReunionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PuntoReunionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PuntoReunionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
