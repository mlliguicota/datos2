import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { NavigationService } from '../../core/services/navigation.service';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';
import { PuntoReunionService } from '../../core/services/punto-reunion.service';
import { IProbabilidad } from '../../core/interfaces/probabilidades.interface';
import { IConsecuencia } from '../../core/interfaces/consecuencias.interface';
import { IestimacionRiesgo } from '../../core/interfaces/estimacionRiesgo.interfaces';
import { IpeligroPuntoEncuentro, IpeligroPuntoEncuentroGet, IpeligroPuntoEncuentroPost, IpeligroPuntoEncuentroPut } from '../../core/interfaces/peligroPuntoEncuentro.interface';
import { PlanEmergenciaService } from '../../core/services/plan-emergencia.service';
import { IplanEmergencia } from '../../core/interfaces/planEmergencia.interface';
import { DocumentoPdfService } from '../../core/services/documento-pdf.service';
import { InivelOficina } from '../../core/interfaces/nivelOficina.interface';
import { NivelesOficinaService } from '../../core/services/niveles-oficina.service';







@Component({
  selector: 'app-punto-reunion',
  templateUrl: './punto-reunion.component.html',
  styleUrls: ['./punto-reunion.component.scss']
})
export class PuntoReunionComponent implements OnInit {

  constructor(
    private _oficina: SharingOfficeService ,
    private _authService : AuthService ,
    private toast: ToastService,
    private navigationService: NavigationService,
    private _PlanEmergenciaService : PlanEmergenciaService ,
    private _puntoReunionService : PuntoReunionService,
    private _documentoPdfService :DocumentoPdfService ,
    private _nivelesOficiona : NivelesOficinaService ,

  ) { }

  nombreOficina :string = "";
  puntoEncuentro :string = "";
  puntoEncuentroTmp :string = "";
  ciudad :string ="";
  fechaEvaluacion :string ="";
  realizador :string ="";
  numeroColaboradores :string = "";
  numeroVisitantes : string = "";


// selecciones  probabilidad
selecccion_p_existencia :string  = "";
selecccion_p_desniveles :string  = "";
selecccion_p_transito :string  = "";
selecccion_p_proximidad :string  = "";
selecccion_p_existencia_l :string  = "";
selecccion_p_piso :string  = "";


// selecciones consecuencia
selecccion_c_existencia :string  = "";
selecccion_c_desniveles :string  = "";
selecccion_c_transito :string  = "";
selecccion_c_proximidad :string  = "";
selecccion_c_existencia_l :string  = "";
selecccion_c_piso :string  = "";


// selecciones estimacion riesgo
selecccion_er_existencia :string  = "";
selecccion_er_desniveles :string  = "";
selecccion_er_transito :string  = "";
selecccion_er_proximidad :string  = "";
selecccion_er_existencia_l :string  = "";
selecccion_er_piso :string  = "";

/* CAMBIO Y CORRECCION ORTOGRÁFICO 21/12/2023 SUD-BC  */
existencia :string = "Existencia de Objetos Peligrosos o edificaciones que pueden caer sobre las personas"
desniveles :string ="Desniveles u obstáculos que pueden provocar caídas de las personas"
transito :string = "Tránsito de vehículos similares que pueden provocar atropellamiento"
proximidad :string = "Proximidad de sustancias inflamables que pueden provocar un incendio"
existencias_electricas :string ="Existencias de líneas eléctricas o equipos energizados que puedan causar accidentes"
pisos :string = "Pisos sobre el que se ubican las personas es inestables y puede provocar caídas a otro nivel"

loading : boolean = true
toastKey: any;
codigoOficina :number;
codigoEmpresa : number;
usuario : string;
inhabilitado :boolean = true;

listaProbabilidades : Array<IProbabilidad> = new Array<IProbabilidad>()
listaConsecuencias : Array<IConsecuencia> = new Array<IConsecuencia>()
listaEstimaciones : Array<IestimacionRiesgo> = new Array<IestimacionRiesgo>()
listapeligroPuntoEncuentro : Array<IpeligroPuntoEncuentro> = new Array<IpeligroPuntoEncuentro>()
listaPut : Array<IpeligroPuntoEncuentroPut> = new Array <IpeligroPuntoEncuentroPut>()
listaPost : Array<IpeligroPuntoEncuentroPost> = new Array <IpeligroPuntoEncuentroPost>()
listaPlanEmergencia :IplanEmergencia[];
lista_niveles_oficinas : InivelOficina[] = new Array<InivelOficina>();
  ngOnInit(): void {
    this.loading = false;

    this.codigoOficina = this._oficina.currentOfficeData.id.codigo
    this.codigoEmpresa =  this._oficina.currentOfficeData.id.codigoEmpresa

    this.usuario =  this._authService.getUsuarioData().usuarioIngreso
    console.log("Usuario =>>>>>>>>>>>>>" + this.usuario)
    this.inicializarCabecera()
    
    
  }





  downloadPDF() {
    // Extraemos el
    let nombreArchivo :string = 'Punto_Reunion.pdf'
    this._documentoPdfService.downloadPDF( nombreArchivo , document.getElementById('htmlData') )
   
  }



 async inicializarCabecera(){
       this.loading = true
       this.nombreOficina = this._oficina.currentOfficeData.nombreOficina;
     
       this.ciudad = this._oficina.currentOfficeData.ciudadOficina;

       let date: Date = new Date();
       this.fechaEvaluacion = date.getDate() + "-" + (date.getMonth()+1)  +"-" +  date.getFullYear() ;

       let response :any = await this._puntoReunionService.obtenerProbabilidades().toPromise()
       this.listaProbabilidades = response.pageContent

       let response2 :any = await this._puntoReunionService.obtenerConsecuencias().toPromise()
       this.listaConsecuencias = response2.pageContent

       let response3 :any = await this._puntoReunionService.obtenerEstimacionesRiesgos().toPromise()
       this.listaEstimaciones = response3.pageContent

       let response4 :any = await this._puntoReunionService.obtenerPeligroPuntoEncuentro(this.codigoEmpresa , this.codigoOficina).toPromise()
       this.listapeligroPuntoEncuentro = response4.pageContent

      let response5:any = await this._PlanEmergenciaService.obtenerPlanEmergencia(this.codigoEmpresa , this.codigoOficina).toPromise()
      this.listaPlanEmergencia  =response5.pageContent
      this.puntoEncuentroTmp  = this.listaPlanEmergencia[0].puntoEncuentro
      this.puntoEncuentro =this.listaPlanEmergencia[0].puntoEncuentro
   
      this.realizador = this.listaPlanEmergencia[0].elaborador

       console.log (this.listaConsecuencias)

      
       // Obtener info pisos
let responseInfoPisos :any = await this._nivelesOficiona.obtenerNivelesOficinas(this.codigoEmpresa, this.codigoOficina).toPromise();
this.lista_niveles_oficinas = responseInfoPisos.pageContent;

let valor :number = 0;
let numero_visitantes :number = 0;
    

this.lista_niveles_oficinas.forEach(niveles =>  {
  valor = valor + niveles.totalEmpleadosPiso
  numero_visitantes = numero_visitantes + niveles.visitantes
})

this.numeroColaboradores =  valor.toString();
this.numeroVisitantes = numero_visitantes.toString();
     
this.setearDatosIniciales()

       this.loading = false

  }


 setearDatosIniciales(){

   this.listapeligroPuntoEncuentro.forEach(punto => {

let indice = this.listaEstimaciones.findIndex(estimacion =>  estimacion.codigo == punto.codigoEstimacionRiesgo  )                     
let probabilidad :string =""
let consecuencia :string =""

if (indice  >= 0) {
  probabilidad=  this.obtieneValorProbabilidad(this.listaEstimaciones[indice].codigoProbabilidad)  
  consecuencia=  this.obtieneValorConsecuencia(this.listaEstimaciones[indice].codigoConsecuencia) 
}


  switch (punto.peligroIdentificado) {
      case this.existencia:
         this.selecccion_p_existencia = probabilidad
         this.selecccion_c_existencia = consecuencia
          break;
      case this.desniveles:
          this.selecccion_c_desniveles = consecuencia
          this.selecccion_p_desniveles  = probabilidad

          break;
      case this.transito:
          this.selecccion_c_transito = consecuencia
          this.selecccion_p_transito  = probabilidad
          
          break;
      case this.proximidad:
          this.selecccion_c_proximidad = consecuencia
          this.selecccion_p_proximidad = probabilidad

              break;
        case this.existencias_electricas:
          this.selecccion_c_existencia_l = consecuencia
          this.selecccion_p_existencia_l = probabilidad
              break;
      case this.pisos:
            this.selecccion_p_piso  = probabilidad
            this.selecccion_c_piso = consecuencia
                break;

      default:
          console.log("ninguna opcion");
          break;
  }
            

   })
  


   this.generarEstimacion()

 }


goPrevious() {
  this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
   
}

 async saveContinue(){
   

  this.loading = true
    this.generarEstimacion()
    this.llenaListasGuardado()

  if (this.listaPost.length>0) {
    console.log('POSt')
    console.log(this.listaPost)
     await this._puntoReunionService.registrarPeligroPuntoEncuentro(this.listaPost).toPromise()
  }

  if (this.listaPut.length>0) {
    console.log('PUt')
    console.log(this.listaPut)
    await this._puntoReunionService.actualizarPeligroPuntoEncuentro(this.listaPut).toPromise()
  }
  console.log("nuevo =>" +  this.puntoEncuentro +"anterior" +this.puntoEncuentroTmp)
  if (this.puntoEncuentroTmp !=this.puntoEncuentro){

   await   this._puntoReunionService.actualizarPlanEmergencia({
        puntoEncuentro : this.puntoEncuentro,
        id : {
               codigoEmpresa : this.codigoEmpresa,
              codigoOficina : this.codigoOficina
        } ,
         nombreEquipo : 'PRUEBA' ,
         usuarioModificacion : this.usuario

      }).toPromise()
 

  }
  this.loading = false
  this.toast.mostrarToastSuccess('Datos grabados correctamente', this.toastKey);  
    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;
     
  }


  llenaDatos(probabilidad :number , consecuencia :number  , peligroIdent :string){
    let valorEstimacion =   this.obtieneCodigoEstimacion(probabilidad,consecuencia) ;
 
    let indice = this.listapeligroPuntoEncuentro.findIndex(pel =>  pel.peligroIdentificado == peligroIdent )                     

    if (indice  >= 0) {    // ya existe PUT
     this.listaPut.push({
          codigo: this.listapeligroPuntoEncuentro[indice].codigo  ,
          codigoEmpresa :this.codigoEmpresa ,
          codigoEstimacionRiesgo : valorEstimacion ,
          codigoOficina : this.codigoOficina ,
          nombreEquipo : 'Nombre Equipo' ,
          peligroIdentificado : peligroIdent ,
          usuarioModificacion : this.usuario

     })

    }else { // No existe Post
      this.listaPost.push({

        codigoEmpresa :this.codigoEmpresa ,
        codigoEstimacionRiesgo : valorEstimacion ,
        codigoOficina : this.codigoOficina ,
        nombreEquipo : 'Nombre Equipo' ,
        peligroIdentificado : peligroIdent ,
        estado : 'A' ,
        usuarioIngreso :this.usuario
 

   })

    }

  }

  llenaListasGuardado(){
   
    if (this.selecccion_er_existencia.length>0) {

        this.llenaDatos(this.obtieneCodigoProbabilidad(this.selecccion_p_existencia) ,
        this.obtieneCodigoConsecuencia(this.selecccion_c_existencia) , this.existencia) 

    }

    if (this.selecccion_er_desniveles.length>0) {

      this.llenaDatos(this.obtieneCodigoProbabilidad(this.selecccion_p_desniveles) ,
      this.obtieneCodigoConsecuencia(this.selecccion_c_desniveles) , this.desniveles) 
      
    }

    if (this.selecccion_er_transito.length>0) {
      this.llenaDatos(this.obtieneCodigoProbabilidad(this.selecccion_p_transito) ,
      this.obtieneCodigoConsecuencia(this.selecccion_c_transito) , this.transito) 
    }

    if (this.selecccion_er_proximidad.length>0) {
      this.llenaDatos(this.obtieneCodigoProbabilidad(this.selecccion_p_proximidad) ,
      this.obtieneCodigoConsecuencia(this.selecccion_c_proximidad) , this.proximidad) 
    }

    if (this.selecccion_er_existencia_l.length>0) {
      this.llenaDatos(this.obtieneCodigoProbabilidad(this.selecccion_p_existencia_l) ,
      this.obtieneCodigoConsecuencia(this.selecccion_c_existencia_l) , this.existencias_electricas) 
    }

    if (this.selecccion_er_piso.length>0) {
      this.llenaDatos(this.obtieneCodigoProbabilidad(this.selecccion_p_piso) ,
      this.obtieneCodigoConsecuencia(this.selecccion_c_existencia_l) , this.pisos) 
    }



  }


  generarEstimacion(){
    this.estimacionDesnivel();
    this.estimacionExistencia()
    this.estimacionExistenciaL()
    this.estimacionPiso()
    this.estimacionProximidad()
    this.estimacionTransito()
  }

  obtieneCodigoEstimacion(probabilidad : number , consecuencia : number): number {

  
    let indice = this.listaEstimaciones.findIndex(estimacion =>  estimacion.codigoConsecuencia == consecuencia &&  estimacion.codigoProbabilidad == probabilidad  )                     
    let valor  = -1 
    if (indice  >= 0) {
      valor=  this.listaEstimaciones[indice].codigo
    }
    return valor

  }



  obtieneValorProbabilidad(probabilidad : number):string{
     
    let indice = this.listaProbabilidades.findIndex(prob =>    prob.codigo == probabilidad  )                     
    let valor  =  "" 
    if (indice  >= 0) {
      valor=  this.listaProbabilidades[indice].gradoCorto
    }
    return valor
  }


  obtieneValorConsecuencia(consecuencia :number) :string
  {      
    let indice = this.listaConsecuencias.findIndex(conse =>    conse.codigo == consecuencia  )                     
    let valor  = "" 
    if (indice  >= 0) {
      valor=  this.listaConsecuencias[indice].gradoCorto
    } 
    return valor
  }




  obtieneCodigoProbabilidad(probabilidad : string):number{
     
    let indice = this.listaProbabilidades.findIndex(prob =>    prob.gradoCorto == probabilidad  )                     
    let valor  = -1 
    if (indice  >= 0) {
      valor=  this.listaProbabilidades[indice].codigo
    }
    return valor
  }

  obtieneCodigoConsecuencia(consecuencia :string) :number
  {      
    let indice = this.listaConsecuencias.findIndex(conse =>    conse.gradoCorto == consecuencia  )                     
    let valor  = -1 
    if (indice  >= 0) {
      valor=  this.listaConsecuencias[indice].codigo
    } 
    return valor
  }


  estimacionExistencia(){
      console.log(this.selecccion_p_existencia)
      console.log(this.selecccion_c_existencia)
      this.selecccion_er_existencia =   this.obtenerEstimacion(this.selecccion_p_existencia ,this.selecccion_c_existencia )
  }

 
  estimacionDesnivel(){
    console.log(this.selecccion_p_desniveles)
    console.log(this.selecccion_c_desniveles)
    this.selecccion_er_desniveles =   this.obtenerEstimacion(this.selecccion_p_desniveles ,this.selecccion_c_desniveles )
}
 
estimacionTransito(){
  console.log(this.selecccion_p_transito)
  console.log(this.selecccion_c_transito)
  this.selecccion_er_transito =   this.obtenerEstimacion(this.selecccion_p_transito ,this.selecccion_c_transito )
}

estimacionProximidad(){
  console.log(this.selecccion_p_proximidad)
  console.log(this.selecccion_c_proximidad)
  this.selecccion_er_proximidad =   this.obtenerEstimacion(this.selecccion_p_proximidad ,this.selecccion_c_proximidad )
}

estimacionExistenciaL(){
  console.log(this.selecccion_p_existencia_l)
  console.log(this.selecccion_c_existencia_l)
  this.selecccion_er_existencia_l =   this.obtenerEstimacion(this.selecccion_p_existencia_l ,this.selecccion_c_existencia_l )
}

estimacionPiso(){
  console.log(this.selecccion_p_piso)
  console.log(this.selecccion_c_piso)
  this.selecccion_er_piso =   this.obtenerEstimacion(this.selecccion_p_piso ,this.selecccion_c_piso )
}



  obtenerEstimacion( probabilidad : string , consecuencia :string)  : string  {
   
         let valor :string = '';
if ( probabilidad == 'B'  ) 
{

    switch (consecuencia) {
      case 'LD':
        valor = 'TRIVIAL';
          break;
      case 'D':
        valor = 'TOLERABLE';
          break;
      case 'ED':
        valor = 'MODERADO';
          break;
      default:
          console.log("ninguna opcion");
          break;
  }


} 


if ( probabilidad == 'M'  ) 
{
  switch (consecuencia) {
    case 'LD':
      valor = 'TOLERABLE';
        break;
    case 'D':
      valor = 'MODERADO';
        break;
    case 'ED':
      valor = 'IMPORTANTE';
        break;
    default:
        console.log("ninguna opcion");
        break;
}

} 


if ( probabilidad == 'A'  ) 
{
 
  switch (consecuencia) {
    case 'LD':
      valor = 'MODERADO';
        break;
    case 'D':
      valor = 'IMPORTANTE';
        break;
    case 'ED':
      valor = 'INTOLERABLE';
        break;
    default:
        console.log("ninguna opcion");
        break;
}


  } 


return valor 


  }



}
