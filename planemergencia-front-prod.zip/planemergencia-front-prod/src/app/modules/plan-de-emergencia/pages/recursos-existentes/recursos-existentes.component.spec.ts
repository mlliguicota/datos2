import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecursosExistentesComponent } from './recursos-existentes.component';

describe('RecursosExistentesComponent', () => {
  let component: RecursosExistentesComponent;
  let fixture: ComponentFixture<RecursosExistentesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RecursosExistentesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RecursosExistentesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
