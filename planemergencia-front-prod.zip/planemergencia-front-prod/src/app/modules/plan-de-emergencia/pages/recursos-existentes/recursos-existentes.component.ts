import { Component, OnInit } from '@angular/core';
import * as FileSaver from 'file-saver';
import { CascadeSelect } from 'primeng/cascadeselect';
import { AuthService } from 'src/app/core/services/auth.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { InivelOficina } from '../../core/interfaces/nivelOficina.interface';
import { IRecursoNivelPost, IRecursoNivelPut, recursoNivel } from '../../core/interfaces/recursoNivel.interface';
import { IRecursos } from '../../core/interfaces/recursosExistentes.interface';
import { NavigationService } from '../../core/services/navigation.service';
import { NivelesOficinaService } from '../../core/services/niveles-oficina.service';
import { RecursoNivelService } from '../../core/services/recurso-nivel.service';
import { RecursosExistentesService } from '../../core/services/recursos-existentes.service';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';


@Component({
  selector: 'app-recursos-existentes',
  templateUrl: './recursos-existentes.component.html',
  styleUrls: ['./recursos-existentes.component.scss']
})
export class RecursosExistentesComponent implements OnInit {

  constructor(private _recursosExistenteService : RecursosExistentesService ,
    private _oficina: SharingOfficeService  , 
    private toast: ToastService,
    private navigationService: NavigationService,
    private _nivelesOficiona : NivelesOficinaService ,
    private _recursoNivelService : RecursoNivelService ,
    private _authService : AuthService) {
       
      this.toastKey = this.toast.genToastKey();
    }

    toastKey: any;
    visibleS1 :boolean = false
    visiblePB :boolean = false
    visibleP1 :boolean = false
    visibleP2 :boolean = false
    visibleP3 :boolean = false
    visibleP4 :boolean = false
    visibleP5 :boolean = false
    visibleP6 :boolean = false
    visibleP7 :boolean = false
    visibleP8 :boolean = false
    visibleP9 :boolean = false
    visibleP10 :boolean = false
    visibleP11 :boolean = false
    visibleP12 :boolean = false
    visibleP13 :boolean = false
    visibleP14 :boolean = false
    visibleP15 :boolean = false
    visibleP16 :boolean = false
    visibleP17 :boolean = false
    visibleP18 :boolean = false
    visibleP19 :boolean = false
    visibleP20 :boolean = false

  lista_niveles_oficinas : InivelOficina[] = new Array<InivelOficina>();
  lista_recursos : IRecursos[] = new Array<IRecursos>()
  listaRecursoNivel: recursoNivel[] = new Array<recursoNivel>()
  listaTotalRecuroNivel :  recursoNivel[] = new Array<recursoNivel>()
  listaInfoPisos : any [] = new Array <any>()
  observacion : string ;
  loading : boolean = true;
   listaPut :  IRecursoNivelPut [] = new Array<IRecursoNivelPut>()
   listaPost :  IRecursoNivelPost [] = new Array<IRecursoNivelPost>()
 
  riesgos: any [] = new Array<any>();
 
  codigoOficina : number = 2
  codigoEmpresa : number = 1 ;
  usuario : string = 'prueba' ;
  orden : number 
  ngOnInit(): void {
    this.loading =true;
    this.codigoOficina = this._oficina.currentOfficeData.id.codigo
    this.codigoEmpresa =  this._oficina.currentOfficeData.id.codigoEmpresa
    this.usuario =  this._authService.getUsuarioData().usuarioIngreso
    console.log("Usuario =>>>>>>>>>>>>>" + this.usuario)
    this.orden = 0
    this.inicializarRecursos();

  
  
  }


 async inicializarRecursos(){
    
 let responseRecursos :any = await  this._recursosExistenteService.obtenerRecursos().toPromise()
 this.lista_recursos = responseRecursos.pageContent  



   // Obtener info pisos
let responseInfoPisos :any = await this._nivelesOficiona.obtenerNivelesOficinas(this.codigoEmpresa, this.codigoOficina).toPromise();
this.lista_niveles_oficinas = responseInfoPisos.pageContent;


// obtengo recurosNiveles
for(const nivel of this.lista_niveles_oficinas){
  let responseRecursosNivel : any = await this._recursoNivelService.obtenerRecursoNivel(nivel.codigo).toPromise()
  if (responseRecursosNivel.totalItems > 0 ) {
    this.listaRecursoNivel =   responseRecursosNivel.pageContent;
    this.listaTotalRecuroNivel = this.listaTotalRecuroNivel.concat(this.listaRecursoNivel)
    this.observacion  = this.listaRecursoNivel[0].observacion
   }
  }

  console.log(this.listaTotalRecuroNivel )
 console.log('Obtener valor')
  console.log (this.ObtenerValor(0,1)  + "piso 0  recurso 1") 
  console.log (this.ObtenerValor(1,1)  + "piso 0  recurso 1") 
  console.log (this.ObtenerValor(2,1)  + "piso 0  recurso 1") 
 

this.inicializarRegistros()
 this.inicializarTabla()

 this.loading= false

  }

 
  async inicializarRegistros(){

 for(const nivel of this.lista_niveles_oficinas){
switch (nivel.numeroPiso) {
  case 0:
     this.visibleS1 = true
      break;
  case 1:
      this.visiblePB = true
      break;
  case 2:
    this.visibleP1 = true
      break;
  case 3:
    this.visibleP2 = true
      break;
  case 4:
    this.visibleP3 = true
      break;
  case 5:
    this.visibleP4 = true
      break;
  case 6:
    this.visibleP5 = true
      break;
  case 7:
     this.visibleP6 = true
          break;
  case 8:
         this.visibleP7 = true
         break;
  case 9:
          this.visibleP8 = true
          break;
 case 10:
            this.visibleP9 = true
            break;
 case 11:
            this.visibleP10 = true
            break;
 case 12:
            this.visibleP11 = true
            break;
 case 13:
            this.visibleP12 = true
            break;
 case 14:
            this.visibleP13 = true
            break;
 case 15:
            this.visibleP14 = true
            break;
 case 16:
            this.visibleP15 = true
            break;
 case 17:
            this.visibleP16 = true
            break;
 case 18:
            this.visibleP17 = true
            break;
 case 19:
            this.visibleP18 = true
            break;
 case 20:
            this.visibleP19 = true
            break;
 case 21:
            this.visibleP20 = true
            break;
              
  default:
      console.log("No such day exists!");
      break;
}

 }
  
 console.log('Console log ListaToatal recurso')
 console.log(this.listaTotalRecuroNivel)

 }

  ObtenerValor( piso : number , codigo_recurso : number ):string {  
    let indice = this.lista_niveles_oficinas.findIndex(select => select.numeroPiso== piso  )                     
     
     // NO existe el piso en la oficina
      if (indice < 0 ){
            return ""
      } 
      let id_nivel :number  = this.lista_niveles_oficinas[indice].codigo

      let indice_2 = this.listaTotalRecuroNivel.findIndex(valor => valor.id.codigoNivel == id_nivel && valor.id.codigoRecurso == codigo_recurso)     
      // no existe asociado el nivel al recurso
      if (indice_2 < 0 ){
        return ""
     }
       let valor1 :number =  this.listaTotalRecuroNivel[indice_2].cantidad
       let valor :string =  valor1.toString()
// muestro vacio cuando es cero0
       if (valor=="0"){

          return ""
       }

       return  valor
 }

 ObtenerNivel(piso :number) :number{
  let indice = this.lista_niveles_oficinas.findIndex(select => select.numeroPiso== piso  )                     
     
  // NO existe el piso en la oficina
   if (indice < 0 ){
         return -5
   } 
   let id_nivel :number  = this.lista_niveles_oficinas[indice].codigo
   return id_nivel

 }

 ObtieneCodigoNivelRecurso( id_nivel : number , codigo_recurso : number ):number {  
                   
  
    let indice_2 = this.listaTotalRecuroNivel.findIndex(valor => valor.id.codigoNivel == id_nivel && valor.id.codigoRecurso == codigo_recurso)     
    // no existe asociado el nivel al recurso
    if (indice_2 < 0 ){
      return -1
   }
     let valor :number =  this.listaTotalRecuroNivel[indice_2].id.codigo
     return  valor
}


  inicializarTabla()
  {
  
   for(const recurso of this.lista_recursos){
       
      let riesgo: any = {
        code : recurso.codigo,
       riesgo : recurso.descripcion,
       S1 :  this.ObtenerValor(0,recurso.codigo),
       PB : this.ObtenerValor(1,recurso.codigo),
       P1 : this.ObtenerValor(2,recurso.codigo),
       P2 : this.ObtenerValor(3,recurso.codigo),
       P3 : this.ObtenerValor(4,recurso.codigo),
       P4 : this.ObtenerValor(5,recurso.codigo),
       P5 : this.ObtenerValor(6,recurso.codigo),
       P6 : this.ObtenerValor(7,recurso.codigo),
       P7 : this.ObtenerValor(8,recurso.codigo),
       P8 : this.ObtenerValor(9,recurso.codigo),
       P9 : this.ObtenerValor(10,recurso.codigo),
       P10 : this.ObtenerValor(11,recurso.codigo),
       P11 : this.ObtenerValor(12,recurso.codigo),
       P12 : this.ObtenerValor(13,recurso.codigo),
       P13 : this.ObtenerValor(14,recurso.codigo),
       P14 : this.ObtenerValor(15,recurso.codigo),
       P15 : this.ObtenerValor(16,recurso.codigo),
       P16 : this.ObtenerValor(17,recurso.codigo),
       P17 : this.ObtenerValor(18,recurso.codigo),
       P18 : this.ObtenerValor(19,recurso.codigo),
       P19 : this.ObtenerValor(20,recurso.codigo),
       P20 : this.ObtenerValor(21,recurso.codigo),
   };
     this.riesgos.push(riesgo)
   }
 
   console.log("riesgos cargados")

    console.log(this.riesgos)

  }

  async  saveContinue() {

    this.grabarRecursos()
    console.log("Muestro post")
   console.log(this.listaPost)
   console.log("Muestro put")
   console.log(this.listaPut)
    
   if (this.listaPost.length > 0) {
    await this._recursoNivelService.registrarRecursosNiveles(this.listaPost).toPromise()

   }

   if(this.listaPut.length>0){
   await this._recursoNivelService.actualizarRecursoNiveles(this.listaPut).toPromise()

   }

    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;
}

goPrevious() {
  this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
}

          

registrarRecurso(id_nivel : number , id_riesgo : number , valor : any){
    let valor_final :number;      
  let codigo = this.ObtieneCodigoNivelRecurso(id_nivel , id_riesgo )
    if (codigo > 0 ){ // existe Put 
      if (valor!=""){
        valor_final=valor
 

      }else {
        valor_final=0

      }

        this.listaPut.push({
             cantidad  : valor_final ,
             nombreEquipo :'prueba' ,
             observacion : this.observacion ,
             usuarioModificacion : this.usuario,
            id : {
                   codigo : codigo ,
                   codigoNivel : id_nivel ,
                   codigoRecurso : id_riesgo

            }
    
        })

    } else if(valor!=""){ // N existe post
      this.listaPost.push({
        cantidad  : valor ,
        nombreEquipo :'prueba' ,
        observacion : this.observacion ,
        usuarioIngreso : this.usuario ,
        estado : 'A'   ,
       
       id : {
              
              codigoNivel : id_nivel ,
              codigoRecurso : id_riesgo

       }

   })

    }



}


grabarRecursos(){

  this.riesgos.forEach(riesgo => {

  // if(riesgo.S1!=""){
   
    this.registrarRecurso(this.ObtenerNivel(0) , riesgo.code  , riesgo.S1)

 //  } 

 //  if(riesgo.PB!=""){

    this.registrarRecurso(this.ObtenerNivel(1) , riesgo.code  , riesgo.PB)
 //  }

  // if(riesgo.P1!=""){

    this.registrarRecurso(this.ObtenerNivel(2) , riesgo.code  , riesgo.P1)
 //  }

//   if(riesgo.P2!=""){
    this.registrarRecurso(this.ObtenerNivel(3) , riesgo.code  , riesgo.P2)
  // }

 //  if(riesgo.P3!=""){
    this.registrarRecurso(this.ObtenerNivel(4) , riesgo.code  , riesgo.P3)
 //  }

//   if(riesgo.P4!=""){
    this.registrarRecurso(this.ObtenerNivel(5) , riesgo.code  , riesgo.P4)
  // }

//   if(riesgo.P5!=""){
    this.registrarRecurso(this.ObtenerNivel(6) , riesgo.code  , riesgo.P5)
 //  }
 //  if(riesgo.P6!=""){
    this.registrarRecurso(this.ObtenerNivel(7) , riesgo.code  , riesgo.P6)
//   }
 //  if(riesgo.P7!=""){
    this.registrarRecurso(this.ObtenerNivel(8) , riesgo.code  , riesgo.P7)
   //}

  // if(riesgo.P8!=""){
    this.registrarRecurso(this.ObtenerNivel(9) , riesgo.code  , riesgo.P8)

 //  }

 //  if(riesgo.P9!=""){
    this.registrarRecurso(this.ObtenerNivel(10) , riesgo.code  , riesgo.P9)
 //  }

 //  if(riesgo.P10!=""){
    this.registrarRecurso(this.ObtenerNivel(11) , riesgo.code  , riesgo.P10)
  // }

 //  if(riesgo.P11!=""){
    this.registrarRecurso(this.ObtenerNivel(12) , riesgo.code  , riesgo.P11)
 //  }

 //  if(riesgo.P12!=""){
    this.registrarRecurso(this.ObtenerNivel(13) , riesgo.code  , riesgo.P12)
  // }

  // if(riesgo.P13!=""){
    this.registrarRecurso(this.ObtenerNivel(14) , riesgo.code  , riesgo.P13)
  // }

 //  if(riesgo.P14!=""){
    this.registrarRecurso(this.ObtenerNivel(15) , riesgo.code  , riesgo.P14)
 //  }
 //  if(riesgo.P15!=""){
    this.registrarRecurso(this.ObtenerNivel(16) , riesgo.code  , riesgo.P15)
  // }

//   if(riesgo.P16!=""){
    this.registrarRecurso(this.ObtenerNivel(17) , riesgo.code  , riesgo.P16)
 //  }

//   if(riesgo.P17!=""){
    this.registrarRecurso(this.ObtenerNivel(18) , riesgo.code  , riesgo.P17)
 //  }

//   if(riesgo.P18!=""){
    this.registrarRecurso(this.ObtenerNivel(19) , riesgo.code  , riesgo.P18)
 //  }

//   if(riesgo.P19!=""){
    this.registrarRecurso(this.ObtenerNivel(20) , riesgo.code  , riesgo.P19)
 //  }

 //  if(riesgo.P20!=""){
    this.registrarRecurso(this.ObtenerNivel(21) , riesgo.code  , riesgo.P20)
 //  }









      

  })
  

}






guardaInfoTabla()
{


}


}
