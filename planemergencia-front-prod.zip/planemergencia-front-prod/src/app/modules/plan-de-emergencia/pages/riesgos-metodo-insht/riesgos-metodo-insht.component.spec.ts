import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RiesgosMetodoInshtComponent } from './riesgos-metodo-insht.component';

describe('RiesgosMetodoInshtComponent', () => {
  let component: RiesgosMetodoInshtComponent;
  let fixture: ComponentFixture<RiesgosMetodoInshtComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RiesgosMetodoInshtComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RiesgosMetodoInshtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
