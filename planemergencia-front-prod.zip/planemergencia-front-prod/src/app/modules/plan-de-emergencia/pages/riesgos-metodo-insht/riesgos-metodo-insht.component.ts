import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { AuthService } from 'src/app/core/services/auth.service';
import { NavigationService } from '../../core/services/navigation.service';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';
import { RiesgosService } from '../../../admin/core/services/Riesgo.service';
import { MetodoInshtContent } from '../../../admin/core/models/MetodoInshtContent';
import { MetodoInshtService } from '../../../admin/core/services/MetodoInsht.service';
import { MetodoInshtId } from 'src/app/modules/admin/core/models/MetodoInshtId';
import { DocumentoPdfService } from '../../core/services/documento-pdf.service';

@Component({
  selector: 'app-riesgos-metodo-insht',
  templateUrl: './riesgos-metodo-insht.component.html',
  styleUrls: ['./riesgos-metodo-insht.component.scss']
})
export class RiesgosMetodoInshtComponent implements OnInit {

  loading         : boolean = true;
  loading1         : boolean = true;
  codigoOficina   : number;
  codigoEmpresa   : number;
  usuario         : string;

  fechaDate : Date = new Date();

  localidad : string;
  hoja : string = '1';
  areaSeccion : string = 'TODAS';
  fecha : string = this.fechaDate.getDate().toString() + '/'+ ((this.fechaDate.getMonth()+1).toString() ) + '/'+ this.fechaDate.getFullYear().toString();

  botonesRiesgo : boolean = true;

  //Sismos y terremotos
  valorAmenaza1     : number;
  valorVulnerable1  : number;
  valorRiesgo1      : number;
  //Inundaciones
  valorAmenaza2     : number;
  valorVulnerable2  : number;
  valorRiesgo2      : number;
  //Deslaves
  valorAmenaza3     : number;
  valorVulnerable3  : number;
  valorRiesgo3      : number;
  //Tsunamis
  valorAmenaza4     : number;
  valorVulnerable4  : number;
  valorRiesgo4      : number;
  //Erupcion Volcanica
  valorAmenaza5     : number;
  valorVulnerable5  : number;
  valorRiesgo5      : number;

  modifique :boolean=false;


  obtuve1:boolean=false;
  obtuve2:boolean=false;
  obtuve3:boolean=false;
  obtuve4:boolean=false;
  obtuve5:boolean=false;

  constructor(private _oficina               : SharingOfficeService ,
              private _authService           : AuthService ,
              private navigationService      : NavigationService,
              private messageService         : MessageService,
              private _riesgoService         : RiesgosService,
              private _metodoInshtService    : MetodoInshtService,
              private _documentoPdfService   : DocumentoPdfService) {            
  }

  ngOnInit(): void {
    this.loading = false;

    this.codigoOficina = this._oficina.currentOfficeData.id.codigo;
    this.codigoEmpresa = this._oficina.currentOfficeData.id.codigoEmpresa;
    this.localidad     = this._oficina.currentOfficeData.nombreOficina;

    this.usuario =  this._authService.getUsuarioData().usuarioIngreso;

    this.loading1=true;
    this.cargarDatos(1);
    this.cargarDatos(2);
    this.cargarDatos(3);
    this.cargarDatos(4);
    this.cargarDatos(5);
  }

  goPrevious() {
    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
  }

  saveContinue(){
    //Grabo los 5 registros
    if(this.modifique){
      this.obtenerDataGrabar(this.codigoOficina,this.valorAmenaza1,this.valorVulnerable1,1);
      this.obtenerDataGrabar(this.codigoOficina,this.valorAmenaza2,this.valorVulnerable2,2);
      this.obtenerDataGrabar(this.codigoOficina,this.valorAmenaza3,this.valorVulnerable3,3);
      this.obtenerDataGrabar(this.codigoOficina,this.valorAmenaza4,this.valorVulnerable4,4);
      this.obtenerDataGrabar(this.codigoOficina,this.valorAmenaza5,this.valorVulnerable5,5);
    }else{
      this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;
    }
    
  }

  downloadPDF() {
    // Extraemos el
    let nombreArchivo :string = 'Metodo_Insht.pdf'
    this._documentoPdfService.downloadPDF( nombreArchivo , document.getElementById('htmlData') )
   
  }

  async cargarDatos(caso: number){
    let riesgo: string='';
    let codigoEstimacion : number=0;
    
    if(caso == 1){
      riesgo = 'Sismos y terremotos';
    }else if(caso == 2){
      riesgo = 'Inundaciones';
    }else if(caso == 3){
      riesgo = 'Deslaves';
    }else if(caso == 4){
      riesgo = 'Tsunami';
    }else if(caso == 5){
      riesgo = 'Erupción Volcánica';
    }

    //Obtengo el metodo para poder luego buscar la estimacion
    await this.getMetodoInst(this.codigoOficina,riesgo).then((data: any) => {
      if (data.resCode != 0) {
        this.messageService.add({severity:'error', summary:'Grabar data', detail:'Hubo un error al obtener data del metodo'});
      }else{
        if(data.respuesta.length>0){
          codigoEstimacion = data.respuesta[0].codigoEstimacionRiesgo;
        }else{
          if(caso == 1){
            this.obtuve1=true;
          }else if(caso == 2){
            this.obtuve2=true;
          }else if(caso == 3){
            this.obtuve3=true;
          }else if(caso == 4){
            this.obtuve4=true;
          }else if(caso == 5){
            this.obtuve5=true;
          }
        }
      }
    });

    if(codigoEstimacion!=0){
      await this.getEstimacionByCodigo(codigoEstimacion).then((data: any) => {
        if (data.resCode == 0) {
          if(data.respuesta.length>0){
            if(caso == 1){ 
              this.valorAmenaza1     = data.respuesta[0].codigoProbabilidad;
              this.valorVulnerable1  = data.respuesta[0].codigoConsecuencia;
              this.estimacion(1);
              this.obtuve1=true;
            }else if(caso == 2){
              this.valorAmenaza2     = data.respuesta[0].codigoProbabilidad;
              this.valorVulnerable2  = data.respuesta[0].codigoConsecuencia;
              this.estimacion(2);
              this.obtuve2=true;
            }else if(caso == 3){
              this.valorAmenaza3     = data.respuesta[0].codigoProbabilidad;
              this.valorVulnerable3  = data.respuesta[0].codigoConsecuencia;
              this.estimacion(3);
              this.obtuve3=true;
            }else if(caso == 4){
              this.valorAmenaza4     = data.respuesta[0].codigoProbabilidad;
              this.valorVulnerable4  = data.respuesta[0].codigoConsecuencia;
              this.estimacion(4);
              this.obtuve4=true;
            }else if(caso == 5){
              this.valorAmenaza5     = data.respuesta[0].codigoProbabilidad;
              this.valorVulnerable5  = data.respuesta[0].codigoConsecuencia;
              this.estimacion(5);
              this.obtuve5=true;
            }
          }
        } else {
          this.messageService.add({severity:'error', summary:'Grabar data', detail:'Hubo un error al grabar data del metodo'});
        }
      });
    }

    if(this.obtuve1 && this.obtuve2 && this.obtuve3 && this.obtuve4 && this.obtuve5){
      this.loading1=false;
      this.modifique=false;
    }

  }

  estimacion(escenario :number){
    this.modifique=true;
    if(escenario == 1){//Sismos y terremotos
      this.valorRiesgo1 = this.obtenerEstimacion(this.valorAmenaza1,this.valorVulnerable1); 
    }else if(escenario == 2){//Inundaciones
      this.valorRiesgo2 = this.obtenerEstimacion(this.valorAmenaza2,this.valorVulnerable2); 
    }else if(escenario == 3){//Deslaves
      this.valorRiesgo3 = this.obtenerEstimacion(this.valorAmenaza3,this.valorVulnerable3); 
    }else if(escenario == 4){//Tsunami
      this.valorRiesgo4 = this.obtenerEstimacion(this.valorAmenaza4,this.valorVulnerable4); 
    }else if(escenario == 5){//Erupción Volcánica
      this.valorRiesgo5 = this.obtenerEstimacion(this.valorAmenaza5,this.valorVulnerable5); 
    }
  }

  obtenerEstimacion( amenaza : number , vulnerabilidad :number) : number  {
    if ( amenaza == 1  ) {
      if(vulnerabilidad == 1){
        return 1;
      }else if (vulnerabilidad == 2){
        return 2;
      }else if (vulnerabilidad == 3){
        return 3;
      }
    }else if ( amenaza == 2  ) {
      if(vulnerabilidad == 1){
        return 2;
      }else if (vulnerabilidad == 2){
        return 3;
      }else if (vulnerabilidad == 3){
        return 4;
      }
    }else if ( amenaza == 3  ) {
      if(vulnerabilidad == 1){
        return 3;
      }else if (vulnerabilidad == 2){
        return 4;
      }else if (vulnerabilidad == 3){
        return 5;
      }  
    }
    return -1;
  }

  getEstimacionByCodigo(codigo:number){
    return new Promise((resolve)=>{
      this._riesgoService.getEstimacionByCode(codigo).subscribe({
        next: (res:any)=>{
          const data ={ respuesta :res.pageContent, 
                        resCode   : 0 
                      };
          resolve(data);
        },
        error: (err)=>{
          const e='Error _riesgoService.getEstimacionRiego';
          const data = { resCode: -1, error: e };
          resolve(data);
        },
      });
    
  });
  }

  getPromesaEstimacion(probabilidad:number,consecuencia:number){
    return new Promise((resolve)=>{
        this._riesgoService.getEstimacionRiego(probabilidad,consecuencia).subscribe({
          next: (res:any)=>{
            const data ={ respuesta :res.pageContent, 
                          resCode   : 0 
                        };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _riesgoService.getEstimacionRiego';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
      
    });
  }

  getMetodoInst(idOficina: number,riesgo:string){
    return new Promise((resolve)=>{
        this._metodoInshtService.getMetodoByOfiRiesgo(idOficina,riesgo).subscribe({
          next: (res:any)=>{
            const data = { respuesta : res.pageContent,
                           resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _metodoInshtService.getMetodo';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
        
    });
  }


  postMetodoInst(metodoInshtIn: MetodoInshtContent,usuario:string){
    return new Promise((resolve)=>{
        this._metodoInshtService.postMetodo(metodoInshtIn,usuario).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _metodoInshtService.postMetodo';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
        
    });
  }

  putMetodoInst(metodoInshtIn: MetodoInshtContent,usuario:string){
    return new Promise((resolve)=>{
        this._metodoInshtService.putMetodo(metodoInshtIn,usuario).subscribe({
          next: (res:any)=>{
            const data = {resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='_metodoInshtService.putMetodo';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
        
    });
  }

  async obtenerDataGrabar(idOficina: number, probabilidad: number,consecuencia: number, caso : number){
    let riesgo : string = '';
    let codigo_estimacion : number = 0;
    let codigo_metodo_insht :number = 0;
    let isUpdate : boolean = false;
    let nuevoMetodo: MetodoInshtContent = new MetodoInshtContent();
    let metodoActual : MetodoInshtContent[]=[];
    console.log('caso: ',caso)
    if(caso == 1){
      this.loading = true;
      riesgo = 'Sismos y terremotos';
      codigo_metodo_insht = 1; 
    }else if(caso == 2){
      riesgo = 'Inundaciones';
      codigo_metodo_insht = 2;
    }else if(caso == 3){
      riesgo = 'Deslaves';
      codigo_metodo_insht = 3;
    }else if(caso == 4){
      riesgo = 'Tsunami';
      codigo_metodo_insht = 4;
    }else if(caso == 5){
      riesgo = 'Erupción Volcánica';
      codigo_metodo_insht = 5;
    }

    //Obtengo el codigo del metodo por id oficina y el riesgo el resultado queda en this.metodoInshtActual
    await this.getMetodoInst(idOficina,riesgo).then((data: any) => {
      if (data.resCode != 0) {
        this.messageService.add({severity:'error', summary:'Grabar data', detail:'Hubo un error al grabar data del metodo'});
      }else{
        if(data.respuesta.length==0){
          isUpdate = false;
        }else{
          metodoActual = data.respuesta;
          isUpdate = true;
        }
      }

    });

    //obtengo el codigo de la estimacion mediante la probabilidad y la consecuencia
    await this.getPromesaEstimacion(probabilidad,consecuencia).then((data: any) => {
      if (data.resCode == 0) {
          codigo_estimacion = data.respuesta[0].codigo; 

          if(metodoActual.length>0 && isUpdate){
            metodoActual[0].codigoEstimacionRiesgo = codigo_estimacion;
          }
        
      } else {
        this.messageService.add({severity:'error', summary:'Grabar data', detail:'Hubo un error al grabar data del metodo'});
      }
    });

    
    console.log('grabando metodo');

    if(isUpdate){
      await this.putMetodoInst(metodoActual[0],this.usuario).then((data: any) => {
        if (data.resCode != 0) {
          this.messageService.add({severity:'error', summary:'Grabar data', detail:'Hubo un error al grabar data del metodo'});
        }
        if(caso==5){
          this.loading = false;
          this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;
        }
      });
    }else{
      nuevoMetodo.codigoEstimacionRiesgo = codigo_estimacion;
      nuevoMetodo.factoresRiesgo = riesgo;
      nuevoMetodo.id = new MetodoInshtId();
      nuevoMetodo.id.codigoOficina= this.codigoOficina;
      nuevoMetodo.id.codigoEmpresa = 1;


      await this.postMetodoInst(nuevoMetodo,this.usuario).then((data: any) => {
        
        if (data.resCode != 0) {
          this.messageService.add({severity:'error', summary:'Grabar data', detail:'Hubo un error al grabar data del metodo'});
        }
        if(caso==5){
          this.loading = false;
          this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;
        }
      });
    }
  }

}
