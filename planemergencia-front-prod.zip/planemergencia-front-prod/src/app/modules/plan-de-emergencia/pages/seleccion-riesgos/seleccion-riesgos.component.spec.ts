import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SeleccionRiesgosComponent } from './seleccion-riesgos.component';

describe('SeleccionRiesgosComponent', () => {
  let component: SeleccionRiesgosComponent;
  let fixture: ComponentFixture<SeleccionRiesgosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SeleccionRiesgosComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SeleccionRiesgosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
