import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { resolve } from 'dns';
import { AuthService } from 'src/app/core/services/auth.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { Iriesgo, IriesgoOficina, IriesgoOficinagoGet, IriesgoOficinaPost, IriesgoOficinaPut, riesgo } from '../../core/interfaces/seleccionRiesgo.interface';
import { NavigationService } from '../../core/services/navigation.service';

import { RiesgosService } from '../../core/services/riesgos.service';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';

@Component({
  selector: 'app-seleccion-riesgos',
  templateUrl: './seleccion-riesgos.component.html',
  styleUrls: ['./seleccion-riesgos.component.scss']
})
export class SeleccionRiesgosComponent implements OnInit {

  constructor(private _riesgoService : RiesgosService ,
    private _oficina: SharingOfficeService  ,
    private toast: ToastService,
    private navigationService: NavigationService,
    private _authService : AuthService) { 

      this.toastKey = this.toast.genToastKey();
    }


  selectedRiesgos: riesgo[] = new Array<riesgo>();
  selectedRiesgosTmp: riesgo[] = new Array<riesgo>();


  lista_riesgos: riesgo[] = new Array<riesgo>();
  lista_riesgos_response: Iriesgo[] =  new Array<Iriesgo>() ;
  lista_riesgos_oficinas : IriesgoOficina[] = new Array<IriesgoOficina>();
  lista_riesgos_oficinas_post  : IriesgoOficinaPost[] = new Array<IriesgoOficinaPost>();
  lista_riesgos_oficinas_put : IriesgoOficinaPut[] = new Array<IriesgoOficinaPut>();

  existeRiesgo :boolean = false

  
    /// se deben setear al inicio
    codigoOficina : number = 2
    codigoEmpresa : number = 1 ;
    usuario : string = 'jonathan' ;
    loading : boolean = true
    toastKey: any;

  ngOnInit(): void {
    this.codigoOficina = this._oficina.currentOfficeData.id.codigo
    this.codigoEmpresa =  this._oficina.currentOfficeData.id.codigoEmpresa
    this.usuario =  this._authService.getUsuarioData().usuarioIngreso
    console.log("Usuario =>>>>>>>>>>>>>" + this.usuario)
    this.loading = true
    // obtengo la lista de riesgos
    console.log('Ingrese on INit')
    this.cargarRiesgos();
     console.log(this.lista_riesgos)

  }

 async  cargarRiesgos(){
    console.log('Inicio de Carga de riesgos')
       await this.iniciarRiesgos()
       console.log('Fin de Carga de riesgos')
       console.log('Inicio de seleccionar riesgos')
       await  this.seleccionarRiesgos()
       console.log('Fin de seleccionar riesgos')
       this.loading = false
      

  

  }

  iniciarRiesgos(){

    return new Promise((resolve)=> {

      this._riesgoService.obtenerRiesgos().subscribe(  data  => {
        console.log('Ingrese a exitoso' + data.numberOfPages)
         
         this.lista_riesgos_response = data.pageContent;  
         console.log( this.lista_riesgos_response )
        this.lista_riesgos_response.forEach( (riesgo) => {
           this.lista_riesgos.push ({
                    key : riesgo.codigo.toString() ,
                    name : riesgo.descripcion
           })

      })
   
      console.log( this.lista_riesgos )
      const dataRes = { resCode: 0 };
      resolve(dataRes);

      } ,
      (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al obtener los riesgos';
        const dataErr = { resCode: -1, error: e };
        console.log(e)
        resolve(dataErr);
        
   
      }

    )


    })


  }


  seleccionarRiesgos(){
   
    return new Promise((resolve)=> {
 
    this._riesgoService.obtenerRiesgosOficinas(this.codigoOficina , this.codigoEmpresa).subscribe(
      datos => {
               console.log('muestro riesgos Oficinas')
               console.log(datos)
               if (datos.totalItems==0)
               {
                  console.log('No existen  Riesgos asociados')
                  this.existeRiesgo = false
               } else {
                  console.log('Existen  Riesgos asociados')
                  this.existeRiesgo = true
 
                  this.lista_riesgos_oficinas = datos.pageContent
                   datos.pageContent.forEach( riesgosOficinas => {      
                     console.log('Muestro riesgo oficina seleccionado')  
                     console.log(riesgosOficinas)                
                    let indice = this.lista_riesgos.findIndex(riesgo => riesgo.key== riesgosOficinas.id.codigoRiesgo.toString() && riesgosOficinas.estado == 'A'  )                     
                    console.log('indice encontrado => ' +indice )                    
                 
                  if (indice >= 0) {
                    this.selectedRiesgosTmp.push( this.lista_riesgos[indice])
                  }
                  
                //  this.selectedMantenimientoTmp = this.lista_mantenimientos.slice(1,3)
 
                   })
                   this.selectedRiesgos = this.selectedRiesgosTmp
               }
               console.log('Imprimo selececcionado')
               console.log( this.selectedRiesgos)

               const dataRes = { resCode: 0 };
               resolve(dataRes);
 
      } ,
      (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al seleccinar los riegos';
        const dataErr = { resCode: -1, error: e };
        console.log(e)
        resolve(dataErr);
        
   
      }
 
 
     )

     }
   
    )

   
 
  }   

  
goPrevious() {
  this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
}

  saveContinue(){
    console.log('Imprimo seleccionado')
    console.log(this.selectedRiesgos)
 
     this.RiesgoOficinaUpdate();
     this.riesgosOficinasPost()

     this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;
  }



  async riesgosOficinasPost(){

    let ejecutarPost : boolean = false;
     // obtengo los seleccionados
    this.selectedRiesgos.forEach(riesgos => {
   // verifico si existia registro
     let indice = this.lista_riesgos_oficinas.findIndex(riesgosOf => riesgos.key== riesgosOf.id.codigoRiesgo.toString() )                     
      if  (indice < 0) {
        ejecutarPost = true
        this.lista_riesgos_oficinas_post.push({
           id  : {
                 
                  codigoRiesgo :  Number(riesgos.key ) ,
                  codigoEmpresa  : this.codigoEmpresa ,
                  codigoOficina : this.codigoOficina   
                   } ,
                   estado : 'A'  ,
                   nombreEquipo : 'Prueba' ,
                   usuarioIngreso : this.usuario
            })
  
      }
 
   })

   if (ejecutarPost) {
    this.loading = true
    console.log('REGISTRANDO')
     await this.registrarRiesgo()
    this.loading = false
    console.log('REGISTRO GUARDADO')

 
}

 }

  registrarRiesgo(){
  return new Promise((resolve)=> {
    
    this._riesgoService.registrarRiesgosOficinas(this.lista_riesgos_oficinas_post).subscribe(
      datos => {
           console.log('Realice Post')
           console.log(datos)
           const dataRes = { resCode: 0 };
           resolve(dataRes);
      } ,
      (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al registrar los riegos de la oficina';
        const dataErr = { resCode: -1, error: e };
        console.log(e)
        resolve(dataErr);
        
   
      }

 )


  })

 }


async  RiesgoOficinaUpdate(){
    let ejecutarPut : boolean  = false
  if (this.existeRiesgo) {
      this.lista_riesgos_oficinas.forEach(riesgosOf => {
         let estado = ''
         let agregar = false
         let indice = this.selectedRiesgos.findIndex(select => select.key== riesgosOf.id.codigoRiesgo.toString()   )                     
         if  (riesgosOf.estado == 'A' && indice < 0) {  // Si estuvo seleccionado y ahora no 
              // actualizo Incativado
              estado = 'I'
              agregar= true
         }else if (riesgosOf.estado == 'I' && indice >= 0) {  // estado = I

             estado ='A'
             agregar= true
         }

     if  (agregar) {
      ejecutarPut = true
      this.lista_riesgos_oficinas_put.push(
         {
              id : {
                 codigo :riesgosOf.id.codigo ,
                 codigoEmpresa : riesgosOf.id.codigoEmpresa ,
                 codigoOficina : riesgosOf.id.codigoOficina ,
                 codigoRiesgo  : riesgosOf.id.codigoRiesgo

              } ,
              nombreEquipo : 'PRUEBA' ,
              usuarioModificacion : this.usuario  ,
              estado :  estado

         }

     )


     }



      })

  }

   if (ejecutarPut) {
    this.loading = true
    console.log('ACTUALIZANDO')
     await this.actualizarRiesgo()
    this.loading = false
    console.log('REGISTRO ACTUALIZADO')
 
   }  

}


 actualizarRiesgo(){

  return new Promise((resolve)=> {
    this._riesgoService.actualizarRiesgosOficinas(this.lista_riesgos_oficinas_put).subscribe(
      datos => {  console.log('Put Ejecutado') 
                  console.log(datos)
        
      } 
      ,
      (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al actualizar los riesgos de oficinas';
        const dataErr = { resCode: -1, error: e };
        console.log(e)
        resolve(dataErr);        
   
      }
      


      )
  })

 }



    

}
