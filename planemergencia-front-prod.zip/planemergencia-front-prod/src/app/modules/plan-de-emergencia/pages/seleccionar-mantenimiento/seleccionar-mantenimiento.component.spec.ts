import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SeleccionarMantenimientoComponent } from './seleccionar-mantenimiento.component';

describe('SeleccionarMantenimientoComponent', () => {
  let component: SeleccionarMantenimientoComponent;
  let fixture: ComponentFixture<SeleccionarMantenimientoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SeleccionarMantenimientoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SeleccionarMantenimientoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
