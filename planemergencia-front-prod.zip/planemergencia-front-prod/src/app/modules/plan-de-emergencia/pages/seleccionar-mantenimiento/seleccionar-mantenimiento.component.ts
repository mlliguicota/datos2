import { HttpErrorResponse } from '@angular/common/http';
import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { resolve } from 'dns';
import { AuthService } from 'src/app/core/services/auth.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { Imantenimiento, mantenimiento , ImantenientosOficinasPost, ImantenimientosOficinas, ImantenientosOficinasPut } from '../../core/interfaces/seleccionMantenimiento.interface';
import { MantenimientosService } from '../../core/services/mantenimientos.service';
import { NavigationService } from '../../core/services/navigation.service';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';

@Component({
  selector: 'app-seleccionar-mantenimiento',
  templateUrl: './seleccionar-mantenimiento.component.html',
  styleUrls: ['./seleccionar-mantenimiento.component.scss']
})
export class SeleccionarMantenimientoComponent implements OnInit {
 

    /// se deben setear al inicio
    codigoOficina : number = 2
    codigoEmpresa : number = 1 ;
    usuario : string = 'prueba' ;

  existeMantenimiento  : boolean = false;
  selectedMantenimiento: mantenimiento[] = new Array<mantenimiento>();
  selectedMantenimientoTmp: mantenimiento[] = new Array<mantenimiento>();
  lista_mantenimientos: mantenimiento[] =new Array<mantenimiento>();



  lista_mantenimientos_response: Imantenimiento[] =new Array<Imantenimiento>();
  lista_mantenimientos_oficinas : ImantenimientosOficinas[] =new Array<ImantenimientosOficinas>();
  lista_mantenimientos_oficinas_Post  : ImantenientosOficinasPost[] =new Array<ImantenientosOficinasPost>() ;
  lista_mantenimientos_oficinas_Put  : ImantenientosOficinasPut[] = new Array<ImantenientosOficinasPut>() ;


  loading : boolean = true
  toastKey: any;

  constructor(  private _mantenimientoService :  MantenimientosService ,
               private _oficina: SharingOfficeService ,
               private toast: ToastService,
               private navigationService: NavigationService,
               private _authService : AuthService ) {
               
      this.toastKey = this.toast.genToastKey();
                this.loading = true;    
   }

  ngOnInit(): void {

   
    this.codigoOficina = this._oficina.currentOfficeData.id.codigo
    this.codigoEmpresa =  this._oficina.currentOfficeData.id.codigoEmpresa
    this.usuario =  this._authService.getUsuarioData().usuarioIngreso
    console.log("Usuario =>>>>>>>>>>>>>" + this.usuario)
 
  
    console.log('usuario' + this.usuario)
  
    this.cargarMantenimientos()
    console.log( 'codigo Oficina'  + this.codigoOficina)
    console.log( 'codigo Empresa'  + this.codigoEmpresa)
    
  }


  
  async  cargarMantenimientos(){
      console.log('Intento cargar ')
    const codigo =  await this.obtenerMantenimientos()
    const codigo2 = await this.seleccionarMantenimientos()
    console.log('Finalizo Carga ')


   

     this.loading = false;
      }

  
   obtenerMantenimientos(){
      return new Promise((resolve) => {
         
  this._mantenimientoService.obtenerMantenimientos().subscribe(  data  => {
    console.log('Ingrese a exitoso Cargando' + data.numberOfPages)   
     this.lista_mantenimientos_response = data.pageContent;  
    this.lista_mantenimientos_response.forEach( (mantenimiento) => {
      console.log('muestro manteniemiento')
      console.log(mantenimiento)
       this.lista_mantenimientos.push ({
                key : mantenimiento.codigo.toString()  ,
                name : mantenimiento.nombre ,
                visible_detalle : false  ,
                detalle : mantenimiento.detalle

       })

  })
  
  const dataRes = { resCode: 0 };
  resolve(dataRes);
      

  } ,
  (err: HttpErrorResponse) => {
    const e='Ocurrio un error inesperado obteniendo las oficinas';
    const dataErr = { resCode: -1, error: e };
   resolve(dataErr);
    console.log('Error' )

 })

      })

    }  

   seleccionarMantenimientos(){

    return new Promise((resolve) => {
    
      this._mantenimientoService.obtenerMantenimientosOficinas(this.codigoOficina , this.codigoEmpresa).subscribe(
        datos => {
                 console.log('muestro mantenimeinto oficina')
                 console.log(datos)
                 if (datos.totalItems==0)
                 {
                    console.log('No existen  manteniemientos asociados')
                    this.existeMantenimiento = false
                 } else {
                    console.log('Existen  manteniemientos asociados')
                    this.existeMantenimiento = true
  
                    this.lista_mantenimientos_oficinas = datos.pageContent
                     datos.pageContent.forEach( mantOficinas => {      
                       console.log('Muestro manetnemiento oficina seleccionado')  
                       console.log(mantOficinas)                
                      let indice = this.lista_mantenimientos.findIndex(mant => mant.key== mantOficinas.id.codigoMantenimiento.toString() && mantOficinas.estado == 'A'  )                     
                      console.log('indice encontrado => ' +indice )     
                      if (indice  >= 0) {
                        this.lista_mantenimientos[indice].visible_detalle =true;  // setea el valor en visible true
                        this.selectedMantenimientoTmp.push( this.lista_mantenimientos[indice])
                      }               
                      
                   // this.selectedMantenimientoTmp = this.lista_mantenimientos.slice(1,3)
  
                     })
                     this.selectedMantenimiento = this.selectedMantenimientoTmp
                 }
                 console.log('Imprimo selececcionado')
                 console.log( this.selectedMantenimiento)

                 const dataRes = { resCode: 0 };
                 resolve(dataRes);
         }
         ,
         (err: HttpErrorResponse) => {
           const e='Ocurrio un error inesperado obteniendo las oficinas';
           const dataErr = { resCode: -1, error: e };
          resolve(dataErr);
           console.log('Error' )
       
        }

  
       )
   

    })




    
    
  
   }   


   goPrevious() {
    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
  }
       
  saveContinue(){
   console.log('Imprimo seleccionado')
   console.log(this.selectedMantenimiento)

     this.mantenimientosOficinaUpdate();
     this.mantenimientosOficinasPost()
     this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;
 }


async mantenimientosOficinasPost(){

  let ejecutarPost : boolean = false;
   // obtengo los seleccionados
  this.selectedMantenimiento.forEach(mante => {
 // verifico si existia registro
   let indice = this.lista_mantenimientos_oficinas.findIndex(mantof => mante.key== mantof.id.codigoMantenimiento.toString() )                     
    if  (indice < 0) {
      ejecutarPost = true
      this.lista_mantenimientos_oficinas_Post.push({
         id  : {
                codigoMantenimiento :  Number(mante.key ),
                codigoEmpresa  : this.codigoEmpresa ,
                codigoOficina : this.codigoOficina   
                 } ,
                 estado : 'A'  ,
                 nombreEquipo : 'Prueba' ,
                 usuarioIngreso : this.usuario
          })

    }
 
 })

if (ejecutarPost) {
  this.loading = true
  console.log('REGISTRANDO')
   await this.registraMantenimiento()
  this.loading = false
  console.log('Terminando de ejecutar')
}



    

 }


  registraMantenimiento(){
    return new Promise((resolve) => {
      this._mantenimientoService.registrarMantenimientosOficinas(this.lista_mantenimientos_oficinas_Post).subscribe(
        datos => {
       
             console.log('Realice Post')
             console.log(datos)
             const dataRes = { resCode: 0 };
             resolve(dataRes);
            } 
            ,
       (err: HttpErrorResponse) => {
          const e='Ocurrio un error inesperado al resgitrar los mantenimientos';
          const dataErr = { resCode: -1, error: e };
          resolve(dataErr);
          console.log('Error' )
        } )

    } ) 
}





async mantenimientosOficinaUpdate(){
    let ejecutarPut : boolean  = false
    console.log('Ingreso a Update')
  if (this.existeMantenimiento) {
      this.lista_mantenimientos_oficinas.forEach(mantOf => {
         let estado = ''
         let agregar = false
         let indice = this.selectedMantenimiento.findIndex(select => select.key== mantOf.id.codigoMantenimiento.toString()   )                     
         if  (mantOf.estado == 'A' && indice < 0) {  // Si estuvo seleccionado y ahora no 
              // actualizo Incativado
              estado = 'I'
              agregar=true 
         }else if (mantOf.estado == 'I' && indice >= 0) {  // estado = I

             estado ='A'
             agregar=true 
         }

     if  (agregar) {
      ejecutarPut = true
      this.lista_mantenimientos_oficinas_Put.push(
         {
              id : {
                 codigo :mantOf.id.codigo ,
                 codigoEmpresa : mantOf.id.codigoEmpresa ,
                 codigoOficina : mantOf.id.codigoOficina ,
                 codigoMantenimiento : mantOf.id.codigoMantenimiento

              } ,
              nombreEquipo : 'PRUEBA' ,
              usuarioModificacion : this.usuario  ,
              estado :  estado

         }

     )


     }

      })

  }

   if (ejecutarPut) {
    this.loading = true
    console.log('Actualizar')
     await this.ActualizarMantenimiento()
    this.loading = false
    console.log('Terminando de Actualizar')
 
   }  

}



 ActualizarMantenimiento(){
  return new Promise((resolve) => {
    this._mantenimientoService.actualizarMantenimientosOficinas(this.lista_mantenimientos_oficinas_Put).subscribe(
      datos => {
     
           console.log('Realice Put')
           console.log(datos)
           const dataRes = { resCode: 0 };
           resolve(dataRes);
          } 
          ,
     (err: HttpErrorResponse) => {
        const e='Ocurrio un error inesperado al resgitrar los mantenimientos';
        const dataErr = { resCode: -1, error: e };
        resolve(dataErr);
        console.log('Error' )
      } )

  } ) 
}




}
