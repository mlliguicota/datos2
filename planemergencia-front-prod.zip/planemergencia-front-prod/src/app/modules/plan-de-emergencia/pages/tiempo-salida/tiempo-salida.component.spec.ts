import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TiempoSalidaComponent } from './tiempo-salida.component';

describe('TiempoSalidaComponent', () => {
  let component: TiempoSalidaComponent;
  let fixture: ComponentFixture<TiempoSalidaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TiempoSalidaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TiempoSalidaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
