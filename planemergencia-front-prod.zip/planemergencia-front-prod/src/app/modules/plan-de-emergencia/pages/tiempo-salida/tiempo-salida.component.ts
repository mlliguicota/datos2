import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { AuthService } from 'src/app/core/services/auth.service';
import { NavigationService } from '../../core/services/navigation.service';
import { PlanEmergenciaService } from '../../core/services/plan-emergencia.service';
import { SharingOfficeService } from '../../core/services/sharing-office.service';
import Constantes from '../../core/util/constantes';

@Component({
  selector: 'app-tiempo-salida',
  templateUrl: './tiempo-salida.component.html',
  styleUrls: ['../estilos_2.scss']
})
export class TiempoSalidaComponent implements OnInit {

  loading         : boolean = true
  codigoOficina   : number;
  codigoEmpresa   : number;
  usuario         : string;

  datoN  : number;
  datoA  : number;
  datoK  : number;
  datoD  : number;
  datoV  : number;
  datoTS : number | undefined;
  mostrarTS : string | undefined;

  minutos : number | undefined;
  segundos : number | undefined;

  seHicieronCalculos : boolean = false;

  constructor(private _oficina               : SharingOfficeService ,
              private _authService           : AuthService ,
              private navigationService      : NavigationService,
              private _planEmergenciaService : PlanEmergenciaService,
              private messageService         : MessageService) {

  }

  ngOnInit(): void {
    this.loading = false;

    this.codigoOficina = this._oficina.currentOfficeData.id.codigo;
    this.codigoEmpresa = this._oficina.currentOfficeData.id.codigoEmpresa;

    this.usuario =  this._authService.getUsuarioData().usuarioIngreso;

    this.obtenerTS();
  }

  goPrevious() {
    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_PREVIOUS;
  }

  async saveContinue(){
    //grabamos sino seguimos sin graban
    if(this.seHicieronCalculos){
      if(this.datoTS!= null){
        await this.putPromesa(this.codigoEmpresa,this.codigoOficina, this.usuario,this.datoTS).then((data: any) => {
          if (data.resCode == 0) {
            this.messageService.add({severity:'success', summary:'Información pagina', detail:'Tiempo de salida correctamente guardado'});
            this.loading = false;
            
          } else {
            this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener data de tiempo de salida'});
          }
        });
      }
    }
    this.navigationService.NavigationObservableData=Constantes.NAVIGATION_GO_NEXT;
  }

  calcular(){
    this.seHicieronCalculos = true;
    if (this.datoN != null && this.datoN != 0 &&
        this.datoA != null && this.datoA != 0 &&
        this.datoK != null && this.datoK != 0 &&
        this.datoD != null && this.datoD != 0 &&
        this.datoV != null && this.datoV != 0) {
      this.datoTS = (this.datoN/(this.datoA*this.datoK))+(this.datoD/this.datoV);
      this.minutos = Math.trunc(this.datoTS/60);
      this.segundos = Math.trunc(this.datoTS) - (60 * this.minutos);
      this.mostrarTS = this.minutos + '" ' + this.segundos + '\'';
      console.log('mostrar TS = ', this.mostrarTS);
      console.log('mimutos = ', this.minutos);
      console.log('segundos TS = ', this.segundos);
    }else{
      this.datoTS = undefined;
      this.minutos = undefined;
      this.segundos = undefined;
      this.mostrarTS = undefined;
    }
  }

  async obtenerTS(){
    this.loading = true;
    await this.getPromesa(this.codigoEmpresa,this.codigoOficina).then((data: any) => {
      if (data.resCode == 0) {
        this.loading = false;
      } else {
        this.messageService.add({severity:'error', summary:'Información pagina', detail:'Error al obtener data de tiempo de salida'});
        this.loading = false;
      }
      });
  }

  getPromesa(codigoEmpresa:number,codigoOficina:number){
    return new Promise((resolve)=>{
      this._planEmergenciaService.obtenerPlanEmergencia(codigoEmpresa,codigoOficina).subscribe({
          next: (res:any)=>{
            if(res.pageContent[0].tiempoSalida == undefined){
              this.seHicieronCalculos = true;
            }else{
              this.datoTS = res.pageContent[0].tiempoSalida;
              if(this.datoTS != null){
                this.minutos = Math.trunc(this.datoTS/60);
                this.segundos = Math.trunc(this.datoTS) - (60 * this.minutos);
                this.mostrarTS = this.minutos + '" ' + this.segundos + '\'';
                console.log('mostrar TS = ', this.mostrarTS);
              }
            }
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.obtenerPlanEmergencia';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
      
    },
    );
  }

  putPromesa(codigoEmpresa: number,codigoOficina: number,usuario: string,valorTS:number){
    return new Promise((resolve)=>{
      this._planEmergenciaService.putTS(codigoEmpresa,codigoOficina,usuario,valorTS).subscribe({
          next: (res:any)=>{
            const data = { resCode: 0 };
            resolve(data);
          },
          error: (err)=>{
            const e='Error _planEmergenciaService.putTS';
            const data = { resCode: -1, error: e };
            resolve(data);
          },
        });
      
    },
    );
  }




}
