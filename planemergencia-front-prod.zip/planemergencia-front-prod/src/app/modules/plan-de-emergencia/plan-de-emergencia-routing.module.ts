import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LocationWorkingPopulationComponent } from './pages/location-working-population/location-working-population.component';
import { PrincipalComponent } from './pages/principal/principal.component';
import { KeepEmergencyContactComponent } from './pages/keep-emergency-contact/keep-emergency-contact.component';
import { DescripcionEmpresaComponent } from './pages/descripcion-empresa/descripcion-empresa.component';
import { FactoresRiesgoComponent } from './pages/factores-riesgo/factores-riesgo.component';
import { MetodoMeseriComponent } from './pages/metodo-meseri/metodo-meseri.component';
import { EvaluacionPrevencionComponent } from './pages/evaluacion-prevencion/evaluacion-prevencion.component';
import { RecursosExistentesComponent } from './pages/recursos-existentes/recursos-existentes.component';
import { SeleccionarMantenimientoComponent } from './pages/seleccionar-mantenimiento/seleccionar-mantenimiento.component';
import { SeleccionRiesgosComponent } from './pages/seleccion-riesgos/seleccion-riesgos.component';
import { PuntoReunionComponent } from './pages/punto-reunion/punto-reunion.component';
import { CargaArchivoComponent } from './pages/carga-archivo/carga-archivo.component';
import { DescargarArchivoComponent } from './pages/descargar-archivo/descargar-archivo.component';
import { GeneraPlanEmergenciaComponent } from './pages/genera-plan-emergencia/genera-plan-emergencia.component';
import { TiempoSalidaComponent } from './pages/tiempo-salida/tiempo-salida.component';
import { DistribucionEvacuacionComponent } from './pages/distribucion-evacuacion/distribucion-evacuacion.component';
import { RiesgosMetodoInshtComponent } from './pages/riesgos-metodo-insht/riesgos-metodo-insht.component';

const routes: Routes = [

  {
    path: '',
    component: PrincipalComponent,
    data: { breadcrumb: 'Plan de emergencia' },
    children: [
      {
        path: '',
        redirectTo: 'location-working-population',
      },

      {
        path: 'location-working-population',
        component: LocationWorkingPopulationComponent,
        data: { breadcrumb: 'Ubicación y población Tarbajadora' },
      },
      
      {
        path: 'factorRiesgo',
        component: FactoresRiesgoComponent,
        data: { breadcrumb: 'Identificación de factores de Riesgos propios de la Organización' },

      },

      {

        path: 'descripcionEmpresa',
        component: DescripcionEmpresaComponent,
        data: { breadcrumb: 'Descripción de la Empresa' },

      },

      {
        path: 'metodoMeseri',
        component: MetodoMeseriComponent,
        data: { breadcrumb: 'Método Meseri' },

      },

      {
        path: 'evaluacionPrevencion',
        component: EvaluacionPrevencionComponent,
        data: { breadcrumb: 'Evaluación Prevención' }
      },

      {
        path: 'recursosExistentes',
        component: RecursosExistentesComponent,
        data: { breadcrumb: 'Recursos Existentes para la prevención , detección protección y control de Incendios' },

      },

      {
        path: 'keep-emergency-contact',
        component: KeepEmergencyContactComponent,
        data: { breadcrumb: 'Mantener contacto de emergencia' },
      },

      {
        path: 'seleccionarMantenimiento',
        component: SeleccionarMantenimientoComponent,
        data: { breadcrumb: 'Seleccionar Mantenimiento' },
      },
      {
        path: 'seleccionarRiesgos',
        component: SeleccionRiesgosComponent,
        data: { breadcrumb: 'Selección de Riesgos' },
      },
      {
        path: 'tiempoSalida',
        component: TiempoSalidaComponent,
        data: { breadcrumb: 'Tiempo de salida' },
      },
      {
        path: 'distribucionEvacuacion',
        component: DistribucionEvacuacionComponent,
        data: { breadcrumb: 'Distrubución del personal rutas de evacuación' },
      },
      {
        path: 'evaluacionCualiRiesgo',
        component: RiesgosMetodoInshtComponent,
        data: { breadcrumb: 'Evaluación cualitativa de riesgos naturales - Método INSHT' },
      },
      {
        path: 'puntoReunion',
        component: PuntoReunionComponent,
        data: { breadcrumb: 'Punto de reunion' },
      },
      {
        path: 'cargaArchivo',
        component: CargaArchivoComponent,
        data: { breadcrumb: 'Carga Archivo' },
      },

      {
        path: 'descargarArchivo',
        component: DescargarArchivoComponent,
        data: { breadcrumb: 'Descargar Archivo' },
      },
      {
        path: 'planEmergencia',
        component: GeneraPlanEmergenciaComponent,
        data: { breadcrumb: 'Plan de Emergencia' },
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HazardRoutingModule { }
