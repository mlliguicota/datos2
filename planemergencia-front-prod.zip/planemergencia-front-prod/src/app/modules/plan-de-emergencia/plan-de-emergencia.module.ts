import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LocationWorkingPopulationComponent } from
  './pages/location-working-population/location-working-population.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { PrimeNgModule } from '../prime-ng/prime-ng.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ReactiveFormsModule } from '@angular/forms';

import { FormComponent } from './components/form/form.component';
import { FloorsTableComponent } from
  './components/floors-table/floors-table.component';
import { HazardFooterComponent } from
  './components/hazard-footer/hazard-footer.component';
import { UploadFileComponent } from
  './components/upload-file/upload-file.component';
import { PopUpComponent } from './components/pop-up/pop-up.component';
import { SharedModule } from '../../shared/shared.module';
import { HazardRoutingModule } from './plan-de-emergencia-routing.module';
import { PrincipalComponent } from './pages/principal/principal.component';
import { StepMenuComponent } from './components/step-menu/step-menu.component';
import { KeepEmergencyContactComponent }
  from './pages/keep-emergency-contact/keep-emergency-contact.component';
import { DescripcionEmpresaComponent } from './pages/descripcion-empresa/descripcion-empresa.component';
import { FactoresRiesgoComponent } from './pages/factores-riesgo/factores-riesgo.component';
import { MetodoMeseriComponent } from './pages/metodo-meseri/metodo-meseri.component';
import { EvaluacionPrevencionComponent } from './pages/evaluacion-prevencion/evaluacion-prevencion.component';
import { RecursosExistentesComponent } from './pages/recursos-existentes/recursos-existentes.component';
import { SeleccionarMantenimientoComponent } from './pages/seleccionar-mantenimiento/seleccionar-mantenimiento.component';
import { CheckboxModule } from 'primeng/checkbox';
import { SeleccionRiesgosComponent } from './pages/seleccion-riesgos/seleccion-riesgos.component';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { PuntoReunionComponent } from './pages/punto-reunion/punto-reunion.component';
import { CargaArchivoComponent } from './pages/carga-archivo/carga-archivo.component';
import { FileUploadModule } from 'primeng/fileupload';
import { DescargarArchivoComponent } from './pages/descargar-archivo/descargar-archivo.component';
import { RadioButtonModule } from 'primeng/radiobutton';
import { GeneraPlanEmergenciaComponent } from './pages/genera-plan-emergencia/genera-plan-emergencia.component';
import { TiempoSalidaComponent } from './pages/tiempo-salida/tiempo-salida.component';
import { DistribucionEvacuacionComponent } from './pages/distribucion-evacuacion/distribucion-evacuacion.component';
import { RiesgosMetodoInshtComponent } from './pages/riesgos-metodo-insht/riesgos-metodo-insht.component';
import {AccordionModule} from 'primeng/accordion';
import {CardModule} from 'primeng/card';
import {FieldsetModule} from 'primeng/fieldset';



@NgModule({
  declarations: [
    LocationWorkingPopulationComponent,
    FormComponent,
    FloorsTableComponent,
    HazardFooterComponent,
    UploadFileComponent,
    PopUpComponent,
    PrincipalComponent,
    StepMenuComponent,
    KeepEmergencyContactComponent,
    DescripcionEmpresaComponent,
    FactoresRiesgoComponent,
    MetodoMeseriComponent,
    EvaluacionPrevencionComponent,
    RecursosExistentesComponent,
    SeleccionarMantenimientoComponent,
    SeleccionRiesgosComponent,
    PuntoReunionComponent,
    CargaArchivoComponent,
    DescargarArchivoComponent,
    GeneraPlanEmergenciaComponent,
    TiempoSalidaComponent,
    DistribucionEvacuacionComponent,
    RiesgosMetodoInshtComponent
  ],
  imports: [
    HazardRoutingModule,
    CommonModule,
    FormsModule,
    PrimeNgModule,
    CheckboxModule,
    FontAwesomeModule,
    HttpClientModule,
    SharedModule,
    ReactiveFormsModule,
    ConfirmDialogModule,
    FileUploadModule,
    RadioButtonModule,
    AccordionModule,
    CardModule,
    FieldsetModule,
  ],
  exports: [
    LocationWorkingPopulationComponent,
  ],
  providers: [ConfirmationService],
})
export class HazardsModule { }
