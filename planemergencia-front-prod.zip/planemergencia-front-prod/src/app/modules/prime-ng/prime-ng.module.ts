import { NgModule } from '@angular/core';

import { ButtonModule } from 'primeng/button';
import { DropdownModule } from 'primeng/dropdown';
import { ImageModule } from 'primeng/image';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { KeyFilterModule } from 'primeng/keyfilter';
import { TableModule } from 'primeng/table';
import { SelectButtonModule } from 'primeng/selectbutton';
import { ToastModule } from 'primeng/toast';
import { TooltipModule } from 'primeng/tooltip';
import {SlideMenuModule} from 'primeng/slidemenu';
import { SplitButtonModule } from 'primeng/splitbutton';
import {CarouselModule} from 'primeng/carousel';

import {CascadeSelectModule} from 'primeng/cascadeselect';
import {ChipsModule} from 'primeng/chips';
import {FileUploadModule} from 'primeng/fileupload';
import {DialogModule} from 'primeng/dialog';
import {ProgressBarModule} from 'primeng/progressbar';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import {SkeletonModule} from 'primeng/skeleton';

@NgModule({
  declarations: [],
  exports: [
    ButtonModule,
    DropdownModule,
    ImageModule,
    InputNumberModule,
    InputTextModule,
    KeyFilterModule,
    TableModule,
    SelectButtonModule,
    ToastModule,
    TooltipModule,
    SlideMenuModule,
    SplitButtonModule,
    CarouselModule,
    CascadeSelectModule,
    ChipsModule,
    FileUploadModule,
    DialogModule,
    ProgressBarModule,
    ProgressSpinnerModule,
    SkeletonModule,
  ],
})
export class PrimeNgModule { }
