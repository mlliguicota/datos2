import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roles-page',
  templateUrl: './roles-page.component.html',
  styleUrls: ['./roles-page.component.scss']
})
export class RolesPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
