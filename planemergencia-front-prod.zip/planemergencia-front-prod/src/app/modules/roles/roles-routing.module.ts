import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RolesPageComponent } from '../roles/pages/roles-page/roles-page.component';



const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'pageRoles',
        component: RolesPageComponent
      },
      {
        path: '**',
        redirectTo: 'roles/pageRoles'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RolesRoutingModule { }
