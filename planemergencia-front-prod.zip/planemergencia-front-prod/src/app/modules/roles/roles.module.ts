import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { PrimeNgModule } from '../prime-ng/prime-ng.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SharedModule } from 'src/app/shared/shared.module';

import { RolesPageComponent } from './pages/roles-page/roles-page.component';
import { RolesRoutingModule } from './roles-routing.module';
import { AdminRoutingModule } from '../admin/admin-routing.module';
import { SidebarModule } from 'primeng/sidebar';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { PrincipalModule } from 'src/app/principal/principal.module';
import { ToastModule } from 'primeng/toast';
import { HazardsModule } from '../plan-de-emergencia/plan-de-emergencia.module';
import { ConsultaModule } from '../consulta/consulta.module';
import { EditorModule } from 'primeng/editor';

@NgModule({
  declarations: [
    RolesPageComponent,
    
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    ReactiveFormsModule,
    PrimeNgModule,
    SidebarModule,
    ConfirmDialogModule,
    RolesRoutingModule,
    ToastModule,
    EditorModule,
    FormsModule,
    ConsultaModule,
    HazardsModule,
    SharedModule,
    FontAwesomeModule
  ]
})
export class rolesModule { }