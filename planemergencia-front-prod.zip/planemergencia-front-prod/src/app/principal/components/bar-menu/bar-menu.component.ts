import { Component, OnInit } from '@angular/core';
import { FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { fas } from '@fortawesome/free-solid-svg-icons';
import { far } from '@fortawesome/free-regular-svg-icons';

@Component({
  selector: 'app-bar-menu',
  templateUrl: './bar-menu.component.html',
  styleUrls: ['./bar-menu.component.scss']
})
export class BarMenuComponent implements OnInit {
  menuItems:Array<any>=[];
  constructor(library: FaIconLibrary) { 
    library.addIconPacks(fas,far); 
    this.menuItems=[
      {
        name:"Ubicación y poblacion trabajadora" 
      },
      {
        name: "Mantener contacto de emergencia"
      },
      {
        name: "Descripción de la empresa"
      },
      /*28/12/2023 - SUD-BC CAMBIOS EN TILDES*/
      {
        name: "Identificación de factores de riesgos propios de la organizacion"
      },
      {
        name: "Método Meseri"
      },
      {
        name: "Evaluaciónes prevención y control de factores de riesgos detectados"
      },
      {
        name: "Recursos existentes para la prevención, detección, protección y control de incendios"
      },
      {
        name:"Ubicación y población trabajadora"
      },
      {
        name: "Mantener contacto de emergencia"
      },
      {
        name: "Descripción de la empresa"
      },
      {
        name: "Identificación de factores de riesgos propios de la organización"
      },
      {
        name: "Método Meseri"
      },
      {
        name: "Evaluaciónes prevención y control de factores de riesgos detectados"
      },
      {
        name: "Recursos existentes para la prevención, detección, protección y control de incendios"
      },
      {
        name:"Ubicación y población trabajadora"
      },
      {
        name: "Mantener contacto de emergencia"
      },
      {
        name: "Descripción de la empresa"
      },
      {
        name: "Identificación de factores de riesgos propios de la organización"
      },
      {
        name: "Método Meseri"
      },
      {
        name: "Evaluaciónes prevencion y control de factores de riesgos detectados"
      },
      {
        name: "Recursos existentes para la prevención, detección, protección y control de incendios"
      }
    ]
   }

  ngOnInit(): void {
  }


  isOverflown(element: HTMLElement) {
    return element.scrollWidth > element.clientWidth;
  }

  scroll(element: HTMLElement, direction: number) {
    element.scrollLeft += 150 * direction;
  }

  canScrollStart(element: HTMLElement) {
    return element.scrollLeft > 0;
  }

  canScrollEnd(element: HTMLElement) {
    return element.scrollLeft + element.clientWidth != element.scrollWidth;
  }
  
}
