import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { fas } from '@fortawesome/free-solid-svg-icons';
import { far } from '@fortawesome/free-regular-svg-icons';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/core/services/auth.service';
import { IUsuario } from
  'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';
import Constantes from 'src/app/modules/plan-de-emergencia/core/util/constantes';

@Component({
  selector: 'app-header-bar',
  templateUrl: './header-bar.component.html',
  styleUrls: ['./header-bar.component.scss'],
})
export class HeaderBarComponent implements OnInit, OnChanges {
  @Input() usuario:IUsuario=Constantes.USUARIO_DEFAULT;
  esAdmin: boolean = false; // Propiedad para indicar si el usuario es administrador
  nombre: string='default';
  constructor(library: FaIconLibrary,
    private router: Router,
    private authService: AuthService) {
    library.addIconPacks(fas, far);
  }
  ngOnChanges(changes: SimpleChanges): void {
    this.ngOnInit();
  }
  cerrarSesion() {
    this.authService.logout();
    this.router.navigateByUrl('/auth/login');
  }

  ngOnInit(): void {
    this.nombre=this.usuario.usuario;
    // Llama a la función getRolUsuario() del servicio de autenticación para obtener el rol del usuario
    const rolUsuario = this.authService.getRolUsuario().nombre;

    // Verifica si el usuario tiene el rol de administrador
    this.esAdmin = (rolUsuario == 'Administrador');
  }
}
