import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/services/auth.service';
import { IUsuario } from
  'src/app/modules/plan-de-emergencia/core/interfaces/usuario.interface';
import Constantes from 'src/app/modules/plan-de-emergencia/core/util/constantes';
@Component({
  selector: 'app-principal-page',
  templateUrl: './principal-page.component.html',
  // styleUrls: ['./principal-page.component.scss'],
})
export class PrincipalPageComponent implements OnInit {
  usuario: IUsuario = Constantes.USUARIO_DEFAULT;
  constructor(private authService: AuthService) {
  }

  ngOnInit(): void {
    const user: string = sessionStorage.getItem('userData') + '';
    this.usuario = this.buildUserData(JSON.parse(user));
  }
  private buildUserData(user: any): IUsuario {
    const usuario: IUsuario = {
      id: user.codigo,
      usuario: user.usuario,
      codigoRol: user.codigoRol,
    };
    return usuario;
  }
}
