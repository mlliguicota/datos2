import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PrincipalPageComponent } from
  './pages/principal-page/principal-page.component';

const routes: Routes = [
  {
    path: '',
    component: PrincipalPageComponent,
    children: [
      {
        path: '',
        redirectTo: 'plan-de-emergencia',
      },
      {
        path: '**',
        redirectTo: 'dashboard',
      },
      {
        path: 'plan-de-emergencia',
        loadChildren: () =>import('../modules/plan-de-emergencia/plan-de-emergencia.module')
            .then((m) => m.HazardsModule),
      },
    ],
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PrincipalRoutingModule { }
