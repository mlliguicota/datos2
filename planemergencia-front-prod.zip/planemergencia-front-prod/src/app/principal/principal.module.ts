import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PrincipalRoutingModule } from './principal-routing.module';
import { PrincipalPageComponent } from './pages/principal-page/principal-page.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { PrimeNgModule } from '../modules/prime-ng/prime-ng.module';
import { HeaderBarComponent } from './components/header/header-bar.component';
import { BarMenuComponent } from './components/bar-menu/bar-menu.component';
import { HazardsModule } from '../modules/plan-de-emergencia/plan-de-emergencia.module';
import { SharedModule } from '../shared/shared.module';
@NgModule({
  declarations: [
    PrincipalPageComponent,
    HeaderBarComponent,
    BarMenuComponent,
  ],
  exports:[
    HeaderBarComponent
  ],
  imports: [
    CommonModule,
    PrincipalRoutingModule,
    FontAwesomeModule,
    PrimeNgModule,
    HazardsModule,
    SharedModule,
  ],
})
export class PrincipalModule { }
