import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrSpanComponent } from './err-span.component';

describe('ErrSpanComponent', () => {
  let component: ErrSpanComponent;
  let fixture: ComponentFixture<ErrSpanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ErrSpanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrSpanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
