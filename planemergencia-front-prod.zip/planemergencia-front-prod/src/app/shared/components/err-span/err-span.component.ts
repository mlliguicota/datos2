import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-err-span',
  templateUrl: './err-span.component.html',
  styleUrls: ['./err-span.component.scss'],
})
export class ErrSpanComponent implements OnInit {
  @Input('message') message: string = '';
  constructor() { }

  ngOnInit(): void {
  }
}
