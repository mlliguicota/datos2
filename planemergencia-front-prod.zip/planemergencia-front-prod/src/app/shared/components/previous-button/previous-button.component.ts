import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-previous-button',
  templateUrl: './previous-button.component.html',
  styleUrls: ['./previous-button.component.scss']
})
export class PreviousButtonComponent{
  @Output() newEvent = new EventEmitter<number>();
  clickEvent(){
    this.newEvent.emit();
  }

}
