import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrimeNgModule } from '../modules/prime-ng/prime-ng.module';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ErrSpanComponent } from './components/err-span/err-span.component';
import { NextButtonComponent } from './components/next-button/next-button.component';
import { PreviousButtonComponent } from './components/previous-button/previous-button.component';

@NgModule({
  declarations: [
    ErrSpanComponent,
    NextButtonComponent,
    PreviousButtonComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    PrimeNgModule,
    ReactiveFormsModule,
    FontAwesomeModule
  ],
  exports: [
    ErrSpanComponent,
    NextButtonComponent,
    PreviousButtonComponent,
  ]
})
export class SharedModule { }
