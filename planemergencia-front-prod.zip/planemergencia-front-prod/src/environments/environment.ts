/* eslint-disable max-len */
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.


export const environment = {
  production: false,
  BASE_URL_CPR: 'http://localhost:9720/cpr',
  //BASE_URL_GEN: 'http://www.sasfcloud.com:8000/age',
  BASE_URL_ARCHIVOS: 'http://localhost:9000',
  BASE_BUCKET_ARCHIVOS: 'bucketdesa',
  EXTERNAL_BASE_URL: 'http://localhost:8000',
  REMOTE_BASE_URL: 'http://localhost:8000',
  GENU_URL: '/pec/gen/genUsuarios',
  GENP_URL: '/pec/gen/genPermisos/rol',
  GENO_URL: '/pec/gen/genOficinas',
  GENN_URL: '/pec/eme/emeNivelesOficina',
  GENNV_URL: '/pec/eme/emeNivelesOficina/varios',
  GENR_URL: '/pec/gen/genRoles',
  AUTH_URL: '/pec/jwt/token/login',
  REFT_URL: '/pec/jwt/token/refresh',
  tokenStr: 'token',
  user: 'admin',
  pass: 'admin',
  loginUrl: 'http://localhost:4200/auth/login',

  //Jorge
  EMEC_URL:'/pec/eme/emeContactosEmergencia',
  EMEM_URL:'/pec/eme/emeMantenimientos',
  EMEI_URL:'/pec/eme/emeInstitucionesEmergencia',
  EMECO_URL:'/pec/eme/emeContactosOficina',
  GENTO_URL:'/pec/gen/genTiposOficina',
  GENOIO_URL: '/pec/gen/genOficinas/informacionOficinas',
  ESTIMA_RIES_URL:'/pec/eme/emeEstimacionesRiesgo',
  EME_METODO_INSHT_URL:'/pec/eme/emeMetodoInsht',
  EME_ARCHIVOS_URL:'/pec/eme/emeArchivosPlanes',
  GEN_INFO_TRABAJADORES:'/pec/gen/genUsuarios/informacionTrabajadores',
  GEN_LIDERES_PISO:'/pec/gen/genUsuarios/informacionLiderPiso',

  /** BASES URL DESA LOCAL */
 /*
  BASE_URL_EME: 'http://www.sasfcloud.com:8000',
  BASE_URL_PLA: 'http://www.sasfcloud.com:8000',
  BASE_URL_JWT: 'http://www.sasfcloud.com:8000',
  BASE_URL_GEN: 'http://www.sasfcloud.com:8000',
  BASE_URL_AUD: 'http://www.sasfcloud.com:8000',
 */
/*
  BASE_URL_EME: 'http://localhost:8993',
  BASE_URL_PLA: 'http://localhost:8994',
  BASE_URL_JWT: 'http://localhost:8991',
  BASE_URL_GEN: 'http://localhost:8992',
  BASE_URL_AUD: 'http://localhost:8995',
*/
  /** BASES URL PROD  */
/*
  BASE_URL_EME: 'http://www.sasfcloud.com:8000',
  BASE_URL_PLA: 'http://www.sasfcloud.com:8000',
  BASE_URL_JWT: 'http://www.sasfcloud.com:8000',
  BASE_URL_GEN: 'http://www.sasfcloud.com:8000',
  BASE_URL_AUD: 'http://www.sasfcloud.com:8000',  
  
  */

  /**BASES OPENSHIFT DESARROLLO  */
/*
  BASE_URL_EME: 'http://claro-eme-pec-eme.openshift-apps.dev.conecel.com',
  BASE_URL_PLA: 'http://claro-eme-pec-pla.openshift-apps.dev.conecel.com',
  BASE_URL_JWT: 'http://claro-eme-pec-jwt.openshift-apps.dev.conecel.com',
  BASE_URL_GEN: 'http://claro-eme-pec-gen.openshift-apps.dev.conecel.com',
  BASE_URL_AUD: 'http://claro-eme-pec-aud.openshift-apps.dev.conecel.com',

*/

  /**BASES OPENSHIFT PRODUCCION  */
 /*
  BASE_URL_EME: 'http://claro-eme-pec-eme.openshift-apps.conecel.com',
  BASE_URL_PLA: 'http://claro-eme-pec-pla.openshift-apps.conecel.com',
  BASE_URL_JWT: 'http://claro-eme-pec-jwt.openshift-apps.conecel.com',
  BASE_URL_GEN: 'http://claro-eme-pec-gen.openshift-apps.conecel.com',
  BASE_URL_AUD: 'http://claro-eme-pec-aud.openshift-apps.conecel.com',
*/

/**/

/*Version 4 opensift Desarrollo */
/*
BASE_URL_EME: 'http://claro-eme-pec-eme.router-default.apps.aro-dev.conecel.com',
BASE_URL_PLA: 'http://claro-eme-pec-pla.router-default.apps.aro-dev.conecel.com',
BASE_URL_JWT: 'http://claro-eme-pec-jwt.router-default.apps.aro-dev.conecel.com',
BASE_URL_GEN: 'http://claro-eme-pec-gen.router-default.apps.aro-dev.conecel.com',
BASE_URL_AUD: 'http://claro-eme-pec-aud.router-default.apps.aro-dev.conecel.com',
*/
/**/ 


/*Version 4 opensift Produccion */

BASE_URL_EME: 'http://claro-eme-pec-eme.router-default.apps.ocp-c2p.conecel.com',
BASE_URL_PLA: 'http://claro-eme-pec-pla.router-default.apps.ocp-c2p.conecel.com',
BASE_URL_JWT: 'http://claro-eme-pec-jwt.router-default.apps.ocp-c2p.conecel.com',
BASE_URL_GEN: 'http://claro-eme-pec-gen.router-default.apps.ocp-c2p.conecel.com',
BASE_URL_AUD: 'http://claro-eme-pec-aud.router-default.apps.ocp-c2p.conecel.com',




    /**  Kar**/
  EME_MESSERI_URL: '/pec/eme/emeMetodoMeseri',
  EME_RIESGOS_URL: '/pec/eme/emeRiesgos',
  EME_RIESGOS_OFICINAS_URL: '/pec/eme/emeRiesgosOficina',
  EME_RIESGOS_OFICINAS_URL_VARIOS: '/pec/eme/emeRiesgosOficina/varios',
  EME_MANTENIMIENTO_URL: '/pec/eme/emeMantenimientos',
  EME_MANTENIMIENTO_OFICINA_URL: '/pec/eme/emeMantenimientosOficina',
  EME_MANTENIMIENTO_OFICINA_URL_VARIOS: '/pec/eme/emeMantenimientosOficina/varios',
  EME_PLANEMERGENCIA_URL: '/pec/eme/emePlanesEmergencia',
  EME_RECURSOS_URL: '/pec/eme/emeRecursos',
  EME_RECURSOS_NIVELES_URL: '/pec/eme/emeRecursosNivel',
  EME_NIVELES_OFICINA_URL: '/pec/eme/emeNivelesOficina',
  EME_AREAS_OFICINA_URL: '/pec/eme/emeAreaOficinas',
  EME_CARACTERISTICAS_EDIFICIO_URL: '/pec/eme/emeCaracteristicasEdificio',
  EME_PARAMETROS_OFICINA_URL: '/pec/eme/emeParametrosOficina',
  EME_PLA_SECCIONES_URL: '/pec/pla/plaSecciones',
  EME_EVALUACION_CUANTITATIVA_URL: '/pec/eme/emeEvaluacionCuantitativa',
  EME_EVALUACION_TAXATIVA_URL: '/pec/eme/emeEvaluacionTaxativa',
  EME_RECURSO_NIVEL: '/pec/eme/emeRecursosNivel',
  EME_EQUIPO: '/pec/eme/emeEquipos',
  EME_EQUIPO_OFICINA: '/pec/eme/emeEquiposOficina',
  EME_PROBABILIDADES : '/pec/eme/emeProbabilidades' ,
  EME_CONSECUENCIAS : '/pec/eme/emeConsecuencias' ,
  EME_ESTIMACIONES_RIESGOS : '/pec/eme/emeEstimacionesRiesgo' ,
  EME_PELIGRO_PUNTO_ENCUENTRO : '/pec/eme/emePeligrosPuntoEncuentro' ,
  EME_RUTAS_EVACUACION : '/pec/eme/emeRutasEvacuacion' ,
  EME_RUTAS_NIVEL : '/pec/eme/emeRutasNivel',
  GEN_DESCARGA_ARCHIVO : '/pec/gen/genArchivos/descargarArchivo',
  GEN_SUBIR_ARCHIVO : '/pec/gen/genArchivos/subirArchivo',
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
