class ServerController {
  /*async index(req, res) {
    res.sendFile(process.cwd()+'/dist/clear-glass/index.html');
  }*/

  async liveness(req, res) {
    res.status(200).json({status: '200'});
  }

  async readiness(req, res) {
    res.status(200).json({status: '200'});
  }
}

module.exports = new ServerController();

