const {Router} = require('express');
const serverController = require('./../controller/server.controller');

class ServerRoutes {
  router = new Router();

  constructor() {
    this.config();
  }

  config() {
    //this.router.get('/', serverController.index);
    this.router.get('/health-check/readiness', serverController.readiness);
    this.router.get('/health-check/liveness', serverController.liveness);
  }
}

const serverRoutes = new ServerRoutes();
module.exports = serverRoutes.router;

