const express = require('express');
const morgan = require('morgan');
const bodyParser = require('body-parser');
const serverRouter = require('./routes/server.router');


class Server {
  app;

  constructor() {
    this.app = express();
    this.config();
    this.router();
  }

  config() {
    this.app.use(express.static(process.cwd()+'/dist/clear-glass/'));
    this.app.set('port', process.env.PORT || 4200);
    this.app.use(morgan('dev'));
    this.app.use(bodyParser.json());
    this.app.use(bodyParser.urlencoded({ extended: true }));
  }

  router() {
    this.app.use('/', serverRouter);
  }

  start() {
    this.app.listen(this.app.get('port'), () => {
      console.log('listening on port ' + this.app.get('port'));
    });
  }
}


const server = new Server();
server.start();
