const scanner = require('sonarqube-scanner');
const pass= 'Salvarado1';
scanner(
    {
    // serverUrl: 'http://localhost:9000',
      serverUrl: 'http://192.168.0.115:9002',
      token: 'a29c98d9a2d06f2ae81d4438164f1aa4dcfc7d54',
      options: {
        'sonar.projectName': 'claro-emergencia',
        'sonar.projectKey': 'claro-emergencia',
        'sonar.projectDescription': 'Description for "My App" project...',
        'sonar.sources': 'src/app',
        'sonar.projectVersion': '1.0',
        'sonar.login': 'admin',
        'sonar.password': pass,
        'sonar.tests': 'src/app',
        'sonar.test.inclusions': '**/*.spec.ts',
        'sonar.typescript.lcov.reportPaths': 'coverage/ngv/lcov.info',
        'sonar.javascript.node.maxspace': '4096',
      },
    },
    function() {
      return process.exit();
    },
);
